package com.opus.optimus.config.service.repository.recon;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.recon.ForceMatchHeaderDetails;

/**
 * The Interface ReconHeaderInfoRepository.
 */
@Repository
public interface ReconHeaderInfoRepository extends MongoRepository<ForceMatchHeaderDetails, String> {

	@Query (value = "{ $and : [ { 'projectName' : ?0 }, { 'sourceName' : ?1 }] }")
	ForceMatchHeaderDetails findByprojectNameandSourceName(String projectName, String sourceName);
}
