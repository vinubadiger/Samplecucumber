package com.opus.optimus.config.service.interceptor;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import com.opus.optimus.config.service.repository.ProfileRepository;
import com.opus.optimus.config.service.repository.RoleRepository;
import com.opus.optimus.config.service.repository.UserRolePermissionRepository;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.ui.services.user.ApiConfig;
import com.opus.optimus.ui.services.user.Profile;
import com.opus.optimus.ui.services.user.Role;

/**
 * The Class LoginInterceptor.
 */
@Component
public class LoginInterceptor implements HandlerInterceptor {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(LoginInterceptor.class);

	/** The Constant FORWARD_SLASH. */
	private static final String FORWARD_SLASH = "/";

	private static final String USER_NAME = "unique_name";
	private static final String ROLES = "roles";

	/** The user role perm repo. */
	@Autowired
	UserRolePermissionRepository userRolePermRepo;

	/** The profile repository. */
	@Autowired
	ProfileRepository profileRepository;

	/** The user repository. */
	@Autowired
	RoleRepository roleRepository;

	/** The context name. */
	@Value ("${server.servlet.context-path}")
	private String contextName;

	/*
	 * (non-Javadoc)
	 * @see org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	/**
	 * Checks if is permitted.
	 *
	 * @param actionName the action name
	 * @param methodRequired the method required
	 * @param roles the roles
	 * @return true, if is permitted
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		List<String> roles = null;
		try{
			String jwttoken = request.getHeader("Authorization");
			String requestUri = request.getRequestURI();
			log.debug("Request URL - {}", requestUri);
			String reqMethod = request.getMethod().toUpperCase();

			int endIndex = requestUri.indexOf(FORWARD_SLASH, contextName.length() + 1);
			String actionName = "";

			if (endIndex > 0){
				actionName = requestUri.substring(contextName.length() + 1, endIndex);
			}

			roles = (List<String>) getClaimsFromJwt(jwttoken).getClaim(ROLES);// Extracting "roles" claim from token
			if (roles.isEmpty()){
				log.error("No role found for the User");
				return false;
			}

			// Note : If a user configured in Azure logs in. If users role exists in Profile collection then we should create that user in User
			// collection.
			// If the role doesnt exist in Profile collection the user should not be created
			if (actionName.equalsIgnoreCase("SaveUser")){
				int found = 0;
				for (String role : roles){
					Role roleDbExists = roleRepository.findByRoleName(role);
					if (roleDbExists != null){
						found = 1;
						break;
					}

				}
				if (found == 1){
					return true;
				}
			}

			// Fetch the role for the logged in user to get his permissions on the basis of fetched role
			if (requestUri.contains("/GetLoggedinUserRole/")){
				return true;
			}

			boolean isPermission = false;
			for (String role : roles){
				isPermission = isPermitted(actionName, reqMethod, role);
				if (isPermission){
					break;
				}
			}

			if (isPermission){
				String username = (String) getClaimsFromJwt(jwttoken).getClaim(USER_NAME);// Extracting "unique_name" claim from token
				if (username == null || username.isEmpty()){
					log.error("User name is null or empty");
					return false;
				}
				// Set username in SecurityContext to access username in controller
				SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
				List<GrantedAuthority> grantedAuthorities = new ArrayList<>();

				for (String role : roles){
					GrantedAuthority authority = new SimpleGrantedAuthority(role);
					grantedAuthorities.add(authority);
				}
				securityContext.setAuthentication(new UsernamePasswordAuthenticationToken(username, "", grantedAuthorities));
				SecurityContextHolder.setContext(securityContext);
				return true;

			} else{
				response.setHeader("UNAUTHORIZED", "You are unauthorized to access the resource");
				response.setStatus(403);
				return false;
			}
		} catch (Exception e){
			log.error(e.getMessage(), e);
			if (roles == null){
				response.setHeader("INVALID_JWT_TOKEN", "Invalid JWT Token / You are unauthorized to access the resource");
			}
			return false;
		}
	}

	public boolean isPermitted(String actionName, String methodRequired, String roleName) {
		try{
			log.debug("Checking permission for Action - {} against Role - {}", actionName, roleName);
			Profile profile = profileRepository.getCurrentUserPermission(roleName);
			int count = 0;
			for (ApiConfig apiConfig : profile.getRestApiConfig()){
				if (apiConfig.getActionName().equals(actionName)){
					count++;
					if (count == 1){
						break;
					}
				}
			}

			return count > 0;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Parses the JWT.
	 *
	 * @param jwt the jwt
	 * @return the JWTClaimsSet
	 */
	private JWTClaimsSet getClaimsFromJwt(String jwt) {
		try{
			JWTClaimsSet claimsSet = JWTParser.parse(jwt).getJWTClaimsSet();
			claimsSet.getClaims().forEach((key, value) -> log.debug("JWT Claim (key) {} -> (Value) {}", key, value));
			return claimsSet;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}
