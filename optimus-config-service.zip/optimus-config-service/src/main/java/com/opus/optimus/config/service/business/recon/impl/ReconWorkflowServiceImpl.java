package com.opus.optimus.config.service.business.recon.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.config.service.business.IWorkflowService;
import com.opus.optimus.config.service.business.recon.IReconWorkflowService;
import com.opus.optimus.config.service.business.scheduler.BatchDefinitionService;
import com.opus.optimus.config.service.repository.UserRepository;
import com.opus.optimus.config.service.repository.etl.PublishedWorkflowRepository;
import com.opus.optimus.config.service.repository.recon.ActivityRepository;
import com.opus.optimus.config.service.repository.recon.ReconReasonNoteRepository;
import com.opus.optimus.config.service.util.UserContextUtility;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.subtypes.EtlSource;
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationConfig;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;
import com.opus.optimus.offline.runtime.workflow.api.impl.StepLink;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Workflow;
import com.opus.optimus.ui.services.recon.Activity;
import com.opus.optimus.ui.services.recon.ReasonNote;
import com.opus.optimus.ui.services.recon.ReconSourceFormHelper;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.StepInputData;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class ReconWorkflowServiceImpl.
 */
@Service
public class ReconWorkflowServiceImpl implements IReconWorkflowService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconWorkflowServiceImpl.class);

	/** The recon wf repo. */
	@Autowired
	private ActivityRepository activeRepository;

	/** The recon reasonnote repo. */
	@Autowired
	private ReconReasonNoteRepository reconReasonNoteRepo;

	/** The wf service. */
	@Autowired
	private IWorkflowService wfService;

	/** The published workflow repository. */
	@Autowired
	private PublishedWorkflowRepository publishedWorkflowRepository;

	/** The batch definition service. */
	@Autowired
	private BatchDefinitionService batchDefinitionService;

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;

	/** The Constant ACTIVITY_CREATED. */
	private static final String ACTIVITY_CREATED = "Recon configuration saved successfully";

	/** The Constant ACTIVITY_EXISTS. */
	private static final String ACTIVITY_EXISTS = "Activity already exists";

	/** The Constant ACTIVITY_NOT_EXISTS. */
	private static final String ACTIVITY_NOT_EXISTS = "Activity not exists";

	/** The Constant ACTIVITY_DELETED. */
	private static final String ACTIVITY_DELETED = "Activity deleted";

	private static final String DATA_INGESTION_DATE = "di_processing_date";

	/** The UserContextUtility repository. */
	@Autowired
	UserContextUtility userContextUtility;

	@Override
	public ServiceResponse save(Activity activity) throws Exception {

		validateActivity(activity);

		logger.debug("Saving Activity..");

		try{
			Activity activityFromDb = activeRepository.get(activity.getName(), activity.getWorkflowType());
			if (activityFromDb != null){
				logger.debug("Existing Activity found.");

				if (activity.getId() == null){
					return new ServiceResponse(500, ResponseStatus.FAILED, ACTIVITY_EXISTS, activity.getName());
				}
			}
			Activity dbActivity = activeRepository.save(activity);
			logger.debug("Activity Saved with id {}. Publishing the Activity into Published Service", dbActivity.getId());
			PublishedService publishWokflow = savePublishedService(activity);
			logger.debug("Activity Published");

			logger.debug("Updating Activity's batch definition..");
			BatchDefinition batchDefinition = updateSaveBatchDefinition(activity, publishWokflow);
			logger.debug("Activity's batch definition updated with ID {}!", batchDefinition.getId());
			return new ServiceResponse(200, ResponseStatus.SUCCESS, ACTIVITY_CREATED, activity.getName());
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Validate activity.
	 *
	 * @param activity the activity
	 * @throws Exception the exception
	 */
	private void validateActivity(Activity activity) {
		try {
		List<String> validSourceNames = Arrays.asList("Source-A", "Source-B");
		for (MongoDBReaderConfig dbrstps : activity.getDbReaderSteps()){
			if (!validSourceNames.contains(dbrstps.getStepName())){
				throw new GenericException("Sources must be tagged as either Source-A or Source-B");
			}
		}
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Update save batch definition.
	 *
	 * @param activity the activity
	 * @param publishWokflow the publish wokflow
	 * @return the batch definition
	 */
	private BatchDefinition updateSaveBatchDefinition(Activity activity, PublishedService publishWokflow) {
		try{
			BatchDefinition batchDefinition = batchDefinitionService.getBatchDefinition(activity.getProjectName(), activity.getName(), activity.getWorkflowType());
			if (batchDefinition == null){
				batchDefinition = new BatchDefinition();
				batchDefinition.setProjectName(activity.getProjectName());
				batchDefinition.setWorkflowName(activity.getName());
				batchDefinition.setWorkflowType(activity.getWorkflowType());
				batchDefinition.setDescription(activity.getDescription());
				batchDefinition.setStepInputs(new HashMap<String, List<String>>());
			}

			WorkflowConfig workflowConfig = publishWokflow.getWorkflowConfig();
			logger.debug("Setting Step Inputs data for Recon-workflow in Batch");
			if (workflowConfig.getStepConfigs() != null){
				List<StepInputData> stepInputData = Optional.ofNullable(batchDefinition.getStepInputData()).orElse(new ArrayList<>());
				workflowConfig.getStepConfigs().forEach(stepConfig -> {
					switch (stepConfig.getStepType()) {
					case StepTypeConstants.MONGO_DBREADER_STEP_TYPE:
						break;
					case StepTypeConstants.RECON_CONFIG_STEP:
						break;
					default:
						break;
					}
				});
				batchDefinition.setStepInputData(stepInputData);
			}
			batchDefinition.setGroupId(publishWokflow.getId());
			batchDefinition.setWorkflowId(activity.getId());
			return batchDefinitionService.saveBatchDefinition(batchDefinition);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Save published service.
	 *
	 * @param activity the activity
	 * @return the published service
	 */
	private PublishedService savePublishedService(Activity activity) {
		try{
			PublishedService publishWokflow = publishedWorkflowRepository.get(activity.getProjectName(), activity.getName(), activity.getWorkflowType());
			if (publishWokflow == null){
				publishWokflow = new PublishedService();
				publishWokflow.setProjectName(activity.getProjectName());
				publishWokflow.setWorkflowName(activity.getName());
				publishWokflow.setWorkflowType(activity.getWorkflowType());
			}
			publishWokflow.setWorkflowConfig(populateReconWorkflowConfig(activity));

			String publishWokflowId = publishedWorkflowRepository.save(publishWokflow).getId();
			if (null == publishWokflowId){
				publishWokflow = publishedWorkflowRepository.get(activity.getProjectName(), activity.getName(), activity.getWorkflowType());
			}
			return publishWokflow;
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Populate recon workflow config.
	 *
	 * @param activity the activity
	 * @return the workflow config
	 */
	private WorkflowConfig populateReconWorkflowConfig(Activity activity) {
		try{
			if (null == activity.getDbReaderSteps() || activity.getDbReaderSteps().isEmpty()){
				return null;
			}
			logger.debug("Linking StepConfigs from Activity");
			List<IStepLink> stepLinks = new ArrayList<>();
			String reconConfigStepName = activity.getReconStepConfig().getStepName();
			activity.getDbReaderSteps().forEach(dbrstp -> {
				StepLink stepLink = new StepLink(dbrstp.getStepName(), reconConfigStepName);
				stepLink.setName(UUID.randomUUID().toString());
				stepLink.setType("link");
				stepLinks.add(stepLink);

				dbrstp.getSourceDefinition().setActivityName(activity.getName());
			});
			StepLink stepLink = new StepLink(reconConfigStepName, activity.getReconStatusUpdateConfig().getStepName());
			stepLink.setName(UUID.randomUUID().toString());
			stepLinks.add(stepLink);
			stepLink.setType("link");
			logger.debug("StepConfigs are set & StepLinks configured");

			logger.debug("Setting StepConfigs from Activity");
			List<IStepConfig> stepConfigs = new ArrayList<>();
			stepConfigs.addAll(activity.getDbReaderSteps());

			EtlSource sourceDefinition = null;
			MongoDBReaderConfig mongoDbStep;
			Optional<IStepConfig> step = stepConfigs.stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getStepName().equals("Source-A")).findAny();
			if (step.isPresent()){
				mongoDbStep = (MongoDBReaderConfig) step.get();
				sourceDefinition = mongoDbStep.getSourceDefinition();
				stepConfigs.remove(step.get());

				List<MongoDBFieldConfig> reconFieldConfig = activity.getSourceAFields();
				reconFieldConfig.add(getDataIngestionFieldConfig());
				activity.setSourceAFields(reconFieldConfig);
				sourceDefinition.setFieldConfigs(activity.getSourceAFields());

				mongoDbStep.setSourceDefinition(sourceDefinition);
				stepConfigs.add(mongoDbStep);
			}

			step = stepConfigs.stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getStepName().equals("Source-B")).findAny();

			if (step.isPresent()){
				mongoDbStep = (MongoDBReaderConfig) step.get();
				sourceDefinition = mongoDbStep.getSourceDefinition();
				stepConfigs.remove(step.get());

				List<MongoDBFieldConfig> reconFieldConfig = activity.getSourceBFields();
				reconFieldConfig.add(getDataIngestionFieldConfig());
				activity.setSourceBFields(reconFieldConfig);
				sourceDefinition.setFieldConfigs(activity.getSourceBFields());

				mongoDbStep.setSourceDefinition(sourceDefinition);
				stepConfigs.add(mongoDbStep);
			}
			ReconciliationConfig reconStep = activity.getReconStepConfig();
			reconStep.setSourceMapping(activity.getSourceMapping());
			reconStep.setActivityName(activity.getName());
			reconStep.setReconType(activity.getReconType());
			stepConfigs.add(reconStep);
			activity.getReconStatusUpdateConfig().setActivityName(activity.getName());
			activity.getReconStatusUpdateConfig().setUnreconciledBacklog(activity.isUnreconciledBacklog());
			activity.getReconStatusUpdateConfig().setTimeLegInterval(activity.getTimeLegInterval());
			activity.getReconStatusUpdateConfig().setUnit(activity.getUnit());
			activity.getReconStatusUpdateConfig().setCaseCreationThreshold(activity.getCaseCreationThreshold());
			stepConfigs.add(activity.getReconStatusUpdateConfig());

			return WorkflowConfig.builder().name(activity.getName()).stepConfigs(stepConfigs).stepLinks(stepLinks).build();
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	private MongoDBFieldConfig getDataIngestionFieldConfig() {
		MongoDBFieldConfig dataIngestionDateField = new MongoDBFieldConfig();
		dataIngestionDateField.setFieldIndex((short) 0);
		dataIngestionDateField.setImplicitDecimal(false);
		dataIngestionDateField.setMaxSize(0);
		dataIngestionDateField.setName(DATA_INGESTION_DATE);
		dataIngestionDateField.setNoOfDecimals((short) 0);
		dataIngestionDateField.setPrimaryField(false);
		dataIngestionDateField.setSourceDataType(FieldType.DATETIME);
		dataIngestionDateField.setSourceFieldName(DATA_INGESTION_DATE);
		dataIngestionDateField.setTargetDataType(FieldType.DATETIME);
		dataIngestionDateField.setTargetFieldName(DATA_INGESTION_DATE);
		return dataIngestionDateField;

	}

	@Override
	public Activity get(String projectName, String workflowName, String workflowType) {
		try{
			return activeRepository.findReconSource(projectName, workflowName, workflowType);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * populate Recon Source Details.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the recon source form helper
	 */
	@Override
	public ReconSourceFormHelper getReconSourceFormHelper(String projectName, String workflowName, String workflowType) {
		try{
			Workflow workflow = wfService.get(projectName, workflowName, workflowType);
			ReconSourceFormHelper reconSourceFormHelper = new ReconSourceFormHelper();
			if (workflow != null){
				List<EtlSource> etlSources = new ArrayList<>();
				populateDbInformation(workflow, etlSources);
				reconSourceFormHelper.setSources(etlSources);
			}
			return reconSourceFormHelper;
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Populate db information.
	 *
	 * @param workflow the workflow
	 * @param etlSources the etl sources
	 */
	private void populateDbInformation(Workflow workflow, List<EtlSource> etlSources) {
		try{
			if (null == workflow.getStepConfigs() || workflow.getStepConfigs().isEmpty()){
				return;
			}
			workflow.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGODB_WRITER_STEPTYPE)).collect(Collectors.toList()).forEach(stepConfig2 -> {
				MongoDBWriterConfig mongoDbstepConfig = (MongoDBWriterConfig) stepConfig2;
				EtlSource etlSource = new EtlSource();
				etlSource.setSourceName(workflow.getWorkflowName());
				etlSource.setSourceName(workflow.getWorkflowName());
				etlSource.setDataSourceName(mongoDbstepConfig.getDataSourceName());
				etlSource.setCollectionName(mongoDbstepConfig.getCollectionName());
				etlSource.setFieldConfigs(mongoDbstepConfig.getFieldConfigs());
				etlSource.getFieldConfigs().add(getDataIngestionFieldConfig());
				etlSources.add(etlSource);
			});
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Get All Recon Activity of a Project.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the all
	 */
	@Override
	public List<Activity> getAll(String projectName, String workflowType) {
		try{
			return activeRepository.getAll(projectName, workflowType);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public List<Activity> getActivity() {
		try{
			User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());

			if (userContextUtility.checkIfAdminUser()){
				return activeRepository.getActivity();
			} else{
				return activeRepository.findActivitiesByProjectNames(user.getProjects());
			}
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * @param projectName the project name
	 * @param activityName the recon activity name
	 * @param workflowType the workflow type
	 * @return serviceResponse
	 */
	@Override
	public ServiceResponse delete(String projectName, String activityName, String workflowType) {
		try{
			Activity activityDb = get(projectName, activityName, workflowType);
			if (activityDb != null){
				ServiceResponse responseBatchdefinition = this.batchDefinitionService.delete(projectName, activityName, workflowType);
				if (responseBatchdefinition.getStatus().equals(ResponseStatus.FAILED)){

					return new ServiceResponse(500, ResponseStatus.FAILED, responseBatchdefinition.getMsg(), activityName);
				} else{
					this.activeRepository.delete(activityDb);
					return new ServiceResponse(200, ResponseStatus.SUCCESS, ACTIVITY_DELETED, activityName);
				}
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, ACTIVITY_NOT_EXISTS, activityName);
			}
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Get all ReasonNote
	 * 
	 * @return serviceResponse
	 */
	@Override
	public List<ReasonNote> getReasonNotes() {
		return reconReasonNoteRepo.findAll();
	}
}
