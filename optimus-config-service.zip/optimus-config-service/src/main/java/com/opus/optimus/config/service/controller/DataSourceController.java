package com.opus.optimus.config.service.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.config.service.business.IDataSourceService;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class DataSourceController exposes api related to .
 */
@RestController
@Api (value = "/settings/datasource", description = "REST Apis related to datasource!!!")
@RequestMapping ("{actionName}/settings/datasource")
public class DataSourceController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(DataSourceController.class);

	/** The data source service. */
	@Autowired
	private IDataSourceService dataSourceService;

	/**
	 * Save.
	 *
	 * @param dataSource the data source
	 * @return the service response
	 */
	@ApiOperation (value = "datasource ", response = MongoDataSourceMeta.class, tags = "datasource [Save]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping
	public ServiceResponse save(@RequestBody MongoDataSourceMeta dataSource) {

		logger.debug("Saving data source -- {}", dataSource.getDataSourceName());
		return this.dataSourceService.save(dataSource);

	}

	/**
	 * Gets the.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the mongo data source meta
	 */
	@ApiOperation (value = "Get datasource,databaseType ", response = MongoDataSourceMeta.class, tags = "datasourcedatabaseType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{dataSourceName}/{databaseType}")
	public MongoDataSourceMeta get(@PathVariable ("dataSourceName") String dataSourceName, @PathVariable ("databaseType") String databaseType) {

		logger.debug("Get datasource --{}", dataSourceName);
		return this.dataSourceService.get(dataSourceName, databaseType);

	}

	/**
	 * Delete.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the service response
	 */
	@ApiOperation (value = "dataSourceName ", response = String.class, tags = "dataSourceName[Delete]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Deleted"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@DeleteMapping (value = "/{dataSourceName}/{databaseType}")
	public ServiceResponse delete(@PathVariable ("dataSourceName") String dataSourceName, @PathVariable ("databaseType") String databaseType) {

		logger.debug("Delete datasource -- {}", dataSourceName);
		return this.dataSourceService.delete(dataSourceName, databaseType);

	}

	/**
	 * Update.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @param dataSource the data source
	 * @return the service response
	 */
	@ApiOperation (value = "dataSourceName ", response = String.class, tags = "dataSourceName[Update]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Updated"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PutMapping (value = "/{dataSourceName}/{databaseType}")
	public ServiceResponse update(@PathVariable ("dataSourceName") String dataSourceName, @PathVariable ("databaseType") String databaseType, @RequestBody MongoDataSourceMeta dataSource) {
		logger.debug("Update datasource -- {}", dataSourceName);

		return this.dataSourceService.update(dataSourceName, databaseType, dataSource);

	}

	/**
	 * Gets the data sources.
	 *
	 * @param databaseType the database type
	 * @return the data sources
	 */
	@ApiOperation (value = "getDataSources ", response = MongoDataSourceMeta.class, tags = "getDataSources using databaseType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "getDataSources/{databaseType}")
	public List<MongoDataSourceMeta> getDataSources(@PathVariable ("databaseType") String databaseType) {
		logger.debug("Get DataSources of database type -- {}", databaseType);

		return this.dataSourceService.getDataSources(databaseType);

	}

	/**
	 * Gets the collections.
	 *
	 * @param databaseType the database type
	 * @param dataSourceName the data source name
	 * @return the collections
	 */
	@ApiOperation (value = "getCollections ", response = MongoDataSourceMeta.class, tags = "getCollections")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "getCollections/{databaseType}/{dataSourceName}")
	public List<MongoDataSourceMeta> getCollections(@PathVariable ("databaseType") String databaseType, @PathVariable ("dataSourceName") String dataSourceName) {
		logger.debug(" Get Collections of datasource -- {}", dataSourceName);

		return this.dataSourceService.getCollections(dataSourceName, databaseType);

	}

	/**
	 * Gets the all data source details.
	 *
	 * @return the all data source details
	 */
	@ApiOperation (value = "GetAllDataSourceDetails ", response = MongoDataSourceMeta.class, tags = "GetAllDataSourceDetails")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "getAllDataSourceDetails")
	public List<MongoDataSourceMeta> getAllDataSourceDetails() {

		logger.debug("Get All DataSource Details");
		return this.dataSourceService.getAllDataSourceDetails();

	}

	/**
	 * Gets the mongo conn test.
	 *
	 * @param dataSource the data source
	 * @return the mongo conn test
	 */
	@PostMapping (value = "/dbTest")
	public Map<String, Boolean> getConnTest(@RequestBody MongoDataSourceMeta dataSource) {

		return this.dataSourceService.checkDataBaseConnection(dataSource);

	}

	/**
	 * Retrieve the column names from the Oracle DB table
	 * 
	 * @param dataSource
	 * @param databaseType
	 * @param collectionName
	 * @return
	 */
	@GetMapping (value = "tablemetadata/{dataSource}/{databaseType}/{collectionName}")
	public ServiceResponse getTableFields(@PathVariable ("dataSource") String dataSource, @PathVariable ("databaseType") String databaseType, @PathVariable ("collectionName") String collectionName) {
		logger.debug("inside getTableFields() dataSource : {},databaseType : {}, collectionName : {}", dataSource, databaseType, collectionName);
		if (databaseType.equals("Oracle_DB")){
			return this.dataSourceService.getTableFields(dataSource, databaseType, collectionName);
		}
		else{
			return new ServiceResponse(500, ResponseStatus.FAILED, "Currently we are supporting only Oracle Database...", null);
		}

	}
}
