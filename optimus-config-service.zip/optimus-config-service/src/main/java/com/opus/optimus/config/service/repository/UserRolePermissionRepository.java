package com.opus.optimus.config.service.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.user.UserRolePermission;

/**
 * The Interface UserRolePermissionRepository.
 */
@Repository
public interface UserRolePermissionRepository extends MongoRepository<UserRolePermission, String> {

	/**
	 * Find permission details.
	 *
	 * @param apiUrl the api url
	 * @param methodRequired the method required
	 * @param roles the roles
	 * @return the user role permission
	 */
	@Query (value = "{ $and : [ { 'apiUrl' : ?0 }, { 'methodRequired' : ?1 },{'roles' : ?2} ] }")
	UserRolePermission findPermissionDetails(String apiUrl, String methodRequired, String roles);
}
