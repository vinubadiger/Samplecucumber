package com.opus.optimus.config.service.business.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.MongoSecurityException;
import com.mongodb.MongoSocketOpenException;
import com.mongodb.MongoTimeoutException;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.config.service.business.IDataSourceService;
import com.opus.optimus.config.service.repository.etl.DataSourceRepository;
import com.opus.optimus.config.service.util.DBUtil;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.config.datasource.ServerAddressMetadata;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.field.impl.DBFieldConfig;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;

/**
 * The Class DataSourceServiceImpl.
 */
/**
 * @author Bhushan.Shinde
 */
@Service
public class DataSourceServiceImpl implements IDataSourceService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(DataSourceServiceImpl.class);

	/** The data source repository. */
	@Autowired
	private DataSourceRepository dataSourceRepository;

	/** The Constant DATASOURCE_DELETED. */
	private static final String DATASOURCE_DELETED = "Datasource deleted";

	/** The Constant DATASOURCE_CREATED. */
	private static final String DATASOURCE_CREATED = "Datasource saved successfully";

	/** The Constant DATASOURCE_UPDATED. */
	private static final String DATASOURCE_UPDATED = "Datasource updated successfully";

	/** The Constant DATASOURCE_NOT_EXISTS. */
	private static final String DATASOURCE_NOT_EXISTS = "Datasource not exists";

	/** The Constant ACTIVITY_EXISTS. */
	private static final String DATASOURCE_EXISTS = "Datasource already exists";

	/** The Constant JDBC_ORACLE_DRIVER. */
	private static final String JDBC_ORACLE_DRIVER = "jdbc:oracle:thin:@";

	/** The Constant COLON. */
	private static final String COLON = ":";

	/**
	 * Save the MongoDataSourceMeta.
	 *
	 * @param dataSource the data source
	 * @return the service response
	 */
	@Override
	public ServiceResponse save(MongoDataSourceMeta dataSource) {
		try{
			// validate the data source for valid connection details.
			validateDataSource(dataSource);
			MongoDataSourceMeta mongoDataSourceMetaDb = get(dataSource.getDataSourceName(), dataSource.getDatabaseType());
			if (mongoDataSourceMetaDb != null && dataSource.getId() != null){
				dataSource.setId(mongoDataSourceMetaDb.getId());
				MongoDataSourceMeta updatedDocument = this.dataSourceRepository.save(dataSource);
				log.info("Data Source updated successfully. ID: {}", updatedDocument.getId());
				// update the offline datasource factory
				// restClient.updateOfflineMongoDataSourceFactory(dataSource);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_UPDATED, dataSource);
			} else if (dataSource.getId() == null && mongoDataSourceMetaDb != null){
				return new ServiceResponse(400, ResponseStatus.FAILED, DATASOURCE_EXISTS, dataSource);
			} else{
				final MongoDataSourceMeta insertedDocument = this.dataSourceRepository.save(dataSource);
				log.info("Data Source created successfully. ID: {}", insertedDocument.getId());
				// update the offline datasource factory
				// restClient.updateOfflineMongoDataSourceFactory(dataSource);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_CREATED, dataSource);
			}
		} catch (IllegalArgumentException e){
			return new ServiceResponse(422, ResponseStatus.FAILED, "Host list can not be empty.", dataSource);
		} catch (MongoSecurityException e){
			return new ServiceResponse(401, ResponseStatus.FAILED, "Unable to authenticate with provided configuration.", dataSource);
		} catch (GenericException e){
			return new ServiceResponse(408, ResponseStatus.FAILED, "Timed out while connecting to Host/s.", dataSource);
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Validate data source.
	 *
	 * @param dataSourceMeta the data source meta
	 */
	private void validateDataSource(MongoDataSourceMeta dataSourceMeta) {
		if (dataSourceMeta.getDatabaseType().equals("Mongo_DB")){
			final MongoDataSource dataSource = new MongoDataSource(dataSourceMeta);
			dataSource.init();
			try{
				dataSource.getDatabase().getCollection(dataSourceMeta.getCollections().get(0)).countDocuments();
			} catch (MongoSocketOpenException | MongoTimeoutException | DataSourceInitializationException exception){
				throw new GenericException("Timed out while connecting Host/s.", exception);
			}
		} else if (dataSourceMeta.getDatabaseType().equals("Oracle_DB")){
			getOracleConnTest(dataSourceMeta);
		} else{
			throw new GenericException("Database type not supported");
		}

	}

	/**
	 * Gets the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the mongo data source meta
	 */
	@Override
	public MongoDataSourceMeta get(String dataSourceName, String databaseType) {
		try{
			return this.dataSourceRepository.findByDataSource(dataSourceName, databaseType);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Delete the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the service response
	 */
	@Override
	public ServiceResponse delete(String dataSourceName, String databaseType) {
		try{
			MongoDataSourceMeta mongoDataSourceMeta = this.dataSourceRepository.findByDataSource(dataSourceName, databaseType);
			if (mongoDataSourceMeta != null){
				this.dataSourceRepository.delete(mongoDataSourceMeta);
				// restClient.removeOfflineMongoDataSourceFactory(mongoDataSourceMeta);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_DELETED, dataSourceName);
			} else{
				log.debug(DATASOURCE_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, DATASOURCE_NOT_EXISTS, dataSourceName);
			}
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Update the Datasource.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @param mongoDataSourceMeta the mongo data source meta
	 * @return the service response
	 */
	@Override
	public ServiceResponse update(String dataSourceName, String databaseType, MongoDataSourceMeta mongoDataSourceMeta) {
		try{
			MongoDataSourceMeta mongoDataSrcDb = get(dataSourceName, databaseType);

			if (mongoDataSrcDb != null){
				mongoDataSourceMeta.setId(mongoDataSrcDb.getId());
				save(mongoDataSourceMeta);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, DATASOURCE_UPDATED, dataSourceName);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, DATASOURCE_NOT_EXISTS, dataSourceName);
			}
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the data sources.
	 *
	 * @param databaseType the database type
	 * @return the data sources
	 */
	@Override
	public List<MongoDataSourceMeta> getDataSources(String databaseType) {
		try{
			return this.dataSourceRepository.findBydatabaseTypeLike(databaseType);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the collections.
	 *
	 * @param dataSourceName the data source name
	 * @param databaseType the database type
	 * @return the collections
	 */
	@Override
	public List<MongoDataSourceMeta> getCollections(String dataSourceName, String databaseType) {
		try{
			return this.dataSourceRepository.findBydatabaseTypeLike(databaseType, dataSourceName);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the all data source details.
	 *
	 * @return the all data source details
	 */
	@Override
	public List<MongoDataSourceMeta> getAllDataSourceDetails() {
		try{
			return this.dataSourceRepository.findAll();
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the mongo conn test.
	 *
	 * @param dataSource the data source
	 * @return the mongo conn test
	 */
	@Override
	public Map<String, Boolean> getMongoConnTest(MongoDataSourceMeta dataSource) {
		try{
			Map<String, Boolean> results = new HashMap<>();
			List<ServerAddressMetadata> serverAddressMetadata = dataSource.getAddressMetadatas();
			for (ServerAddressMetadata object : serverAddressMetadata){
				checkMongoConnection(dataSource, object, results);
			}
			return results;
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the oracle conn test.
	 *
	 * @param dataSource the data source
	 * @return the oracle conn test
	 */
	@Override
	public Map<String, Boolean> getOracleConnTest(MongoDataSourceMeta dataSource) {
		try{
			Map<String, Boolean> results = new HashMap<>();
			List<ServerAddressMetadata> serverAddressMetadata = dataSource.getAddressMetadatas();
			for (ServerAddressMetadata object : serverAddressMetadata){
				String connectionUrl = new StringBuilder(JDBC_ORACLE_DRIVER).append(object.getIpAddress()).append(COLON).append(object.getPort()).append(COLON).append(dataSource.getServiceName()).toString();
				checkOracleConnection(connectionUrl, dataSource, object, results);
			}
			return results;
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Check the oracle connection.
	 *
	 * @param connectionUrl the connection url
	 * @param dataSource the data source
	 * @param object the object
	 * @param results the results
	 * @return the oracle conn test
	 */
	private void checkOracleConnection(String connectionUrl, MongoDataSourceMeta dataSource, ServerAddressMetadata object, Map<String, Boolean> results) {
		if (dataSource.isAuthenticationRequired()){
			try (Connection conn = DriverManager.getConnection(connectionUrl, dataSource.getAuthMetaData().getUserName(), dataSource.getAuthMetaData().getPassword())){
				results.put(object.getIpAddress(), true);
			} catch (Exception e){
				results.put(object.getIpAddress(), false);
			}
		} else{
			results.put(object.getIpAddress(), false);
		}
	}

	/**
	 * Check the mongo connection.
	 *
	 * @param dataSource the data source
	 * @param object the object
	 * @param results the results
	 * @return the mongo conn test
	 */
	private void checkMongoConnection(MongoDataSourceMeta dataSource, ServerAddressMetadata object, Map<String, Boolean> results) {
		if (dataSource.isAuthenticationRequired()){
			try{
				ServerAddress seeds = new ServerAddress(object.getIpAddress(), object.getPort());
				MongoCredential credential = MongoCredential.createCredential(dataSource.getAuthMetaData().getUserName(), dataSource.getDatabaseName(), dataSource.getAuthMetaData().getPassword().toCharArray());
				MongoClientOptions options = MongoClientOptions.builder().build();
				try (MongoClient mongoClient = new MongoClient(seeds, credential, options)){
					MongoDatabase db = mongoClient.getDatabase(dataSource.getDatabaseName());
					log.debug("Connection to DB {} successfull. Collection in the DB are as follows-", object.getIpAddress());
					db.listCollectionNames().iterator().forEachRemaining(collection -> log.debug(collection));
					results.put(object.getIpAddress(), true);
				}
			} catch (Exception e){
				log.error(e.getMessage(), e);
				results.put(object.getIpAddress(), false);
			}
		} else{
			results.put(object.getIpAddress(), false);
		}
	}

	
	@Override
	public ServiceResponse getTableFields(@PathVariable ("dataSource") String dataSource, @PathVariable ("databaseType") String databaseType, @PathVariable ("collectionName") String collectionName) {

		log.debug("inside DataSourceServiceImpl ");
		MongoDataSourceMeta mongoDataSourceMetaDb = get(dataSource, databaseType);

		log.debug("inside DataSourceServiceImpl  mongoDataSourceMetaDb : {}", mongoDataSourceMetaDb);

		List<DBFieldConfig> dbFieldConfigList = new ArrayList<>();

		String sql = "SELECT ROW_NUMBER() OVER (ORDER BY COLUMN_NAME)-1 as ROW_INDEX, COLUMN_NAME, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE FROM all_tab_cols WHERE table_name = '" + collectionName.toUpperCase() + "' ORDER BY COLUMN_NAME";
		log.debug("Total columns sql : {} ", sql);

		boolean tableFound = false;

		try (Connection conn = DBUtil.getOracleConnection(mongoDataSourceMetaDb); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()){

			int columnCount = 0;
			while (rs.next()){
				tableFound = true;
				columnCount++;
				DBFieldConfig dbFieldConfig = new DBFieldConfig();
				dbFieldConfig.setFieldIndex(rs.getShort("ROW_INDEX"));
				dbFieldConfig.setName(rs.getString("COLUMN_NAME"));
				dbFieldConfig.setMaxSize(rs.getInt("DATA_LENGTH"));

				FieldType fieldType = mapDataTypes(OracleDataTypeEnum.valueOf(rs.getString("DATA_TYPE")), rs.getInt("DATA_SCALE"), rs.getInt("DATA_PRECISION"));

				dbFieldConfig.setType(fieldType);

				dbFieldConfigList.add(dbFieldConfig);
			}

			log.debug("Total columns  in : {},{} ", collectionName, columnCount);

			if (!tableFound){
				return new ServiceResponse(500, ResponseStatus.FAILED, "Table/Collection does not exist...", dbFieldConfigList);
			}

		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			log.error(e.getMessage(), e);
		}
		return new ServiceResponse(200, ResponseStatus.SUCCESS, "Fields Fetched", dbFieldConfigList);

	}

	/**
	 * Map data types.
	 *
	 * @param oracleDataTypeEnum the oracle data type enum
	 * @param scale the scale
	 * @param precision the precision
	 * @return the field type
	 */
	public FieldType mapDataTypes(OracleDataTypeEnum oracleDataTypeEnum, int scale, int precision) {
		FieldType fieldType = null;
		switch (oracleDataTypeEnum) {
		case VARCHAR:
			fieldType = FieldType.STRING;
			break;
		case VARCHAR2:
			fieldType = FieldType.STRING;
			break;
		case CHAR:
			fieldType = FieldType.STRING;
			break;
		case DATE:
			fieldType = FieldType.DATETIME;
			break;
		case NUMBER:
			if (scale == 0)
				fieldType = FieldType.INT;
			else if (scale > 0 && precision > 0) fieldType = FieldType.DOUBLE;
			break;
		default:
			log.debug("Data Type not found...");
		}

		return fieldType;
	}

	@Override
	public Map<String, Boolean> checkDataBaseConnection(MongoDataSourceMeta dataSource) {
			if (dataSource.getDatabaseType().equals("Oracle_DB")){
				log.debug("Entered in getOracleConnTest");
				return getOracleConnTest(dataSource);
			} else if (dataSource.getDatabaseType().equals("Mongo_DB")){
				log.debug("Entered in getMongoConnTest");
				return getMongoConnTest(dataSource);
			} else{
				return null;
			}
		}
	}

