package com.opus.optimus.config.service.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.config.service.business.IWorkflowService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Workflow;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class WorkflowController exposes api related to Workflow.
 */
@RestController
@Api (value = "/workflows")
@RequestMapping ("{actionName}/workflows")
public class WorkflowController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(WorkflowController.class);

	/** The Constant WORKFLOW_EXISTS. */
	private static final String WORKFLOW_EXISTS = "Workflow exists";

	/** The workflow service. */
	@Autowired
	private IWorkflowService workflowService;

	/**
	 * Gets the.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name,workflowname,workflowType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{projectname}/{workflowname}/{workflowType}")
	public Workflow get(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType) {
		logger.debug("Get {} worklow -- {} of project -- {}", workflowType, workflowName, projectName);
		return this.workflowService.get(projectName, workflowName, workflowType);

	}

	/**
	 * Gets the all.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the all
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name,workflowType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{projectname}/{workflowType}")
	public List<Workflow> getAll(@PathVariable ("projectname") String projectName, @PathVariable ("workflowType") String workflowType) {
		logger.debug("Get all {} workflows of project -- {}", workflowType, projectName);
		return this.workflowService.get(projectName, workflowType);

	}

	/**
	 * Get All ETL Workflows.
	 *
	 * @return the etl workflow
	 */
	@ApiOperation (value = "Get Etl Workflow list", response = Workflow.class, tags = "Get ETL Workflow list")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/ETL")
	public List<Workflow> getEtlWorkflow() {
		logger.debug("Get all ETL workflows");
		return this.workflowService.get("ETL");

	}

	/**
	 * Save.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Workflow ", response = Workflow.class, tags = "Workflow [Save]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping
	public ServiceResponse save(@RequestBody Workflow workflow) {
		logger.debug("Saving workflow -- {}", workflow);

		Workflow workflowinDB = this.workflowService.get(workflow.getProjectName(), workflow.getWorkflowName(), workflow.getWorkflowType());

		if (workflowinDB != null){
			logger.debug("Existing Workflow found with workflow Id - {}", workflowinDB.getId());
			if (workflow.getId() == null){
				return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_EXISTS, workflow.getWorkflowName());
			}
		}
		return this.workflowService.save(workflow);

	}

	/**
	 * Update.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name,workflowType")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully updated"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PutMapping
	public ServiceResponse update(@RequestBody Workflow workflow) {
		logger.debug("Updating workflow -- {}", workflow.getWorkflowName());
		return this.workflowService.update(workflow);

	}

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	@ApiOperation (value = "Workflow ", response = Workflow.class, tags = "Workflow[Delete]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Deleted"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@DeleteMapping (value = "/{projectname}/{workflowname}/{workflowType}")
	public ServiceResponse delete(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType) {
		logger.debug("Deleting workflow -- {}", workflowName);
		return this.workflowService.delete(projectName, workflowName, workflowType);

	}

	/**
	 * Gets the project workflows.
	 *
	 * @param projectName the project name
	 * @return the project workflows
	 */
	@ApiOperation (value = "Get Workflow ", response = Workflow.class, tags = "Get Workflow list using project name")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{projectname}")
	public List<Workflow> getProjectWorkflows(@PathVariable ("projectname") String projectName) {
		logger.debug("Get all workflows of project -- {}", projectName);
		return this.workflowService.getAllWorkflows(projectName);

	}

	/**
	 * Duplicate.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param targetWorkflow the target workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Workflow ", response = Workflow.class, tags = "Workflow[Duplicate]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping (value = "duplicate/{projectname}/{workflowname}/{workflowType}/{targetWorkflow}/{description}")
	public ServiceResponse duplicate(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType, @PathVariable ("targetWorkflow") String targetWorkflow, @PathVariable ("description") String description) {

		logger.debug("Duplicating workflow -- {} with source workflow name -- {}", targetWorkflow, workflowName);

		Workflow workflowinDB = this.workflowService.get(projectName, targetWorkflow, workflowType);
		if (workflowinDB != null){
			logger.debug("Workflow already exists with this name");
			return new ServiceResponse(500, ResponseStatus.FAILED, WORKFLOW_EXISTS, targetWorkflow);
		}
		return this.workflowService.duplicateWorkflow(projectName, workflowName, workflowType, targetWorkflow, description);

	}

}
