package com.opus.optimus.config.service.repository.recon;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.recon.ReasonNote;

@Repository
public interface ReconReasonNoteRepository extends MongoRepository<ReasonNote, String> {

}
