package com.opus.optimus.config.service.listeners;

import static com.opus.optimus.config.service.constant.ConfigServiceConstant.DELETE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.ID;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.SAVE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.config.service.repository.audit.BatchDefinitionAuditRepository;
import com.opus.optimus.config.service.repository.scheduler.BatchDefinitionRepository;
import com.opus.optimus.config.service.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.BatchDefinitionAudit;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;

@Component
public class BatchDefinitionEventListener extends AbstractMongoEventListener<BatchDefinition> {
	private static final Logger log = LoggerFactory.getLogger(BatchDefinitionEventListener.class);

	@Autowired
	private BatchDefinitionAuditRepository batchDefinitionAuditRepository;
	@Autowired
	private BatchDefinitionRepository batchDefinitionRepository;
	private BatchDefinition batchDefinitionStore;

	@Override
	public void onAfterSave(AfterSaveEvent<BatchDefinition> event) {
		BatchDefinitionAudit batchDefinitionAudit = getBatchDefinitionAudit(event.getSource());
		batchDefinitionAudit.setAction(SAVE);
		batchDefinitionAuditRepository.save(batchDefinitionAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<BatchDefinition> event) {
		storeBatchDefinition(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<BatchDefinition> event) {
		BatchDefinitionAudit batchDefinitionAudit = getBatchDefinitionAudit(batchDefinitionStore);
		batchDefinitionAudit.setAction(DELETE);
		batchDefinitionAuditRepository.save(batchDefinitionAudit);
	}

	private BatchDefinitionAudit getBatchDefinitionAudit(BatchDefinition batchDefination) {
		BatchDefinitionAudit batchDefinitionAudit = new BatchDefinitionAudit();
		BeanUtils.copyProperties(batchDefination, batchDefinitionAudit, ID);
		setAdditionalAuditingFields(batchDefination, batchDefinitionAudit);
		return batchDefinitionAudit;
	}

	private void setAdditionalAuditingFields(BatchDefinition batchDefination, BatchDefinitionAudit batchDefinitionAudit) {
		batchDefinitionAudit.setDocumentId(batchDefination.getId());
		batchDefinitionAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeBatchDefinition(BeforeDeleteEvent<BatchDefinition> event) {
		Optional<BatchDefinition> batchDefinition = batchDefinitionRepository.findById(event.getDocument().get(_ID).toString());
		if (batchDefinition.isPresent()){
			batchDefinitionStore = batchDefinition.get();
		}
	}

}
