package com.opus.optimus.config.service.listeners;

import static com.opus.optimus.config.service.constant.ConfigServiceConstant.DELETE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.ID;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.SAVE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.config.service.repository.audit.DataSourceAuditRepository;
import com.opus.optimus.config.service.repository.etl.DataSourceRepository;
import com.opus.optimus.config.service.util.GetVersionNumber;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.ui.services.audit.MongoDataSourceMetaAudit;

@Component
public class DataSourceEventListener extends AbstractMongoEventListener<MongoDataSourceMeta> {
	private static final Logger log = LoggerFactory.getLogger(DataSourceEventListener.class);

	@Autowired
	private DataSourceAuditRepository dataSourceAuditRepository;
	@Autowired
	private DataSourceRepository dataSourceRepository;
	private MongoDataSourceMeta mongoDataSourceMetaStore;

	@Override
	public void onAfterSave(AfterSaveEvent<MongoDataSourceMeta> event) {
		MongoDataSourceMetaAudit mongoDataSourceMetaAudit = getMongoDataSourceMetaAudit(event.getSource());
		mongoDataSourceMetaAudit.setAction(SAVE);
		dataSourceAuditRepository.save(mongoDataSourceMetaAudit);

	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<MongoDataSourceMeta> event) {
		storeMongoDataSourceMeta(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<MongoDataSourceMeta> event) {
		MongoDataSourceMetaAudit mongoDataSourceMetaAudit = getMongoDataSourceMetaAudit(mongoDataSourceMetaStore);
		mongoDataSourceMetaAudit.setAction(DELETE);
		dataSourceAuditRepository.save(mongoDataSourceMetaAudit);
	}

	private MongoDataSourceMetaAudit getMongoDataSourceMetaAudit(MongoDataSourceMeta mongoDataSourceMeta) {
		MongoDataSourceMetaAudit mongoDataSourceMetaAudit = new MongoDataSourceMetaAudit();
		BeanUtils.copyProperties(mongoDataSourceMeta, mongoDataSourceMetaAudit, ID);
		setAdditionalAuditingFields(mongoDataSourceMeta, mongoDataSourceMetaAudit);
		return mongoDataSourceMetaAudit;
	}

	private void setAdditionalAuditingFields(MongoDataSourceMeta mongoDataSourceMeta, MongoDataSourceMetaAudit mongoDataSourceMetaAudit) {
		mongoDataSourceMetaAudit.setDocumentId(mongoDataSourceMeta.getId());
		mongoDataSourceMetaAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeMongoDataSourceMeta(BeforeDeleteEvent<MongoDataSourceMeta> event) {
		Optional<MongoDataSourceMeta> mongoDataSourceMeta = dataSourceRepository.findById(event.getDocument().get(_ID).toString());
		if (mongoDataSourceMeta.isPresent()){
			mongoDataSourceMetaStore = mongoDataSourceMeta.get();
		}
	}

}
