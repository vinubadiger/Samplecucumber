
package com.opus.optimus.config.service.constant;

public class ConfigServiceConstant {
	public static final String ID = "id";
	public static final String SAVE = "save";
	public static final String DELETE = "delete";
	public static final String _ID = "_id";
}
