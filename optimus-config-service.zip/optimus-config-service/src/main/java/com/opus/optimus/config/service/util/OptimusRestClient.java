package com.opus.optimus.config.service.util;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper;
import com.opus.optimus.ui.services.scheduler.CaseCloseResponse;
import com.opus.optimus.ui.services.scheduler.CaseCreation;
import com.opus.optimus.ui.services.scheduler.CaseResponse;
import com.opus.optimus.ui.services.util.CommonUtil;

/**
 * The Class RestClient client to perform HTTP requests for below tasks. 1.Create JobInfo when user schedule job or onjob creation 2.Close case using
 * caseID
 */
@Service
public class OptimusRestClient {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(OptimusRestClient.class);

	/** The host url. */
	@Value ("${client.hosturl}")
	private String hostUrl;

	/** The api base url. */
	@Value ("${client.baseurl}")
	private String apiBaseUrl;

	/** The salesforce auth url. */
	@Value ("${saleforce.authurl}")
	String salesforceAuthUrl;

	/** The salesforce case url. */
	@Value ("${saleforce.casecloseurl}")
	String salesforceCaseUrl;

	/** The salesforce token. */
	@Value ("${saleforce.token}")
	String salesforceToken;

	/** The salesforce token. */
	@Value ("${saleforce.exceptiontype}")
	String exceptionType;

	/** The rest template. */
	RestTemplate restTemplate;

	/** The rest template with requestfactory. */
	RestTemplate restTemplatewithrequestfactory;

	@Value ("${offline.datasource.operations.update}")
	String updateMongoEndpoint;

	@Value ("${offline.datasource.operations.remove}")
	String removeMongoEndpoint;

	@Autowired
	private BeanUtilService beanUtilService;

	public static final String ORIGIN = "Recon force match";
	public static final String CASE_STATE = "New";
	public static final String REASON_CODE = "NO match record";

	/**
	 * Init the two restTemplate object 1.Create a new instance of the {@link RestTemplate} using default settings. 2.Create a new instance of the
	 * {@link RestTemplate} based on the given {@link ClientHttpRequestFactory}.
	 */
	@PostConstruct
	public void init() {
		restTemplate = new RestTemplate();
		restTemplatewithrequestfactory = new RestTemplate(new HttpComponentsClientHttpRequestFactory());
	}

	/**
	 * Method call to close case
	 *
	 * @param cases the cases
	 * @param token the token
	 */
	public CaseCloseResponse patchMethodCall(CaseCreation cases, String token) {
		CaseCloseResponse caseCloseResponse = null;
		logger.debug("In Rest client close case");
		try{
			String authtoken = "OAuth " + token;
			logger.debug("token created {} ", authtoken);
			final String uri = salesforceCaseUrl;

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("Authorization", authtoken);

			MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
			map.add("records", cases);
			HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
			String caseResponse = restTemplatewithrequestfactory.patchForObject(uri, httpEntity, String.class);

			if (caseResponse != null){
				caseCloseResponse = CommonUtil.getObjectFromString(caseResponse, CaseCloseResponse.class);
			}
			return caseCloseResponse;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Case Close request.
	 *
	 * @param cases the cases
	 * @param token the token
	 */
	public CaseCloseResponse closeCase(String caseId, String comment, String reason, String reasonCode) {
		logger.debug("In Rest client Close Case");
		CaseCloseResponse caseCloseResponse = null;
		try{
			final String uri = salesforceAuthUrl;
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			HttpEntity<String> request = new HttpEntity<>(salesforceToken, headers);
			String recievedtoken = restTemplate.postForObject(uri, request, CaseResponse.class).getAccess_token();
			logger.debug("token - {}", recievedtoken);
			CaseCreation create = new CaseCreation();
			create.setCaseId(caseId);
			create.setStatus("Closed");
			create.setExceptionType(exceptionType);
			create.setComments(comment);
			create.setReason(reason);
			create.setReasonCode(reasonCode);
			caseCloseResponse = patchMethodCall(create, recievedtoken);
			return caseCloseResponse;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * This Method will call the Offline rest api to update the data source factory for any modification on the UI for a particular data source
	 * 
	 * @param dataSourceMeta
	 */
	public void updateOfflineMongoDataSourceFactory(final MongoDataSourceMeta dataSourceMeta) {
		logger.debug("In Rest client updateOfflineMongoDataSourceFactory");
		try{
			String taskManagerEndpoint = new StringBuilder(hostUrl).append(updateMongoEndpoint).toString();
			logger.debug("Calling API with url: {}", taskManagerEndpoint);
			restTemplate.postForObject(taskManagerEndpoint, dataSourceMeta, String.class);
		} catch (Exception e){
			logger.error("Unable to communicate with offline runtime API for data source factory update. Error: {}", e.getMessage(), e);
		}
	}

	/**
	 * This Method will call the Offline rest api to remove the data source factory on the UI for a particular data source
	 * 
	 * @param dataSourceMeta
	 */
	public void removeOfflineMongoDataSourceFactory(final MongoDataSourceMeta dataSourceMeta) {
		logger.debug("In Rest client removeOfflineMongoDataSourceFactory");
		try{
			String taskManagerEndpoint = new StringBuilder(hostUrl).append(removeMongoEndpoint).toString();
			logger.debug("Calling API with url: {}", taskManagerEndpoint);
			Map<String, String> params = new HashMap<>();
			params.put("dataSourceName", dataSourceMeta.getDataSourceName());
			restTemplate.delete(taskManagerEndpoint, params);
		} catch (Exception e){
			logger.error("Unable to communicate with offline runtime API for data source factory remove. Error: {}", e.getMessage(), e);
		}
	}

	/**
	 * For creating case on Salesforce
	 * 
	 * @param reasonCode
	 * @param projectName
	 * @param workflowName
	 */
	public SalesforceCaseResponse createCase(SalesforceCaseRequest salesForceCaseRequest) {
		SalesforceCaseHelper salesforceCaseHelper = beanUtilService.getBeanObject(SalesforceCaseHelper.class);
		SalesforceCaseResponse salesforcecaseresponse = salesforceCaseHelper.createCase(salesForceCaseRequest, salesforceCaseHelper.authenticate().getAccessToken());
		logger.debug("Response in forceMatch: ---> {}", salesforcecaseresponse);
		return salesforcecaseresponse;
	}
}
