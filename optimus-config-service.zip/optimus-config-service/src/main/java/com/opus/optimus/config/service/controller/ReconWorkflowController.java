package com.opus.optimus.config.service.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.config.service.business.recon.IReconWorkflowService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Workflow;
import com.opus.optimus.ui.services.recon.Activity;
import com.opus.optimus.ui.services.recon.ReasonNote;
import com.opus.optimus.ui.services.recon.ReconSourceFormHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Ranjana.Yadav The Class ReconWorkflowController exposes api related Reconciliation workflow.
 */
@RestController
@Api (value = "/reconWorkflows")
@RequestMapping ("{actionName}/reconWorkflows")
public class ReconWorkflowController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(ReconWorkflowController.class);

	/** The recon wf service. */
	@Autowired
	private IReconWorkflowService reconWfService;

	/**
	 * Save recon def.
	 *
	 * @param activity the activity
	 * @return the service response
	 * @throws Exception
	 */
	@ApiOperation (value = "Save Activity ", response = Activity.class, tags = "Save Activity")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping (value = "/reconSourceDefinition")
	public ServiceResponse saveReconDef(@RequestBody Activity activity) throws Exception {
		logger.debug("Save Recon activity -- {}", activity.getName());
		return reconWfService.save(activity);

	}

	/**
	 * Gets the.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the activity
	 */
	@ApiOperation (value = "Get Activity ", response = Activity.class, tags = "Get Activity")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/reconSourceDefinition/{projectName}/{workflowName}/{workflowType}")
	public Activity get(@PathVariable ("projectName") String projectName, @PathVariable ("workflowName") String workflowName, @PathVariable ("workflowType") String workflowType) {
		logger.debug("Get Recon activity -- {}", workflowName);
		return reconWfService.get(projectName, workflowName, workflowType);
	}

	/**
	 * Gets the.
	 *
	 * @author Ranjana.Yadav
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return All RECON Activity of a project
	 */

	@ApiOperation (value = "Get All Activity of a project ", response = Activity.class, tags = "Get ALL Activity of a project")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/GetAll/Activity/{projectName}/{workflowType}")
	public List<Activity> get(@PathVariable ("projectName") String projectName, @PathVariable ("workflowType") String workflowType) {
		return reconWfService.getAll(projectName, workflowType);
	}

	/**
	 * Gets the recon source form helper.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return populating source information
	 */

	@ApiOperation (value = "Get ReconSourceFormHelper ", response = ReconSourceFormHelper.class, tags = "Get ReconSourceFormHelper")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/etlSource/{projectName}/{workflowName}/{workflowType}")
	public ReconSourceFormHelper getReconSourceFormHelper(@PathVariable ("projectName") String projectName, @PathVariable ("workflowName") String workflowName, @PathVariable ("workflowType") String workflowType) {
		return reconWfService.getReconSourceFormHelper(projectName, workflowName, workflowType);
	}

	/**
	 * Gets the activity.
	 *
	 * @return All Activity of all projects
	 */
	@ApiOperation (value = "Get All Activity ", response = Activity.class, tags = "Get ALL Activity")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/getActivity")
	public List<Activity> getActivity() {
		logger.debug("Get all recon Workflows");
		return reconWfService.getActivity();
	}

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the Activity name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	@ApiOperation (value = "activity ", response = Workflow.class, tags = "Activity[Delete]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Deleted"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@DeleteMapping (value = "/{projectname}/{activityName}/{workflowType}")
	public ServiceResponse delete(@PathVariable ("projectname") String projectName, @PathVariable ("activityName") String activityName, @PathVariable ("workflowType") String workflowType) {

		logger.debug("Deleting Recon workflow");
		return this.reconWfService.delete(projectName, activityName, workflowType);

	}

	/**
	 * Gets the ReasonNote.
	 * 
	 * @return All ReasonNote
	 */
	@ApiOperation (value = "Get All ReasonNote ", response = Activity.class, tags = "Get ALL ReasonNote")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/getReasonNotes")
	public List<ReasonNote> getReasonNotes() {
		logger.debug("Get All ReasonNotes");
		return reconWfService.getReasonNotes();

	}
}
