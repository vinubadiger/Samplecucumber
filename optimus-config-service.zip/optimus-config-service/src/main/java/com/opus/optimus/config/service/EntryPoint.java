package com.opus.optimus.config.service;

import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.config.service.util.BeanUtilService;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IDataSourceConfigService;
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.DataSourceConfigServiceImpl;

/**
 * The Class EntryPoint.
 */
@SpringBootApplication
@EnableMongoAuditing
@EnableMongoRepositories ({ "com.opus.optimus.config.service.repository", "com.opus.optimus.offline.runtime.taskmanager.mongo.repository" })
public class EntryPoint {

	/** The bean util service. */
	@Autowired
	private BeanUtilService beanUtilService;

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(EntryPoint.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(EntryPoint.class, args);
	}

	/**
	 * Builds the and register data source factory.
	 */

	@PostConstruct
	private void buildAndRegisterDataSourceFactory() {
		try{
			final Object dataSourceConfigService = this.beanUtilService.getBeanObject(DataSourceConfigServiceImpl.class);

			List<MongoDataSourceMeta> dataSourceMetas = ((IDataSourceConfigService) dataSourceConfigService).findAllDataSourceConfigs();

			final DataSourceFactory dataSourceFactory = this.beanUtilService.getBeanObject(DataSourceFactory.class);
			if (dataSourceMetas != null){
				dataSourceMetas.parallelStream().forEach(dataSourceMeta -> {
					logger.debug("Registering Datasource -- {}", dataSourceMeta.getDataSourceName());
					final MongoDataSource dataSource = new MongoDataSource(dataSourceMeta);
					dataSource.init();
					dataSourceFactory.register(dataSourceMeta.getDataSourceName(), dataSource);
					logger.debug("Registered--{}{}", dataSource.getClass(), dataSourceMeta.getDataSourceName());
				});
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Bean
	@Primary
	public ObjectMapper optimusObjectMapper(MapperFactory mapperFactory) {
		return mapperFactory.getMapper();
	}

}
