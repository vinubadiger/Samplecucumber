package com.opus.optimus.config.service.listeners;

import static com.opus.optimus.config.service.constant.ConfigServiceConstant.DELETE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.ID;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.SAVE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.config.service.repository.audit.ActivityAuditRepository;
import com.opus.optimus.config.service.repository.recon.ActivityRepository;
import com.opus.optimus.config.service.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.ActivityAudit;
import com.opus.optimus.ui.services.recon.Activity;

@Component
public class ActivityEventListener extends AbstractMongoEventListener<Activity> {
	private static final Logger log = LoggerFactory.getLogger(ActivityEventListener.class);

	@Autowired
	private ActivityAuditRepository activityAuditRepository;
	@Autowired
	private ActivityRepository activityRepository;
	private Activity activityStore;

	@Override
	public void onAfterSave(AfterSaveEvent<Activity> event) {
		ActivityAudit activityAudit = getActivityAudit(event.getSource());
		activityAudit.setAction(SAVE);
		activityAuditRepository.save(activityAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<Activity> event) {
		storeActivity(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<Activity> event) {
		ActivityAudit activityAudit = getActivityAudit(activityStore);
		activityAudit.setAction(DELETE);
		activityAuditRepository.save(activityAudit);
	}

	private ActivityAudit getActivityAudit(Activity activity) {
		ActivityAudit activityAudit = new ActivityAudit();
		BeanUtils.copyProperties(activity, activityAudit, ID);
		setAdditionalAuditingFields(activity, activityAudit);
		return activityAudit;
	}

	private void setAdditionalAuditingFields(Activity workflow, ActivityAudit activityAudit) {
		activityAudit.setDocumentId(workflow.getId());
		activityAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeActivity(BeforeDeleteEvent<Activity> event) {
		Optional<Activity> activity = activityRepository.findById(event.getDocument().get(_ID).toString());
		if (activity.isPresent()){
			activityStore = activity.get();
		}
	}

}
