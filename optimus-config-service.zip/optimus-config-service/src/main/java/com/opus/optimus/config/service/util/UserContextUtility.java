package com.opus.optimus.config.service.util;

import java.util.Collection;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.GenericException;

@Component
public class UserContextUtility {

	/** The Constant log. */
	public static final Logger log = LoggerFactory.getLogger(UserContextUtility.class);

	/** The admin.role. */
	@Value ("${user.adminrole}")
	public String adminRole;

	/**
	 * Get current Username set by SecurityContext in LoginInterceptor
	 *
	 * @return the logged username
	 */
	public String getLoggedUsername() {
		String userName = null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null){
			userName = (String) auth.getPrincipal();
		}
		log.debug("Logged in Username  {}", userName);
		return userName;
	}

	/**
	 * Checks if the logged in user is admin or non admin. If admin returns true, if non admin returns false
	 *
	 * @return true, if successful
	 */
	public boolean checkIfAdminUser() {
		try{
			Collection<?> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
			Optional<?> isAdmin = authorities.stream().filter(authority -> authority.toString().equals(adminRole)).findAny();
			return isAdmin.isPresent();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}
