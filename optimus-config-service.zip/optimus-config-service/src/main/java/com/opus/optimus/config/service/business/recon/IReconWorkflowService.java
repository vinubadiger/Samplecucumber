package com.opus.optimus.config.service.business.recon;

import java.util.List;

import org.springframework.stereotype.Service;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.Activity;
import com.opus.optimus.ui.services.recon.ReasonNote;
import com.opus.optimus.ui.services.recon.ReconSourceFormHelper;

/**
 * The Interface IReconWorkflowService.
 */
@Service
public interface IReconWorkflowService {

	/**
	 * Save.
	 *
	 * @param reconSourceDef the recon source def
	 * @return the activity
	 * @throws Exception
	 */
	ServiceResponse save(Activity reconSourceDef) throws Exception;

	/**
	 * Gets the Recon Activity of a project
	 * 
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the activity
	 */
	Activity get(String projectName, String workflowName, String workflowType);

	/**
	 * Gets the recon source form helper.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the recon source form helper
	 */
	ReconSourceFormHelper getReconSourceFormHelper(String projectName, String workflowName, String workflowType);

	/**
	 * Gets the all.
	 *
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the all
	 */
	List<Activity> getAll(String projectName, String workflowType);

	/**
	 * Gets the activity.
	 *
	 * @return the activity
	 */
	List<Activity> getActivity();

	ServiceResponse delete(String projectName, String activityName, String workflowType);

	/**
	 * Get all Reason Notes
	 * 
	 * @return reasonNotes
	 */
	List<ReasonNote> getReasonNotes();

}
