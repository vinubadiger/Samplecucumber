package com.opus.optimus.config.service.business.scheduler.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.opus.optimus.config.service.business.scheduler.BatchDefinitionService;
import com.opus.optimus.config.service.repository.scheduler.BatchDefinitionRepository;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Class BatchDefinitionServiceImpl.
 */
@Service ("batchDefinitionService")
public class BatchDefinitionServiceImpl implements BatchDefinitionService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(BatchDefinitionServiceImpl.class);

	/** The batch definition repository. */
	@Autowired
	private BatchDefinitionRepository batchDefinitionRepository;

	/** The mongo template. */
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public BatchDefinition saveBatchDefinition(BatchDefinition batchDefinition) {
		if (batchDefinition.getId() == null){
			batchDefinition.setCreatedDate(new Date());
		}
		batchDefinition.setModifiedDate(new Date());
		return this.batchDefinitionRepository.save(batchDefinition);
	}

	@Override
	public BatchDefinition getBatchDefinition(String projectName, String workflowName, String workflowType) {
		try{
			return this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public ServiceResponse deleteCheck(String projectName, String workflowName, String workflowType) {
		BatchDefinition batchDb = this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		if (batchDb == null){
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Workflow is not scheduled, can be deleted", workflowName);
		} else{
			if (batchDb.getSchedulerPolicy() == null || batchDb.isDisabled()){
				log.debug("Workflow is not scheduled, can be deleted {}", workflowName);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Workflow is not scheduled, can be deleted", workflowName);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, "Workflow is scheduled, cannot be deleted", workflowName);
			}
		}

	}

	@Override
	public ServiceResponse delete(String projectName, String workflowName, String workflowType) {
		BatchDefinition batchDb = this.batchDefinitionRepository.findWorkflowByGivenData(projectName, workflowName, workflowType);
		if (batchDb != null){
			log.debug("Scheduling information deleting...{}", batchDb);
			batchDefinitionRepository.delete(batchDb);
		}
		return new ServiceResponse(200, ResponseStatus.SUCCESS, "Scheduling information is deleted of Workflow", workflowName);

	}

}