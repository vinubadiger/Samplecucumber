package com.opus.optimus.config.service.repository.audit;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.audit.ProjectAudit;

@Repository
public interface ProjectAuditRepository extends MongoRepository<ProjectAudit, String> {
}
