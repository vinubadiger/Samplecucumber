package com.opus.optimus.config.service.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.config.service.business.IProjectService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Project;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class ProjectController exposes api related to project.
 */
@RestController
@Api (value = "/projects")
@RequestMapping ("{actionName}/projects")
public class ProjectController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(ProjectController.class);

	/** The project service. */
	@Autowired
	private IProjectService projectService;

	/**
	 * Gets the.
	 *
	 * @param projectName the project name
	 * @return the project
	 */
	@ApiOperation (value = "Get project list ", response = Project.class, tags = "Get project list using project name")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/{name}")
	public Project get(@PathVariable ("name") String projectName) {
		logger.debug("Get project details of -- {}", projectName);
		return this.projectService.get(projectName);
	}

	/**
	 * Save.
	 *
	 * @param project the project
	 * @return the service response
	 */
	@ApiOperation (value = "Projects ", response = Project.class, tags = "Projects[Save]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping
	public ServiceResponse save(@RequestBody Project project) {

		logger.debug("Saving Project -- {}", project.getProjectName());
		return this.projectService.save(project);

	}

	/**
	 * Gets the project names.
	 *
	 * @return the project names
	 */
	@ApiOperation (value = "Get all project list ", response = Project.class, tags = "Get project list")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping
	public List<Project> getProjectNames() {

		logger.debug("Get all project names");
		return this.projectService.getProjectNames();

	}

	/**
	 * Update.
	 *
	 * @param project the project
	 * @return the service response
	 */
	@ApiOperation (value = "Projects ", response = Project.class, tags = "Projects[Update]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Updated"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PutMapping
	public ServiceResponse update(@RequestBody Project project) {
		logger.debug("Update project -- {}", project.getProjectName());
		return this.projectService.update(project);

	}

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	@ApiOperation (value = "Projects ", response = Project.class, tags = "Projects[Delete]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Updated"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@DeleteMapping (value = "/{name}")
	public ServiceResponse delete(@PathVariable ("name") String projectName) {
		logger.debug("Deleting project -- {}", projectName);
		return this.projectService.delete(projectName);

	}

	/**
	 * Duplicate.
	 *
	 * @param sourceProjectName the source project name
	 * @param destinationProjectName the destination project name
	 * @param projectDescription the project description
	 * @return the service response
	 */
	@ApiOperation (value = "Project duplicate ", response = Project.class, tags = "Projects[duplicate]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successful"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping (value = "duplicate/{sourceProjectName}/{destinationProjectName}/{projectDescription}")
	public @ResponseBody ServiceResponse duplicate(@PathVariable ("sourceProjectName") String sourceProjectName, @PathVariable ("destinationProjectName") String destinationProjectName, @PathVariable ("projectDescription") String projectDescription) {

		logger.debug("Duplicating project -- {} from source project -- {}", destinationProjectName, sourceProjectName);
		return projectService.duplicate(sourceProjectName, destinationProjectName, projectDescription);

	}

}
