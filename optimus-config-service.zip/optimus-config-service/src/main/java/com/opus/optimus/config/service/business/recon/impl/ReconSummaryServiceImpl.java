package com.opus.optimus.config.service.business.recon.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.mongodb.Block;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.opus.optimus.config.service.business.recon.IReconSummaryService;
import com.opus.optimus.config.service.repository.etl.PublishedWorkflowRepository;
import com.opus.optimus.config.service.repository.recon.ActivityRepository;
import com.opus.optimus.config.service.repository.recon.ReconHeaderInfoRepository;
import com.opus.optimus.config.service.repository.recon.ReconSummaryByTxnDateRepository;
import com.opus.optimus.config.service.repository.recon.ReconSummaryRepository;
import com.opus.optimus.config.service.util.OptimusRestClient;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.ReconStatusUpdateConfig;
import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;
import com.opus.optimus.offline.config.recon.SourceMappingType;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconType;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKeyDate;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.Activity;
import com.opus.optimus.ui.services.recon.ForceMatchHeaderDetails;
import com.opus.optimus.ui.services.recon.ForceMatchRecordInfo;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;
import com.opus.optimus.ui.services.recon.ForceMatchedRecords;
import com.opus.optimus.ui.services.util.CommonUtil;
import com.opus.optimus.ui.services.util.MongoQueryFilter;

/**
 * The Class ReconSummaryServiceImpl.
 */
@Service
public class ReconSummaryServiceImpl implements IReconSummaryService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconSummaryServiceImpl.class);

	/** The Constant ACTIVITY_NAME. */
	private static final String ACTIVITY_NAME = "activityName";

	/** The Constant RECON_CONTROL_FIELD. */
	private static final String RECON_CONTROL_FIELD = "$reconControlFields";

	private static final String RECON_CONTROL_PROPERTY = "reconControlFields";

	/** The Constant PROCESSING_DATE. */
	private static final String PROCESSING_DATE = "processingDate";

	/** The Constant STATUS. */
	private static final String STATUS = "status";

	/** The Constant SUB_STATUS. */
	private static final String SUB_STATUS = "subStatus";

	private static final String TRANSACTION_DATE = "transactionDate";

	private static final String RECON_TYPE = "reconType";
	private static final String TOTAL_AMOUNT = "totalAmount";
	private static final String TOTAL_VARIANCE = "totalVariance";

	private static final String SOURCE_A = "Source-A";
	private static final String SOURCE_B = "Source-B";

	/** The recon summary repository. */
	@Autowired
	private ReconSummaryRepository reconSummaryRepository;

	@Autowired
	private ReconSummaryByTxnDateRepository reconSummaryByTxnDateRepo;
	/** The published service repo. */
	@Autowired
	private PublishedWorkflowRepository publishedServiceRepo;

	@Autowired
	private ActivityRepository activeRepository;

	/** The mongo reader. */
	@Autowired
	private ReconMongoDbReader mongoReader;

	/** The rest client. */
	@Autowired
	OptimusRestClient restClient;

	@Autowired
	private ReconHeaderInfoRepository reconHeaderInfoRepository;

	private WorkflowConfig getWorkflow(String projectName, String activityName) {
		PublishedService publishedService = publishedServiceRepo.get(projectName, activityName, StepTypeConstants.RECON_WORKFLOW_TYPE);
		if (publishedService == null){
			throw new GenericException("Activity not found");
		}
		WorkflowConfig wkconfig = publishedService.getWorkflowConfig();
		if (wkconfig == null){
			throw new GenericException("Workflow configuration not found");
		}
		return wkconfig;
	}

	/**
	 * Gets the summary.
	 *
	 * @author Ranjana.Yadav
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param parameters the parameters
	 * @param paginationDetails the pagination details
	 * @return the summary
	 * @throws Exception the exception
	 */

	private MongoDBReaderConfig getMongoDbReaderStep(WorkflowConfig wkconfig, String sourceName) {
		Optional<IStepConfig> step = wkconfig.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getSourceName().equals(sourceName)).findAny();
		if (step.isPresent()){
			return (MongoDBReaderConfig) step.get();
		} else{
			throw new GenericException("Mongo db reader step not found for source -- " + sourceName);
		}

	}

	@Override
	public Page<Object> getSummary(String projectName, String activityName, String sourceName, Map<String, Object> parameters, Map<String, Integer> paginationDetails, List<MongoQueryFilter> filters) throws Exception {
		try{
			logger.debug("Getting Activity Summary for activity -- {}", activityName);
			WorkflowConfig wkconfig = getWorkflow(projectName, activityName);
			MongoDBReaderConfig mongoDbReaderStep = getMongoDbReaderStep(wkconfig, sourceName);
			return mongoReader.getTransaction(mongoDbReaderStep, activityName, parameters, paginationDetails, filters);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Update summary results.
	 *
	 * @param recordHolder the record holder
	 * @param collection the collection
	 * @param activityName the activity name
	 * @param forceMatchedRecord
	 * @param processingDate the processing date
	 */
	@Override
	public void updateSummaryResults(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, MongoCollection<Document> collection, String activityName, ForceMatchedRecords forceMatchedRecord) {
		try{
			logger.debug("Aggregation started against the forced matched records  for processing Date......");
			List<Document> andConditions = new ArrayList<>();
			andConditions.add(new Document(new StringBuilder(RECON_CONTROL_PROPERTY).append(".").append(activityName).toString(), new Document("$exists", Boolean.TRUE)));
			Document match = new Document("$match", new Document("$and", andConditions));

			Document idDocument = new Document(ACTIVITY_NAME, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(ACTIVITY_NAME).toString());
			idDocument.append(PROCESSING_DATE, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(PROCESSING_DATE).toString());
			idDocument.append(STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(STATUS).toString());
			idDocument.append(SUB_STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(SUB_STATUS).toString());
			Document totalAmount = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("amount").toString());
			Document totalVariance = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("absoluteTolerance").toString());
			Document count = new Document("$sum", Long.valueOf(1));
			Document group = new Document("$group", new Document("_id", idDocument).append(TOTAL_AMOUNT, totalAmount).append(TOTAL_VARIANCE, totalVariance).append("count", count));

			List<Bson> aggregationQuery = new ArrayList<>();
			aggregationQuery.add(match);
			aggregationQuery.add(group);
			logger.debug("Aggregate Query-- {}", aggregationQuery);
			AggregateIterable<Document> result = collection.aggregate(aggregationQuery);

			result.forEach((Block<? super Document>) (Document document) -> decorateSummaryRecordHolder(document, recordHolder, forceMatchedRecord.getSourceName(), forceMatchedRecord.getStepName()));

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Decorate summary record holder.
	 *
	 * @param document the document
	 * @param recordHolder the record holder
	 * @param sourceName the source name
	 * @param stepName the step name
	 */
	private void decorateSummaryRecordHolder(Document document, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, String sourceName, String stepName) {
		if (null == document){
			logger.debug("Result rowset is null for processing date ");
			return;
		}
		logger.debug("Processing result rowset for processing date : {}", document);
		try{
			Document key = (Document) document.get("_id");
			SummaryKey summaryKey = SummaryKey.builder().activityName(key.getString(ACTIVITY_NAME)).processingDate(key.getDate(PROCESSING_DATE)).status(ReconStatus.valueOf(key.getString(STATUS))).subStatus(ReconSubStatus.valueOf(key.getString(SUB_STATUS))).build();

			ReconSourceSummary reconSourceSummary = ReconSourceSummary.builder().sourceName(sourceName).stepName(stepName).totalAmount(document.getDouble("totalAmount")).totalVarianceAmnt(document.getDouble("totalVariance")).recordCount(document.getLong("count")).build();
			if (!recordHolder.containsKey(summaryKey)){
				recordHolder.put(summaryKey, new ArrayList<ReconSourceSummary>());
			}
			recordHolder.get(summaryKey).add(reconSourceSummary);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Save activity summary.
	 *
	 * @param recordHolder the record holder
	 * @param activityType the activity type
	 * @param projectName the project name
	 */
	private void saveActivitySummary(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, SourceMappingType sourceMappingType, String projectName, WorkflowConfig workflowConfig) {
		try{
			List<ReconAcitivitySummary> entites = new ArrayList<>();
			logger.debug("Updating Activity Summaries for processing date");
			for (Entry<SummaryKey, List<ReconSourceSummary>> entry : recordHolder.entrySet()){
				SummaryKey summaryKey = entry.getKey();
				ReconAcitivitySummary acitivitySummary = ReconAcitivitySummary.builder().activityName(summaryKey.getActivityName()).processingDate(summaryKey.getProcessingDate()).status(summaryKey.getStatus()).subStatus(summaryKey.getSubStatus()).activityType(sourceMappingType).projectName(projectName).build();
				entry.getValue().forEach(rec -> {
					switch (rec.getStepName()) {
					case (SOURCE_A):
						acitivitySummary.setSourceASummary(rec);
						break;
					case (SOURCE_B):
						acitivitySummary.setSourceBSummary(rec);
						break;
					default:
						logger.error("Neither Source A nor Source B found in record");
						break;
					}
				});
				entites.add(populateActivitySummary(acitivitySummary));
			}
			validateSourceSummary(entites, workflowConfig);
			logger.debug("Activity Summaries record count to be saved - {}", Integer.valueOf(entites.size()));
			reconSummaryRepository.saveAll(entites);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	private void validateSourceSummary(List<ReconAcitivitySummary> entites, WorkflowConfig reconWorkflow) {
		ReconSourceSummary source = new ReconSourceSummary();
		for (ReconAcitivitySummary reconAcitivitySummary : entites){
			validateSourceA(reconAcitivitySummary, reconWorkflow, source);
			validateSourceB(reconAcitivitySummary, reconWorkflow, source);
		}

	}

	private void validateSourceA(ReconAcitivitySummary reconAcitivitySummary, WorkflowConfig reconWorkflow, ReconSourceSummary source) {
		if (reconAcitivitySummary.getSourceASummary() == null){
			Optional<IStepConfig> step = reconWorkflow.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getStepName().equals(SOURCE_A)).findAny();
			if (step.isPresent()){
				MongoDBReaderConfig stepConfig = (MongoDBReaderConfig) step.get();
				source.setSourceName(stepConfig.getSourceDefinition().getSourceName());
				reconAcitivitySummary.setSourceASummary(source);
			}

		}
	}

	private void validateSourceB(ReconAcitivitySummary reconAcitivitySummary, WorkflowConfig reconWorkflow, ReconSourceSummary source) {
		if (reconAcitivitySummary.getSourceBSummary() == null){
			Optional<IStepConfig> step = reconWorkflow.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getStepName().equals(SOURCE_B)).findAny();
			if (step.isPresent()){
				MongoDBReaderConfig stepConfig = (MongoDBReaderConfig) step.get();
				source.setSourceName(stepConfig.getSourceDefinition().getSourceName());
				reconAcitivitySummary.setSourceBSummary(source);
			}

		}
	}

	/**
	 * Populate activity summary.
	 *
	 * @param acitivitySummary the acitivity summary
	 * @return the recon acitivity summary
	 */
	private ReconAcitivitySummary populateActivitySummary(ReconAcitivitySummary acitivitySummary) {
		try{
			logger.debug("populating processing date summary !! ");
			ReconAcitivitySummary dbAcitivitySummary = reconSummaryRepository.findAcitivitySummary(acitivitySummary.getActivityName(), acitivitySummary.getProjectName(), acitivitySummary.getProcessingDate(), acitivitySummary.getStatus(), acitivitySummary.getSubStatus());
			if (dbAcitivitySummary != null){
				acitivitySummary.setId(dbAcitivitySummary.getId());
			}
			return acitivitySummary;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public ServiceResponse forceMatch(ForceMatchRequest forceMatchRequest, String projectName, String activityName) {

		Set<String> cases = new HashSet<>();
		Activity activity = activeRepository.findReconSource(projectName, activityName, StepTypeConstants.RECON_WORKFLOW_TYPE);
		SourceMappingType sourceMappingType = activity.getSourceMapping();
		ReconType reconType = activity.getReconType();
		UUID newRelatedRecordsRefId = UUID.randomUUID();
		ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder = new ConcurrentHashMap<>();
		ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate = new ConcurrentHashMap<>();
		logger.info("UUID in forcematch {} ", newRelatedRecordsRefId);
		ServiceResponse responseA = generateSourceWiseSummary(forceMatchRequest.getSourceA(), cases, recordHolder, recordHolderTxnDate, projectName, activityName, forceMatchRequest.getRemarks(), forceMatchRequest.getManReasonId(), newRelatedRecordsRefId.toString());

		ServiceResponse responseB = generateSourceWiseSummary(forceMatchRequest.getSourceB(), cases, recordHolder, recordHolderTxnDate, projectName, activityName, forceMatchRequest.getRemarks(), forceMatchRequest.getManReasonId(), newRelatedRecordsRefId.toString());

		logger.debug("Case set source A and source B {}", cases);

		WorkflowConfig workflowConfig = getWorkflow(projectName, activityName);

		try{

			cases.parallelStream().forEach(caseId -> {
				logger.debug("caseID in loop while sending to salesforce client {}", caseId);
				String systemNote = CommonUtil.createSystemNote(forceMatchRequest);
				restClient.closeCase(caseId, systemNote, "Reconciled", "Forcematch");
			});

		} catch (Exception e){
			logger.error("Error while closing case", e);
		}

		if (responseA != null && responseA.getStatusCode() == 200 || responseB != null && responseB.getStatusCode() == 200){
			saveActivitySummary(recordHolder, sourceMappingType, projectName, workflowConfig);
			saveActivitySummaryByTxnDate(recordHolderTxnDate, sourceMappingType, projectName, reconType);
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Reconciled with force match done", activityName);
		} else{
			return new ServiceResponse(500, ResponseStatus.FAILED, "Reconciled with force match not done", activityName);
		}

	}

	/**
	 * Generate source wise summary.
	 *
	 * @param forceMatchedRecord the force matched record
	 * @param cases the cases
	 * @param recordHolder the record holder
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param remarks the remarks
	 * @return the service response
	 */
	private ServiceResponse generateSourceWiseSummary(ForceMatchedRecords forceMatchedRecord, Set<
					String> cases, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate, String projectName, String activityName, String remarks, String manReasonId, String newRelatedRecordsRefId) {
		List<ForceMatchRecordInfo> sourceInfo = forceMatchedRecord.getSelectedRec();
		cases.addAll(sourceInfo.stream().map(recordInfo -> recordInfo.getCaseID()).collect(Collectors.toSet()));

		logger.info("SOURCE-A---> sourceName -{},stepName - {}, remarks - {}", forceMatchedRecord.getSourceName(), forceMatchedRecord.getStepName(), remarks);

		return changeStatus(forceMatchedRecord, projectName, activityName, remarks, manReasonId, recordHolder, recordHolderTxnDate, newRelatedRecordsRefId);
	}

	public ServiceResponse changeStatus(ForceMatchedRecords forceMatchedRecords, String projectName, String activityName, String remarks, String manReasonId, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, ConcurrentMap<
					SummaryKeyDate,
					List<ReconSourceSummary>> recordHolderTxnDate, String newRelatedRecordsRefId) {
		try{
			WorkflowConfig wkconfig = getWorkflow(projectName, activityName);

			MongoDBReaderConfig mongoDbReaderStep = getMongoDbReaderStep(wkconfig, forceMatchedRecords.getSourceName());

			return mongoReader.changeStatusinDb(mongoDbReaderStep, activityName, projectName, forceMatchedRecords, remarks, manReasonId, recordHolder, recordHolderTxnDate, newRelatedRecordsRefId);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Change status.
	 *
	 * @param recordHolder the record holder
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param stepName the step name
	 * @param recordId the record id
	 * @param remarks the remarks
	 * @return the service response
	 */

	@Override
	public Page<Object> getRelatedRecord(String projectName, String sourceName, String activityName, String relatedIds, int pageNo, int size) {
		try{
			logger.debug("Getting Related Records");
			WorkflowConfig wkconfig = getWorkflow(projectName, activityName);

			MongoDBReaderConfig mongoDbReaderStep = getMongoDbReaderStep(wkconfig, sourceName);

			return mongoReader.getRelatedRecord(mongoDbReaderStep, relatedIds, pageNo, size);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public ForceMatchHeaderDetails saveForceMatchHeader(ForceMatchHeaderDetails forceMatchHeaderDetails) {

		return reconHeaderInfoRepository.save(forceMatchHeaderDetails);
	}

	@Override
	public List<ForceMatchHeaderDetails> findAllheaders() {
		try{
			return reconHeaderInfoRepository.findAll();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public ForceMatchHeaderDetails findbyProjectNameandSourceName(String projectName, String sourceName) {

		return reconHeaderInfoRepository.findByprojectNameandSourceName(projectName, sourceName);
	}

	@Override
	public Page<Object> getForceMatchDataByCaseID(String projectName, String activityName, String sourceName, String caseId, int pageNo, int size, List<MongoQueryFilter> conditions) {
		try{
			logger.debug("Getting force match data by caseId -- {}", caseId);
			WorkflowConfig wkconfig = getWorkflow(projectName, activityName);
			MongoDBReaderConfig mongoDbReaderStep = getMongoDbReaderStep(wkconfig, sourceName);

			return mongoReader.getForceMatchDataByCaseID(mongoDbReaderStep, caseId, pageNo, size, conditions);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public ServiceResponse unreconcile(ForceMatchRequest forceMatchRequest, String projectName, String activityName) {
		Set<String> cases = new HashSet<>();
		Activity activity = activeRepository.findReconSource(projectName, activityName, StepTypeConstants.RECON_WORKFLOW_TYPE);
		SourceMappingType sourceMappingType = activity.getSourceMapping();
		ReconType recontype = activity.getReconType();

		ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder = new ConcurrentHashMap<>();
		ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate = new ConcurrentHashMap<>();

		ServiceResponse responseA = generateSourceWiseunreconcileSummary(forceMatchRequest.getSourceA(), cases, recordHolder, recordHolderTxnDate, projectName, activityName, forceMatchRequest.getRemarks(), forceMatchRequest.getManReasonId());

		ServiceResponse responseB = generateSourceWiseunreconcileSummary(forceMatchRequest.getSourceB(), cases, recordHolder, recordHolderTxnDate, projectName, activityName, forceMatchRequest.getRemarks(), forceMatchRequest.getManReasonId());

		logger.debug("Case set source A and source B Unreconcile{}", cases);
		WorkflowConfig workflowConfig = getWorkflow(projectName, activityName);

		if (responseA != null && responseA.getStatusCode() == 200 || responseB != null && responseB.getStatusCode() == 200){

			saveActivitySummary(recordHolder, sourceMappingType, projectName, workflowConfig);
			saveActivitySummaryByTxnDate(recordHolderTxnDate, sourceMappingType, projectName, recontype);
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Reconciled with force match done", activityName);
		} else{
			return new ServiceResponse(500, ResponseStatus.FAILED, "Reconciled with force match not done", activityName);
		}

	}

	/**
	 * Generate source wise summary.
	 *
	 * @param forceMatchedRecord the force matched record
	 * @param cases the cases
	 * @param recordHolder the record holder
	 * @param recordHolderTxnDate
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param remarks the remarks
	 * @return the service response
	 */
	private ServiceResponse generateSourceWiseunreconcileSummary(ForceMatchedRecords forceMatchedRecord, Set<
					String> cases, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate, String projectName, String activityName, String remarks, String manReasonId) {
		logger.info("SOURCE-A---> sourceName -{},stepName - {}, remarks - {}", forceMatchedRecord.getSourceName(), forceMatchedRecord.getStepName(), remarks);
		return changeStatustounreconcile(forceMatchedRecord, projectName, activityName, remarks, manReasonId, recordHolder, recordHolderTxnDate);
	}

	public ServiceResponse changeStatustounreconcile(ForceMatchedRecords forceMatchedRecords, String projectName, String activityName, String remarks, String manReasonId, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, ConcurrentMap<
					SummaryKeyDate,
					List<ReconSourceSummary>> recordHolderTxnDate) {
		try{

			WorkflowConfig wkconfig = getWorkflow(projectName, activityName);
			Optional<IStepConfig> reconStepconfig = wkconfig.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE)).findAny();
			if (reconStepconfig.isPresent()){
				ReconStatusUpdateConfig reconStatusUpdate = (ReconStatusUpdateConfig) reconStepconfig.get();
				MongoDBReaderConfig stepToUpdate = getMongoDbReaderStep(wkconfig, forceMatchedRecords.getSourceName());
				return mongoReader.changeStatusinDbforUnreconcile(stepToUpdate, activityName, projectName, forceMatchedRecords, remarks, manReasonId, recordHolder, recordHolderTxnDate, reconStatusUpdate);
			} else{
				throw new GenericException("Recon config Step not found for activity " + activityName);
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	private void saveActivitySummaryByTxnDate(ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolder, SourceMappingType activityType, String projectName, ReconType reconType) {
		logger.debug("Creating Recon Summary Structure based on transaction date to save in DB..");
		try{
			List<ReconSummaryByTrnDate> entites = new ArrayList<>();
			logger.debug("Saving Activity Summaries");
			recordHolder.entrySet().forEach(entry -> {
				SummaryKeyDate summaryKey = entry.getKey();
				ReconSummaryByTrnDate acitivitySummary = ReconSummaryByTrnDate.builder().activityName(summaryKey.getActivityName()).transactionDate(summaryKey.getTransactionDate()).status(summaryKey.getStatus()).subStatus(summaryKey.getSubStatus()).activityType(activityType).projectName(projectName).reconType(reconType).build();
				entry.getValue().forEach(rec -> {
					switch (rec.getStepName()) {
					case (SOURCE_A):
						acitivitySummary.setSourceASummary(rec);
						break;
					case (SOURCE_B):
						acitivitySummary.setSourceBSummary(rec);
						break;
					default:
						logger.error("Neither Source A nor Source B found in record");
						break;
					}
				});
				entites.add(populateActivitySummaryBytrnDate(acitivitySummary));
			});

			int dbUpdateRecordCount = entites.size();
			logger.debug("Activity Summaries record count to be saved - {}", dbUpdateRecordCount);
			reconSummaryByTxnDateRepo.saveAll(entites);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	private ReconSummaryByTrnDate populateActivitySummaryBytrnDate(ReconSummaryByTrnDate acitivitySummary) {
		try{
			logger.debug("populating transaction date summary !! ");
			ReconSummaryByTrnDate dbAcitivitySummary = reconSummaryByTxnDateRepo.findAcitivitySummary(acitivitySummary.getActivityName(), acitivitySummary.getProjectName(), acitivitySummary.getTransactionDate(), acitivitySummary.getStatus(), acitivitySummary.getSubStatus(), acitivitySummary.getReconType());
			if (dbAcitivitySummary != null){
				acitivitySummary.setId(dbAcitivitySummary.getId());
			}
			return acitivitySummary;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public void updateSummaryResultsForTxnDate(ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate, MongoCollection<Document> collection, String activityName, ForceMatchedRecords forceMatchedRecord, Date transactionDate) {
		try{
			logger.debug("updating Summary Results transaction date summary !! ");
			List<Document> andConditions = new ArrayList<>();
			andConditions.add(new Document(RECON_CONTROL_PROPERTY, new Document("$exists", Boolean.TRUE)));
			andConditions.add(new Document(new StringBuilder(RECON_CONTROL_PROPERTY).append(".").append(activityName).toString(), new Document("$exists", Boolean.TRUE)));
			andConditions.add(new Document(new StringBuilder(RECON_CONTROL_PROPERTY).append(".").append(activityName).append(".").append(TRANSACTION_DATE).toString(), transactionDate));
			Document match = new Document("$match", new Document("$and", andConditions));

			Document idDocument = new Document(ACTIVITY_NAME, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(ACTIVITY_NAME).toString());
			idDocument.append(TRANSACTION_DATE, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(TRANSACTION_DATE).toString());
			idDocument.append(STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(STATUS).toString());
			idDocument.append(SUB_STATUS, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(SUB_STATUS).toString());
			idDocument.append(RECON_TYPE, new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append(RECON_TYPE).toString());

			Document totalAmount = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("amount").toString());
			Document totalVariance = new Document("$sum", new StringBuilder(RECON_CONTROL_FIELD).append(".").append(activityName).append(".").append("absoluteTolerance").toString());
			Document count = new Document("$sum", Long.valueOf(1));
			Document group = new Document("$group", new Document("_id", idDocument).append(TOTAL_AMOUNT, totalAmount).append(TOTAL_VARIANCE, totalVariance).append("count", count));

			List<Bson> aggregationQuery = new ArrayList<>();
			aggregationQuery.add(match);
			aggregationQuery.add(group);
			AggregateIterable<Document> result = collection.aggregate(aggregationQuery);

			result.forEach((Block<? super Document>) (Document document) -> decorateSummaryRecordHolderTxndate(document, recordHolderTxnDate, forceMatchedRecord.getSourceName(), forceMatchedRecord.getStepName()));

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	private void decorateSummaryRecordHolderTxndate(Document document, ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate, String sourceName, String stepName) {
		if (null == document){
			logger.debug("Result rowset is for transaction date null");
			return;
		}
		logger.debug("Processing result rowset for transaction date : {}", document);
		try{
			Document key = (Document) document.get("_id");
			SummaryKeyDate summaryKey = SummaryKeyDate.builder().activityName(key.getString(ACTIVITY_NAME)).transactionDate(key.getDate(TRANSACTION_DATE)).status(ReconStatus.valueOf(key.getString(STATUS))).subStatus(ReconSubStatus.valueOf(key.getString(SUB_STATUS))).build();

			ReconSourceSummary reconSourceSummary = ReconSourceSummary.builder().sourceName(sourceName).stepName(stepName).totalAmount(document.getDouble("totalAmount")).totalVarianceAmnt(document.getDouble("totalVariance")).recordCount(document.getLong("count")).build();
			if (!recordHolderTxnDate.containsKey(summaryKey)){
				recordHolderTxnDate.put(summaryKey, new ArrayList<ReconSourceSummary>());
			}
			recordHolderTxnDate.get(summaryKey).add(reconSourceSummary);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
