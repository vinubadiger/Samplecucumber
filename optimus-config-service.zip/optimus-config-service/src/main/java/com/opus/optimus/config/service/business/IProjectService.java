package com.opus.optimus.config.service.business;

import java.util.List;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Project;

/**
 * The Interface IProjectService.
 */
public interface IProjectService {

	/**
	 * Gets the Project.
	 *
	 * @param projectName the project name
	 * @return the project
	 */
	Project get(String projectName);

	/**
	 * Save Project.
	 *
	 * @param project the project
	 * @return the service response
	 */
	ServiceResponse save(Project project);

	/**
	 * Gets the project names.
	 *
	 * @return the project names
	 */
	List<Project> getProjectNames();

	/**
	 * Update Project.
	 *
	 * @param project the project
	 * @return the service response
	 */
	ServiceResponse update(Project project);

	/**
	 * Delete Project.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	ServiceResponse delete(String projectName);

	/**
	 * Duplicate Project.
	 *
	 * @param sourceProjectName the source project name
	 * @param destinationProjectName the destination project name
	 * @param projectDescription the project description
	 * @return the service response
	 */
	ServiceResponse duplicate(String sourceProjectName, String destinationProjectName, String projectDescription);

}
