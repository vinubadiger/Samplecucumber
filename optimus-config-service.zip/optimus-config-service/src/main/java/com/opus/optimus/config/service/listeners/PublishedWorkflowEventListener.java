package com.opus.optimus.config.service.listeners;

import static com.opus.optimus.config.service.constant.ConfigServiceConstant.DELETE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.ID;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.SAVE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.config.service.repository.audit.PublishedWorkflowAuditRepository;
import com.opus.optimus.config.service.repository.etl.PublishedWorkflowRepository;
import com.opus.optimus.config.service.util.GetVersionNumber;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.ui.services.audit.PublishedServiceAudit;

@Component
public class PublishedWorkflowEventListener extends AbstractMongoEventListener<PublishedService> {
	private static final Logger log = LoggerFactory.getLogger(PublishedWorkflowEventListener.class);
	@Autowired
	private PublishedWorkflowAuditRepository publishedWorkflowAuditRepository;

	@Autowired
	private PublishedWorkflowRepository publishedWorkflowRepository;

	private PublishedService publishedServiceStore;

	@Override
	public void onAfterSave(AfterSaveEvent<PublishedService> event) {
		PublishedServiceAudit publishedServiceAudit = getPublishedServiceAudit(event.getSource());
		publishedServiceAudit.setAction(SAVE);
		publishedWorkflowAuditRepository.save(publishedServiceAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<PublishedService> event) {
		storePublishedService(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<PublishedService> event) {
		PublishedServiceAudit publishedServiceAudit = getPublishedServiceAudit(publishedServiceStore);
		publishedServiceAudit.setAction(DELETE);
		publishedWorkflowAuditRepository.save(publishedServiceAudit);
	}

	private PublishedServiceAudit getPublishedServiceAudit(PublishedService publishedService) {
		PublishedServiceAudit publishedServiceAudit = new PublishedServiceAudit();
		BeanUtils.copyProperties(publishedService, publishedServiceAudit, ID);
		setAdditionalAuditingFields(publishedService, publishedServiceAudit);
		return publishedServiceAudit;
	}

	private void setAdditionalAuditingFields(PublishedService publishedService, PublishedServiceAudit publishedServiceAudit) {
		publishedServiceAudit.setDocumentId(publishedService.getId());
		publishedServiceAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storePublishedService(BeforeDeleteEvent<PublishedService> event) {
		Optional<PublishedService> publishedService = publishedWorkflowRepository.findById(event.getDocument().get(_ID).toString());
		if (publishedService.isPresent()){
			publishedServiceStore = publishedService.get();
		}
	}

}
