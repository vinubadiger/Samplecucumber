package com.opus.optimus.config.service.business.impl;

/**
 * The Enums of FieldType.
 */
public enum OracleDataTypeEnum {

	/** The varchar. */
	VARCHAR,

	/** The varchar2. */
	VARCHAR2,

	/** The number. */
	NUMBER,

	/** The date. */
	DATE,
	/** The date. */
	CHAR,
}
