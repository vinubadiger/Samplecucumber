package com.opus.optimus.config.service.listeners;

import static com.opus.optimus.config.service.constant.ConfigServiceConstant.DELETE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.ID;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.SAVE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.config.service.repository.audit.WorkflowAuditRepository;
import com.opus.optimus.config.service.repository.etl.WorkflowRepository;
import com.opus.optimus.config.service.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.WorkflowAudit;
import com.opus.optimus.ui.services.project.Workflow;

@Component
public class WorkflowEventListener extends AbstractMongoEventListener<Workflow> {
	private static final Logger log = LoggerFactory.getLogger(WorkflowEventListener.class);

	@Autowired
	private WorkflowAuditRepository workflowAuditRepository;
	@Autowired
	private WorkflowRepository workflowRepository;

	private Workflow workflowStore;

	@Override
	public void onAfterSave(AfterSaveEvent<Workflow> event) {
		WorkflowAudit workflowAudit = getWorkflowAudit(event.getSource());
		workflowAudit.setAction(SAVE);
		workflowAuditRepository.save(workflowAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<Workflow> event) {
		storeWorkflow(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<Workflow> event) {
		WorkflowAudit workflowAudit = getWorkflowAudit(workflowStore);
		workflowAudit.setAction(DELETE);
		workflowAuditRepository.save(workflowAudit);
	}

	private WorkflowAudit getWorkflowAudit(Workflow workflow) {
		WorkflowAudit workflowAudit = new WorkflowAudit();
		BeanUtils.copyProperties(workflow, workflowAudit, ID);
		setAdditionalAuditingFields(workflow, workflowAudit);
		return workflowAudit;
	}

	private void setAdditionalAuditingFields(Workflow workflow, WorkflowAudit workflowAudit) {
		workflowAudit.setDocumentId(workflow.getId());
		workflowAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeWorkflow(BeforeDeleteEvent<Workflow> event) {
		Optional<Workflow> workflow = workflowRepository.findById(event.getDocument().get(_ID).toString());
		if (workflow.isPresent()){
			workflowStore = workflow.get();
		}
	}

}
