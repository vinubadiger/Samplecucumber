package com.opus.optimus.config.service.repository.recon;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;

/**
 * The Interface ReconSummaryRepository.
 */
@Repository
public interface ReconSummaryRepository extends MongoRepository<ReconAcitivitySummary, String> {

	/**
	 * Find by processing date between.
	 *
	 * @param from the from
	 * @param to the to
	 * @param projectName the project name
	 * @return the list
	 */
	@Query (value = "{ $and: [ {'processingDate':{ $lte: ?1, $gte: ?0}}, { 'projectName' : ?2}] }")
	List<ReconAcitivitySummary> findByProcessingDateBetween(Date from, Date to, String projectName);

	/**
	 * Find by processing date between.
	 *
	 * @param from the from
	 * @param to the to
	 * @return the list
	 */
	@Query (value = "{'processingDate':{ $lte: ?1, $gte: ?0}}")
	List<ReconAcitivitySummary> findByProcessingDateBetween(Date from, Date to);

	/**
	 * @param activityName
	 * @param projectName
	 * @param processingDate
	 * @param status
	 * @param subStatus
	 * @return
	 */
	@Query (value = "{ $and: [ { 'activityName' : ?0 }, { 'projectName' : ?1 },{'processingDate' : ?2}, {'status' : ?3}, {'subStatus' : ?4} ] }")
	ReconAcitivitySummary findAcitivitySummary(String activityName, String projectName, Date processingDate, ReconStatus status, ReconSubStatus subStatus);
}
