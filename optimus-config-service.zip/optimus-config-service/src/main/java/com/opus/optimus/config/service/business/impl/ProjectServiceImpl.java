package com.opus.optimus.config.service.business.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.config.service.business.IProjectService;
import com.opus.optimus.config.service.business.IWorkflowService;
import com.opus.optimus.config.service.business.scheduler.BatchDefinitionService;
import com.opus.optimus.config.service.repository.UserRepository;
import com.opus.optimus.config.service.repository.etl.ProjectRepository;
import com.opus.optimus.config.service.repository.etl.PublishedWorkflowRepository;
import com.opus.optimus.config.service.util.UserContextUtility;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Project;
import com.opus.optimus.ui.services.project.Workflow;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class ProjectServiceImpl.
 */
@Service
public class ProjectServiceImpl implements IProjectService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(ProjectServiceImpl.class);

	/** The Constant PROJECT_EXISTS. */
	private static final String PROJECT_EXISTS = "Project already exists";

	/** The Constant PROJECT_NOT_EXISTS. */
	private static final String PROJECT_NOT_EXISTS = "Project not exists";

	/** The Constant PROJECT_CREATED. */
	private static final String PROJECT_CREATED = "Project created succesfully";

	/** The Constant PROJECT_DELETED. */
	private static final String PROJECT_DELETED = "Project deleted succesfully";

	/** The Constant PROJECT_DUPLICATED. */
	private static final String PROJECT_DUPLICATED = "Project duplicated";

	/** The Constant PROJECT_UPDATED. */
	private static final String PROJECT_UPDATED = "Project updated succesfully";

	/** The project repository. */
	@Autowired
	private ProjectRepository projectRepository;

	/** The workflow service. */
	@Autowired
	private IWorkflowService workflowService;

	@Autowired
	private BatchDefinitionService batchDefinitionService;

	@Autowired
	PublishedWorkflowRepository publishedWorkflowRepository;

	/** The project repository. */
	@Autowired
	private UserRepository userRepository;

	/** The UserContextUtility repository. */
	@Autowired
	UserContextUtility userContextUtility;

	/**
	 * Gets the Project.
	 *
	 * @param projectName the project name
	 * @return the project
	 */
	@Override
	public Project get(String projectName) {
		try{
			return this.projectRepository.findProjectByProjectName(projectName);
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Save Project.
	 *
	 * @param project the project
	 * @return the service response
	 */
	@Override
	public ServiceResponse save(Project project) {
		try{
			Project projectdb = get(project.getProjectName());
			if (projectdb != null){
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_EXISTS, projectdb);
			} else{
				this.projectRepository.save(project);

				ServiceResponse response = new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_CREATED, project);

				User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());

				if (user.getProjects() == null){
					user.setProjects(new ArrayList<>());
				}
				user.getProjects().add(project.getProjectName());
				userRepository.save(user);

				return response;
			}

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getProjectNames :", e);
		}
	}

	/**
	 * Gets the project names.
	 *
	 * @return the project names
	 */
	@Override
	public List<Project> getProjectNames() {
		try{
			User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());

			List<Project> projects = null;
			if (userContextUtility.checkIfAdminUser()){
				projects = this.projectRepository.findAll();
			} else{
				projects = projectRepository.findProjectsByProjectName(user.getProjects());
			}
			Collections.sort(projects);
			Collections.reverse(projects);
			return projects;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getProjectNames :", e);
		}
	}

	/**
	 * Update Project.
	 *
	 * @param project the project
	 * @return the service response
	 */
	@Override
	public ServiceResponse update(Project project) {
		Project projectdb = get(project.getProjectName());
		try{
			if (projectdb != null){
				project.setId(projectdb.getId());
				this.projectRepository.save(project);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_UPDATED, project);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, projectdb);
			}
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Duplicate Project.
	 *
	 * @param sourceProjectName the source project name
	 * @param destinationProjectName the destination project name
	 * @param projectDescription the project description
	 * @return the service response
	 */
	@Override
	public ServiceResponse duplicate(String sourceProjectName, String destinationProjectName, String projectDescription) {
		try{
			log.debug("Entered in duplicate project");
			Project project2;
			Project project1 = get(sourceProjectName);
			Project projectDb2 = get(destinationProjectName);
			if (projectDb2 == null){

				if (project1 != null){
					project2 = project1;
					project2.setId(null);
					project2.setProjectName(destinationProjectName);
					project2.setProjectDescription(projectDescription);
					this.projectRepository.save(project2);
					this.workflowService.duplicate(sourceProjectName, project2.getProjectName());
					ServiceResponse response = new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_DUPLICATED, project2);

					User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());

					if (user != null){
						user.getProjects().add(project2.getProjectName());
						userRepository.save(user);
					}
					return response;
				} else{
					log.info("Source project does not exists");
					return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, sourceProjectName);
				}
			} else{
				log.info("Project with this name already exists");
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_EXISTS, destinationProjectName);

			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in duplicate :", e);
		}

	}

	/**
	 * Delete project as well its workflow.
	 *
	 * @param projectName the project name
	 * @return the service response
	 */
	@Override
	public ServiceResponse delete(String projectName) {
		Project project = this.projectRepository.findProjectByProjectName(projectName);
		try{
			if (project != null){
				ServiceResponse responseWf = this.workflowService.deleteCheck(projectName);
				if (responseWf.getStatus().equals(ResponseStatus.SUCCESS)){
					List<Workflow> workflowList = this.workflowService.getAllWorkflows(projectName);
					workflowList.forEach(wf -> this.batchDefinitionService.delete(projectName, wf.getWorkflowName(), wf.getWorkflowType()));
					workflowList.forEach(wf -> this.workflowService.deleteWorkflow(projectName, wf.getWorkflowName(), wf.getWorkflowType()));
					for (Workflow wf : workflowList){
						PublishedService publishedService = this.publishedWorkflowRepository.get(wf.getProjectName(), wf.getWorkflowName(), wf.getWorkflowType());
						if (publishedService != null){
							log.debug("PublishedService deleting...{}", publishedService.getProjectName());
							this.publishedWorkflowRepository.delete(publishedService);
						}
					}
					log.debug("Project deleting...{}", project.getProjectName());
					this.projectRepository.delete(project);
					return new ServiceResponse(200, ResponseStatus.SUCCESS, PROJECT_DELETED, project);
				} else{
					return new ServiceResponse(500, ResponseStatus.FAILED, responseWf.getMsg(), project);
				}
			} else{
				log.debug(PROJECT_NOT_EXISTS);
				return new ServiceResponse(500, ResponseStatus.FAILED, PROJECT_NOT_EXISTS, project);
			}
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

}
