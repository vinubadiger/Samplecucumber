package com.opus.optimus.config.service.business.scheduler;

import org.springframework.stereotype.Service;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;


/**
 * The Interface BatchDefinitionService.
 */
@Service
public interface BatchDefinitionService {

	/**
	 * Save batch definition.
	 *
	 * @param batchDefinition the batch definition
	 * @return the batch definition
	 */
	BatchDefinition saveBatchDefinition(BatchDefinition batchDefinition);

	/**
	 * Gets the batch definition.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the batch definition
	 */
	BatchDefinition getBatchDefinition(String projectName, String workflowName, String workflowType);

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	ServiceResponse delete(String projectName, String workflowName, String workflowType);

	/**
	 * Delete check.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	ServiceResponse deleteCheck(String projectName, String workflowName, String workflowType);

}