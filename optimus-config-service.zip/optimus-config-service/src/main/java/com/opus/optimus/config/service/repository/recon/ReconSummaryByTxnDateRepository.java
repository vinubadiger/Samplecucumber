package com.opus.optimus.config.service.repository.recon;

import java.util.Date;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconType;

@Repository
public interface ReconSummaryByTxnDateRepository extends MongoRepository<ReconSummaryByTrnDate, String> {

	@Query (value = "{ $and: [ { 'activityName' : ?0 }, { 'projectName' : ?1 },{'transactionDate' : ?2}, {'status' : ?3}, {'subStatus' : ?4},{'reconType': ?5} ] }")
	ReconSummaryByTrnDate findAcitivitySummary(String activityName, String projectName, Date transactionDate, ReconStatus status, ReconSubStatus subStatus, ReconType reconType);

}
