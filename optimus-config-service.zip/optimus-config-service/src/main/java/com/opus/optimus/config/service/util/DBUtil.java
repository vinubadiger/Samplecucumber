package com.opus.optimus.config.service.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta;
import com.opus.optimus.offline.config.exception.GenericException;

/**
 * Class for handling DB connection with oracle
 * 
 * @author Yogesh.Chaudhari
 */
public class DBUtil {

	private static final String JDBC_ORACLE_DRIVER = "jdbc:oracle:thin:@";

	private static final String COLON = ":";

	private DBUtil() {
		// Default Constructor
	}

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(DBUtil.class);

	public static Connection getOracleConnection(MongoDataSourceMeta mongoDataSourceMeta) {

		Connection conn = null;

		logger.debug("IP address  : {} and port : {}", mongoDataSourceMeta.getAddressMetadatas().get(0).getIpAddress(), mongoDataSourceMeta.getAddressMetadatas().get(0).getPort());
		String url = new StringBuilder(JDBC_ORACLE_DRIVER).append(mongoDataSourceMeta.getAddressMetadatas().get(0).getIpAddress()).append(COLON).append(mongoDataSourceMeta.getAddressMetadatas().get(0).getPort()).append(COLON).append(mongoDataSourceMeta.getServiceName()).toString();
		try{
			conn = DriverManager.getConnection(url, mongoDataSourceMeta.getAuthMetaData().getUserName(), mongoDataSourceMeta.getAuthMetaData().getPassword());

		} catch (SQLException se){
			throw new GenericException("Error in getOracleConnection :", se);
		} catch (Exception e){
			logger.debug("Exception  : {} ", e);
		}
		return conn;
	}
}
