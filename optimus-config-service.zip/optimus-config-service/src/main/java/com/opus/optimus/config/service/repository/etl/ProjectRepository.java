package com.opus.optimus.config.service.repository.etl;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.project.Project;

/**
 * The Interface ProjectRepository.
 */
@Repository
public interface ProjectRepository extends MongoRepository<Project, String> {

	/**
	 * Find project by project name.
	 *
	 * @param projectName the project name
	 * @return the project
	 */
	@Query (value = "{'projectName': {$regex : '^?0$', $options: 'i'}}")
	Project findProjectByProjectName(String projectName);

	/**
	 * Find all the records for the project for which the user have access
	 * 
	 * @param projectName
	 * @return
	 */
	@Query (value = "{'projectName': { $in : ?0}}")
	List<Project> findProjectsByProjectName(List<String> projectName);
}
