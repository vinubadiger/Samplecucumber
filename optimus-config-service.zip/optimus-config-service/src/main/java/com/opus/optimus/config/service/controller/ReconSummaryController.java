package com.opus.optimus.config.service.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.config.service.business.recon.IReconSummaryService;
import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.ForceMatchHeaderDetails;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;
import com.opus.optimus.ui.services.util.MongoQueryFilter;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class ReconSummaryController exposes api related to Reconciliation.
 */
@RestController
@Api (value = "/reconSummary")
@RequestMapping ("{actionName}/reconSummary")
public class ReconSummaryController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(ReconSummaryController.class);

	/** The recon summary service. */
	@Autowired
	private IReconSummaryService iReconSummaryService;

	/**
	 * Gets the summary.
	 * 
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param pageNo the page no
	 * @param pageSize the page size
	 * @return the summary
	 * @throws Exception
	 */

	@ApiOperation (value = "Get Summary ", response = ReconAcitivitySummary.class, tags = "Get Summary")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping (value = "/getSummary/{projectName}/{activityName}/{sourceName}/{pageNo}/{pageSize}")
	public Page<Object> getSummary(@RequestBody List<
					MongoQueryFilter> conditions, @PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName, @PathVariable ("sourceName") String sourceName, @PathVariable ("pageNo") int pageNo, @PathVariable ("pageSize") int pageSize, @RequestParam (value = "status", required = false) String status, @RequestParam (value = "subStatus", required = false) String subStatus, @RequestParam (value = "startDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date startDate, @RequestParam (value = "endDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date endDate) throws Exception {
		Map<String, Integer> paginationDetails = new HashMap<>();
		paginationDetails.put("page", pageNo);
		paginationDetails.put("size", pageSize);

		Map<String, Object> parameters = new HashMap<>();
		parameters.put("status", status);
		parameters.put("subStatus", subStatus);
		parameters.put("startDate", startDate);
		parameters.put("endDate", endDate);

		return iReconSummaryService.getSummary(projectName, activityName, sourceName, parameters, paginationDetails, conditions);

	}

	/**
	 * To change the status and substatus on record level input as List
	 * 
	 * @param projectName
	 * @param activityName
	 * @param sourceName
	 * @param caseId
	 * @param status
	 */
	@ApiOperation (value = "Change Status for List", response = ServiceResponse.class, tags = "Change Status")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Status changed"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping (value = "/forceMatch/{projectName}/{activityName}")
	public ServiceResponse forceMatch(@RequestBody ForceMatchRequest forceMatchRequest, @PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName) {
		return this.iReconSummaryService.forceMatch(forceMatchRequest, projectName, activityName);

	}

	@ApiOperation (value = "get record by case id", response = ServiceResponse.class, tags = "Change Status")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Status changed"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping (value = "/getRecordByCaseId/{projectName}/{activityName}/{sourceName}/{caseId}/{pageNo}/{pageSize}")
	public Page<Object> getForceMatchDataByCaseID(@RequestBody List<
					MongoQueryFilter> conditions, @PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName, @PathVariable ("sourceName") String sourceName, @PathVariable ("caseId") String caseId, @PathVariable ("pageNo") int pageNo, @PathVariable ("pageSize") int pageSize) {
		return this.iReconSummaryService.getForceMatchDataByCaseID(projectName, activityName, sourceName, caseId, pageNo, pageSize, conditions);

	}

	/**
	 * @param relatedIds
	 * @param projectName
	 * @param activityName
	 * @param sourceName
	 * @param pageNo
	 * @param size
	 * @return
	 */
	@ApiOperation (value = "Get Related Record", response = ServiceResponse.class, tags = "Related Record")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Records"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/relatedRecord/{projectName}/{activityName}/{sourceName}/{relatedId}/{pageNo}/{size}")
	public Page<
					Object> getRelatedRecord(@PathVariable ("relatedId") String relatedIds, @PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName, @PathVariable ("sourceName") String sourceName, @PathVariable ("pageNo") int pageNo, @PathVariable ("size") int size) {
		return iReconSummaryService.getRelatedRecord(projectName, sourceName, activityName, relatedIds, pageNo, size);

	}

	@PostMapping (value = "/saveforceMatchHeaderDetails")
	public ForceMatchHeaderDetails saveForceMatchHeaderDetails(@RequestBody ForceMatchHeaderDetails forceMatchHeaderDetails) {

		logger.info("in recont header info {}", forceMatchHeaderDetails);
		return iReconSummaryService.saveForceMatchHeader(forceMatchHeaderDetails);

	}

	@GetMapping (value = "/getAllReconHeaders")
	public List<ForceMatchHeaderDetails> getAllReconHeaders() {

		return iReconSummaryService.findAllheaders();

	}

	@GetMapping (path = { "/getReconHeaderbyprojectnameandsource/{projectName}/{source}" })
	public ForceMatchHeaderDetails getReconHeadersbyProjectandsource(@PathVariable ("projectName") String projectName, @PathVariable ("source") String source) {

		return iReconSummaryService.findbyProjectNameandSourceName(projectName, source);

	}

	/**
	 * To change the status and substatus on record level input as List
	 * 
	 * @param projectName
	 * @param activityName
	 * @param sourceName
	 * @param caseId
	 * @param status
	 */
	@ApiOperation (value = "Change Status for List unreconcile", response = ServiceResponse.class, tags = "Change Status to Un-reconciled")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Status changed"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping (value = "/unreconcile/{projectName}/{activityName}")
	public ServiceResponse unreconcile(@RequestBody ForceMatchRequest forceMatchRequest, @PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName) {
		return this.iReconSummaryService.unreconcile(forceMatchRequest, projectName, activityName);

	}

}
