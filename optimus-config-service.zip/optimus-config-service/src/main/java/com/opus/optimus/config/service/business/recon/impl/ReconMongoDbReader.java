package com.opus.optimus.config.service.business.recon.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.config.service.business.recon.IReconSummaryService;
import com.opus.optimus.config.service.util.BeanUtilService;
import com.opus.optimus.config.service.util.OptimusRestClient;
import com.opus.optimus.offline.config.casemanagement.Priority;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.ReconStatusUpdateConfig;
import com.opus.optimus.offline.config.recon.subtypes.CaseStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKeyDate;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.ForceMatchRecordInfo;
import com.opus.optimus.ui.services.recon.ForceMatchedRecords;
import com.opus.optimus.ui.services.recon.RecordProcessingData;
import com.opus.optimus.ui.services.util.CommonUtil;
import com.opus.optimus.ui.services.util.MongoQueryFilter;

/**
 * The Class ReconMongoDbReader.
 */
@Service
public class ReconMongoDbReader {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconMongoDbReader.class);

	private static final String RECON_CONTROL_FIELDS = "reconControlFields";

	private static final String STATUS = "status";
	private static final String DATE = "Date";
	private static final String SUB_STATUS = "subStatus";
	private static final String DOT_OPERATOR = ".";
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	private static final String GMT_TIMEZONE = "GMT";
	private static final String PROCESSING_DATE = "processingDate";
	private static final String START_DATE = "startDate";
	private static final String END_DATE = "endDate";

	@Autowired
	private BeanUtilService beanUtilService;

	/** The data source factory. */
	private DataSourceFactory dataSourceFactory;

	@Autowired
	private IReconSummaryService reconSummaryService;

	@Autowired
	OptimusRestClient restClient;

	private IDataSource getDataSource(final MongoDBReaderConfig config) {
		try{
			String dataSourceName = config.getSourceDefinition().getDataSourceName();
			logger.debug("DataSource Name - {}", dataSourceName);
			dataSourceFactory = beanUtilService.getBeanObject(DataSourceFactory.class);
			return dataSourceFactory.getDataSource(dataSourceName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the transaction.
	 *
	 * @param config the config
	 * @param activityName the activity name
	 * @param parameters the parameters
	 * @param pagination the pagination
	 * @param filters the filters
	 * @return the transaction
	 */
	public Page<Object> getTransaction(final MongoDBReaderConfig config, String activityName, Map<String, Object> parameters, Map<String, Integer> pagination, List<MongoQueryFilter> filters) {
		logger.debug("Getting transaction summary");
		List<Object> records = new ArrayList<>();
		try{
			IDataSource dataSource = getDataSource(config);
			String collectionName = config.getSourceDefinition().getCollectionName();
			logger.debug("Source Collection -- {} ", collectionName);
			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				MongoDatabase database = mongoDataSource.getDatabase();

				MongoTemplate mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), database.getName());
				Pageable pageable = PageRequest.of(pagination.get("page").intValue(), pagination.get("size").intValue());
				Query query = new Query().with(pageable);

				Criteria criteria = getCondition(activityName, parameters);
				if (!filters.isEmpty()){
					criteria.andOperator(buildFilterConditions(filters));
				}
				query.addCriteria(criteria);

				mongoTemplate.executeQuery(query, collectionName, doc -> {
					doc.put("id", doc.get("_id").toString());
					logger.info("ReconControlInfo --->{}", doc);
					records.add(doc);
				});
				return PageableExecutionUtils.getPage(records, pageable, () -> mongoTemplate.count(query, collectionName));
			}
			throw new GenericException("Data source not available");
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * @param criteria
	 * @param filters
	 * @return
	 */
	private Criteria[] buildFilterConditions(List<MongoQueryFilter> filters) {

		List<Criteria> fieldCriterias = filters.stream().map(this::createCriteriaPerOperator).collect(Collectors.toList());
		return fieldCriterias.toArray(new Criteria[fieldCriterias.size()]);

	}

	private Criteria createCriteriaPerOperator(MongoQueryFilter dbQuery) {
		checkAndUpdateDateField(dbQuery);

		Criteria operatorCriteria = Criteria.where(dbQuery.getFieldName());
		switch (dbQuery.getOperatorLiteral()) {
		case EQUAL:
			operatorCriteria.is(dbQuery.getFieldValue());
			break;
		case GT:
			operatorCriteria.gt(dbQuery.getFieldValue());
			break;
		case GTE:
			operatorCriteria.gte(dbQuery.getFieldValue());
			break;
		case IN:
			String inValues = dbQuery.getFieldValue().toString();
			Object[] inValuesArray = inValues.split(",");
			operatorCriteria.in(inValuesArray);
			break;
		case LT:
			operatorCriteria.lt(dbQuery.getFieldValue());
			break;
		case LTE:
			operatorCriteria.lte(dbQuery.getFieldValue());
			break;
		case NOTEQUAL:
			operatorCriteria.ne(dbQuery.getFieldValue());
			break;
		case NOTIN:
			String values = dbQuery.getFieldValue().toString();
			Object[] valuesList = values.split(",");
			operatorCriteria.nin(valuesList);
			break;
		case LIKE:
			operatorCriteria.regex(dbQuery.getFieldValue().toString());
			break;
		default:
			break;
		}
		return operatorCriteria;
	}

	private void checkAndUpdateDateField(MongoQueryFilter dbQuery) {
		if (dbQuery.getFieldType() != null && dbQuery.getFieldType().equalsIgnoreCase(DATE)){
			SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT, Locale.ENGLISH);
			formatter.setTimeZone(TimeZone.getTimeZone(GMT_TIMEZONE));
			try{
				Date date = formatter.parse(dbQuery.getFieldValue().toString());
				dbQuery.setFieldValue(date);
			} catch (ParseException e){
				throw new GenericException(e);
			}
		}
	}

	/**
	 * Gets the condition.
	 *
	 * @param activityName the activity name
	 * @param parameters the parameters
	 * @return the condition
	 */
	private Criteria getCondition(String activityName, Map<String, Object> parameters) {
		String status = (String) parameters.get(STATUS);
		String subStatus = (String) parameters.get(SUB_STATUS);
		Date startDate = (Date) parameters.get(START_DATE);
		Date endDate = (Date) parameters.get(END_DATE);
		StringBuilder field = new StringBuilder(RECON_CONTROL_FIELDS).append(DOT_OPERATOR).append(activityName);
		Criteria criteria = Criteria.where(field.toString()).exists(true);

		if (null != status && !status.isEmpty()){
			criteria.and(field + DOT_OPERATOR + STATUS).is(status);
		}
		if (null != subStatus && !subStatus.isEmpty()){
			criteria.and(field + DOT_OPERATOR + SUB_STATUS).is(subStatus);
		}
		if (null != startDate){
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			criteria.and(field + DOT_OPERATOR + PROCESSING_DATE).gte(startDate).lt(endDate1);
		}

		return criteria;
	}

	private String getUser() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return (String) auth.getPrincipal();
	}

	/*	*//**
			 * Change status in db.
			 *
			 * @param collection the collection
			 * @param activityName the activity name
			 * @param recordId the record id
			 * @param comment the comment
			 * @return the date
			 */

	public ServiceResponse changeStatusinDb(MongoDBReaderConfig mongoDBReaderConfig, String activityName, String projectName, ForceMatchedRecords forceMatchedRecords, String remarks, String manReasonId, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, ConcurrentMap<
					SummaryKeyDate,
					List<ReconSourceSummary>> recordHolderTxnDate, String newRelatedRecordsRefId) {

		List<ForceMatchRecordInfo> recordsInfo = forceMatchedRecords.getSelectedRec();
		List<String> oids = new ArrayList<>();
		Set<String> refIds = new HashSet<>();
		Set<Date> processingDates = new HashSet<>();
		Set<Date> transactionDates = new HashSet<>();

		recordsInfo.forEach(recordInfo -> {
			oids.add(recordInfo.getRecId());
			refIds.add(recordInfo.getRelatedRecordsRefId());
			processingDates.add(recordInfo.getProcessingDate());
			transactionDates.add(recordInfo.getTransactionDate());
		});
		String dataSourceName = mongoDBReaderConfig.getSourceDefinition().getDataSourceName();
		String collectionName = mongoDBReaderConfig.getSourceDefinition().getCollectionName();
		logger.debug("DataSource Name : {}, Collection Name : {}", dataSourceName, collectionName);
		final IDataSource dataSource;
		try{
			dataSourceFactory = beanUtilService.getBeanObject(DataSourceFactory.class);

			dataSource = dataSourceFactory.getDataSource(dataSourceName);

			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				MongoDatabase database = mongoDataSource.getDatabase();

				MongoTemplate mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), database.getName());

				StringBuilder field = new StringBuilder(RECON_CONTROL_FIELDS + ".").append(activityName);

				BulkOperations bulkOps = mongoTemplate.bulkOps(BulkMode.UNORDERED, HashMap.class, collectionName);

				changesForceMatchStatus(bulkOps, oids, field, remarks, manReasonId, getUser(), newRelatedRecordsRefId);

				Query noMatchQuery = new Query();
				Criteria noMatchCriteria = Criteria.where("_id").nin(oids);
				noMatchCriteria.and(field + ".relatedRecordsRefId").in(refIds);
				noMatchQuery.addCriteria(noMatchCriteria);
				List<Object> records = new ArrayList<>();
				Map<String, String> refIdVsCaseIds = new HashMap<>();
				List<SalesforceCaseRequest> childcases = new ArrayList<>();
				mongoTemplate.executeQuery(noMatchQuery, collectionName, doc -> {
					doc.put("id", doc.get("_id").toString());
					records.add(doc);
					SalesforceCaseRequest salesForceCaseRequest = SalesforceCaseRequest.builder().referenceId(doc.get("_id").toString()).origin("Recon").reasonCode("NoMatch").status("OPEN").systemErrorType(Severity.ERROR).reasonCode("Marked as No match").project(projectName).activity(activityName).comment(remarks).contactSkypeName(getUser()).description("Records has been marked as No match").subject("No Match record").project(projectName).priority(Priority.MEDIUM).childcases(childcases).build();
					logger.debug("SalesForceRequest nomatch-->{}", salesForceCaseRequest);
					SalesforceCaseResponse response = restClient.createCase(salesForceCaseRequest);
					for (SalesforceCaseDetails details : response.getSuccessList()){
						refIdVsCaseIds.put(details.getReferenceId(), details.getCaseId());
					}
				});

				logger.info("Map of refernce id and Case id ==========>> {}", refIdVsCaseIds);

				changeNoMatchStatus(refIdVsCaseIds, bulkOps, field, remarks, manReasonId, getUser());

				MongoCollection<Document> collection = database.getCollection(collectionName);
				reconSummaryService.updateSummaryResults(recordHolder, collection, activityName, forceMatchedRecords);
				transactionDates.forEach(transactionDate -> reconSummaryService.updateSummaryResultsForTxnDate(recordHolderTxnDate, collection, activityName, forceMatchedRecords, transactionDate));
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Records updated", null);
			}
		} catch (NoSuchDataSourceAvailableException | DataSourceInitializationException e){
			throw new GenericException(e);
		} catch (GenericException e){
			throw e;
		}
		return new ServiceResponse(500, ResponseStatus.FAILED, "Records Not updated", "Mongo data source not found");
	}

	/**
	 * @param bulkOps
	 * @param oids
	 * @param field
	 * @param remarks
	 * @param manReasonId
	 * @param userName
	 */
	void changesForceMatchStatus(BulkOperations bulkOps, List<String> oids, StringBuilder field, String remarks, String manReasonId, String userName, String newRelatedRecordsRefId) {
		Query forceMatchQuery;
		for (String oid : oids){
			forceMatchQuery = new Query();
			Criteria criteria = Criteria.where("_id").is(oid);
			forceMatchQuery.addCriteria(criteria);
			Update update = new Update();
			update.set(field + DOT_OPERATOR + STATUS, ReconStatus.RECONCILED.toString());
			update.set(field + DOT_OPERATOR + SUB_STATUS, ReconSubStatus.ForceMatch.toString());
			update.set(field + ".caseInfo.status", CaseStatus.CLOSE.toString());
			update.set(field + ".caseInfo.closureComments", remarks);
			update.set(field + ".manReasonComments", remarks);
			update.set(field + ".manReasonId", manReasonId);
			update.set(field + ".updatedBy", userName);
			update.set(field + ".relatedRecordsRefId", newRelatedRecordsRefId);
			bulkOps.updateOne(forceMatchQuery, update);
			bulkOps.execute();

		}
	}

	/**
	 * @param bulkOps
	 * @param oids
	 * @param field
	 * @param remarks
	 * @param manReasonId
	 * @param userName
	 */
	void changeUnreconciledStatus(BulkOperations bulkOps, List<ForceMatchRecordInfo> records, String field, String remarks, String manReasonId, String userName, Map<String, RecordProcessingData> refIdVsCaseIds, ReconStatusUpdateConfig reconStatusUpdate) {
		Query unreconciledQuery;
		for (Map.Entry<String, RecordProcessingData> entry : refIdVsCaseIds.entrySet()){
			unreconciledQuery = new Query();
			Criteria criteria = Criteria.where("_id").is(entry.getKey());
			unreconciledQuery.addCriteria(criteria);

			UUID newRelatedRecordsRefId = UUID.randomUUID();
			Date newDate = entry.getValue().getProcessingDate();
			logger.debug("New Date for Un reconcilliation -- {} ", newDate);
			LocalDateTime localDatNew = newDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
			localDatNew = localDatNew.plusDays(reconStatusUpdate.getTimeLegInterval());
			Date date = Date.from(localDatNew.atZone(ZoneId.systemDefault()).toInstant());
			final Date currDate = Date.from(java.time.LocalDate.now().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());

			Update update = new Update();
			update.set(field + DOT_OPERATOR + STATUS, ReconStatus.UNRECONCILED.toString());
			if (reconStatusUpdate.isUnreconciledBacklog() && currDate.after(date)){
				update.set(field + DOT_OPERATOR + SUB_STATUS, ReconSubStatus.Aged.toString());
			} else{
				update.set(field + DOT_OPERATOR + SUB_STATUS, ReconSubStatus.NoMatch.toString());
			}
			update.set(field + ".caseInfo.status", CaseStatus.OPEN.toString());
			update.set(field + ".caseInfo.closureComments", remarks);
			update.set(field + ".caseInfo.caseID", entry.getValue().getCaseID());
			update.set(field + ".manReasonComments", remarks);
			update.set(field + ".manReasonId", manReasonId);
			update.set(field + ".updatedBy", userName);
			update.set(field + ".relatedRecordsRefId", newRelatedRecordsRefId.toString());
			bulkOps.updateOne(unreconciledQuery, update);
			bulkOps.execute();
		}
	}

	/**
	 * @param refIdVsCaseIds
	 * @param bulkOps
	 * @param field
	 * @param remarks
	 * @param manReasonId
	 * @param userName
	 */
	void changeNoMatchStatus(Map<String, String> refIdVsCaseIds, BulkOperations bulkOps, StringBuilder field, String remarks, String manReasonId, String userName) {
		for (Map.Entry<String, String> entry : refIdVsCaseIds.entrySet()){
			Query updateNomatchQuery = new Query();
			Criteria criteria = Criteria.where("_id").is(entry.getKey());
			updateNomatchQuery.addCriteria(criteria);
			Update update = new Update();
			update.set(field + DOT_OPERATOR + STATUS, ReconStatus.UNRECONCILED.toString());
			update.set(field + DOT_OPERATOR + SUB_STATUS, ReconSubStatus.NoMatch.toString());
			update.set(field + ".caseInfo.caseID", entry.getValue());
			update.set(field + ".caseInfo.status", CaseStatus.OPEN.toString());
			update.set(field + ".caseInfo.closureComments", remarks);
			update.unset(field + ".relatedRecordsRefId");
			update.set(field + ".manReasonComments", remarks);
			update.set(field + ".manReasonId", manReasonId);
			update.set(field + ".updatedBy", userName);
			bulkOps.updateOne(updateNomatchQuery, update);
			bulkOps.execute();
		}
	}

	/**
	 * @param mongoDBReaderConfig
	 * @param relatedIds
	 * @param pageNo
	 * @param size
	 * @return
	 */
	public Page<Object> getRelatedRecord(MongoDBReaderConfig mongoDBReaderConfig, String relatedIds, int pageNo, int size) {

		try{
			List<Object> records = new ArrayList<>();
			String dataSourceName = mongoDBReaderConfig.getSourceDefinition().getDataSourceName();
			String collectionName = mongoDBReaderConfig.getSourceDefinition().getCollectionName();
			logger.info("DataSource Name - {}, Collection Name - {}", dataSourceName, collectionName);
			dataSourceFactory = beanUtilService.getBeanObject(DataSourceFactory.class);
			final IDataSource dataSource = dataSourceFactory.getDataSource(dataSourceName);

			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				MongoDatabase database = mongoDataSource.getDatabase();

				MongoTemplate mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), database.getName());
				Pageable pageable = PageRequest.of(pageNo, size);
				Query query = new Query().with(pageable);

				String activityName = mongoDBReaderConfig.getSourceDefinition().getActivityName();
				Criteria criteria = Criteria.where(RECON_CONTROL_FIELDS + "." + activityName + ".relatedRecordsRefId").is(relatedIds);

				query.addCriteria(criteria);

				mongoTemplate.executeQuery(query, collectionName, doc -> {
					doc.put("id", doc.get("_id").toString());
					logger.info("Document--{}", doc);
					records.add(doc);
				});
				return PageableExecutionUtils.getPage(records, pageable, () -> mongoTemplate.count(query, collectionName));
			} else{
				throw new GenericException("Data source not found");
			}
		} catch (GenericException e){
			throw e;

		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	public Page<Object> getForceMatchDataByCaseID(MongoDBReaderConfig mongoDBReaderConfig, String caseId, int pageNo, int size, List<MongoQueryFilter> conditions) {
		try{
			List<Object> records = new ArrayList<>();
			String dataSourceName = mongoDBReaderConfig.getSourceDefinition().getDataSourceName();
			String collectionName = mongoDBReaderConfig.getSourceDefinition().getCollectionName();
			logger.info("DataSource Name - {}, Collection Name - {}", dataSourceName, collectionName);
			dataSourceFactory = beanUtilService.getBeanObject(DataSourceFactory.class);
			final IDataSource dataSource = dataSourceFactory.getDataSource(dataSourceName);

			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				MongoDatabase database = mongoDataSource.getDatabase();

				MongoTemplate mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), database.getName());
				Pageable pageable = PageRequest.of(pageNo, size);
				Query query = new Query().with(pageable);

				String activityName = mongoDBReaderConfig.getSourceDefinition().getActivityName();
				Criteria criteria = Criteria.where(RECON_CONTROL_FIELDS + "." + activityName + ".caseInfo.caseID").is(caseId);
				if (!conditions.isEmpty()){
					criteria.andOperator(buildFilterConditions(conditions));
				}
				query.addCriteria(criteria);

				mongoTemplate.executeQuery(query, collectionName, doc2 -> {
					doc2.put("id", doc2.get("_id").toString());
					logger.info("Document--{}", doc2);
					records.add(doc2);
				});
				return PageableExecutionUtils.getPage(records, pageable, () -> mongoTemplate.count(query, collectionName));
			} else{
				throw new GenericException("Data source not found");
			}
		} catch (GenericException e){
			throw e;

		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/*	*//**
			 * Change status in db.
			 *
			 * @param collection the collection
			 * @param activityName the activity name
			 * @param recordHolderTxnDate
			 * @param recordId the record id
			 * @param comment the comment
			 * @return the date
			 */

	public ServiceResponse changeStatusinDbforUnreconcile(MongoDBReaderConfig mongoDBReaderConfig, String activityName, String projectName, ForceMatchedRecords forceMatchedRecords, String remarks, String manReasonId, ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, ConcurrentMap<
					SummaryKeyDate,
					List<ReconSourceSummary>> recordHolderTxnDate, ReconStatusUpdateConfig reconStatusUpdate) {
		logger.info("Changing status to unreconcile");
		List<ForceMatchRecordInfo> recordsInfo = forceMatchedRecords.getSelectedRec();
		List<String> oids = new ArrayList<>();
		Set<String> refIds = new HashSet<>();
		Set<Date> processingDates = new HashSet<>();
		Set<Date> transactionDates = new HashSet<>();
		recordsInfo.forEach(recordInfo -> {
			oids.add(recordInfo.getRecId());
			refIds.add(recordInfo.getRelatedRecordsRefId());
			refIds.add(recordInfo.getRelatedRecordsRefId());
			processingDates.add(recordInfo.getProcessingDate());
			transactionDates.add(recordInfo.getTransactionDate());
		});

		String dataSourceName = mongoDBReaderConfig.getSourceDefinition().getDataSourceName();
		String collectionName = mongoDBReaderConfig.getSourceDefinition().getCollectionName();
		logger.debug("DataSource Name : {}, Collection Name : {}", dataSourceName, collectionName);
		final IDataSource dataSource;
		try{
			dataSourceFactory = beanUtilService.getBeanObject(DataSourceFactory.class);

			dataSource = dataSourceFactory.getDataSource(dataSourceName);

			if (MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				final MongoDataSource mongoDataSource = (MongoDataSource) dataSource;
				MongoDatabase database = mongoDataSource.getDatabase();

				MongoTemplate mongoTemplate = new MongoTemplate(mongoDataSource.getMongoClient(), database.getName());
				String field = RECON_CONTROL_FIELDS + "." + activityName;
				BulkOperations bulkOps = mongoTemplate.bulkOps(BulkMode.UNORDERED, HashMap.class, collectionName);

				/**
				 * Saleforce case creation
				 */

				Query matchQuery = new Query();
				Criteria matchCriteria = Criteria.where(field + ".relatedRecordsRefId").is(recordsInfo.get(0).getRelatedRecordsRefId());
				matchQuery.addCriteria(matchCriteria);
				List<Object> records = new ArrayList<>();
				Map<String, RecordProcessingData> mongoIDVsCaseIds = new HashMap<>();
				List<SalesforceCaseRequest> childcases1 = new ArrayList<>();
				mongoTemplate.executeQuery(matchQuery, collectionName, doc -> {
					doc.put("id", doc.get("_id").toString());
					records.add(doc);
					logger.debug("document {}" + doc.toJson());
					RecordProcessingData recordProcessingData = new RecordProcessingData();
					if (null != ((Document) ((Document) doc.get(RECON_CONTROL_FIELDS)).get(activityName)).getDate("processingDate")){
						recordProcessingData.setProcessingDate(((Document) ((Document) doc.get(RECON_CONTROL_FIELDS)).get(activityName)).getDate("processingDate"));
					}
					SalesforceCaseRequest salesForceCaseRequest = SalesforceCaseRequest.builder().referenceId(doc.get("_id").toString()).origin("Recon").reasonCode("NoMatch").status("OPEN").systemErrorType(Severity.ERROR).reasonCode("Marked as No match").project(projectName).activity(activityName).comment(remarks).contactSkypeName(getUser()).description("Records has been marked as No match").subject("No Match record").project(projectName).priority(Priority.MEDIUM).childcases(childcases1).build();
					logger.debug("SalesForceRequest nomatch-->{}", salesForceCaseRequest);
					SalesforceCaseResponse response = restClient.createCase(salesForceCaseRequest);
					for (SalesforceCaseDetails details : response.getSuccessList()){
						recordProcessingData.setCaseID(details.getCaseId());
						mongoIDVsCaseIds.put(details.getReferenceId(), recordProcessingData);

					}
				});

				/**
				 * Updating status of all mongoIDVsCaseIds
				 */
				changeUnreconciledStatus(bulkOps, recordsInfo, field, remarks, manReasonId, getUser(), mongoIDVsCaseIds, reconStatusUpdate);

				MongoCollection<Document> collection = database.getCollection(collectionName);
				reconSummaryService.updateSummaryResults(recordHolder, collection, activityName, forceMatchedRecords);
				transactionDates.forEach(transactionDate -> reconSummaryService.updateSummaryResultsForTxnDate(recordHolderTxnDate, collection, activityName, forceMatchedRecords, transactionDate));
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Records updated", null);
			}
		} catch (NoSuchDataSourceAvailableException | DataSourceInitializationException e){
			throw new GenericException(e);
		} catch (GenericException e){
			throw e;
		}
		return new ServiceResponse(500, ResponseStatus.FAILED, "Records Not updated", "Mongo data source not found");
	}

}
