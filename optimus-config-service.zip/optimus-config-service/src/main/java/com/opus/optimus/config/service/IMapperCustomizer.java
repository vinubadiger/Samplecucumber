package com.opus.optimus.config.service;

/**
 * The Interface IMapperCustomizer.
 *
 * @param <T> the generic type
 */
@FunctionalInterface
public interface IMapperCustomizer<T> {

	/**
	 * Customize.
	 *
	 * @param data the data
	 */
	void customize(T data);
}
