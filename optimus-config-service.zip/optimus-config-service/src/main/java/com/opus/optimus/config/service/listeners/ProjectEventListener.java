package com.opus.optimus.config.service.listeners;

import static com.opus.optimus.config.service.constant.ConfigServiceConstant.DELETE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.ID;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant.SAVE;
import static com.opus.optimus.config.service.constant.ConfigServiceConstant._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.config.service.repository.audit.ProjectAuditRepository;
import com.opus.optimus.config.service.repository.etl.ProjectRepository;
import com.opus.optimus.config.service.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.ProjectAudit;
import com.opus.optimus.ui.services.project.Project;

@Component
public class ProjectEventListener extends AbstractMongoEventListener<Project> {
	private static final Logger log = LoggerFactory.getLogger(ProjectEventListener.class);

	@Autowired
	private ProjectAuditRepository projectAuditRepository;

	@Autowired
	private ProjectRepository projectRepository;

	private Project projectStore;

	@Override
	public void onAfterSave(AfterSaveEvent<Project> event) {
		ProjectAudit projectAudit = getProjectAudit(event.getSource());
		projectAudit.setAction(SAVE);
		projectAuditRepository.save(projectAudit);

	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<Project> event) {
		storeProject(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<Project> event) {
		ProjectAudit projectAudit = getProjectAudit(projectStore);
		projectAudit.setAction(DELETE);
		projectAuditRepository.save(projectAudit);
	}

	private ProjectAudit getProjectAudit(Project project) {
		ProjectAudit projectAudit = new ProjectAudit();
		BeanUtils.copyProperties(project, projectAudit, ID);
		setAdditionalAuditingFields(project, projectAudit);
		return projectAudit;
	}

	private void setAdditionalAuditingFields(Project project, ProjectAudit projectAudit) {
		projectAudit.setDocumentId(project.getId());
		projectAudit.setVersion(GetVersionNumber.getVersion());

	}

	private void storeProject(BeforeDeleteEvent<Project> event) {
		Optional<Project> project = projectRepository.findById(event.getDocument().get(_ID).toString());
		if (project.isPresent()){
			projectStore = project.get();
		}
	}

}
