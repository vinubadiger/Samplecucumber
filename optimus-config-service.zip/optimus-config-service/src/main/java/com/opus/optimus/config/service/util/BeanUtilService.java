package com.opus.optimus.config.service.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.annotation.Configuration;

import com.opus.optimus.offline.config.exception.GenericException;

/**
 * The Class BeanUtilService.
 */
@Configuration
public class BeanUtilService implements BeanDefinitionRegistryPostProcessor {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(BeanUtilService.class);

	/** The application context. */
	private ConfigurableListableBeanFactory beanFactory;

	/**
	 * Gets the bean object.
	 *
	 * @param <T> the generic type
	 * @param requiredType the required type
	 * @return the bean object
	 */
	public synchronized <T> T getBeanObject(Class<T> requiredType) {
		try{
			logger.debug("Fetching Bean object from container for class {}", requiredType.getName());
			String beanName = requiredType.getName();
			if (beanFactory.containsBean(beanName)){
				logger.debug("Found bean for type {}", beanName);
				return beanFactory.getBean(requiredType);
			} else{
				logger.debug("Bean not Found for type {}; Registering one !!", beanName);
				Object singletonObject = beanFactory.createBean(requiredType, AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, true);
				beanFactory.registerSingleton(beanName, singletonObject);
				return beanFactory.getBean(requiredType);
			}
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory2) {
		beanFactory = beanFactory2;
	}

	@Override
	public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry2) {
		logger.debug("Not required to set registry for now");
	}
}