package com.opus.optimus.config.service.repository.scheduler;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Interface BatchDefinitionRepository.
 */
@Repository ("batchDefinitionRepository")
public interface BatchDefinitionRepository extends MongoRepository<BatchDefinition, String> {

	/**
	 * Find workflow by given data.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the batch definition
	 */
	@Query (value = "{ $and : [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	BatchDefinition findWorkflowByGivenData(String projectName, String workflowName, String workflowType);

}