package com.opus.optimus.config.service.business.recon;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import org.bson.Document;
import org.springframework.data.domain.Page;

import com.mongodb.client.MongoCollection;
import com.opus.optimus.offline.config.recon.ReconSourceSummary;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey;
import com.opus.optimus.offline.config.recon.subtypes.SummaryKeyDate;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.recon.ForceMatchHeaderDetails;
import com.opus.optimus.ui.services.recon.ForceMatchRequest;
import com.opus.optimus.ui.services.recon.ForceMatchedRecords;
import com.opus.optimus.ui.services.util.MongoQueryFilter;

/**
 * The Interface ReconSummaryService.
 */
public interface IReconSummaryService {

	/**
	 * Gets the summary.
	 *
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param filters
	 * @param pageNo the page no
	 * @param size the size
	 * @param subStatus
	 * @param status
	 * @param endDate
	 * @param startDate
	 * @return the summary
	 * @throws Exception
	 */
	Page<Object> getSummary(String projectName, String activityName, String sourceName, Map<String, Object> parameters, Map<String, Integer> paginationDetails, List<MongoQueryFilter> filters) throws Exception;

	/**
	 * @param recordHolder
	 * @param projectName
	 * @param activityName
	 * @param sourceName
	 * @param recordId
	 * @param caseId
	 */
	ServiceResponse forceMatch(ForceMatchRequest forceMatchRequest, String projectName, String activityName);

	/**
	 * @param projectName
	 * @param sourceName
	 * @param activityName
	 * @param relatedIds
	 * @param page
	 * @param size
	 * @return
	 */
	Page<Object> getRelatedRecord(String projectName, String sourceName, String activityName, String relatedIds, int page, int size);

	ForceMatchHeaderDetails saveForceMatchHeader(ForceMatchHeaderDetails forceMatchHeaderDetails);

	List<ForceMatchHeaderDetails> findAllheaders();

	ForceMatchHeaderDetails findbyProjectNameandSourceName(String projectName, String sourceName);

	void updateSummaryResults(ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder, MongoCollection<Document> collection, String activityName, ForceMatchedRecords forceMatchedRecord);

	void updateSummaryResultsForTxnDate(ConcurrentMap<SummaryKeyDate, List<ReconSourceSummary>> recordHolderTxnDate, MongoCollection<Document> collection, String activityName, ForceMatchedRecords forceMatchedRecord, Date transactionDate);

	Page<Object> getForceMatchDataByCaseID(String projectName, String activityName, String sourceName, String caseId, int pageNo, int size, List<MongoQueryFilter> conditions);

	/**
	 * @param forceMatchRequest
	 * @param projectName
	 * @param activityName
	 * @return
	 */
	ServiceResponse unreconcile(ForceMatchRequest forceMatchRequest, String projectName, String activityName);
}
