package com.opus.optimus.config.test.controller.reconsummary

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.bson.Document
import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import com.mongodb.MongoClient
import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.MapperFactory
import com.opus.optimus.config.service.UserAudtiting
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.util.OptimusRestClient
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.ui.services.recon.Activity
import com.opus.optimus.ui.services.recon.ForceMatchHeaderDetails
import com.opus.optimus.ui.services.recon.ForceMatchRecordInfo
import com.opus.optimus.ui.services.recon.ForceMatchRequest
import com.opus.optimus.ui.services.recon.ForceMatchedRecords
import com.opus.optimus.ui.services.scheduler.CaseCloseResponse
import com.opus.optimus.ui.services.util.MongoQueryFilter
import de.flapdoodle.embed.mongo.MongodExecutable
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import groovy.json.JsonOutput
import spock.lang.Specification
import com.mongodb.BasicDBObjectBuilder

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@TestPropertySource(locations="classpath:application-test.properties")
class ReconSummaryControllerTest extends Specification {

	/*@Configuration
	 static class EmbeddedMongoTemplateConfiguration {
	 @Bean
	 @Primary //may omit this if this is the only SomeBean defined/visible
	 public MongoTemplate mongoTemplate () {
	 }
	 }*/

	@Autowired
	protected MockMvc mvc;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	MongoTemplate mongoTemplate;

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	UserAudtiting userAudtiting = Stub(UserAudtiting.class);

	@SpringBean
	OptimusRestClient restClient = Stub(OptimusRestClient.class);


	@Autowired
	DataSourceFactory dataSourceFactory;




	def object;
	def condition;
	def activity;
	def mongoDataSourceMeta;
	def AmexDI;
	ForceMatchRequest forceMatchRequest;
	SalesforceCaseResponse response ;
	ForceMatchRequest f1


	List<MongoQueryFilter> conditions = new ArrayList()

	private MongodExecutable mongodExecutable;
	private MongoTemplate mongoTemplate;

	def setup() {
		String ip = "localhost";
		int port = 27017;

		IMongodConfig mongodConfig = new MongodConfigBuilder().version(Version.Main.V3_5)
				.net(new Net(ip, port, Network.localhostIsIPv6()))
				.build();

		MongodStarter starter = MongodStarter.getDefaultInstance();
		mongodExecutable = starter.prepare(mongodConfig);
		mongodExecutable.start();
		mongoTemplate = new MongoTemplate(new MongoClient(ip, port), "test");

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/ForceMatchheaderDetails.json")
		object = mapper.readValue(jsonStream, ForceMatchHeaderDetails.class)

		def jsonStreamConditions = getClass().getResourceAsStream("/MongoQueryfilter.json")
		condition = mapper.readValue(jsonStreamConditions, MongoQueryFilter.class)

		def jsonStreamActivity = getClass().getResourceAsStream("/Activity.json")
		activity = mapper.readValue(jsonStreamActivity, Activity.class)

		def jsonforceMatchRequest = getClass().getResourceAsStream("/ForceMatchRequest.json")
		forceMatchRequest = mapper.readValue(jsonforceMatchRequest, ForceMatchRequest.class)

		def jsonStreamMeta = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		mongoDataSourceMeta = mapper.readValue(jsonStreamMeta, MongoDataSourceMeta.class)

		mongoTemplate.save(mongoDataSourceMeta,"MongoDataSourceMeta");


		def mongoDataSource = new MongoDataSource(mongoDataSourceMeta);
		mongoDataSource.init()
		dataSourceFactory.register(mongoDataSourceMeta.getDataSourceName(), mongoDataSource);

		File file = new File(getClass().getResource("/Amex.txt").getPath())
		String fileContent = file.text
		def dbObject = Document.parse(fileContent)

		mongoTemplate.save(dbObject, "AmexDI")

		file = new File(getClass().getResource("/Ptech.txt").getPath())
		fileContent = file.text
		dbObject = Document.parse(fileContent)
		/* dbObject =	BasicDBObjectBuilder.start()
		 .add("reconControlFields.TestActivity.processingDate", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2018-12-06T05:30:00.000Z"))
		 .get()*/
		mongoTemplate.save(dbObject, "PtechDI")



		SimpleDateFormat formatTranDate = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat formatProcessingDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date   transactionDate = formatTranDate.parse ( "2018-12-06" );
		Date   processingDate  = formatProcessingDate.parse ( "2012-01-31 23:59:48" );


		List<ForceMatchRecordInfo> selectedRec = new ArrayList<>();
		ForceMatchRecordInfo rec = ForceMatchRecordInfo.builder().recId("5cc1b7f3090b600006728d10").caseID("5000j000003KA2FAAW").relatedRecordsRefId("67e4f235-09a1-4899-8b0d-a935fe56f34d")/*.processingDate(processingDate)*/.transactionDate(transactionDate).build()
		selectedRec.add(rec)

		ForceMatchedRecords sourceA = ForceMatchedRecords.builder().sourceName("Ptech").stepName("Source-A").selectedRec(selectedRec).build();
		ForceMatchedRecords sourceB = ForceMatchedRecords.builder().sourceName("Amex").stepName("Source-B").selectedRec(selectedRec).build();

		f1 = ForceMatchRequest.builder().remarks("test").sourceA(sourceA).sourceB(sourceB).manReasonId("test").build()





		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userAudtiting.getCurrentAuditor()>> Optional.of("user1");
	}


	def "Get Summary with Pagination"() {


		when:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(activity))
				).andReturn()

		def response = mvc.perform(
				post('/GetReconRecordSummary/reconSummary/getSummary/TestProject/TestActivity/Amex/0/15')
				.contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(conditions)).param("status","UNRECONCILED").param("subStatus","MultipleMatches")
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		//		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	def "Get Recon by case ID"() {
		when:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(activity))
				).andReturn()
		def response = mvc.perform(
				post('/GetReconRecordSummary/reconSummary/getRecordByCaseId/TestProject/TestActivity/Amex/5000j000003KA2FAAW/0/10')
				.contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(conditions))
				).andReturn()
		then:
		response.getResponse().getStatus() == 200
	}
	def "Get Recon Headers by projectName and Source name"() {
		given:
		mvc.perform(
				post('/GetReconRecordSummary/reconSummary/saveforceMatchHeaderDetails').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()
		when:
		def response = mvc.perform(
				get('/GetReconRecordSummary/reconSummary/getReconHeaderbyprojectnameandsource/Service-Payments-Postpaid/Samson')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("projectName").equals("Service-Payments-Postpaid") &&
				containerObject.getString("sourceName").equals("Samson")
	}
	def "Get All Recon Headers"() {
		given:
		mvc.perform(
				post('/GetReconRecordSummary/reconSummary/saveforceMatchHeaderDetails').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()
		when:
		def response = mvc.perform(
				get('/GetReconRecordSummary/reconSummary/getAllReconHeaders')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("projectName").equals("Service-Payments-Postpaid") &&
				containerObject.getString("sourceName").equals("Samson")
	}
	def "Get Related Records"() {
		when:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(activity))
				).andReturn()
		def response = mvc.perform(
				get('/GetReconRecordSummary/reconSummary/relatedRecord/TestProject/TestActivity/Amex/67e4f235-09a1-4899-8b0d-a935fe56f34d/0/10')
				).andReturn().response
		then:
		response.status == 200
	}



	def "ForceMatch : change the status and substatus on record level input"() {
		given:


		SalesforceCaseResponse createCaseresponse = new SalesforceCaseResponse();
		SalesforceCaseDetails salesforceCaseDetails = new SalesforceCaseDetails();
		salesforceCaseDetails.setCaseId("5000j000003KA2FAAW");
		List<SalesforceCaseDetails> successList = new ArrayList();
		successList.add(salesforceCaseDetails)
		createCaseresponse.setSuccessList(successList);

		restClient.createCase(_)>>createCaseresponse;
		CaseCloseResponse caseReponse = new CaseCloseResponse();
		restClient.closeCase("", "", "Reconciled", "Forcematch")>>caseReponse




		when:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(activity))
				).andReturn()

		def response = mvc.perform(
				post('/GetReconRecordSummary/reconSummary/forceMatch/TestProject/TestActivity').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(f1))
				).andReturn().response
		then:
		response.status == 200
	}


	def "Unreconcile : change the status and substatus on record level input"() {
		given:

		SalesforceCaseResponse createCaseresponse = new SalesforceCaseResponse();
		SalesforceCaseDetails salesforceCaseDetails = new SalesforceCaseDetails();
		salesforceCaseDetails.setCaseId("5000j000003KA2FAAW");
		List<SalesforceCaseDetails> successList = new ArrayList();
		successList.add(salesforceCaseDetails)
		createCaseresponse.setSuccessList(successList);

		restClient.createCase(_)>>createCaseresponse;

		CaseCloseResponse caseReponse = new CaseCloseResponse();
		restClient.closeCase(_, _, _, _)>>caseReponse
		when:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(activity))
				).andReturn()

		def response = mvc.perform(
				post('/GetReconRecordSummary/reconSummary/unreconcile/TestProject/TestActivity').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(f1))
				).andReturn().response
		then:
		response.status == 200
	}




	def cleanup() {
		mongoTemplate.getDb().drop();
		mongodExecutable.stop();
	}
}