package com.opus.optimus.config.test.service.util

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.security.authentication.AnonymousAuthenticationToken
import org.springframework.security.core.Authentication
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.test.context.TestPropertySource
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.util.UserContextUtility
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")

class UserContextUtilityTest extends Specification {
	
	@Autowired
	UserContextUtility userContextUtility
	
	def "getLoggedUsername"() {
		given:
		SecurityContextHolder.getContext().getAuthentication()>>null
		when:
		String reponse = userContextUtility.getLoggedUsername();
		then:
		reponse==null
	}

	
	def "checkIfAdminUser"(){
		
		when:
		boolean response = userContextUtility.checkIfAdminUser()
		then:
		thrown  GenericException
		
	}
}
