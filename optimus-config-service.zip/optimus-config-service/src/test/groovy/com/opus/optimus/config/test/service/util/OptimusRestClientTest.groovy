package com.opus.optimus.config.test.service.util

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.web.client.RestTemplate

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.MapperFactory
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.util.OptimusRestClient
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.ui.services.scheduler.CaseCloseResponse
import com.opus.optimus.ui.services.scheduler.CaseCreation
import com.opus.optimus.ui.services.scheduler.CaseResponse

import spock.lang.Ignore
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")

class OptimusRestClientTest extends Specification {

	@Autowired
	protected OptimusRestClient OptimusClient;
	@Autowired
	MapperFactory mapperFactory
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	
	@SpringBean(name ="com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper")
	SalesforceCaseHelper salesforceCaseHelper = Stub(SalesforceCaseHelper.class);

	@SpringBean
	RestTemplate restTemplate = Stub(RestTemplate.class);

	CaseCloseResponse caseCloseResponse;
	CaseCreation caseCreation
	SalesforceCaseRequest salesforceCaseRequest
	SalesforceCaseResponse salesforceCaseResponse;
	
	MongoDataSourceMeta dataSourceMeta;
	
	def response;
	def setup() {
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/SalesforceCaseRequest.json")
		salesforceCaseRequest = mapper.readValue(jsonStream, SalesforceCaseRequest.class)
		
		caseCloseResponse = new CaseCloseResponse();
		caseCloseResponse.setHasError(false);


		caseCreation = new CaseCreation();
	}

	def "Test Close case"(){
		when :
		restTemplate.postForObject(_, _, _)>> "recievedtoken";
		restTemplate.patchForObject(_, _, _)>> response;
		
	
		
		OptimusClient.closeCase("101",  "test comment", "For testing reason", " reasonCode")
		then :
		caseCloseResponse.isHasError() == false
	}
	
	def "Test Create case"(){
		given :
		
		salesforceCaseResponse = new SalesforceCaseResponse();
		salesforceCaseResponse.setHasError(false)
		salesforceCaseHelper.createCase(_, _)>>salesforceCaseResponse;
		when :
		OptimusClient.createCase(salesforceCaseRequest);
		
		then :
		caseCloseResponse.isHasError() == false
	}
	
	def "Remove Mongo Data Source factory"(){
		given:
		restTemplate.delete(_, _)>> null;
		 dataSourceMeta =  new MongoDataSourceMeta();
		  dataSourceMeta.setDataSourceName("config-database");
		when:
		OptimusClient.removeOfflineMongoDataSourceFactory( dataSourceMeta)
		then:
		println("method is completed")
	}
	
	def "update mongo data source factory"(){
		given:
		restTemplate.postForObject(_, _, _)>>null;
		when:
		OptimusClient.updateOfflineMongoDataSourceFactory(dataSourceMeta);
		then:
		println("updated datasource factory")
	}
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
