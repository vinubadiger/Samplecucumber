package com.opus.optimus.config.test.service.workflow

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.business.IWorkflowService
import com.opus.optimus.config.service.business.scheduler.BatchDefinitionService
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.repository.etl.WorkflowRepository
import com.opus.optimus.config.service.util.OptimusRestClient
import com.opus.optimus.config.service.util.UserContextUtility
import com.opus.optimus.ui.constants.ResponseStatus
import com.opus.optimus.ui.constants.ServiceResponse
import com.opus.optimus.ui.services.project.Workflow
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class WorkflowServiceTest extends Specification{
	@Autowired
	private IWorkflowService wfService;

	@SpringBean
	WorkflowRepository workflowRepository = Stub(WorkflowRepository.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	private BatchDefinitionService batchDefinitionService

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	Workflow wf ;
	ServiceResponse response
	def setup() {
		userContextUtility.checkIfAdminUser() >> true
	}

	def "Delete Workflow"(){
		given :
		wf = new Workflow()
		wf.setProjectName("TestProject")
		wf.setWorkflowName("TestWorkflow")
		wf.setWorkflowType("ETL");
		this.workflowRepository.findWorkFlowByProjectName(_, _, _)>>wf;
		when:
		ServiceResponse response = wfService.deleteWorkflow("TestProject","TestWorkflow","ETL")
		then:
		response.getStatus()== ResponseStatus.SUCCESS
	}
	def "Delete Workflow when workflow not exists"(){

		when:
		ServiceResponse response = wfService.deleteWorkflow("TestProject","TestWorkflow1","ETL")
		then:
		response.getStatus()== ResponseStatus.SUCCESS
	}

	def "Delete Workflow when workflow is null"(){
		given :
		Workflow wf = null;
		this.workflowRepository.findWorkFlowByProjectName(_, _, _)>>wf
		when:
		ServiceResponse response = wfService.deleteWorkflow("TestProject","TestWorkflow1","ETL")
		then:
		response.getStatus()== ResponseStatus.FAILED
	}

	def "Delete Workflow when batch definition not exists"(){
		given :
		wf = new Workflow()
		wf.setProjectName("TestProject")
		wf.setWorkflowName("TestWorkflow")
		wf.setWorkflowType("ETL");
		response= new ServiceResponse(500,ResponseStatus.FAILED,"Batch definition not exists",null);
		this.workflowRepository.findWorkFlowByProjectName(_, _, _)>>wf;
		this.batchDefinitionService.delete(_, _, _)>>response
		when:
		ServiceResponse response = wfService.deleteWorkflow("TestProject","TestWorkflow1","ETL")
		then:
		response.getStatus()== ResponseStatus.SUCCESS
	}


	def "Duplicate Workflow for projects"(){
		given :
		wf = new Workflow()
		wf.setProjectName("TestProject")
		wf.setWorkflowName("TestWorkflow")
		wf.setWorkflowType("ETL");
		this.workflowRepository.findWorkFlowByProjectName(_, _, _)>>wf;
		when:
		ServiceResponse response =wfService.duplicate("TestProject","New_Project")
		then:
		println("Project duplicated")
	}


	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
