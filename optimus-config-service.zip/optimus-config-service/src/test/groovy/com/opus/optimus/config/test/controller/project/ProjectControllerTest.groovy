package com.opus.optimus.config.test.controller.project

import org.json.JSONObject
import org.spockframework.spring.SpringBean
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.repository.UserRepository
import com.opus.optimus.config.service.repository.scheduler.BatchDefinitionRepository
import com.opus.optimus.config.service.util.UserContextUtility
import com.opus.optimus.ui.services.scheduler.BatchDefinition
import com.opus.optimus.ui.services.scheduler.SchedulerPolicy
import com.opus.optimus.ui.services.scheduler.TimeBased
import com.opus.optimus.ui.services.user.User

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ProjectControllerTest extends Specification {
	
	@Autowired
	protected MockMvc mvc
	
	@Autowired
	MongoTemplate mongoTemplate;

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;
	
	List<String> adminRole
	
	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);
	
	@SpringBean
	BatchDefinitionRepository batchDefinitionRepository = Stub(BatchDefinitionRepository.class);
	
	
	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);
	
	BatchDefinition batchDefinition;
	
	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
		
		adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");
		
		
		
	}

	
	def "Get Project Details Using projectName"() {
		given:
		Map request = [
			institutionId : '100',
			institutionName :'test',
			projectName : 'test',
			projectDescription : 'test',
			createdBy : 'opus'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;
		
		def response1 = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
		when:
		def response = mvc.perform(
			get('/GetProject/projects/test')
		 ).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		println("Response Body --> " + response.getResponse().getStatus())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200||204 && 
		containerObject.getString("institutionId").equals("100") && 
		containerObject.getString("projectName").equals("test") 
	}
	
	def "Save Project"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile'
		]
		
		when:
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_) >> user;

		
		def response1 = mvc.perform(
				post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn().response
	
		then:
		def response = mvc.perform(
			get('/GetProject/projects/test-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200||204 && 
		containerObject.getString("institutionId").equals("101") && 
		containerObject.getString("projectName").equals("test-project_101") &&
		containerObject.getString("createdBy").equals("t-mobile") 
	}

	def "Save Project with already exists"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile'
		]
		
		when:
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_) >> user;

	 mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
		def response1 = mvc.perform(
				post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn().response
	
		then:
		def response = mvc.perform(
			get('/GetProject/projects/test-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200||204 &&
		containerObject.getString("institutionId").equals("101") &&
		containerObject.getString("projectName").equals("test-project_101") &&
		containerObject.getString("createdBy").equals("t-mobile")
	}

	
	
	def "Get All Projects for admin role"() {
		
		given:
		
		Map request = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		userContextUtility.checkIfAdminUser() >> true
		userRepository.findUserByEmail(_ as String) >> user;
		def response1 = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response

			when:
		def response = mvc.perform(
				get('/GetAllProjects/projects')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200||204
	}
	
	def "Get All Projects for other role"() {
		
		given:
		adminRole.add("RECON_OTHER");
		Map request = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		userContextUtility.checkIfAdminUser() >> false
		userRepository.findUserByEmail(_ as String) >> user;
		def response1 = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response

			when:
		def response = mvc.perform(
				get('/GetAllProjects/projects')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200||204
	}
	
	
	def "Update Project"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile'
		]
		
		Map request1 = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile-updated'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		def response1 = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
		when:
		def response = mvc.perform(
				put('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request1))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 && 
		containerObject.getString("status").equals("SUCCESS") 
	}
	
	def "Update Project when project not exists"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'test-project_101',
			projectDescription : 'test_101',
			createdBy : 't-mobile'
		]
		
		Map request1 = [
			institutionId : '101',
			projectName : 'test-project_102',
			projectDescription : 'test_101',
			createdBy : 't-mobile-updated'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		def response1 = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
		when:
		def response = mvc.perform(
				put('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request1))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
		containerObject.getString("status").equals("FAILED")
	}
	
	
	def "Delete Project Using projectName"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'delete-project_101',
			projectDescription : 'delete_101',
			createdBy : 'delete-t-mobile'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
		def response1 = mvc.perform(
			delete('/DeleteProject/projects/delete-project_101')
		 ).andReturn().response

		then:
		def response = mvc.perform(
			get('/GetProject/projects/delete-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	def "Delete Project when  project not exists"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'delete-project_101',
			projectDescription : 'delete_101',
			createdBy : 'delete-t-mobile'
		]
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
		def response1 = mvc.perform(
			delete('/DeleteProject/projects/delete-project_102')
		 ).andReturn().response

		then:
		def response = mvc.perform(
			get('/GetProject/projects/delete-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	
	def "Delete Project when workflow exists"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'delete-project_101',
			projectDescription : 'delete_101',
			createdBy : 'delete-t-mobile'
		]
		
		Map requestWf = [
			projectName : 'delete-project_101',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]

		
		List<String> projects = new ArrayList<String>();
		projects.add("delete-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
			def SaveWfesponse = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestWf))
				).andReturn().response
			
			
			
		def response1 = mvc.perform(
			delete('/DeleteProject/projects/delete-project_101')
		 ).andReturn().response

		then:
		def response = mvc.perform(
			get('/GetProject/projects/delete-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	def "Delete Project when workflow not scheduled"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'delete-project_101',
			projectDescription : 'delete_101',
			createdBy : 'delete-t-mobile'
		]
		
		Map requestWf = [
			projectName : 'delete-project_101',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]

		
		List<String> projects = new ArrayList<String>();
		projects.add("delete-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;
		this.batchDefinitionRepository.findWorkflowByGivenData(_, _, _)>>null;
		

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
		
			def SaveWfesponse = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestWf))
				).andReturn().response
			
			
			
		def response1 = mvc.perform(
			delete('/DeleteProject/projects/delete-project_101')
		 ).andReturn().response

		then:
		def response = mvc.perform(
			get('/GetProject/projects/delete-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	def "Delete Project when workflow is scheduled"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'delete-project_101',
			projectDescription : 'delete_101',
			createdBy : 'delete-t-mobile'
		]
		
		Map requestWf = [
			projectName : 'delete-project_101',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]

		
		List<String> projects = new ArrayList<String>();
		projects.add("delete-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		
		userRepository.findUserByEmail(_ as String) >> user;
		 batchDefinition =  new BatchDefinition();
		 SchedulerPolicy schedulerPolicy = new TimeBased();
		 batchDefinition.setSchedulerPolicy(schedulerPolicy)
		 batchDefinition.setDisabled(false)
		this.batchDefinitionRepository.findWorkflowByGivenData(_, _, _)>>batchDefinition;
		

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
		
			def SaveWfesponse = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestWf))
				).andReturn().response
			
			
			
		def response1 = mvc.perform(
			delete('/DeleteProject/projects/delete-project_101')
		 ).andReturn().response

		then:
		def response = mvc.perform(
			get('/GetProject/projects/delete-project_101')
		 ).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	
	def "Duplicate Projects with same name"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'duplicate-project_101',
			projectDescription : 'duplicate-project_101',
			createdBy : 'duplicate-t-mobile'
		]
		
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
			
		def response = mvc.perform(
				post('/GetAllProjects/projects/duplicate/duplicate-project_101/duplicate-project_101/duplicate-project_101')
				).andReturn()

		then:
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	def "Duplicate Projects with different name"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'duplicate-project_101',
			projectDescription : 'duplicate-project_101',
			createdBy : 'duplicate-t-mobile'
		]
		
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def saveProject = mvc.perform(
			post('/SaveEditProject/projects').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
			).andReturn().response
			
			
		def response = mvc.perform(
				post('/GetAllProjects/projects/duplicate/duplicate-project_101/duplicate-project_102/duplicate-project_102')
				).andReturn()

		then:
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	def "Duplicate Projects where source project not exists"() {
		given:
		Map request = [
			institutionId : '101',
			projectName : 'duplicate-project_101',
			projectDescription : 'duplicate-project_101',
			createdBy : 'duplicate-t-mobile'
		]
		
		
		List<String> projects = new ArrayList<String>();
		projects.add("test-project_101");

		
		def user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
			
		def response = mvc.perform(
				post('/GetAllProjects/projects/duplicate/duplicate-project_101/duplicate-project_102/duplicate-project_102')
				).andReturn()

		then:
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	
	
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
