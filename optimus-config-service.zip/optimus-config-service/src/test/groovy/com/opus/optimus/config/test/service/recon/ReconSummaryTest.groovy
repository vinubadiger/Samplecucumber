package com.opus.optimus.config.test.service.recon

import java.util.concurrent.ConcurrentMap

import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.mongodb.client.MongoCollection
import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.business.recon.IReconSummaryService
import com.opus.optimus.offline.config.recon.ReconSourceSummary
import com.opus.optimus.offline.config.recon.subtypes.SummaryKey
import com.opus.optimus.ui.services.recon.ForceMatchedRecords

import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ReconSummaryTest extends Specification {
	@Autowired
	IReconSummaryService reconSummaryService
	
	def setup() {
		
	}
	
	def "update summary result test"(){
		/*given:
		ConcurrentMap<SummaryKey, List<ReconSourceSummary>> recordHolder
		 MongoCollection<Document> collection 
		String activityName ="TestActivity"
		ForceMatchedRecords forceMatchedRecord
		when:
		reconSummaryService.updateSummaryResults(recordHolder, collection, activityName, forceMatchedRecord)
		
		*/
	}

}
