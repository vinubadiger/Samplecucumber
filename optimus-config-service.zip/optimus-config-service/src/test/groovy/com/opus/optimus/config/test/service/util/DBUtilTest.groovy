package com.opus.optimus.config.test.service.util

import java.sql.DriverManager

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.MapperFactory
import com.opus.optimus.config.service.util.DBUtil
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class DBUtilTest extends Specification {

	DBUtil dbutil ;
	
	@Autowired
	MapperFactory mapperFactory
	@Autowired
	MongoTemplate mongoTemplate;
	
	def oracleDataSource
	def setup() {
		dbutil = new DBUtil();
		
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/OracleDBDataSourceMetaData.json")
		oracleDataSource = mapper.readValue(jsonStream, MongoDataSourceMeta.class)
		
	}
	
	def "connection test"(){
		given:
		DriverManager.getConnection(_, _, _)>>"URL"
		when:
		dbutil.getOracleConnection()
		
		then:
		thrown NullPointerException
		
	}
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
