package com.opus.optimus.config.test.service.constants

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.constant.ConfigServiceConstant

import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ContantsTest extends Specification{
	
	def "ConfigServiceConstantsTest"(){
		given:
		ConfigServiceConstant service = Spy(ConfigServiceConstant)
		expect:
		service.ID=="id"
		service.DELETE=="delete"
		service.SAVE=="save"
		service._ID=="_id"
	}

	
	
}
