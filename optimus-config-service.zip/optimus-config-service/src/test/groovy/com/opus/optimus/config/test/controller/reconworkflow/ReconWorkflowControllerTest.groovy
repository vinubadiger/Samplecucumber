package com.opus.optimus.config.test.controller.reconworkflow

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.MapperFactory
import com.opus.optimus.config.service.business.scheduler.BatchDefinitionService
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.repository.UserRepository
import com.opus.optimus.config.service.util.UserContextUtility
import com.opus.optimus.ui.constants.ResponseStatus
import com.opus.optimus.ui.constants.ServiceResponse
import com.opus.optimus.ui.services.project.Workflow
import com.opus.optimus.ui.services.recon.Activity
import com.opus.optimus.ui.services.user.User

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ReconWorkflowControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	MongoTemplate mongoTemplate;

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	BatchDefinitionService batchDefinitionService = Stub(BatchDefinitionService.class);




	def user = null;

	def object;
	def etlObject;

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/Activity.json")
		object = mapper.readValue(jsonStream, Activity.class)
		def jsonStreamETL = getClass().getResourceAsStream("/ETLWorkflowAmex.json")
		etlObject = mapper.readValue(jsonStreamETL, Workflow.class)


		//Reason Notes:
		DBObject reasonNote1 = BasicDBObjectBuilder.start()
				.add("_id", "5c87ace809cae33282e8cb74")
				.add("manReasonId", "FRC003 - Issuer Generated Issue")
				.get();

		DBObject reasonNote2 = BasicDBObjectBuilder.start()
				.add("_id", "5c87acdf09cae33282e8cb37")
				.add("manReasonId", "FRC002 - Vendor Issue")
				.get();

		DBObject reasonNote3 = BasicDBObjectBuilder.start()
				.add("_id", "5c87acce09cae33282e8cabf")
				.add("manReasonId", "FRC001 - Duplication")
				.get();

		mongoTemplate.save(reasonNote1, "ReasonNote");
		mongoTemplate.save(reasonNote2, "ReasonNote");
		mongoTemplate.save(reasonNote3, "ReasonNote");


		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true

	}

	def "Save Recon Workflow"() {
		when:
		def response = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}

	def "Save Recon Workflow with same name"() {
		when:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		def response = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getInt("statusCode").equals(500)
		containerObject.getString("status").equals("FAILED")
	}

	def "Get Activity"() {
		given:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()


		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		def user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def response = mvc.perform(
				get('/GetReconAllActivities/reconWorkflows/getActivity')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("projectName").equals("TestProject") &&
				containerObject.getString("name").equals("TestActivity") &&
				containerObject.getString("sourceMapping").equals("OneToOne")
	}

	def "Get All Activity with Project Name and Workflow Type"() {
		given:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		when:
		String projectName = "TestProject";
		String workflowType = "RECON";

		def response = mvc.perform(
				get('/GetAllActivityForProject/reconWorkflows/GetAll/Activity/{projectName}/{workflowType}',projectName,workflowType)
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("projectName").equals("TestProject") &&
				containerObject.getString("name").equals("TestActivity") &&
				containerObject.getString("sourceMapping").equals("OneToOne")
	}

	def "Get All Activity with Project Name, Workflow Name and Workflow Type"() {
		given:
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		when:
		String projectName = "TestProject";
		String workflowName = "TestActivity";
		String workflowType = "RECON";

		def response = mvc.perform(
				get('/GetAllActivityForProject/reconWorkflows/reconSourceDefinition/{projectName}/{workflowName}/{workflowType}',projectName,workflowName,workflowType)
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("projectName").equals("TestProject") &&
				containerObject.getString("name").equals("TestActivity") &&
				containerObject.getString("sourceMapping").equals("OneToOne")
	}

	def "Get Reason Notes"() {
		when:
		def response = mvc.perform(
				get('/GetReconAllActivities/reconWorkflows/getReasonNotes')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		((JSONObject) newJArray.get(0)).getString("manReasonId").equals("FRC003 - Issuer Generated Issue") &&
				((JSONObject) newJArray.get(1)).getString("manReasonId").equals("FRC002 - Vendor Issue") &&
				((JSONObject) newJArray.get(2)).getString("manReasonId").equals("FRC001 - Duplication") &&
				response.getResponse().getStatus() == 200
	}

	def "Delete Activity by projectname, workflowName and workflowType"() {
		given:
		given :
		ServiceResponse responseBatchdefinition = new ServiceResponse(200,  ResponseStatus.SUCCESS, "Scheduling information is deleted of Workflow" ,  null);
		this.batchDefinitionService.delete(_, _, _)>>responseBatchdefinition
		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		when:
		def response = mvc.perform(
				delete('/GetReconAllActivities/reconWorkflows/TestProject/TestActivity/RECON')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}

	def "Delete Activity when activity not exists"() {

		when:
		def response = mvc.perform(
				delete('/GetReconAllActivities/reconWorkflows/TestProject/TestActivity/RECON')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("FAILED")&&
				containerObject.getString("msg").equals("Activity not exists")
	}

	def "Delete Activity when batch Definition not exists"() {
		given :
		ServiceResponse responseBatchdefinition = new ServiceResponse(500,  ResponseStatus.FAILED, "Batch Definition not exists" ,  null);
		this.batchDefinitionService.delete(_, _, _)>>responseBatchdefinition

		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		when:
		def response = mvc.perform(
				delete('/GetReconAllActivities/reconWorkflows/TestProject/TestActivity/RECON')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("FAILED")&&
				containerObject.getString("msg").equals("Batch Definition not exists")
	}


	def "Get Recon Source "() {

		given:

		def worklflow = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(etlObject))
				).andReturn().response




		def response1 = mvc.perform(
				post('/SaveReconConfig/reconWorkflows/reconSourceDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn()

		when:
		def response = mvc.perform(
				get('/GetReconAllActivities/reconWorkflows/etlSource/TestProject/Amex/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}



	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}