package com.opus.optimus.config.test.controller.workflow

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.repository.UserRepository
import com.opus.optimus.config.service.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class WorkflowControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	def user = null;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}

	def "Get Workflow Using projectname, workflowname, workflowType"() {
		given:
		Map requestSave = [
			projectName : 'test-project_100',
			projectId : '222',
			workflowName : 'workflowName_222_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response

		when:
		def response = mvc.perform(
				get('/GetWorkFlowList/workflows/test-project_100/workflowName_222_ETL/Recon')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200||204 &&
				containerObject.getString("projectId").equals("222") &&
				containerObject.getString("projectName").equals("test-project_100") &&
				containerObject.getString("workflowType").equals("Recon") &&
				containerObject.getString("workflowName").equals("workflowName_222_ETL")
	}

	def "Get Workflow Using projectname, workflowType"() {
		given:
		Map requestSave = [
			projectName : 'test-project_100',
			projectId : '222',
			workflowName : 'workflowName_222_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response

		when:
		def response = mvc.perform(
				get('/GetWorkFlowList/workflows/test-project_100/Recon')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200||204 &&
				containerObject.getString("projectId").equals("222") &&
				containerObject.getString("projectName").equals("test-project_100") &&
				containerObject.getString("workflowType").equals("Recon") &&
				containerObject.getString("workflowName").equals("workflowName_222_ETL")
	}

	def "Get All ETL Workflow"() {
		given:
		Map requestSaveETL = [
			projectName : 'test-project_100_ETL',
			projectId : '223',
			workflowName : 'workflowName_222_ETL',
			workflowType : 'ETL'
		]
		def responseSave1 = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSaveETL))
				).andReturn().response

		when:
		def response = mvc.perform(
				get('/GetWorkFlowList/workflows/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}

	def "Save Workflow"() {
		given:
		Map request = [
			projectName : 'test-project_101',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]

		when:
		def response = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn().response

		then:
		response.status == 200
	}

	def "Save Workflow with duplicate name"() {
		given:
		Map request = [
			projectName : 'test-project_101',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]



		when:
		def response1 = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		def response = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getInt("statusCode").equals(500)
		containerObject.getString("status").equals("FAILED")
	}

	def "Update Workflow"() {
		given:
		Map requestSave = [
			projectName : 'test-project_102',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response


		when:
		Map requestUpdate = [
			projectName : 'test-project_102',
			projectId : '1112',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]
		def response = mvc.perform(
				put('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestUpdate))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}


	def "Update Workflow when workflow not exists"() {
		given:
		Map requestSave = [
			projectName : 'test-project_102',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response


		when:
		Map requestUpdate = [
			projectName : 'test-project_102',
			projectId : '1112',
			workflowName : 'workflowName_111_ETLCopy',
			workflowType : 'Recon'
		]
		def response = mvc.perform(
				put('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestUpdate))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		containerObject.getInt("statusCode").equals(500)
		containerObject.getString("status").equals("FAILED")
	}

	def "Delete Workflow Using projectname, workflowname, workflowType"() {
		given:
		Map requestSave = [
			projectName : 'test-project_103',
			projectId : '1111',
			workflowName : 'workflowName_111_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response

		when:
		def response = mvc.perform(
				delete('/DeleteWorkFlow/workflows/test-project_103/workflowName_111_ETL/Recon')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}

	def "Get Workflow Using projectname"() {
		given:
		Map requestSave = [
			projectName : 'test-project_100',
			projectId : '222',
			workflowName : 'workflowName_222_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response

		when:
		def response = mvc.perform(
				get('/GetWorkFlowList/workflows/test-project_100')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200||204 &&
				containerObject.getString("projectId").equals("222") &&
				containerObject.getString("projectName").equals("test-project_100") &&
				containerObject.getString("workflowType").equals("Recon") &&
				containerObject.getString("workflowName").equals("workflowName_222_ETL")
	}

	def "Duplicate Workflow"() {
		given:
		Map requestSave = [
			projectName : 'test-project_100',
			projectId : '222',
			workflowName : 'workflowName_222_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response

		when:
		def response = mvc.perform(
				post('/GetWorkFlowList/workflows/duplicate/test-project_100/workflowName_222_ETL/Recon/workflowName_target/desc')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}

	def "Duplicate Workflow with same name"() {
		given:
		Map requestSave = [
			projectName : 'test-project_100',
			projectId : '222',
			workflowName : 'workflowName_222_ETL',
			workflowType : 'Recon'
		]
		def responseSave = mvc.perform(
				post('/SaveEditWorkFlow/workflows').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestSave))
				).andReturn().response

		when:
		def response = mvc.perform(
				post('/GetWorkFlowList/workflows/duplicate/test-project_100/workflowName_222_ETL/Recon/workflowName_222_ETL/desc')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getInt("statusCode").equals(500)
		containerObject.getString("status").equals("FAILED")
	}

	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
