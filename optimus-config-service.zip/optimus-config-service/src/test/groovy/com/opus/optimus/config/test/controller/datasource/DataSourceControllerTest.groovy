package com.opus.optimus.config.test.controller.datasource

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.opus.optimus.config.service.EntryPoint
import com.opus.optimus.config.service.MapperFactory
import com.opus.optimus.config.service.UserAudtiting
import com.opus.optimus.config.service.interceptor.LoginInterceptor
import com.opus.optimus.config.service.repository.etl.DataSourceRepository
import com.opus.optimus.config.service.repository.etl.WorkflowRepository
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta


import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest(classes = EntryPoint.class)
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class DataSourceControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	MongoTemplate mongoTemplate;

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	UserAudtiting userAudtiting = Stub(UserAudtiting.class);




	def object;
	def newobject;
	def oracleDataSource;
	MongoDataSourceMeta dataSource;

	def setup() {
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		object = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		def jsonStreamNew = getClass().getResourceAsStream("/MongoDBDataSourceMetaData2.json")
		newobject = mapper.readValue(jsonStreamNew, MongoDataSourceMeta.class)

		def jsonStreamOracle = getClass().getResourceAsStream("/OracleDBDataSourceMetaData.json")
		oracleDataSource = mapper.readValue(jsonStreamOracle, MongoDataSourceMeta.class)




		mongoTemplate.save(object, "MongoDataSourceMeta")

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userAudtiting.getCurrentAuditor()>> Optional.of("user1");
	}



	def "Get All Data Source Details"() {

		when:
		def response = mvc.perform(
				get('/GetAllSettings/settings/datasource/getAllDataSourceDetails')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("dataSourceName").equals("config-database") &&
				containerObject.getString("databaseType").equals("Mongo_DB")
	}


	def "Save  mongodb Data Source"() {
		given:


		when:
		def response = mvc.perform(
				post('/SaveSetting/settings/datasource').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(newobject))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
	}

	def "Save Oracle Data Source"() {
		given:


		when:
		def response = mvc.perform(
				post('/SaveSetting/settings/datasource').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(oracleDataSource))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
	}

	def "Save Other Data Source"() {
		given:
		dataSource = new MongoDataSourceMeta();
		dataSource.setDatabaseType("Other")

		when:
		def response = mvc.perform(
				post('/SaveSetting/settings/datasource').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(dataSource))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
	}



	def "Delete Data Source Details Using dataSourceName, databaseType"() {

		when:
		def response = mvc.perform(
				delete('/DeleteSetting/settings/datasource/config-database/Mongo_DB')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}


	def "Delete Data Source Details when  dataSource not exists"() {

		when:
		def response = mvc.perform(
				delete('/DeleteSetting/settings/datasource/config-databaseNo/Mongo_DB')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("FAILED")
	}

	def "Put Data Source Details Using dataSourceName, databaseType"() {
		when:
		def response = mvc.perform(
				put('/SaveSetting/settings/datasource/config-database/Mongo_DB').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(newobject))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}


	def "Get DataSources - Collection Using databaseType, dataSourceName"() {

		when:
		def response = mvc.perform(
				get('/GetCollections/settings/datasource/getCollections/Mongo_DB/config-database')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("dataSourceName").equals("config-database") &&
				containerObject.getString("databaseType").equals("Mongo_DB")
	}

	def "Get DataSources  of mongob database type "() {

		when:
		def response = mvc.perform(
				get('/GetSetting/settings/datasource/getDataSources/Mongo_DB')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("dataSourceName").equals("config-database") &&
				containerObject.getString("databaseType").equals("Mongo_DB")
	}


	def "Get Data Source Details Using dataSourceName, databaseType"() {

		when:
		def response = mvc.perform(
				get('/GetDataSources/settings/datasource/config-database/Mongo_DB')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("dataSourceName").equals("config-database") &&
				containerObject.getString("databaseType").equals("Mongo_DB")
	}


	def "Retrieve the column names from the Oracle DB table"() {
		when:
		def response = mvc.perform(
				get('/GetDBTableFields/settings/datasource/tablemetadata/OracleDataSource/Oracle_DB/payment')
				).andReturn().response
		then:
		response.status == 200
	}

	def "Retrieve the column names where db is not oracle"() {
		when:
		def response = mvc.perform(
				get('/GetDBTableFields/settings/datasource/tablemetadata/OracleDataSource/Not_Oracle_DB/payment')
				).andReturn().response
		then:
		response.status == 200
	}



	def "check Mongodb  connection test"(){
		given:
		dataSource = new MongoDataSourceMeta();
		dataSource.setDatabaseType("Mongo_DB")
		when:
		def response = mvc.perform(
				post('/DBTest/settings/datasource/dbTest').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(object))
				).andReturn().response
		then:
		response.status==200
	}

	def "check oracle connection test"(){
		given:
		dataSource = new MongoDataSourceMeta();
		dataSource.setDatabaseType("Mongo_DB")
		when:
		def response = mvc.perform(
				post('/DBTest/settings/datasource/dbTest').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(oracleDataSource))
				).andReturn().response
		then:
		response.status==200
	}

	def "check other connection test"(){
		given:
		dataSource = new MongoDataSourceMeta();
		dataSource.setDatabaseType("other")
		when:
		def response = mvc.perform(
				post('/DBTest/settings/datasource/dbTest').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(dataSource))
				).andReturn().response
		then:
		response.status==200
	}


	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
