package com.opus.optimus.scheduler.services.quartz;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.Priority;
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequestForSchedular;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.user.Institution;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.exception.casehandler.JobErrorCaseRequestFactory;
import com.opus.optimus.offline.runtime.exception.casehandler.ReconCaseTemplateSeviceImpl;
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper;
import com.opus.optimus.offline.runtime.exception.utility.CaseTemplateResolverUtil;
import com.opus.optimus.offline.runtime.taskmanager.exception.CustomException;
import com.opus.optimus.offline.runtime.taskmanager.model.ExecutionInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;
import com.opus.optimus.offline.runtime.taskmanager.model.SourceInfo;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;
import com.opus.optimus.scheduler.constants.JobKeyIdentifierGroup;
import com.opus.optimus.scheduler.constants.SchedularConstants;
import com.opus.optimus.scheduler.repository.InstitutionRepository;
import com.opus.optimus.scheduler.repository.PublishedWorkflowRepository;
import com.opus.optimus.scheduler.services.BatchDefinitionService;
import com.opus.optimus.scheduler.services.InstitutionService;
import com.opus.optimus.scheduler.services.JobInfoDataService;
import com.opus.optimus.scheduler.services.webclient.OptimusRestClient;
import com.opus.optimus.scheduler.util.BeanUtilService;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.StepInputData;
import com.opus.optimus.ui.services.util.FileUtility;

/**
 * The Class JobExecution class is responsible for schedule the create job ,schedule job.
 */
@Component
public class JobExecution implements Job {

	public static final String ORIGIN = "ETL";

	public static final String CASE_STATE = "Open";

	public static final String REASON_CODE = "Error";

	public static final String ORIGIN_QUARTZ = "Data Ingestion";

	public static final String DATE_FORMATE = "yyyy-MM-dd'T'HH:mm:ss";

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(JobExecution.class);

	private static final String SUCCESS_RESPONSE = "success";

	/*
	 * quartz implementation to execute job
	 */
	@Override
	public void execute(JobExecutionContext arg) throws JobExecutionException {
		logger.info("Executing Job at : {}", new Date());
		try{
			JobDataMap jobDataMap = arg.getMergedJobDataMap();

			String jobGroup = arg.getJobDetail().getKey().getGroup();

			switch (jobGroup) {
			case JobKeyIdentifierGroup.WORKFLOW:
				String projectName = (String) jobDataMap.get(QuartzScheduler.PROJECT_NAME);
				String workflowName = (String) jobDataMap.get(QuartzScheduler.WORKFLOW_NAME);
				String workflowType = (String) jobDataMap.get(QuartzScheduler.WORKFLOW_TYPE);
				String groupId = (String) jobDataMap.get(QuartzScheduler.GROUP_ID);
				List<?> stepInputData = (List<?>) jobDataMap.get(QuartzScheduler.STEPINPUT_DATA);
				logger.debug("Triggering WORKFLOW execution for Project - {}, Workflow- {}, GroupId- {}, Type- {}, with StepInputData - {}", projectName, workflowName, groupId, workflowType, stepInputData);
				setInputDataAndTriggerJob(projectName, workflowName, groupId, workflowType, stepInputData);
				break;

			case JobKeyIdentifierGroup.CUTOVER:
				noOfFilesProcessCheck();
				String institutionId = (String) jobDataMap.get(QuartzScheduler.INSTITUTION_ID);
				updateDataIngestionDate(institutionId);
				break;

			default:
				break;
			}

		} catch (Exception e){
			logger.error("Error while executing Quartz Job :"+ e.getMessage(), e);
			createCaseforQuartz("Quartz Exception", QuartzScheduler.PROJECT_NAME, QuartzScheduler.WORKFLOW_NAME, Priority.HIGH, e.getMessage());
			throw new JobExecutionException(e);
		}
	}

	/**
	 * Number of files process check.
	 *
	 * @param projectName : Project name of given job
	 * @param workflowName : workflow name of given job
	 * @param workflowType : ETL type work flow
	 */
	private void noOfFilesProcessCheck() {
		try{
			Calendar startDateTime = Calendar.getInstance();
			Calendar previousDateTime = Calendar.getInstance();
			previousDateTime.add(Calendar.DATE, -1);

			BatchDefinitionService batchDefinitionService = BeanUtilService.getBeanObject(BatchDefinitionService.class);
			JobInfoDataService jobinfoDataService = BeanUtilService.getBeanObject(JobInfoDataService.class);

			logger.debug("Fetching all Batch definitions to check Expected number of file check");
			List<BatchDefinition> batchDefinitionList = batchDefinitionService.getAllEtlEnableBatchDefination();
			batchDefinitionList.stream().forEach(batchDefinition -> {
				String fileDirectory = "";
				Optional<String> fileLocationOptional = batchDefinition.getStepInputData().stream().filter(e -> StepTypeConstants.FILE_READER_STEPTYPE.equalsIgnoreCase(e.getStepType())).map(StepInputData::getStepInputValue).findFirst();
				if (fileLocationOptional.isPresent()){
					fileDirectory = fileLocationOptional.get();
				}
				int expectedNoOfFileCount = batchDefinition.getNumberOfExpectedFiles();
				long proccessedNoOfFileCount = jobinfoDataService.findForNoOfFilesToBeProcess(batchDefinition.getWorkflowType(), batchDefinition.getProjectName(), batchDefinition.getWorkflowName(), previousDateTime.getTime(), startDateTime.getTime());
				logger.debug("Checking if a case has to be created for mimatch in expected number of files for Project - {}, Workflow - {}, Type - {}", batchDefinition.getProjectName(), batchDefinition.getWorkflowName(), batchDefinition.getWorkflowType());
				caseCreationCheck(expectedNoOfFileCount, proccessedNoOfFileCount, batchDefinition.getProjectName(), batchDefinition.getWorkflowName(), fileDirectory);
			});
		} catch (Exception e){
			logger.error("Error Executing mongo repository ", e);
		}
	}

	/**
	 * Case creation type check using No. of files expected to process & no of files processed.
	 * 
	 * @param expectedNoOfFileCount : Count of no of processing files
	 * @param proccessedNoOfFileCount : Count of actual no of processed files
	 * @param projectName : Project name of given job
	 * @param workflowName : workflow name of given job
	 * @param fileDirectory
	 */
	private void caseCreationCheck(int expectedNoOfFileCount, long proccessedNoOfFileCount, String projectName, String workflowName, String fileDirectory) {
		switch (Integer.compare(expectedNoOfFileCount, (int) proccessedNoOfFileCount)) {
		case 0:
			logger.debug("No of files processed as expected : {} , {}", expectedNoOfFileCount, proccessedNoOfFileCount);
			break;
		case -1:
			createCase("Files received more than expected", projectName, workflowName, Priority.MEDIUM, fileDirectory, expectedNoOfFileCount, proccessedNoOfFileCount);
			logger.debug("No of files processed are more than expected : {} , {}", expectedNoOfFileCount, proccessedNoOfFileCount);
			break;
		case 1:
			createCase("Numbers of files recieved are less than expected.", projectName, workflowName, Priority.HIGH, fileDirectory, expectedNoOfFileCount, proccessedNoOfFileCount);
			logger.debug("No of files processed are less than expected : {} , {}", expectedNoOfFileCount, proccessedNoOfFileCount);
			break;
		default:
			logger.error("Problem with given count of proceesed files : {}, {}", expectedNoOfFileCount, proccessedNoOfFileCount);
			break;
		}
	}

	/**
	 * For creating case on Salesforce.
	 *
	 * @param reasonCode the reason code
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param priority the priority
	 * @param fileDirectory
	 * @param proccessedNoOfFileCount
	 * @param expectedNoOfFileCount
	 */
	private void createCase(String reasonCode, String projectName, String workflowName, Priority priority, String fileDirectory, int expectedNoOfFileCount, long proccessedNoOfFileCount) {
		try{
			SalesforceCaseHelper salesforceCaseHelper = BeanUtilService.getBeanObject(SalesforceCaseHelper.class);
			BeanUtilService.getBeanObject(ReconCaseTemplateSeviceImpl.class);
			BeanUtilService.getBeanObject(CaseTemplateResolverUtil.class);
			JobErrorCaseRequestFactory jobErrorCaseRequestFactory = BeanUtilService.getBeanObject(JobErrorCaseRequestFactory.class);

			final SalesforceAuthenticateResponse response = salesforceCaseHelper.authenticate();
			if (StringUtils.isEmpty(response.getAccessToken())){
				logger.error("Can not post the cases to the sales force application due to authentication failure. {}", response);
				return;
			}
			final String accessToken = response.getAccessToken();

			// set schedular specific data in POJO

			SalesforceCaseRequestForSchedular salesforceCaseRequestForSchedular = SalesforceCaseRequestForSchedular.builder().reasonCode(reasonCode).subject(reasonCode + "For :" + projectName + "-" + workflowName).project(projectName).priority(priority).fileDBDetails(fileDirectory).description(createDescription(expectedNoOfFileCount, proccessedNoOfFileCount, projectName, workflowName)).build();

			SalesforceCaseRequest salesForceCaseRequest = jobErrorCaseRequestFactory.createPlainSalesForceReqObjForSchedular(salesforceCaseRequestForSchedular);

			logger.debug("SalesForce Case Request : ---> {}", salesForceCaseRequest);
			SalesforceCaseResponse salesforcecaseresponse = salesforceCaseHelper.createCase(salesForceCaseRequest, accessToken);
			logger.debug("SalesForce Case Response : --->{}", salesforcecaseresponse);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	private String createDescription(int expectedNoOfFileCount, long proccessedNoOfFileCount, String projectName, String workflowName) {
		StringBuilder discriptionMessage = new StringBuilder();
		discriptionMessage.append("Project Name : ").append(projectName);
		discriptionMessage.append("Workflow Name : " + workflowName);
		discriptionMessage.append("Expected number of files : " + expectedNoOfFileCount);
		discriptionMessage.append("Recieved file count: " + proccessedNoOfFileCount);
		return discriptionMessage.toString();
	}

	/**
	 * Sets the input data and trigger job.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @param workflowType the workflow type
	 * @param stepInputData the step input data
	 * @return the string
	 */
	public String setInputDataAndTriggerJob(String projectName, String workflowName, String groupId, String workflowType, List<?> stepInputData) {
		logger.debug("in job execution");
		String institutionId = BeanUtilService.getBeanObject(Environment.class).getProperty("institution.institutionId");
		logger.debug("intistutionid {}", institutionId);
		try{
			PublishedService publishedService = getPublishServiceByGroupId(groupId);

			if (publishedService.getWorkflowConfig().getStepConfigs() == null || publishedService.getWorkflowConfig().getStepConfigs().isEmpty()){
				return "Workflow is not properly configured!";
			}

			if (workflowType.equals("ETL")){
				return setInputDataAndTriggerDIJob(projectName, workflowName, workflowType, groupId, stepInputData, publishedService);
			} else{
				logger.debug("Trying to trigger an RECON job with Group Id: {}", groupId);
				return setStepInputAndTriggerJob(projectName, workflowName, workflowType, groupId, publishedService);
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Sets the input data and trigger DI job.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param stepInputData the step input data
	 * @param publishedService the published service
	 * @return the string
	 */
	private String setInputDataAndTriggerDIJob(String projectName, String workflowName, String workflowType, String groupId, List<?> stepInputData, PublishedService publishedService) {
		try{

			logger.debug("Trying to trigger an ETL job with Group Id: {}", groupId);

			long isSourceFileReader = publishedService.getWorkflowConfig().getStepConfigs().stream().filter(stepConfig -> (stepConfig.getStepType().equals(StepTypeConstants.FILE_READER_STEPTYPE) || stepConfig.getStepType().equals(StepTypeConstants.EXCEL_READER_STEPTYPE))).count();

			if (isSourceFileReader > 0){
				if (null == stepInputData || stepInputData.isEmpty()){
					return "StepInputs not found";
				} else{
					return setETLStepInputDataAndTriggerJob(projectName, workflowName, groupId, workflowType, stepInputData);
				}
			}

			long isOracleDBReader = publishedService.getWorkflowConfig().getStepConfigs().stream().filter(stepConfig -> (stepConfig.getStepType().equals(StepTypeConstants.DBREADER_STEP_TYPE))).count();

			if (isOracleDBReader > 0){
				return setStepInputAndTriggerJob(projectName, workflowName, workflowType, groupId, publishedService);
			} else{
				return "Unable to Execute Job";
			}

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Sets the ETL step input data and trigger job.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @param workflowType the workflow type
	 * @param stepInputData the step input data
	 * @return the string
	 */
	private String setETLStepInputDataAndTriggerJob(String projectName, String workflowName, String groupId, String workflowType, List<?> stepInputData) {
		for (Object stepInput : stepInputData){
			StepInputData inputData = (StepInputData) stepInput;
			switch (inputData.getStepInputType()) {
			case FILE_FOLDER_LOCATION:
				String directoryLocation = inputData.getStepInputValue();
				logger.debug("Directory location in StepInputData: {}", directoryLocation);
				return createJobForEveryFileInFolder(directoryLocation, projectName, workflowName, workflowType, groupId, inputData);
			case FILE_EXTENSION:
				logger.debug("Case FILE_EXTENSION is not yet handled");
				break;

			default:
				break;
			}
		}
		return "Job not submitted. Please check your configuration";
	}

	/**
	 * Creates the job for every file in folder.
	 *
	 * @param directoryLocation the directory location
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param inputData the input data
	 * @return the string
	 */
	private String createJobForEveryFileInFolder(String directoryLocation, String projectName, String workflowName, String workflowType, String groupId, StepInputData inputData) {
		try{
			logger.debug("Creating job for files under directory - {}", directoryLocation);
			File dir = new File(directoryLocation);
			if (dir.exists() && dir.isDirectory() && dir.list().length > 0){
				sendJobRequestForEachFIle(dir, directoryLocation, projectName, workflowName, workflowType, groupId, inputData);
				return SUCCESS_RESPONSE;
			} else{
				logger.debug("Case management directory is emty hence case created and to log error send to taskmanager");
				final JobInfo jobInfo = buildETLJobInfo(projectName, workflowName, workflowType, groupId, inputData.getStepName(), directoryLocation, "");
				sendToServerToCreateAndRun(jobInfo);
				return "Directory/File does not exist. Case has been logged.";
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	private void sendJobRequestForEachFIle(File dir, String directoryLocation, String projectName, String workflowName, String workflowType, String groupId, StepInputData inputData) {
		String serviceUser = BeanUtilService.getBeanObject(Environment.class).getProperty("service.userName");
		Arrays.asList(dir.listFiles()).parallelStream().filter(File::isFile).forEach(file -> {
			try{
				PosixFileAttributes serviceUserDetails = getServiceUserDetails(file);
				Set<PosixFilePermission> arr = serviceUserDetails.permissions();
				String fileOwner = serviceUserDetails.owner().getName();
				logger.debug("File Owner: {}", fileOwner + "Permissions are" + serviceUserDetails.permissions());
				File mkdirectory = createProjectDirectory(projectName, workflowName);
				if (serviceUser.equals(fileOwner) && arr.contains(PosixFilePermission.OWNER_READ)){
					checkFilePropertyAndTriggerJob(mkdirectory, file, projectName, workflowName, workflowType, groupId, inputData);
				} else{
					logger.debug("DI File not uploaded by Service User, Case has been logged");
					createCase("File Read Error", projectName, workflowName, Priority.HIGH, directoryLocation, 0, 0);
					throw new GenericException("DI File not uploaded by Service User, Case has been logged");
				}
			} catch (GenericException e){
				throw e;
			} catch (Exception e){
				throw new GenericException(e);
			}
		});
	}

	/**
	 * Check file property and trigger job.
	 *
	 * @param mkdirectory the mkdirectory
	 * @param file the file
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param inputData the input data
	 */
	private void checkFilePropertyAndTriggerJob(File mkdirectory, File file, String projectName, String workflowName, String workflowType, String groupId, StepInputData inputData) {
		try{
			String destFilePath = mkdirectory.getAbsolutePath().concat(File.separator).concat(file.getName());
			logger.debug("Destination File Name  {}", destFilePath);
			File destinationFile = new File(destFilePath);
			logger.debug("Checking if file already exists");
			JobInfo jobInfo;
			if (destinationFile.exists()){
				logger.error("File already exists. replacing the to be Processed file");
			}
			logger.debug("Moving file to In Process directory");
			FileUtility.moveFileInProcessDirectory(file.getAbsolutePath(), destFilePath);
			jobInfo = buildETLJobInfo(projectName, workflowName, workflowType, groupId, inputData.getStepName(), destFilePath, file.getName());
			logger.debug("Sending Job information to run");
			sendToServerToCreateAndRun(jobInfo);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * @param projectName
	 * @param workflowName
	 * @return
	 */
	private File createProjectDirectory(String projectName, String workflowName) {
		try{
			String fileInprocessLocation = BeanUtilService.getBeanObject(Environment.class).getProperty("file.process.directory");
			File mkdirectory = new File(fileInprocessLocation, new StringBuilder(projectName).append("-").append(workflowName).toString());
			if (!mkdirectory.exists()){
				logger.debug("Creating Directory {}, with permission : {}", mkdirectory, Boolean.valueOf(mkdirectory.canWrite()));
				if (mkdirectory.mkdirs()){
					logger.debug("Directory is created!");
				} else{
					logger.error("Unable to create destination directory");
				}
			}
			return mkdirectory;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Sets the recon step input and trigger.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param publishedService the published service
	 * @return the string
	 */
	private String setStepInputAndTriggerJob(String projectName, String workflowName, String workflowType, String groupId, PublishedService publishedService) {
		try{
			JobInfo jobInfo = buildJobInfoStructure(projectName, workflowName, workflowType, groupId, publishedService);
			sendToServerToCreateAndRun(jobInfo);
			return SUCCESS_RESPONSE;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Builds the recon job info.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param publishedService the published service
	 * @return the job info
	 */
	private JobInfo buildJobInfoStructure(String projectName, String workflowName, String workflowType, String groupId, PublishedService publishedService) {
		try{
			JobInfo jobinfo = buildGenericJobInfo(projectName, workflowName, workflowType, groupId);

			final StringBuilder source = new StringBuilder();
			publishedService.getWorkflowConfig().getStepConfigs().forEach(stepConfig -> {
				switch (stepConfig.getStepType()) {
				case StepTypeConstants.MONGO_DBREADER_STEP_TYPE:
					String sourceName = ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getSourceName();
					source.append((source == null || source.length() == 0) ? sourceName : ", " + sourceName);
					break;
				case StepTypeConstants.DBREADER_STEP_TYPE:
					source.append("Oracle Database");
					break;
				default:
					break;
				}
			});
			jobinfo.setSourceInfo(SourceInfo.builder().source(source.toString()).build());
			jobinfo.getJobTasks().forEach(jobTask -> jobTask.getExecutionInfo().setStepInputs(setEmptyStepInputs(publishedService)));
			return jobinfo;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the step inputs for recon.
	 *
	 * @param publishedService the published service
	 * @return the step inputs for recon
	 */
	private Map<String, List<String>> setEmptyStepInputs(PublishedService publishedService) {
		try{
			HashMap<String, List<String>> stepInputs = new HashMap<>();
			List<String> emptyArray = new ArrayList<>();
			emptyArray.add("");
			publishedService.getWorkflowConfig().getStepConfigs().stream().filter(stepConfig -> (stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) || stepConfig.getStepType().equals(StepTypeConstants.DBREADER_STEP_TYPE))).collect(Collectors.toList()).forEach(stepConfig -> stepInputs.put(stepConfig.getStepName(), emptyArray));
			return stepInputs;
		} catch (GenericException ce){
			throw ce;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Get the publish service by group id.
	 *
	 * @param groupId the group id
	 * @return publish service object for specific groupId
	 */
	private PublishedService getPublishServiceByGroupId(String groupId) {
		try{
			PublishedWorkflowRepository publishedRepoService = BeanUtilService.getBeanObject(PublishedWorkflowRepository.class);
			Optional<PublishedService> publishedServiceOpt = publishedRepoService.findById(groupId);
			PublishedService publishedService = publishedServiceOpt.isPresent() ? publishedServiceOpt.get() : null;
			if (null == publishedService){
				throw new CustomException("Acitity Not Yet Published", 500);
			}
			return publishedService;
		} catch (CustomException e){
			logger.error("Activity is not Published");
			throw new GenericException(e);
		}
	}

	/**
	 * Send to server to create and run.
	 *
	 * @param jobInfo the job info
	 */
	public void sendToServerToCreateAndRun(JobInfo jobInfo) {
		try{
			OptimusRestClient client = BeanUtilService.getBeanObject(OptimusRestClient.class);
			String jobId = client.createJob(jobInfo);
			if (jobId != null){
				updateJobInfo(jobId, jobInfo);
				client.runJob(jobId);
			} else{
				logger.error("Failed to create the job. PLease check the server log");
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Update job info.
	 *
	 * @param jobId the job id
	 * @param jobInfo the job info
	 */
	private void updateJobInfo(String jobId, JobInfo jobInfo) {
		logger.debug("Id in service {}", jobId);
		try{
			JobInfoDataService jobInfoservice = BeanUtilService.getBeanObject(JobInfoDataService.class);
			logger.info("{}", jobInfoservice);
			jobInfoservice.save(jobId, jobInfo);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Builds the ETL job info.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @param stepName the step name
	 * @param destfile the destfile
	 * @param filename the filename
	 * @return the job info
	 */
	public JobInfo buildETLJobInfo(String projectName, String workflowName, String workflowType, String groupId, String stepName, String destfile, String filename) {
		try{
			JobInfo jobinfo = buildGenericJobInfo(projectName, workflowName, workflowType, groupId);
			SourceInfo sourcefile = new SourceInfo();
			sourcefile.setSource(filename);
			jobinfo.setSourceInfo(sourcefile);

			jobinfo.getJobTasks().forEach(jobTask -> jobTask.getExecutionInfo().setStepInputs(getStepInputsForEtl(stepName, destfile, filename)));

			logger.debug("Updating Batch definition");
			updateBatchDefinition(groupId, projectName, workflowName, workflowType);
			return jobinfo;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Update batch definition.
	 *
	 * @param groupId the group id
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 */
	private void updateBatchDefinition(String groupId, String projectName, String workflowName, String workflowType) {
		try{
			if (null == groupId || groupId.isEmpty()){
				BatchDefinitionService batchDefinitionService = BeanUtilService.getBeanObject(BatchDefinitionService.class);
				BatchDefinition batchDefinition = batchDefinitionService.getBatchDefinition(projectName, workflowName, workflowType);
				groupId = batchDefinition.getGroupId();
				if (null == groupId || groupId.isEmpty()){
					groupId = BeanUtilService.getBeanObject(PublishedWorkflowRepository.class).get(projectName, workflowName, workflowType).getId();
					batchDefinition.setGroupId(groupId);
					batchDefinitionService.saveBatchDefinition(batchDefinition);
				}
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Builds the generic job info.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param groupId the group id
	 * @return the job info
	 */
	private JobInfo buildGenericJobInfo(String projectName, String workflowName, String workflowType, String groupId) {
		try{
			JobInfo jobinfo = new JobInfo();
			jobinfo.setName(projectName + workflowName);
			jobinfo.setStatus(JobStatus.CREATED);
			jobinfo.setGroupId(groupId);
			jobinfo.setProjectName(projectName);
			jobinfo.setWorkflowName(workflowName);
			jobinfo.setWorkflowType(workflowType);
			jobinfo.setJobTasks(getJobTasks(workflowName, groupId));

			return jobinfo;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the job tasks.
	 *
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @return the job tasks
	 */
	private List<JobTask> getJobTasks(String workflowName, String groupId) {
		try{
			JobTask jobtask = new JobTask();
			jobtask.setTaskId(UUID.randomUUID().toString().replace("-", ""));
			jobtask.setExecutionInfo(getExecutionInfo(workflowName, groupId));
			ArrayList<JobTask> jobtasks = new ArrayList<>();
			jobtasks.add(jobtask);
			return jobtasks;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the execution info.
	 *
	 * @param workflowName the workflow name
	 * @param groupId the group id
	 * @return the execution info
	 */
	private ExecutionInfo getExecutionInfo(String workflowName, String groupId) {
		try{
			ExecutionInfo executionInfo = new ExecutionInfo();
			executionInfo.setGroupId(groupId);
			executionInfo.setId(workflowName);
			executionInfo.setType("Workflow");
			executionInfo.setErrorHandlingId(null);
			executionInfo.setErrorHandlingType(null);
			return executionInfo;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the step inputs for etl.
	 *
	 * @param stepName the step name
	 * @param destfile the destfile
	 * @param filename the filename
	 * @return the step inputs for etl
	 */
	private Map<String, List<String>> getStepInputsForEtl(String stepName, String destfile, String filename) {
		try{
			HashMap<String, List<String>> stepInputs = new HashMap<>();
			logger.info("File name  while creating jobInfo object {}", filename);
			List<String> readerStepParameter = new ArrayList<>();
			logger.info("File directory location in while creating jobInfo object {}", destfile);
			readerStepParameter.add(destfile);
			stepInputs.put(stepName, readerStepParameter);
			return stepInputs;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Update data ingestion date.
	 *
	 * @param institutionId the institution id
	 */
	private void updateDataIngestionDate(String institutionId) {
		try{
			InstitutionRepository institutionRepository = BeanUtilService.getBeanObject(InstitutionRepository.class);
			Optional<Institution> institutionOptional = institutionRepository.findById(institutionId);
			if (!institutionOptional.isPresent()){
				throw new GenericException("Institution not found");
			}
			Institution institution = institutionOptional.get();

			InstitutionService institutionService = BeanUtilService.getBeanObject(InstitutionService.class);
			institutionService.updateDataIngestionDate(institution);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the file owners id.
	 *
	 * @param file the file
	 * @param serviceUser the service user
	 * @return the file owners id
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private PosixFileAttributes getServiceUserDetails(File file) {
		try{
			Path path = file.toPath();
			return Files.readAttributes(path, PosixFileAttributes.class);
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * For creating case on Salesforce for Quartz
	 * 
	 * @param reasonCode
	 * @param projectName
	 * @param workflowName
	 * @param priority
	 * @param comment
	 */
	private void createCaseforQuartz(String reasonCode, String projectName, String workflowName, Priority priority, String comment) {
		try{
			SalesforceCaseHelper salesforceCaseHelper = BeanUtilService.getBeanObject(SalesforceCaseHelper.class);
			List<SalesforceCaseRequest> childcases = new ArrayList<>();
			UUID uuid = UUID.randomUUID();
			SalesforceCaseRequest salesForceCaseRequest = SalesforceCaseRequest.builder().referenceId(uuid.toString()).origin(ORIGIN_QUARTZ).reasonCode(SchedularConstants.SCHEDUALAR_QUARTZ).status(CASE_STATE).systemErrorType(Severity.ERROR).reasonCode(reasonCode).project(projectName + "" + workflowName).activity("Schedualar-Operation").comment("Exception Details :" + comment).contactSkypeName("").description("").subject(reasonCode + "For :" + projectName + "-" + workflowName).project(projectName).priority(priority).childcases(childcases).build();
			logger.debug("SalesForce Case Request : ---> {}", salesForceCaseRequest);
			SalesforceCaseResponse salesforcecaseresponse = salesforceCaseHelper.createCase(salesForceCaseRequest, salesforceCaseHelper.authenticate().getAccessToken());
			logger.debug("SalesForce Case Response : --->{}", salesforcecaseresponse);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Stop the current running job.
	 *
	 * @param jobId the job id
	 */
	public String cancelJob(String jobId) {
		logger.debug("Received Job cancel command for jobId {}", jobId);
		try{
			OptimusRestClient client = BeanUtilService.getBeanObject(OptimusRestClient.class);
			if (jobId != null){
				client.cancelJob(jobId);
				return SUCCESS_RESPONSE;
			} else{
				logger.error("Failed to cancel the job. Please check the server log");
				return "Failed";
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}