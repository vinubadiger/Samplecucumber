package com.opus.optimus.scheduler.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;

/**
 * The Interface PublishedWorkflowRepository.
 */
@Repository
public interface PublishedWorkflowRepository extends MongoRepository<PublishedService, String> {

	/**
	 * Gets the.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the published service
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	PublishedService get(String projectName, String workflowName, String workflowType);

	/**
	 * Gets the.
	 *
	 * @param activityName the activity name
	 * @param workflowType the workflow type
	 * @return the published service
	 */
	@Query (value = "{ $and: [ { 'workflowName' : ?0 },{'workflowType' : ?1} ] }")
	PublishedService get(String activityName, String workflowType);
}
