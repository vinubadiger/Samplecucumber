package com.opus.optimus.scheduler.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.user.Institution;


/**
 * The Interface InstitutionRepository.
 */
@Repository
public interface InstitutionRepository extends MongoRepository<Institution, String> {

	/**
	 * Find by institution id.
	 *
	 * @param institutionId the institution id
	 * @return the institution
	 */
	@Query ("{id:'?0'}")
	Institution findByInstitutionId(String institutionId);
	
	@Query("{ 'institutionName' :'?0'}")
	Institution findByInstitutionName(String institutionName);
}