/**
 * 
 */
/**
 * @author Yashkumar.Thakur
 */
package com.opus.optimus.scheduler.constants;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class SchedularConstants {
	public static final String SCHEDUALAR_NO_OF_FILE_PROCESS = "Number of processed files from Schedular";
	public static final String SCHEDUALAR_QUARTZ = "Job has been failed";
	public static final String SYSTEM_USERNAME = "system";
	public static final String ID = "id";
	public static final String SAVE = "save";
	public static final String DELETE = "delete";
	public static final String _ID = "_id";

}