package com.opus.optimus.scheduler.services;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Interface BatchDefinitionService.
 */
public interface BatchDefinitionService {

	/**
	 * Save batch definition.
	 *
	 * @param batchDefinition the batch definition
	 * @return the batch definition
	 */
	BatchDefinition saveBatchDefinition(BatchDefinition batchDefinition);

	/**
	 * Save batch definition job execution.
	 *
	 * @param batchDefinition the batch definition
	 */
	void saveBatchDefinitionJobExecution(BatchDefinition batchDefinition);

	/**
	 * Gets the batch definitions.
	 *
	 * @param scheduleFlag the schedule flag
	 * @param page the page
	 * @param size the size
	 * @return the batch definitions
	 */
	Page<BatchDefinition> getBatchDefinitions(String scheduleFlag, int page, int size);

	/**
	 * Gets the batch definitions.
	 *
	 * @param scheduleFlag the schedule flag
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the batch definitions
	 */
	Page<BatchDefinition> getBatchDefinitions(String scheduleFlag, int page, int size, String orderType, String field);

	/**
	 * Gets the batch definition.
	 *
	 * @param batchDefinition the batch definition
	 * @return the batch definition
	 */
	BatchDefinition getBatchDefinition(BatchDefinition batchDefinition);

	/**
	 * Gets the batch definition.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the batch definition
	 */
	BatchDefinition getBatchDefinition(String projectName, String workflowName, String workflowType);

	/**
	 * Removes the scheduling.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the string
	 */
	String removeScheduling(String projectName, String workflowName, String workflowType);

	/**
	 * Find all by.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	Page<BatchDefinition> findAllBy(String search, int page, int size);

	/**
	 * Searchbycolumnnameandtext.
	 *
	 * @param column the column
	 * @param text the text
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	Page<BatchDefinition> searchbycolumnnameandtext(String scheduleFlag, int page, int size, Map<String,String> map);

	/**
	 * Autocomplete by text.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return the page
	 */
	Page<BatchDefinition> autocompleteByText(String column, String pattern);

	/**
	 * Auto restart schedule.
	 */
	void autoRestartSchedule();

	/**
	 * Delete.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	ServiceResponse delete(String projectName, String workflowName, String workflowType);

	ServiceResponse deleteCheck(String projectName, String workflowName, String workflowType);

	BatchDefinition findWorkflowByGivenData(String projectName, String workflowName, String workflowType);
	
	List<BatchDefinition> getAllEtlEnableBatchDefination();

}