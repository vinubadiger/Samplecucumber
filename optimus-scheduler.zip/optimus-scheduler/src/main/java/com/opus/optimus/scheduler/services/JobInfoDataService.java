package com.opus.optimus.scheduler.services;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

/**
 * The Interface JobInfoDataService.
 *
 * @author manjusha.dhamdhere
 */

public interface JobInfoDataService {

	/**
	 * Save.
	 *
	 * @param jobId the job id
	 * @param jobinfo the jobinfo
	 * @return the string
	 */
	String save(String jobId, JobInfo jobinfo);

	/**
	 * Gets the job info.
	 *
	 * @param page the page
	 * @param size the size
	 * @return the job info
	 */
	Page<JobInfo> getJobInfo(int page, int size);

	/**
	 * Gets the job info order by.
	 *
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the job info order by
	 */
	Page<JobInfo> getJobInfoOrderBy(int page, int size, String orderType, String field);

	/**
	 * Gets the job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the job task executor resultby id
	 */
	List<JobTaskExecutorResult> getJobTaskExecutorResultbyId(String jobId);

	/**
	 * Find all by.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	Page<JobInfo> findAllBy(String search, int page, int size);

	/**
	 * Searchbycolumnnameandtext.
	 *
	 * @param column the column
	 * @param text the text
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	Page<JobInfo> searchbycolumnnameandtext(int page, int size, Map<?, ?> map);

	/**
	 * Autocomplete by text.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return the page
	 */
	Page<JobInfo> autocompleteByText(String column, String pattern);

	/**
	 * Gets the jobinfodatabyparam.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param page the page
	 * @param size the size
	 * @return the jobinfodatabyparam
	 */
	Page<JobInfo> getjobinfodatabyparam(String projectName, String workflowName, String workflowType, int page, int size);

	long findForNoOfFilesToBeProcess(String workflowType, String projectName, String workflowName, Date startDate, Date endDate);
}