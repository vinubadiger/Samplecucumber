package com.opus.optimus.scheduler.repository.audit;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.audit.BatchDefinitionAudit;

@Repository
public interface BatchDefinitionAuditRepository extends MongoRepository<BatchDefinitionAudit, String> {
}