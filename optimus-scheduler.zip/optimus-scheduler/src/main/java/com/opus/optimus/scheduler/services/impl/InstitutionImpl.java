package com.opus.optimus.scheduler.services.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.constants.Constants;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.user.Institution;
import com.opus.optimus.scheduler.repository.InstitutionRepository;
import com.opus.optimus.scheduler.services.InstitutionService;
import com.opus.optimus.scheduler.services.quartz.QuartzScheduler;

/**
 * The Class InstitutionImpl.
 */
@Service
public class InstitutionImpl implements InstitutionService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(InstitutionImpl.class);


	/** The institution repository. */
	@Autowired
	private InstitutionRepository institutionRepository;

	@Override
	public void setCutOverTimeLogic() {
		try{
			List<Institution> institutions = this.institutionRepository.findAll();
			List<Institution> institutionsWithCutOver = institutions.stream().filter(institution -> null != institution.getCutoverDetail()).collect(Collectors.toList());
			institutionsWithCutOver.forEach(institution -> {
				log.debug("Setting CutoverTime logic for Institution - {}", institution.getDisplayName());
				int hour = institution.getCutoverDetail().getHour();
				int min = institution.getCutoverDetail().getMinute();
				Calendar calendar = Calendar.getInstance();
				calendar.setTimeZone(Optional.ofNullable(institution.getTimeZone()).orElse(TimeZone.getTimeZone(Constants.TIMEZONE)));
				calendar.setTime(new Date());
				calendar.set(Calendar.HOUR_OF_DAY, hour);
				calendar.set(Calendar.MINUTE, min);
				calendar.set(Calendar.SECOND, 0);
				Date cutOverTime = calendar.getTime();
				institution.getCutoverDetail().setCutOverTime(cutOverTime);
				updateDataIngestionDate(institution);
				QuartzScheduler.quartzSchedulerForCutOverTime(institution);
			});
			List<Institution> updatedList = institutionRepository.saveAll(institutionsWithCutOver);
			log.debug("Updating the Business processing date of total {} number of Instituion", updatedList.size());
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public void updateDataIngestionDate(Institution institution) {
		try{
			if (institution.getBusinessProcessingDate() == null){
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(new Date());
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				institution.setBusinessProcessingDate(calendar.getTime());
			} else{
				Calendar processDateCalendar = Calendar.getInstance();
				processDateCalendar.setTime(institution.getBusinessProcessingDate());

				Calendar now = Calendar.getInstance();
				now.setTime(new Date());

				boolean sameDay = now.get(Calendar.DAY_OF_YEAR) == processDateCalendar.get(Calendar.DAY_OF_YEAR) && now.get(Calendar.YEAR) == processDateCalendar.get(Calendar.YEAR);

				if (sameDay){
					processDateCalendar.set(Calendar.HOUR_OF_DAY, 0);
					processDateCalendar.set(Calendar.MINUTE, 0);
					processDateCalendar.set(Calendar.SECOND, 0);
					processDateCalendar.add(Calendar.DAY_OF_MONTH, 1);
					institution.setBusinessProcessingDate(processDateCalendar.getTime());
				} else{
					now.set(Calendar.HOUR_OF_DAY, 0);
					now.set(Calendar.MINUTE, 0);
					now.set(Calendar.SECOND, 0);
					now.add(Calendar.DAY_OF_MONTH, 1);
					institution.setBusinessProcessingDate(now.getTime());
				}
			}
			log.debug("Business processign date of institution - {} is set as - {}", institution.getDisplayName(), institution.getBusinessProcessingDate());
			this.institutionRepository.save(institution);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}
