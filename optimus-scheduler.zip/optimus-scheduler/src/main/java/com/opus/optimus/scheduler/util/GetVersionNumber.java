package com.opus.optimus.scheduler.util;

import java.sql.Timestamp;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class GetVersionNumber {

	public static Timestamp getVersion() {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());;
		return timestamp;
	}
}
