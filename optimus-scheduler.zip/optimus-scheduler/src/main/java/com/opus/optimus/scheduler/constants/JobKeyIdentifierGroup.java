package com.opus.optimus.scheduler.constants;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class JobKeyIdentifierGroup {

	public static final String WORKFLOW = "WORKFLOW";
	public static final String CUTOVER = "CUTOVER";

}
