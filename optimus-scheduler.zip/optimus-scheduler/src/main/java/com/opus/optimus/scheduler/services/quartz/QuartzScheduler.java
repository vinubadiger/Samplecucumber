package com.opus.optimus.scheduler.services.quartz;

import java.util.Date;
import java.util.TimeZone;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.constants.Constants;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.user.Institution;
import com.opus.optimus.scheduler.constants.JobKeyIdentifierGroup;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Class QuartzScheduler entry point to schedule job.
 */
public class QuartzScheduler {

	/**
	 * Instantiates a new quartz scheduler.
	 */
	private QuartzScheduler() {
	}

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(QuartzScheduler.class);

	/** The Constant PROJECT_NAME. */
	public static final String PROJECT_NAME = "projectName";

	/** The Constant WORKFLOW_NAME. */
	public static final String WORKFLOW_NAME = "workflowName";

	/** The Constant WORKFLOW_TYPE. */
	public static final String WORKFLOW_TYPE = "workflowType";

	/** The Constant GROUP_ID. */
	public static final String GROUP_ID = "groupId";

	/** The Constant STEPINPUT_DATA. */
	public static final String STEPINPUT_DATA = "stepInputData";

	/** The Constant INSTITUTION_NAME. */
	public static final String INSTITUTION_ID = "institutionId";

	/**
	 * Quartz scheduler trigger.
	 *
	 * @param intervalM the interval M
	 * @param batchDefinition the batch definition
	 * @param startTime the start time
	 */
	public static void quartzSchedulerTrigger(int intervalM, BatchDefinition batchDefinition, Date startTime) {
		try{
			JobDataMap jobDataMap = getJobDataMapForWorkflowExecution(batchDefinition);

			String jobKey = getJobKeyForWorkflow(batchDefinition);

			JobDetail job = JobBuilder.newJob(JobExecution.class).withIdentity(jobKey, JobKeyIdentifierGroup.WORKFLOW).setJobData(jobDataMap).build();

			Trigger trigger = TriggerBuilder.newTrigger().withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes(intervalM).repeatForever()).startAt(startTime).build();

			SchedulerFactory scFactory = new StdSchedulerFactory();
			Scheduler sch = scFactory.getScheduler();
			sch.start();
			sch.scheduleJob(job, trigger);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Quartz scheduler cron expression.
	 *
	 * @param crondata the crondata
	 * @param batchDefinition the batch definition
	 * @param startTime the start time
	 */
	public static void quartzSchedulerCronExpression(String crondata, BatchDefinition batchDefinition, Date startTime) {
		try{

			JobDataMap jobDataMap = getJobDataMapForWorkflowExecution(batchDefinition);

			String jobKey = getJobKeyForWorkflow(batchDefinition);

			JobDetail job = JobBuilder.newJob(JobExecution.class).withIdentity(jobKey, JobKeyIdentifierGroup.WORKFLOW).setJobData(jobDataMap).build();

			CronTrigger crontrigger = TriggerBuilder.newTrigger().startAt(startTime).withSchedule(CronScheduleBuilder.cronSchedule(crondata).inTimeZone(TimeZone.getTimeZone(Constants.TIMEZONE))).build();

			SchedulerFactory scFactory = new StdSchedulerFactory();
			Scheduler sch = scFactory.getScheduler();
			sch.start();
			sch.scheduleJob(job, crontrigger);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the job data map for workflow execution.
	 *
	 * @param batchDefinition the batch definition
	 * @return the job data map for workflow execution
	 */
	private static JobDataMap getJobDataMapForWorkflowExecution(BatchDefinition batchDefinition) {
		JobDataMap jobDataMap = new JobDataMap();
		jobDataMap.put(PROJECT_NAME, batchDefinition.getProjectName());
		jobDataMap.put(WORKFLOW_NAME, batchDefinition.getWorkflowName());
		jobDataMap.put(WORKFLOW_TYPE, batchDefinition.getWorkflowType());
		jobDataMap.put(GROUP_ID, batchDefinition.getGroupId());
		jobDataMap.put(STEPINPUT_DATA, batchDefinition.getStepInputData());
		jobDataMap.put("schedularTriggered", true);
		return jobDataMap;
	}

	/**
	 * Gets the job key for workflow.
	 *
	 * @param batchDefinition the batch definition
	 * @return the job key for workflow
	 */
	private static String getJobKeyForWorkflow(BatchDefinition batchDefinition) {
		StringBuilder jobKey = new StringBuilder();
		jobKey.append(batchDefinition.getProjectName());
		jobKey.append(batchDefinition.getWorkflowName());
		jobKey.append(batchDefinition.getWorkflowType());
		return jobKey.toString();
	}

	/**
	 * Removes the quartz scheduler cron expression.
	 *
	 * @param jobKey the job key
	 * @return true, if successful
	 */
	public static boolean removeQuartzSchedulerCronExpression(JobKey jobKey) {
		logger.debug("jobKey :{} ", jobKey);
		SchedulerFactory scFactory = new StdSchedulerFactory();
		try{
			boolean status = scFactory.getScheduler().deleteJob(jobKey);
			logger.debug("Job with jobKey : {} deleted with status : {}", jobKey, Boolean.valueOf(status));
			return status;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Quartz scheduler for cut over time.
	 *
	 * @param institution the institution
	 * @param startTime the start time
	 */
	public static void quartzSchedulerForCutOverTime(Institution institution) {
		try{
			logger.debug("Scheduling Job at CutoverTime for Institution - {}", institution.getDisplayName());
			JobDataMap jobDataMap = new JobDataMap();
			jobDataMap.put(INSTITUTION_ID, institution.getId());

			StringBuilder jobKey = new StringBuilder();
			jobKey.append(institution.getInstitutionName());
			jobKey.append(institution.getDisplayName());

			JobDetail job = JobBuilder.newJob(JobExecution.class).withIdentity(jobKey.toString(), JobKeyIdentifierGroup.CUTOVER).setJobData(jobDataMap).build();

			Trigger trigger = TriggerBuilder.newTrigger().withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInHours(24).repeatForever()).startAt(institution.getCutoverDetail().getCutOverTime()).build();

			SchedulerFactory scFactory = new StdSchedulerFactory();
			Scheduler sch = scFactory.getScheduler();
			sch.start();
			sch.scheduleJob(job, trigger);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}