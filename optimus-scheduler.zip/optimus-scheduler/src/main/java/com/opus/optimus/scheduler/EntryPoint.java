package com.opus.optimus.scheduler;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.scheduler.services.BatchDefinitionService;
import com.opus.optimus.scheduler.services.InstitutionService;

/**
 * The Class EntryPoint that used to bootstrap and launch a application from a Java main.
 */
@SpringBootApplication
@EnableMongoAuditing
@EnableMongoRepositories ({"com.opus.optimus.scheduler.repository", "com.opus.optimus.offline.runtime.exception.repository"})
public class EntryPoint {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(EntryPoint.class);

	/** The batch definition service. */
	@Autowired
	private BatchDefinitionService batchDefinitionService;

	/** The institution service. */
	@Autowired
	private InstitutionService institutionService;

	/**
	 * On server restart Quartz scheduler read scheduling info from DB & reschedule configured jobs.
	 */
	@PostConstruct
	public void autoRestartSchedule() {
		try{
			logger.debug("Auto Restart Schedule Enable - BatchDefinition");
			this.batchDefinitionService.autoRestartSchedule();

			logger.debug("Auto Restart Schedule Enable - Institution");
			this.institutionService.setCutOverTimeLogic();
		} catch (Exception e){
			logger.error(e.getMessage(), e);
		}

	}

	@Bean
	@Primary
	public ObjectMapper optimusObjectMapper(MapperFactory mapperFactory) {
		return mapperFactory.getMapper();
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(EntryPoint.class, args);
	}
}
