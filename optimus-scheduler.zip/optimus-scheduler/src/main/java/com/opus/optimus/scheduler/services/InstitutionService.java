package com.opus.optimus.scheduler.services;

import com.opus.optimus.offline.config.user.Institution;

/**
 * The Interface IInstitutionService.
 */
public interface InstitutionService {

	/**
	 * Auto restart cutOverTime schedule.
	 */
	void setCutOverTimeLogic();

	/**
	 * updateDataIngestionDate - businessDate.
	 */
	void updateDataIngestionDate(Institution institution);

}
