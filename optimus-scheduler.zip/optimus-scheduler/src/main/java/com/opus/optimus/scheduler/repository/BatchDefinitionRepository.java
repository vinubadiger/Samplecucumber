package com.opus.optimus.scheduler.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.query.TextCriteria;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Interface BatchDefinitionRepository.
 */
@Repository ("batchDefinitionRepository")
public interface BatchDefinitionRepository extends MongoRepository<BatchDefinition, String> {

	/**
	 * Find workflow by given data.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the batch definition
	 */
	@Query (value = "{ $and : [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	BatchDefinition findWorkflowByGivenData(String projectName, String workflowName, String workflowType);

	/**
	 * Find all is null.
	 *
	 * @param pageable the pageable
	 * @return the page
	 */
	@Query ("{ 'schedulerPolicy' : null }")
	Page<BatchDefinition> findAllIsNull(Pageable pageable);

	/**
	 * Find all is not null.
	 *
	 * @param pageable the pageable
	 * @return the page
	 */
	@Query ("{ 'schedulerPolicy' : {$ne : null} }")
	Page<BatchDefinition> findAllIsNotNull(Pageable pageable);

	/**
	 * Find all by.
	 *
	 * @param criteria the criteria
	 * @param page the page
	 * @return the page
	 */
	Page<BatchDefinition> findAllBy(TextCriteria criteria, Pageable page);

	/**
	 * Find all is not null.
	 *
	 * @return the list
	 */
	@Query ("{'disabled': false, 'schedulerPolicy' : {$ne : null}}")
	List<BatchDefinition> findAllIsNotNull();

	/**
	 * Gets the expected files counts.
	 *
	 * @return the expected files counts
	 */
	@Query (value = "{'workflowtype' : {$eq:'ETL'}}", fields = "{'project_name': 1, 'workflowname':1, 'workflowtype':1, 'numberOfExpectedFiles':1, 'schedulerPolicy':1, '_id':0}")
	List<BatchDefinition> getExpectedFilesCounts();
	
	/**
	 * Find all the records for the project for which the user have access
	 * @param projectName
	 * @return
	 */
	@Query (value = "{'projectName': { $in : ?0}}")
	List<BatchDefinition> findBatchDefinitionByProjectName(List<String> projectName,Pageable pageable);

	@Query ("{'disabled': false, 'workflowtype' : 'ETL'}")
	List<BatchDefinition> findAllEtlEnableBatchDefinations();
}