package com.opus.optimus.scheduler.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.annotation.Configuration;

import com.opus.optimus.offline.config.exception.GenericException;

/**
 * The Class BeanUtilService.
 */
@Configuration
public class BeanUtilService implements BeanDefinitionRegistryPostProcessor {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(BeanUtilService.class);

	/** The application context. */
	private static ConfigurableListableBeanFactory beanFactory;

	/**
	 * Gets the bean object.
	 *
	 * @param <T> the generic type
	 * @param requiredType the required type
	 * @return the bean object
	 */
	public static synchronized <T> T getBeanObject(Class<T> requiredType) {
		try{
			logger.debug("Fetching Bean object from container for class {}", requiredType.getName());
			return beanFactory.getBean(requiredType);
		} catch (NoSuchBeanDefinitionException e){
			String beanName = requiredType.getName();
			logger.debug("Bean not Found for type {}; Registering one !!", beanName);
			Object singletonObject = beanFactory.createBean(requiredType, AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE, true);
			beanFactory.registerSingleton(beanName, singletonObject);
			return beanFactory.getBean(requiredType);
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see org.springframework.beans.factory.config.BeanFactoryPostProcessor#postProcessBeanFactory(org.springframework.beans.factory.config.
	 * ConfigurableListableBeanFactory)
	 */
	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory2) {
		BeanUtilService.beanFactory = beanFactory2;
	}

	/*
	 * (non-Javadoc)
	 * @see org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor#postProcessBeanDefinitionRegistry(org.springframework.beans.
	 * factory.support.BeanDefinitionRegistry)
	 */
	@Override
	public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry2) {}
}