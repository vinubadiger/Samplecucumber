package com.opus.optimus.scheduler.services.webclient;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;

/**
 * The Class RestClient client to perform HTTP requests for below tasks. 1.Create JobInfo when user schedule job or onjob creation 2.Close case using
 * caseID
 */
@Service
public class OptimusRestClient {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(OptimusRestClient.class);

	/** The host url. */
	@Value ("${client.hosturl}")
	private String hostUrl;

	/** The api base url. */
	@Value ("${client.baseurl}")
	private String apiBaseUrl;

	/** The salesforce auth url. */
	@Value ("${saleforce.authurl}")
	String salesforceAuthUrl;

	/** The salesforce case url. */
	@Value ("${saleforce.casecloseurl}")
	String salesforceCaseUrl;

	/** The salesforce token. */
	@Value ("${saleforce.token}")
	String salesforceToken;

	/** The salesforce token. */
	@Value ("${saleforce.exceptiontype}")
	String exceptionType;

	/**
	 * Decorate rest template.
	 *
	 * @param <T> the generic type
	 * @param url the url
	 * @param requestParams the request params
	 * @param requestBody the request body
	 * @param httpEntity the http entity
	 * @param responseType the response type
	 * @param httpMethod the http method
	 * @return the http components client http request factory
	 * @throws KeyManagementException the key management exception
	 * @throws NoSuchAlgorithmException the no such algorithm exception
	 * @throws KeyStoreException the key store exception
	 */
	public <T> T decorateRestTemplateAndSendRequest(String url, Map<String, ?> requestParams, Object requestBody, HttpEntity<MultiValueMap<String, Object>> httpEntity, Class<T> responseType, HttpMethod httpMethod) throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

		try (CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build()){

			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

			requestFactory.setHttpClient(httpClient);

			RestTemplate restTemplate = new RestTemplate(requestFactory);

			switch (httpMethod) {
			case POST:
				return restTemplate.postForObject(url, requestBody, responseType);
			case GET:
				return restTemplate.getForObject(url, responseType, requestParams);
			case PATCH:
				return restTemplate.patchForObject(url, httpEntity, responseType);
			default:
				return null;
			}
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Builds the api url.
	 *
	 * @param apiUrl the api url
	 * @return the string
	 */
	private String buildApiUrl(String apiUrl) {
		try{
			StringBuilder urlBuilder = new StringBuilder();
			urlBuilder.append(hostUrl);
			urlBuilder.append(apiBaseUrl);
			urlBuilder.append(apiUrl);
			log.info("URL - {}", urlBuilder);
			return urlBuilder.toString();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Creates the job.
	 *
	 * @param job the job
	 * @return the string
	 */
	public String createJob(JobInfo job) {
		log.debug("In Rest client Save job");
		try{
			final String uri = buildApiUrl(job.getName());
			return decorateRestTemplateAndSendRequest(uri, null, job.getJobTasks(), null, String.class, HttpMethod.POST);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Run job.
	 *
	 * @param jobId the job id
	 */
	public void runJob(String jobId) {
		try{
			log.debug("In Rest client Run job");
			final String uri = buildApiUrl("run/{jobId}");
			Map<String, String> params = new HashMap<>();
			params.put("jobId", jobId);
			decorateRestTemplateAndSendRequest(uri, params, null, null, String.class, HttpMethod.GET);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Cancel job.
	 *
	 * @param jobId the job id
	 */
	public void cancelJob(String jobId) {
		try{
			log.debug("In Rest client to cancel job");
			final String uri = buildApiUrl("cancel/{jobId}");
			Map<String, String> params = new HashMap<>();
			params.put("jobId", jobId);
			decorateRestTemplateAndSendRequest(uri, params, null, null, String.class, HttpMethod.GET);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
