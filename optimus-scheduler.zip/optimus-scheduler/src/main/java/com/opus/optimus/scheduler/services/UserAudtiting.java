package com.opus.optimus.scheduler.services;

import static com.opus.optimus.scheduler.constants.SchedularConstants.SYSTEM_USERNAME;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class UserAudtiting implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return authentication != null ? getLoggedInUser(authentication) : getSystemUser();
	}

	private Optional<String> getLoggedInUser(Authentication authentication) {
		if (!authentication.isAuthenticated()) {
			return Optional.empty();
		}
		return Optional.of((String) authentication.getPrincipal());
	}

	private Optional<String> getSystemUser() {
		return Optional.of(SYSTEM_USERNAME);
	}

}