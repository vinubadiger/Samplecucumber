package com.opus.optimus.scheduler.listeners;

import static com.opus.optimus.scheduler.constants.SchedularConstants.DELETE;
import static com.opus.optimus.scheduler.constants.SchedularConstants.ID;
import static com.opus.optimus.scheduler.constants.SchedularConstants.SAVE;
import static com.opus.optimus.scheduler.constants.SchedularConstants._ID;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.scheduler.repository.BatchDefinitionRepository;
import com.opus.optimus.scheduler.repository.audit.BatchDefinitionAuditRepository;
import com.opus.optimus.scheduler.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.BatchDefinitionAudit;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;

@Component
public class BatchDefinitionEventListener extends AbstractMongoEventListener<BatchDefinition> {

	@Autowired
	private BatchDefinitionAuditRepository batchDefinitionAuditRepository;
	@Autowired
	private BatchDefinitionRepository batchDefinitionRepository;
	private BatchDefinition batchDefinitionStore;

	@Override
	public void onAfterSave(AfterSaveEvent<BatchDefinition> event) {
		BatchDefinitionAudit batchDefinitionAudit = getBatchDefinitionAudit(event.getSource());
		batchDefinitionAudit.setAction(SAVE);
		batchDefinitionAuditRepository.save(batchDefinitionAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<BatchDefinition> event) {
		storeBatchDefinition(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<BatchDefinition> event) {
		BatchDefinitionAudit batchDefinitionAudit = getBatchDefinitionAudit(batchDefinitionStore);
		batchDefinitionAudit.setAction(DELETE);
		batchDefinitionAuditRepository.save(batchDefinitionAudit);
	}

	private BatchDefinitionAudit getBatchDefinitionAudit(BatchDefinition batchDefination) {
		BatchDefinitionAudit batchDefinitionAudit = new BatchDefinitionAudit();
		BeanUtils.copyProperties(batchDefination, batchDefinitionAudit, ID);
		setAdditionalAuditingFields(batchDefination, batchDefinitionAudit);
		return batchDefinitionAudit;
	}

	private void setAdditionalAuditingFields(BatchDefinition batchDefination, BatchDefinitionAudit batchDefinitionAudit) {
		batchDefinitionAudit.setDocumentId(batchDefination.getId());
		batchDefinitionAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeBatchDefinition(BeforeDeleteEvent<BatchDefinition> event) {
		Optional<BatchDefinition> batchDefinition = batchDefinitionRepository.findById(event.getDocument().get(_ID).toString());
		if (batchDefinition.isPresent()){
			batchDefinitionStore = batchDefinition.get();
		}
	}

}
