package com.opus.optimus.scheduler.services.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.SkipOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.TextCriteria;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.IStepLink;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.scheduler.repository.JobInfoDataRepository;
import com.opus.optimus.scheduler.repository.JobTaskExecutorResultRepository;
import com.opus.optimus.scheduler.repository.PublishedWorkflowRepository;
import com.opus.optimus.scheduler.repository.UserRepository;
import com.opus.optimus.scheduler.services.JobInfoDataService;
import com.opus.optimus.scheduler.util.BeanUtilService;
import com.opus.optimus.scheduler.util.UserContextUtility;
import com.opus.optimus.ui.services.user.User;
import com.opus.optimus.ui.services.util.CommonUtil;

/**
 * The Class JobInfoDataServiceImpl.
 * 
 * @author manjusha.dhamdhere
 */
@Service
public class JobInfoDataServiceImpl implements JobInfoDataService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(JobInfoDataServiceImpl.class);

	/** The job info data repository. */
	@Autowired
	private JobInfoDataRepository jobInfoDataRepository;

	@Autowired
	private JobTaskExecutorResultRepository jobtaskexecutorresultrepository;

	/** The mongo template. */
	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	PublishedWorkflowRepository publishedWorkflowRepository;

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserContextUtility userContextUtility;

	/**
	 * Save Job info.
	 *
	 * @param jobId the job id
	 * @param jobinfo the jobinfo
	 * @return the string
	 */
	@Override
	public String save(String jobId, JobInfo jobinfo) {
		try{
			logger.debug("JobID - {}, Sourceinfo - {}", jobId, jobinfo.getSourceInfo());
			JobInfo recievedjobinfo = this.jobInfoDataRepository.findJobbyId(jobId);
			logger.debug("job info : {}", CommonUtil.getJsonFromObject(recievedjobinfo));
			recievedjobinfo.setWorkflowName(jobinfo.getWorkflowName());
			recievedjobinfo.setWorkflowType(jobinfo.getWorkflowType());
			recievedjobinfo.setProjectName(jobinfo.getProjectName());
			recievedjobinfo.setGroupId(jobinfo.getGroupId());
			recievedjobinfo.setSourceInfo(jobinfo.getSourceInfo());
			String institutionId = BeanUtilService.getBeanObject(Environment.class).getProperty("institution.institutionId");
			recievedjobinfo.setInstitutionId(institutionId);
			jobInfoDataRepository.save(recievedjobinfo);
			return "Updated Jobinfo";
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the job info.
	 *
	 * @param page the page
	 * @param size the size
	 * @return the job info
	 */
	@Override
	public Page<JobInfo> getJobInfo(int page, int size) {
		try{
			User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
			Pageable pageable = PageRequest.of(page, size);
			if (userContextUtility.checkIfAdminUser()){
				return this.jobInfoDataRepository.findAll(pageable);
			} else{
				return getJobInfoForProjectsAssignedToUser(user, pageable);
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Returns the Batch Definition data for the projects assigned to the user.
	 * 
	 * @return
	 */
	public Page<JobInfo> getJobInfoForProjectsAssignedToUser(User user, Pageable pageable) {
		try{
			List<JobInfo> jobInfoData = jobInfoDataRepository.findJobInfoDataByProjectName(user.getProjects(), pageable);
			return new PageImpl<>(jobInfoData);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the job info order by.
	 *
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the job info order by
	 */
	@Override
	public Page<JobInfo> getJobInfoOrderBy(int page, int size, String orderType, String field) {
		try{
			Sort sort;
			String order = "ASC";
			if (orderType.equals(order)){
				sort = new Sort(Sort.Direction.ASC, field);
			} else{
				sort = new Sort(Sort.Direction.DESC, field);
			}
			Pageable pageable = PageRequest.of(page, size, sort);
			return this.jobInfoDataRepository.findAll(pageable);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Find all Job info by.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	@Override
	public Page<JobInfo> findAllBy(String search, int page, int size) {
		try{
			TextCriteria tsearch = TextCriteria.forDefaultLanguage().matching(search).caseSensitive(false);
			Pageable pageable = PageRequest.of(page, size);
			return jobInfoDataRepository.findAllBy(tsearch, pageable);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Search by column name and text.
	 *
	 * @param column the column
	 * @param text the text
	 * @param page the page
	 * @param size the size
	 * @return the page
	 */
	@Override
	public Page<JobInfo> searchbycolumnnameandtext(int page, int size, Map<?, ?> map) {
		try{
			Pageable pageable = PageRequest.of(page, size);
			List<Criteria> list = new ArrayList<>();
			String column = null;
			int count = 0;
			for (Map.Entry<?, ?> requestMap : map.entrySet()){
				logger.debug("Advance Search Key Value Pair -- {}, {}", requestMap.getKey(), requestMap.getValue());
				if (!(requestMap.getValue().toString().isEmpty())){
					if (count == 0){
						column = requestMap.getKey().toString();
						count++;
					}
					list.add(Criteria.where(requestMap.getKey().toString()).regex(Pattern.compile(requestMap.getValue().toString(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
				}
			}
			Criteria criteria = new Criteria().andOperator(list.toArray(new Criteria[list.size()]));
			SkipOperation skipOperation = Aggregation.skip(Integer.valueOf(pageable.getPageNumber()).longValue() * Integer.valueOf(pageable.getPageSize()).longValue());
			LimitOperation limitOperation = Aggregation.limit(pageable.getPageSize());
			SortOperation sortOperation = sort(Sort.Direction.DESC, column);

			Aggregation agg = newAggregation(Aggregation.match(criteria), skipOperation, limitOperation, sortOperation);
			AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class, JobInfo.class);

			return new PageImpl<>(result.getMappedResults());
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Autocomplete by text.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return the page
	 */
	@Override
	public Page<JobInfo> autocompleteByText(String column, String pattern) {
		try{
			Criteria regxCriteria = Criteria.where(column).regex(pattern);
			SortOperation sortOperation = sort(Sort.Direction.DESC, column);
			Aggregation agg = newAggregation(Aggregation.match(regxCriteria), sortOperation);
			AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class, JobInfo.class);
			return new PageImpl<>(result.getMappedResults());
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the job task executor resultby id
	 */
	@Override
	public List<JobTaskExecutorResult> getJobTaskExecutorResultbyId(String jobId) {
		try{
			logger.debug("Get jobtaskexecutorresult List by JobId {}", jobId);
			JobInfo recievedjobinfo = this.jobInfoDataRepository.findJobbyId(jobId);
			logger.debug("Group Id {}", recievedjobinfo.getGroupId());
			PublishedService publishservice = publishedWorkflowRepository.get(recievedjobinfo.getProjectName(), recievedjobinfo.getWorkflowName(), recievedjobinfo.getWorkflowType());
			List<IStepLink> stepLinks = publishservice.getWorkflowConfig().getStepLinks();
			final List<String> fromName = new ArrayList<>();
			for (IStepLink stepLink : stepLinks){
				fromName.add(stepLink.getFrom());
			}
			fromName.add(stepLinks.get(stepLinks.size() - 1).getTo());
			logger.debug("From name - {}", fromName);
			List<JobTaskExecutorResult> jobtaskexecutorresult = null;
			jobtaskexecutorresult = jobtaskexecutorresultrepository.findAllJobTaskExecutorResultbyId(jobId);
			jobtaskexecutorresult.stream().forEach(jobResult -> jobResult.getStepExecutorResults().sort((left, right) -> Integer.compare(fromName.indexOf(left.getStepName()), fromName.indexOf(right.getStepName()))));
			return jobtaskexecutorresult;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the jobinfodatabyparam.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param page the page
	 * @param size the size
	 * @return the jobinfodatabyparam
	 */
	@Override
	public Page<JobInfo> getjobinfodatabyparam(String projectName, String workflowName, String workflowType, int page, int size) {
		try{
			Pageable pageable = PageRequest.of(page, size);
			return jobInfoDataRepository.getjobinfodatabyparam(projectName, workflowName, workflowType, pageable);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failure analysis failed files.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */

	@Override
	public long findForNoOfFilesToBeProcess(String workflowType, String projectName, String workflowName, Date startDate, Date endDate) {
		try{
			return jobInfoDataRepository.findForNoOfFilesToBeProcess(workflowType, projectName, workflowName, startDate, endDate);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}
