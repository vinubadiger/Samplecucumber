package com.opus.optimus.scheduler.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.query.TextCriteria;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

/**
 * The Interface JobInfoDataRepository.
 */
@Repository
public interface JobInfoDataRepository extends MongoRepository<JobInfo, String> {

	/**
	 * Find job by id.
	 *
	 * @param jobId the job id
	 * @return the job info
	 */
	@Query ("{id:'?0'}")
	JobInfo findJobbyId(String jobId);

	/**
	 * Gets the JobInfo.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the job info
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	JobInfo get(String projectName, String workflowName, String workflowType);

	/**
	 * Find all ids by workflow type.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the list
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'workflowType' : ?0}] }", fields = "{'_id':1}")
	List<String> findAllIdsByWorkflowType(String workflowType, Date startDate, Date endDate);

	/**
	 * Find all ids by workflow type project.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the list
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'projectName' : ?3 }, { 'workflowType' : ?0}]}", fields = "{'_id':1}")
	List<String> findAllIdsByWorkflowTypeProject(String workflowType, Date startDate, Date endDate, String projectName);

	/**
	 * Find all ids by workflow name type.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowName the workflow name
	 * @return the list
	 */
	// for Widget 6
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'workflowName' : ?3 }, { 'workflowType' : ?0}] }", fields = "{'_id':1}")
	List<String> findAllIdsByWorkflowNameType(String workflowType, Date startDate, Date endDate, String workflowName);

	/**
	 * Find all ids by project workflow name type.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'projectName' : ?3 }, { 'workflowType' : ?0}, { 'workflowName' : ?4 }] }", fields = "{'_id':1}")
	List<String> findAllIdsByProjectWorkflowNameType(String workflowType, Date startDate, Date endDate, String projectName, String workflowName);

	/**
	 * Find all ids by project workflow name type file.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the list
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'projectName' : ?3 }, { 'workflowType' : ?0}, { 'workflowName' : ?4 }, { 'sourceInfo.source' : ?5 }] }", fields = "{'_id':1}")
	List<String> findAllIdsByProjectWorkflowNameTypeFile(String workflowType, Date startDate, Date endDate, String projectName, String workflowName, String sourceFile);

	/**
	 * Find all job task executor resultby id.
	 *
	 * @param jobId the job id
	 * @return the list
	 */
	@Query ("{jobId:'?0'}")
	List<JobTaskExecutorResult> findAllJobTaskExecutorResultbyId(String jobId);

	/**
	 * Find all by.
	 *
	 * @param criteria the criteria
	 * @param page the page
	 * @return the page
	 */
	Page<JobInfo> findAllBy(TextCriteria criteria, Pageable page);

	/**
	 * Count of all files.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the long
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'workflowType' : ?0}, {$or:[{'status': 'COMPLETED_FAILED'},{'status': 'COMPLETED_SUCCESS'}]}] }", count = true)
	Long countOfAllFiles(String workflowType, Date startDate, Date endDate);

	/**
	 * Count of failed files.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the long
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'workflowType' : ?0}, {'status': 'COMPLETED_FAILED'}] }", count = true)
	Long countOfFailedFiles(String workflowType, Date startDate, Date endDate);

	/**
	 * Count of all files with project name.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the long
	 */
	// with project name
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'workflowType' : ?0}, { 'projectName' : ?3 },{$or:[{'status': 'COMPLETED_FAILED'},{'status': 'COMPLETED_SUCCESS'}]}] }", count = true)
	Long countOfAllFilesWithProjectName(String workflowType, Date startDate, Date endDate, String projectName);

	/**
	 * Count of failed files with project name.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the long
	 */
	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?1, $lte:?2 } }, { 'workflowType' : ?0}, {'status': 'COMPLETED_FAILED'}, { 'projectName' : ?3 }] }", count = true)
	Long countOfFailedFilesWithProjectName(String workflowType, Date startDate, Date endDate, String projectName);

	/**
	 * Gets the jobinfodatabyparam.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param pageable the pageable
	 * @return the jobinfodatabyparam
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	Page<JobInfo> getjobinfodatabyparam(String projectName, String workflowName, String workflowType, Pageable pageable);

	/**
	 * Gets the job infos.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the job infos
	 */
	@Query (value = "{ $and: [ { 'projectName' : ?0 }, { 'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	List<JobInfo> getJobInfos(String projectName, String workflowName, String workflowType);

	/**
	 * Find all project name by todays date.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param todaysDate the todays date
	 * @return the list
	 */
	@Query (value = "{ $and: [ {$or: [{ 'startedTime': {$gte: ?1, $lte:?2 } },{'startedTime':{$gte: ?3}}]}, { 'workflowType' : ?0}] }")
	List<JobInfo> findAllProjectNameByTodaysDate(String workflowType, Date startDate, Date endDate, Date todaysDate);

	/**
	 * Find all project name and workflow type with today.
	 *
	 * @param workflowType the workflow type
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param todaysDate the todays date
	 * @param projectName the project name
	 * @return the list
	 */
	@Query (value = "{ $and: [ {$or: [{ 'startedTime': {$gte: ?1, $lte:?2 } },{'startedTime':{$gte: ?3}}]}, { 'projectName' : ?4 }, { 'workflowType' : ?0}] }")
	List<JobInfo> findAllProjectNameAndWorkflowTypeWithToday(String workflowType, Date startDate, Date endDate, Date todaysDate, String projectName);

	@Query (value = "{ $and: [ { 'startedTime': {$gte: ?3, $lte:?4 } }, { 'workflowType' : ?0},{ 'workflowName' : ?2},{ 'projectName' : ?1} ,{ 'status': { $ne: 'COMPLETED_FAILED' } },{ 'status': { $ne:'ABORTED' } }] }", count = true)
	long findForNoOfFilesToBeProcess(String workflowType, String projectName, String workflowName, Date startDate, Date endDate);

	/**
	 * Find all the records for the project for which the user have access
	 * 
	 * @param projectName
	 * @return
	 */
	@Query (value = "{'projectName': { $in : ?0}}")
	List<JobInfo> findJobInfoDataByProjectName(List<String> projectName, Pageable pageable);

}
