package com.opus.optimus.scheduler.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.user.User;

/**
 * The Interface UserRepository.
 */
@Repository
public interface UserRepository extends MongoRepository<User, String> {

	/**
	 * Find user by email.
	 *
	 * @param email the email
	 * @return the user
	 */
	@Query (value = "{'email': {$regex : '^?0$', $options: 'i'}}")
	User findUserByEmail(String email);
}
