package com.opus.optimus.scheduler.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.scheduler.services.BatchDefinitionService;
import com.opus.optimus.scheduler.services.quartz.JobExecution;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.StepInputData;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class BatchDefinitionController expose all api related to batch scheduling and batch monitoring.
 */
@RestController
@Api (value = "/scheduler/batchDefinition")
@RequestMapping ("{actionName}/scheduler/batchDefinition")
public class BatchDefinitionController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(BatchDefinitionController.class);

	/** The batch definition service. */
	@Autowired
	private BatchDefinitionService batchDefinitionService;

	@Autowired
	private JobExecution jobExecution;

	/**
	 * Create a Batch Definition with Scheduling Policy.
	 *
	 * @param batchDefinition the batch definition
	 * @return the response entity
	 */
	@PostMapping
	@ApiOperation (value = "Save schedulerJob in the system ", response = BatchDefinition.class, tags = "Scheduler Job [Save]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	public ServiceResponse createBatchDefinition(@RequestBody BatchDefinition batchDefinition) {
		logger.debug("Creating BatchExecution : {}", batchDefinition);
		BatchDefinition currentBatchDefinition = this.batchDefinitionService.getBatchDefinition(batchDefinition);
		if (currentBatchDefinition != null){
			batchDefinition.setId(currentBatchDefinition.getId());
			if (null == batchDefinition.getGroupId() || batchDefinition.getGroupId().isEmpty()){
				batchDefinition.setGroupId(currentBatchDefinition.getGroupId());
			}
		}
		if (batchDefinition.getSchedulerPolicy() != null){
			this.batchDefinitionService.saveBatchDefinitionJobExecution(batchDefinition);
		} else{
			this.batchDefinitionService.saveBatchDefinition(batchDefinition);
		}
		return new ServiceResponse(201, ResponseStatus.SUCCESS, "Scheduling details updated", batchDefinition.getWorkflowName());

	}

	/**
	 * Retrieve All Scheduling or Non Scheduling BatchDefinition without sort order ASC/DESC.
	 *
	 * @param scheduleFlag the schedule flag
	 * @param page the page
	 * @param size the size
	 * @return the scheduling details
	 */
	@ApiOperation (value = "Get list of schedulerJob with pagination ", response = BatchDefinition.class, tags = "Get Schedule Job [pagingation]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping ("/{schedule}/{page}/{size}")
	public ResponseEntity<Page<BatchDefinition>> getSchedulingDetails(@PathVariable ("schedule") String scheduleFlag, @PathVariable ("page") int page, @PathVariable ("size") int size) {
		logger.debug("Fetching Scheduler Details with schedule condition {}", scheduleFlag);
		Page<BatchDefinition> batchDefinition = this.batchDefinitionService.getBatchDefinitions(scheduleFlag, page, size);
		if (batchDefinition.isEmpty()){
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(batchDefinition, HttpStatus.OK);
	}

	/**
	 * Retrieve All Scheduling or Non Scheduling BatchDefinition with sort Order ASC/DESC.
	 *
	 * @param scheduleFlag the schedule flag
	 * @param page the page
	 * @param size the size
	 * @param orderType the order type
	 * @param field the field
	 * @return the scheduling details
	 */
	@ApiOperation (value = "Get list of schedule with pagination,sorting ", response = BatchDefinition.class, tags = "Get Schedule Job [pagingation,Sorting]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping ("/{schedule}/{page}/{size}/{orderType}/{field}")
	public ResponseEntity<Page<BatchDefinition>> getSchedulingDetails(@PathVariable ("schedule") String scheduleFlag, @PathVariable ("page") int page, @PathVariable ("size") int size, @PathVariable ("orderType") String orderType, @PathVariable ("field") String field) {
		logger.debug("Fetching Scheduler Details Field with Order ASC/DESC with schedule condition {} & field {} ", scheduleFlag, field);
		Page<BatchDefinition> batchDefinition = this.batchDefinitionService.getBatchDefinitions(scheduleFlag, page, size, orderType, field);
		if (batchDefinition.isEmpty()){
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(batchDefinition, HttpStatus.OK);
	}

	/**
	 * Create a Batch Definition with Scheduling Policy.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the service response
	 */
	@GetMapping (value = "/deschedule/{projectName}/{workflowName}/{workflowType}")
	@ApiOperation (value = "Remove schedulerJob from the system ", response = BatchDefinition.class, tags = "Scheduler Job [Remove]")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	public ServiceResponse removeBatchDefinition(@PathVariable ("projectName") String projectName, @PathVariable ("workflowName") String workflowName, @PathVariable ("workflowType") String workflowType) {
		logger.debug("Removing BatchExecution of: {}", workflowName);
		BatchDefinition batchDefinition = this.batchDefinitionService.getBatchDefinition(projectName, workflowName, workflowType);

		if (batchDefinition != null){
			batchDefinition.setDisabled(true);
			batchDefinitionService.saveBatchDefinition(batchDefinition);

			String response = this.batchDefinitionService.removeScheduling(projectName, workflowName, workflowType);
			return new ServiceResponse(200, ResponseStatus.SUCCESS, response, workflowName);
		} else{
			return new ServiceResponse(406, ResponseStatus.FAILED, "Scheduling information not found", workflowName);
		}
	}

	/**
	 * Save jobon play.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workFlowType the work flow type
	 * @return the service response
	 */

	@GetMapping ("/createjob/{projectName}/{workflowName}/{workFlowType}")
	public ServiceResponse saveJobonPlay(@PathVariable ("projectName") String projectName, @PathVariable ("workflowName") String workflowName, @PathVariable ("workFlowType") String workFlowType) {
		BatchDefinition batchDefinition = this.batchDefinitionService.getBatchDefinition(projectName, workflowName, workFlowType);
		if (batchDefinition != null){
			List<StepInputData> stepInputs = batchDefinition.getStepInputData();
			String status = jobExecution.setInputDataAndTriggerJob(projectName, workflowName, batchDefinition.getGroupId(), workFlowType, stepInputs);

			if ("success".equalsIgnoreCase(status)){
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Job has been Submitted", null);
			} else{
				return new ServiceResponse(406, ResponseStatus.FAILED, status, null);
			}
		}
		return new ServiceResponse(500, ResponseStatus.SUCCESS, "Request not processed", null);
	}

	/**
	 * Retrieve All BatchDefination data using fulltext search in specific document.
	 *
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return java.util.List
	 */
	@ApiOperation (value = "Search BatchDefinition ", response = JobInfo.class, tags = "Returns all occurrences matched with serach criteria")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping ("/search/{search}/{page}/{size}")
	public ResponseEntity<Page<BatchDefinition>> fullTextsearch(@PathVariable String search, @PathVariable ("page") int page, @PathVariable ("size") int size) {
		Page<BatchDefinition> batchdefination = batchDefinitionService.findAllBy(search, page, size);
		return new ResponseEntity<>(batchdefination, HttpStatus.OK);
	}

	/**
	 * Retrieve All Batchdefination data using fulltext search in specific document.
	 *
	 * @param column the column
	 * @param search the search
	 * @param page the page
	 * @param size the size
	 * @return java.util.List
	 */
	@ApiOperation (value = "Search Batchdefination columnwise[Advance search] ", response = BatchDefinition.class, tags = "Returns all occurrences matched with serach criteria columnwise")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@PostMapping ("/searchbycolumn/{schedule}/{page}/{size}")
	public ResponseEntity<Page<BatchDefinition>> fullTextsearchcolumnwise(@PathVariable ("schedule") String scheduleFlag, @PathVariable ("page") int page, @PathVariable ("size") int size, @RequestBody Map<String, String> map) {
		Page<BatchDefinition> jobinfo = batchDefinitionService.searchbycolumnnameandtext(scheduleFlag, page, size, map);
		return new ResponseEntity<>(jobinfo, HttpStatus.OK);
	}

	/**
	 * Retrieve All Batchdefination data using fulltext search in specific document.
	 *
	 * @param column the column
	 * @param pattern the pattern
	 * @return java.util.List
	 */
	@ApiOperation (value = "Autocomplete Search Batchdefination columnwise[Advance search] ", response = BatchDefinition.class, tags = "Returns all occurrences matched with serach criteria columnwise for autocomplete")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping ("/autocomplete/{column}/{pattern}")
	public ResponseEntity<Page<BatchDefinition>> autocomplete(@PathVariable String column, @PathVariable String pattern) {
		Page<BatchDefinition> jobinfo = batchDefinitionService.autocompleteByText(column, pattern);
		return new ResponseEntity<>(jobinfo, HttpStatus.OK);
	}

	/**
	 * Retrieve the job id for cancel the job
	 *
	 * @param jobId the jobId
	 */
	@GetMapping ("/cancelJob/{jobId}")
	public ServiceResponse cancelJob(@PathVariable ("jobId") String jobId) {
		if (jobId != null){
			String status = jobExecution.cancelJob(jobId);
			if ("success".equalsIgnoreCase(status)){
				return new ServiceResponse(200, ResponseStatus.SUCCESS, "Job has been Cancelled", null);
			} else{
				return new ServiceResponse(406, ResponseStatus.FAILED, status, null);
			}
		}
		return new ServiceResponse(500, ResponseStatus.SUCCESS, "Request not processed", null);
	}

}