package com.opus.optimus.scheduler;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.opus.optimus.ui.services.util.CustomErrorType;

/**
 * The Class GlobalExceptionHandler is global code to handle exception in all controllers.
 */
@ControllerAdvice
public class GlobalExceptionHandler {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	/**
	 * Handle exception.
	 *
	 * @param e the e
	 * @return the response entity
	 */
	@ExceptionHandler (Exception.class)
	public ResponseEntity<CustomErrorType> handleException(final Exception e) {
		logger.error("Inside Global Exception Handler");
		logger.error(e.getMessage(), e);
		String message = Optional.of(e.getMessage()).orElse(e.getClass().getSimpleName());
		return new ResponseEntity<>(new CustomErrorType(e.getLocalizedMessage(), message), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
