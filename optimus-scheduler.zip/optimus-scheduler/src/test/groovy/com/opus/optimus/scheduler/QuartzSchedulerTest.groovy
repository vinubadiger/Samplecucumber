package com.opus.optimus.scheduler;

import org.quartz.JobKey
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.config.user.Institution
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.repository.UserRepository
import com.opus.optimus.scheduler.services.quartz.QuartzScheduler
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.scheduler.BatchDefinition
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations="classpath:application-test.properties")
class QuartzSchedulerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory;

	@Autowired
	ObjectMapper mapper;

	def object;

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def user = null;
	def request;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {


		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}



	def "quartzscheduler -quartzSchedulerTrigger"(){
		given:
		def quartzscheduler =new QuartzScheduler()
		def jsonStream = getClass().getResourceAsStream("/BatchDefination.json")
		request = mapper.readValue(jsonStream, BatchDefinition.class)
		mongoTemplate.save(request, "BatchDefination")

		when:
		quartzscheduler.quartzSchedulerTrigger(1000, request, new Date())
		then:
		println("test")
	}

	def "Exception - quartzSchedulerTrigger"() {
		given:
		def quartzscheduler =new QuartzScheduler()
		quartzscheduler.quartzSchedulerTrigger(_, _, _ as Date) >> { throw new NullPointerException() }
		when:
		quartzscheduler.quartzSchedulerTrigger(100, request, new Date())
		then:
		thrown GenericException
	}

	def "quartzscheduler-quartzSchedulerCronExpression"(){
		given:
		def quartzscheduler =new QuartzScheduler()
		def jsonStream = getClass().getResourceAsStream("/BatchDefination-quartz.json")
		request = mapper.readValue(jsonStream, BatchDefinition.class)
		mongoTemplate.save(request, "BatchDefination")

		when:
		quartzscheduler.quartzSchedulerCronExpression("0 0 0 ? * * 2035", request, new Date())
		then:
		println("void method no assert")
	}

	def "Exception - quartzSchedulerCronExpression"() {
		given:
		def quartzscheduler =new QuartzScheduler()
		quartzscheduler.quartzSchedulerCronExpression(_, _, _ as Date) >> { throw new NullPointerException() }
		when:
		quartzscheduler.quartzSchedulerCronExpression("0 0 0 ? * * 2040", request, new Date())
		then:
		thrown GenericException
	}
	def "quartzscheduler-remove"(){
		given:
		def quartzscheduler =new QuartzScheduler()
		JobKey key=new JobKey("WORKFLOW.projectNameTestworkflowNameTestETL");
		when:
		boolean value =quartzscheduler.removeQuartzSchedulerCronExpression(key)
		then:
		value==false
	}


	def "quartzscheduler-quartzSchedulerForCutOverTime"(){
		given:
		def quartzscheduler =new QuartzScheduler()
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/Institution.json")
		def object = mapper.readValue(jsonStream, Institution.class)

		mongoTemplate.insert(object, "Institution");
		when:
		quartzscheduler.quartzSchedulerForCutOverTime(object)
		then:
		println("void method no assert")
	}

	def "Exception - quartzSchedulerForCutOverTime"() {
		given:
		def quartzscheduler =new QuartzScheduler()
		quartzscheduler.quartzSchedulerForCutOverTime(_) >> { throw new NullPointerException() }
		when:
		quartzscheduler.quartzSchedulerForCutOverTime(null)
		then:
		thrown Exception
	}
	

	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}