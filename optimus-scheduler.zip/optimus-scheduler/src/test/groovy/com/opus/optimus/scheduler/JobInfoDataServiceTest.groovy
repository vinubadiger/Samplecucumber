package com.opus.optimus.scheduler;

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.domain.Page
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.repository.UserRepository
import com.opus.optimus.scheduler.services.impl.JobInfoDataServiceImpl
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import spock.lang.Ignore
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations="classpath:application-test.properties")
class JobInfoDataServiceTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory;

	@Autowired
	ObjectMapper mapper;

	def object;

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def user = null;
	def request;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {


		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}


	@Ignore
	def "Update jobinfo"(){
		given:
		def jobService = new JobInfoDataServiceImpl()
		def jsonStream = getClass().getResourceAsStream("/JobInfo.json")
		request = mapper.readValue(jsonStream, JobInfo.class)
		JobInfo j =mongoTemplate.save(request,"JobInfo");
		println("jobinfo values "+j)
		String jobid =j.getId()
		println("jobid "+jobid)
		when:
		String msg =jobService.save(jobid, request)
		println("msg"+msg)
		then:
		thrown GenericException
	}

	@Ignore
	def "Get username"(){
		given:
		def jobService = new JobInfoDataServiceImpl()
		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");
		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()
		User userinfo =mongoTemplate.save(user,"User");
		println("userinfo "+userinfo)
		when:
		Page<JobInfo> pageble =jobService.getJobInfo(1, 1);
		then:
		pageble.size>0
	}




	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}