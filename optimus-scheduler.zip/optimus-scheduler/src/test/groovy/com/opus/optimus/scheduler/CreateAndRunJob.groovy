package com.opus.optimus.scheduler;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.scheduler.BatchDefinition

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class CreateAndRunJob extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {
		def mapper = mapperFactory.getMapper()

		def jsonStream = getClass().getResourceAsStream("/BatchDefination.json")
		def object = mapper.readValue(jsonStream, BatchDefinition.class)

		def jsonStreamPublishedService = getClass().getResourceAsStream("/PublishedService.json")
		def objectPS = mapper.readValue(jsonStreamPublishedService, PublishedService.class)

		mongoTemplate.insert(object, "BatchDefinition");
		mongoTemplate.insert(objectPS, "PublishedService");


		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}

	def "create job and run" (){
		when:
		MvcResult response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/createjob/projectNameTest/workflowNameTest/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		/*JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		 response.getResponse().getStatus() == 500 &&
		 containerObject.getString("referenceErrorMsg").equals("org.springframework.web.client.ResourceAccessException: I/O error on POST request for \"http://localhost:8080/taskmanager/taskmngr/job/projectNameTestworkflowNameTest\": Connection refused: connect; nested exception is java.net.ConnectException: Connection refused: connect")*/
		response.getResponse().getStatus() == 500
	}

	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}