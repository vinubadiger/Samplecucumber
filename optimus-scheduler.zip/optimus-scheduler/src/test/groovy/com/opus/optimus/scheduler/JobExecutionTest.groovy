package com.opus.optimus.scheduler;

import java.nio.file.attribute.PosixFileAttributes

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.HttpMethod
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.config.casemanagement.Priority
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.config.user.Institution
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.repository.UserRepository
import com.opus.optimus.scheduler.services.quartz.JobExecution
import com.opus.optimus.scheduler.services.webclient.OptimusRestClient
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.scheduler.BatchDefinition
import com.opus.optimus.ui.services.user.User

import spock.lang.Ignore
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations="classpath:application-test.properties")
class JobExecutionTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory;

	@Autowired
	ObjectMapper mapper;

	def object;

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	OptimusRestClient restClient = Spy(OptimusRestClient.class);

	def user = null;
	def request;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);


	def setup() {


		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}



	def "JobExecution -createDescription"(){
		given:
		def jobexecution =new JobExecution()
		when:
		String value =jobexecution.createDescription(1, 1, "test", "test");
		then:
		value=="Project Name : testWorkflow Name : testExpected number of files : 1Recieved file count: 1"
	}

	def "JobExecution throw exception-creatcaseforquartz"(){
		given:
		def jobexecution =new JobExecution()
		when:
		String value =jobexecution.createCaseforQuartz("test", "TestprojectName", "TestworkflowName", Priority.MEDIUM, "testcomment")
		then:
		thrown GenericException
	}

	def "JobExecution buildJobinfo"(){
		given:
		def jobexecution =new JobExecution()
		when:
		String value =jobexecution.createCaseforQuartz("test", "TestprojectName", "TestworkflowName", Priority.MEDIUM, "testcomment")
		then:
		thrown GenericException
	}

	def "JobExecution exception in execute job"(){
		given:
		def jobexecution =new JobExecution()
		jobexecution.execute(_)>>{ throw new NullPointerException() }
		when:
		jobexecution.execute(null)
		then:
		thrown GenericException
	}

	def "JobExecution get setEmptyStepInputs"(){
		given:
		def jobexecution =new JobExecution()
		def jsonStream = getClass().getResourceAsStream("/PublishedService2.json")
		request = mapper.readValue(jsonStream, PublishedService.class)
		PublishedService publishservice =mongoTemplate.save(request, "PublishedService")
		when:
		Map<String, List<String>> emptyset =jobexecution.setEmptyStepInputs(publishservice)

		then:
		emptyset.isEmpty()==false
	}

	def "JobExecution update jobinfo"(){
		given:
		def jobexecution =new JobExecution()
		def jsonStream = getClass().getResourceAsStream("/JobInfo.json")
		request = mapper.readValue(jsonStream, JobInfo.class)
		JobInfo j =mongoTemplate.save(request,"JobInfo");
		println("jobinfo values "+j)
		String jobid =j.getId()
		println("jobid "+jobid)
		expect:
		jobexecution.updateJobInfo(jobid, j)
	}
	def "JobExecution exception update jobinfo"(){
		given:
		def jobexecution =new JobExecution()
		jobexecution.updateJobInfo(_,_ as Object) >> { throw new NullPointerException() }
		when:
		jobexecution.updateJobInfo(null,null)
		then:
		thrown GenericException
	}

	def "JobExecution update BatchDefination"(){
		given:
		def jobexecution =new JobExecution()
		def jsonStream = getClass().getResourceAsStream("/BatchDefination.json")
		request = mapper.readValue(jsonStream, BatchDefinition.class)
		BatchDefinition b=mongoTemplate.save(request, "BatchDefinition")
		println("b"+b.getGroupId())
		expect:
		jobexecution.updateBatchDefinition(null, "projectNameTest", "workflowNameTest", "ETL")
	}

	def "JobExecution getStepInputsForEtl"(){
		given:
		def jobexecution =new JobExecution()
		when:
		Map<String, List<String>> execute =jobexecution.getStepInputsForEtl("stepname", "testfile", "test.txt")
		then:
		execute.size()>0
	}
	@Ignore
	def "JobExecution getServiceUserDetails"(){
		given:
		def jobexecution =new JobExecution()
		String cwd = System.getProperty("user.dir");
		File currentDir = new File(cwd);
		println("filename"+currentDir)
		when:
		PosixFileAttributes PosixFileAttributes =jobexecution.getServiceUserDetails(currentDir)
		then:
		thrown GenericException
	}
	def "JobExecution updateDataIngestionDate"(){
		given:
		def jobexecution =new JobExecution()
		def mapper = mapperFactory.getMapper()

		def jsonStream = getClass().getResourceAsStream("/Institution.json")
		def object = mapper.readValue(jsonStream, Institution.class)

		Institution ins =mongoTemplate.insert(object, "Institution");
		String id =ins.getId()
		expect:
		jobexecution.updateDataIngestionDate(id)
	}
	def "JobExecution updateDataIngestionDate null id"(){
		given:
		def jobexecution =new JobExecution()
		jobexecution.updateDataIngestionDate(_) >> { throw new GenericException() }
		when:
		jobexecution.updateDataIngestionDate("1234")
		then:
		thrown GenericException
	}
	def "JobExecution runjob exception"(){
		given:
		def jobexecution =new JobExecution()
		SalesforceCaseResponse salesforceCaseResponse = new SalesforceCaseResponse();
		SalesforceCaseRequest salesForceCaseRequest = new SalesforceCaseRequest();
		def JobInfo j =JobInfo.builder().name("test").build()

		when:
		restClient.runJob("1")
		println("response from sales force ")
		then:
		thrown GenericException
	}

	def "JobExecution canceljob exception"(){
		given:
		def jobexecution =new JobExecution()
		SalesforceCaseResponse salesforceCaseResponse = new SalesforceCaseResponse();
		SalesforceCaseRequest salesForceCaseRequest = new SalesforceCaseRequest();
		def JobInfo j =JobInfo.builder().name("test").build()

		when:
		restClient.cancelJob("1")
		println("response from sales force ")
		then:
		thrown GenericException
	}
	def "JobExecution createJob exception"(){
		given:
		def jobexecution =new JobExecution()
		SalesforceCaseResponse salesforceCaseResponse = new SalesforceCaseResponse();
		SalesforceCaseRequest salesForceCaseRequest = new SalesforceCaseRequest();
		def JobInfo j =JobInfo.builder().name("test").build()

		when:
		restClient.createJob(j)
		println("response from sales force ")
		then:
		thrown GenericException
	}
	def "JobExecution decorateRestTemplateAndSendRequest exception"(){
		given:
		def jobexecution =new JobExecution()
		SalesforceCaseResponse salesforceCaseResponse = new SalesforceCaseResponse();
		SalesforceCaseRequest salesForceCaseRequest = new SalesforceCaseRequest();
		def JobInfo j =JobInfo.builder().name("test").build()

		when:
		restClient.decorateRestTemplateAndSendRequest(null, null, null, null, null, HttpMethod.POST)
		println("response from sales force ")
		then:
		thrown GenericException
	}
	def "JobExecution cancel job exception"(){
		given:
		def jobexecution =new JobExecution()
		jobexecution.cancelJob(_) >> { throw new GenericException() }

		when:
		jobexecution.cancelJob("1234")
		then:
		thrown GenericException
	}
	def "JobExecution create directory"(){
		given:
		def jobexecution =new JobExecution()
		when:
		File f =jobexecution.createProjectDirectory("projectName","projectName")

		then:
		f!=null
	}
	def "JobExecution exception create directory"(){
		given:
		def jobexecution =new JobExecution()
		and:
		jobexecution.createProjectDirectory(_,_)>> { throw new GenericException() }
		when:
		File f =jobexecution.createProjectDirectory(null,null)
		then:
		thrown GenericException
	}
	def "JobExecution build jobInfo"(){
		given:
		def jobexecution =new JobExecution()
		when:
		JobInfo jobinfo=jobexecution.buildGenericJobInfo("testProjectName", "testWorkflowname", "ETL", "12345")
		then:
		jobinfo.projectName!=null
	}

	def "JobExecution buildETLJobInfo"(){
		given:
		def jobexecution =new JobExecution()
		when:
		JobInfo jobinfo=jobexecution.buildETLJobInfo("projectName", "workflowName", "workflowType", "12345", "stepName", "destfile", "filename")
		then:
		jobinfo.projectName!=null
	}



	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}