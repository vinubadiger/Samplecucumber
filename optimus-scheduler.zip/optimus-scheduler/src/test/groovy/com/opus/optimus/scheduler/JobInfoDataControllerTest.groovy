package com.opus.optimus.scheduler;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.repository.UserRepository
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import groovy.json.JsonOutput
import spock.lang.Ignore
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class JobInfoDataControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory;

	def object;

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def user = null;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {
		//JobInfo
		DBObject successJobToSave = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("status", "COMPLETED_SUCCESS")
				.add("workflowType", "ETL")
				.add("projectName", "projectNameTest")
				.add("workflowName", "workflowNameTest")
				.add("groupId", "5c9df4dd130db900072a110a")
				.add("startedTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-01-29T00:00:00.000Z"))
				.get();

		mongoTemplate.save(successJobToSave, "JobInfo");



		//JobResult
		String jobResult = "{\r\n" +
				"    \"jobId\" : \"a6aeb541-9429-48df-974c-a26bbc25b5a2\",\r\n" +
				"    \"workflowName\" : \"DPS\",\r\n" +
				"    \"projectName\" : \"Airtime\",\r\n" +
				"    \"workflowType\" : \"ETL\",\r\n" +
				"    \"groupId\" : \"5c9df4dd130db900072a110a\",\r\n" +
				"    \"sourceFile\" : \"data.csv\",\r\n" +
				"    \"stepExecutorResults\" : [ \r\n" +
				"        {\r\n" +
				"            \"workflowName\" : \"Workflow1\",\r\n" +
				"            \"stepName\" : \"ebe47332-2e95-46ee-a4a8-b663307e6899\",\r\n" +
				"            \"stepType\" : \"FileReader\",\r\n" +
				"            \"instanceStats\" : {\r\n" +
				"                \"0\" : {\r\n" +
				"                    \"inbound\" : {\r\n" +
				"                        \"dataCount\" : 20,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"outbound\" : {\r\n" +
				"                        \"dataCount\" : 18,\r\n" +
				"                        \"errorCount\" : 2,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"exceptionCounts\" : {},\r\n" +
				"                    \"status\" : \"COMPLETED\"\r\n" +
				"                },\r\n" +
				"                \"1\" : {\r\n" +
				"                    \"inbound\" : {\r\n" +
				"                        \"dataCount\" : 0,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"outbound\" : {\r\n" +
				"                        \"dataCount\" : 0,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 1,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"exceptionCounts\" : {},\r\n" +
				"                    \"status\" : \"COMPLETED\"\r\n" +
				"                },\r\n" +
				"                \"2\" : {\r\n" +
				"                    \"inbound\" : {\r\n" +
				"                        \"dataCount\" : 0,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"outbound\" : {\r\n" +
				"                        \"dataCount\" : 0,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"exceptionCounts\" : {},\r\n" +
				"                    \"status\" : \"COMPLETED\"\r\n" +
				"                },\r\n" +
				"                \"3\" : {\r\n" +
				"                    \"inbound\" : {\r\n" +
				"                         \"dataCount\" : 0,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"outbound\" : {\r\n" +
				"                        \"dataCount\" : 0,\r\n" +
				"                        \"errorCount\" : 0,\r\n" +
				"                        \"endCount\" : 0,\r\n" +
				"                        \"unknownCount\" : 0\r\n" +
				"                    },\r\n" +
				"                    \"exceptionCounts\" : {},\r\n" +
				"                    \"status\" : \"COMPLETED\"\r\n" +
				"                }\r\n" +
				"            }\r\n" +
				"        }\r\n" +
				"    ]\r\n" +
				"}";

		DBObject dbObject = (DBObject) BasicDBObject.parse(jobResult);

		mongoTemplate.save(dbObject,"JobResult");


		List<String> projects = new ArrayList<String>();
		projects.add("Amex_DI");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true

	}



	def "Get JobInfo or Batch Monitor Using page = 0, size = 50"() {
		when:
		def response = mvc.perform(
				get('/GetJobInfoData/scheduler/jobInfoData/0/50')
				).andReturn()

		List<String> projects = new ArrayList<String>();
		projects.add("projectNameTest");

		user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		then:

		response.getResponse().getStatus() == 200
	}

	def "Get Batch Monitor Using page = 0, size = 50, orderType = ASC, field = projectName "() {
		when:
		def response = mvc.perform(
				get('/MonitorSchedulerJob/scheduler/jobInfoData/0/50/ASC/projectName')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200
	}

	def "Get Batch Monitor Using page = 0, size = 50, orderType = DESC, field = projectName"() {
		when:
		def response = mvc.perform(
				get('/MonitorSchedulerJob/scheduler/jobInfoData/0/50/DESC/projectName')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200
	}


	def "Get JobTaskExecutorResult Using jobId"() {
		setup :
		println("In setup")
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/PublishedService.json")
		object = mapper.readValue(jsonStream, PublishedService.class)
		println("Before save "+ object)
		def savedObj = mongoTemplate.save(object, "PublishedService");
		when:
		def response = mvc.perform(
				get('/GetJobInfoData/scheduler/jobInfoData/get/a6aeb541-9429-48df-974c-a26bbc25b5a2')
				).andReturn()


		then:
		//println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200
	}

	def "Searchbycolumn page,size"() {
		given:
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("projectName", "projectNameTest");
		map.put("workflowType", "ETL");

		when:
		def response = mvc.perform(
				post('/SearchJobInfoData/scheduler/jobInfoData/searchbycolumn/0/5').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(map))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200
	}

	def "Full text search page,size"() {
		given:
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("projectName", "projectNameTest");
		map.put("workflowType", "ETL");

		when:
		def response = mvc.perform(
				get('/SearchJobInfoData/scheduler/jobInfoData/search/projectNameTest/0/5').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(map))
				).andReturn()

		then:
		response.getResponse().getStatus() == 500
	}

	def "autocomplete by column,pattern"() {
		when:
		def response = mvc.perform(
				get('/GetJobInfoData/scheduler/jobInfoData/autocomplete/projectName/projectNameTest')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200
	}

	def "getListbyjobinfoparam projectName,workflowName,workFlowType,page,size"() {
		when:
		def response = mvc.perform(
				get('/GetJobInfoData/scheduler/jobInfoData/getlistbyjobinfoparam/projectNameTest/workflowNameTest/ETL/0/5')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200
	}

	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}