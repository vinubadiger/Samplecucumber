package com.opus.optimus.scheduler;

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.services.webclient.OptimusRestClient

import spock.lang.Ignore
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class OptimusWebRestClientTest extends Specification {

	@Autowired
	protected MockMvc mvc


	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);



	def setup() {


		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}


	def "build url" (){
		given:
		def client = new OptimusRestClient()
		when:
		String buildurl =client.buildApiUrl("test")
		println("test"+buildurl)
		then:
		buildurl=="nullnulltest"
	}

	@Ignore
	def "run job url" (){
		given:
		def client = new OptimusRestClient()
		when:
		client.runJob("test")
		then:
		println("call")
	}


	def cleanup() {
	}
}