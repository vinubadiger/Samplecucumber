package com.opus.optimus.scheduler;


import org.spockframework.spring.SpringBean
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContext
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.scheduler.util.UserContextUtility

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class UserContextUtilityTest extends Specification {

	@SpringBean
	SecurityContextHolder securityContextHolder = Stub(SecurityContextHolder.class);

	def userContextUtility

	def setup() {
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		GrantedAuthority authority = new SimpleGrantedAuthority("RECON_ADM");
		grantedAuthorities.add(authority);
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("UserNameTest", "", grantedAuthorities));
		SecurityContextHolder.setContext(securityContext);

		userContextUtility = new UserContextUtility()
	}

	def "Get Logged Username"() {
		when:
		String response = userContextUtility.getLoggedUsername()
		println("Authentication Username --> " + response)
		then:
		response == "UserNameTest"
	}

	def "Check Admin User"() {
		when:
		boolean flag = userContextUtility.checkIfAdminUser()
		println("Flag --> " + flag)
		then:
		flag == false
	}
}