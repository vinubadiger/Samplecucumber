package com.opus.optimus.scheduler;

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.services.impl.BatchDefinitionServiceImpl
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.scheduler.BatchDefinition

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class BatchDefinitionServiceImplTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def request

	def setup() {

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}

	def "findAllBy-Exception"(){

		given:
		def mapper = mapperFactory.getMapper()
		def batchDef = new BatchDefinitionServiceImpl()
		def jsonStream = getClass().getResourceAsStream("/BatchDefination.json")
		request = mapper.readValue(jsonStream, BatchDefinition.class)
		mongoTemplate.save(request, "BatchDefinition");
		batchDef.findAllBy(_, _, _) >> { throw new GenericException() }
		when:
		batchDef.findAllBy("test", 0, 10)()
		then:
		thrown GenericException
	}
	def "removeScheduling"(){

		given:
		def mapper = mapperFactory.getMapper()
		def batchDef = new BatchDefinitionServiceImpl()
		when:
		String s =batchDef.removeScheduling("projectName", "workflowName", "workflowtype")
		then:
		s=="Job Disabled"
	}




	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}