package com.opus.optimus.scheduler;

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.config.user.Institution
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.repository.InstitutionRepository
import com.opus.optimus.scheduler.services.impl.InstitutionImpl
import com.opus.optimus.scheduler.util.UserContextUtility

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class InstitutionImplTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	MapperFactory mapperFactory

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	@SpringBean
	InstitutionImpl institutionimpl = Stub(InstitutionImpl.class);

	@SpringBean
	InstitutionRepository institutionRepository = Stub(InstitutionRepository.class);
	 
	def setup() {

		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true
	}

	def "Save Ins - Exception"(){

		given:
		def inst = new InstitutionImpl()
		def mapper = mapperFactory.getMapper()

		def jsonStream = getClass().getResourceAsStream("/Institution.json")
		def object = mapper.readValue(jsonStream, Institution.class)

		Institution i=mongoTemplate.insert(object, "Institution");
		
		this.institutionRepository.findAll()>>i;

		when:
		inst.setCutOverTimeLogic()

		then:
		thrown GenericException
	}

	def "Save Ins update null - Exception"(){

		given:
		def inst = new InstitutionImpl()
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/Institution.json")
		def object = mapper.readValue(jsonStream, Institution.class)

		mongoTemplate.insert(object, "Institution");
		
		when:
		inst.updateDataIngestionDate(object)

		then:
		thrown GenericException
	}

	def "Save Ins update not null - Exception"(){

		given:
		def inst = new InstitutionImpl()
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/Institution2.json")
		def object = mapper.readValue(jsonStream, Institution.class)

		mongoTemplate.insert(object, "Institution");
		when:
		inst.updateDataIngestionDate(object)

		then:
		thrown GenericException
	}
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}