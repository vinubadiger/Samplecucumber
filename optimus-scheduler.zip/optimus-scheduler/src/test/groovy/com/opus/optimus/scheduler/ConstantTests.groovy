package com.opus.optimus.scheduler;

import java.sql.Timestamp

import org.spockframework.spring.SpringBean
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.scheduler.constants.JobKeyIdentifierGroup
import com.opus.optimus.scheduler.constants.SchedularConstants
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.util.GetVersionNumber

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ConstantTests extends Specification {


	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);


	def "SchedularConstants tests"() {
		given:
		SchedularConstants service = Spy(SchedularConstants)
		expect:
		service.SCHEDUALAR_NO_OF_FILE_PROCESS== "Number of processed files from Schedular" ||
				service.SCHEDUALAR_QUARTZ== "Job has been failed" ||
				service.SYSTEM_USERNAME== "system" ||
				service.ID== "id" ||
				service.SAVE== "save" ||
				service.DELETE== "delete" ||
				service._ID== "_id"
	}

	def "JobKeyIdentifierGroup tests"() {
		given:
		JobKeyIdentifierGroup service = Spy(JobKeyIdentifierGroup)
		expect:
		service.WORKFLOW == "WORKFLOW" ||
				service.CUTOVER == "CUTOVER"
	}
	def "GetVersionNumber tests"() {
		given:
		GetVersionNumber service = Spy(GetVersionNumber)
		expect:
		Timestamp timestamp =service.getVersion()
	}
}