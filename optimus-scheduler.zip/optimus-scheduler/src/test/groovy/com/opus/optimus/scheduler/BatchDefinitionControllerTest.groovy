package com.opus.optimus.scheduler;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.bson.Document
import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.fasterxml.jackson.databind.ObjectMapper
import com.mongodb.BasicDBObject
import com.mongodb.DBObject
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.scheduler.interceptor.LoginInterceptor
import com.opus.optimus.scheduler.repository.UserRepository
import com.opus.optimus.scheduler.services.quartz.JobExecution
import com.opus.optimus.scheduler.util.UserContextUtility
import com.opus.optimus.ui.services.scheduler.BatchDefinition
import com.opus.optimus.ui.services.user.User

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class BatchDefinitionControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	ObjectMapper mapper;

	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def request;
	def requestNonSchedule;
	def requestwithoutGroupId;

	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	@SpringBean
	JobExecution jobExecution = Stub(JobExecution.class);

	def user = null;

	def setup() {

		def jsonStream = getClass().getResourceAsStream("/BatchDefination.json")
		request = mapper.readValue(jsonStream, BatchDefinition.class)

		def jsonStreamnNonSchedule = getClass().getResourceAsStream("/BatchDefinationNonSchedule.json")
		requestNonSchedule = mapper.readValue(jsonStreamnNonSchedule, BatchDefinition.class)

		def jsonStreamnwithoutgroupId = getClass().getResourceAsStream("/BatchDefination-nullgroupid.json")
		requestwithoutGroupId = mapper.readValue(jsonStreamnwithoutgroupId, BatchDefinition.class)


		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");

		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		userContextUtility.checkIfAdminUser() >> true;

		jobExecution.cancelJob(_ as String) >> "success"
	}

	def "Save Batch Definition using schedule and get schedule job" (){
		when:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		List<String> projects = new ArrayList<String>();
		projects.add("projectNameTest");

		def user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		then:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/schedule/0/50')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Save Batch Definition using schedule and get schedule job without group Id" (){
		when:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestwithoutGroupId))
				).andReturn()

		List<String> projects = new ArrayList<String>();
		projects.add("projectNameTest");

		def user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		then:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/schedule/0/50')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}


	def "Save Batch Definition using non schedule and get non-scheduled job" (){
		when:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestNonSchedule))
				).andReturn().response

		List<String> projects = new ArrayList<String>();
		projects.add("projectNameTest1");

		def user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		then:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/nonschedule/0/50')
				).andReturn()

		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest1") &&
				containerObject.getString("projectName").equals("projectNameTest1") &&
				containerObject.getString("workflowName").equals("workflowNameTest1") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Get Batch Definition Using schedule = all, page = 0, size = 50"() {
		given:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		List<String> projects = new ArrayList<String>();
		projects.add("projectNameTest");

		def user = User.builder()
				.email(email)
				.firstName(firstName)
				.lastName(lastName)
				.active(true)
				.projects(projects)
				.build()

		userRepository.findUserByEmail(_ as String) >> user;

		when:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/all/0/50')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Get Batch Definition Using schedule = all, page = 0, size = 50, orderType = ASC, field = workflowId"() {
		given:
		mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		when:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/all/0/50/ASC/workflowId')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Get Batch Definition Using schedule = schedule, page = 0, size = 50, orderType = DESC, field = projectName"() {
		given:
		mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		when:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/schedule/0/50/DESC/projectName')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Get Batch Definition Using schedule = nonschedule, page = 0, size = 50, orderType = DESC, field = workflowName"() {
		given:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestNonSchedule))
				).andReturn().response
		when:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/nonschedule/0/50/DESC/workflowName')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest1") &&
				containerObject.getString("projectName").equals("projectNameTest1") &&
				containerObject.getString("workflowName").equals("workflowNameTest1") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Get - Remove schedulerJob from the system"() {
		given:
		mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		when:
		def response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/deschedule/projectNameTest/workflowNameTest/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}



	def "Get - Retrieve All BatchDefination data using fulltext search in specific document"() {
		given:
		def jsonStream = getClass().getResourceAsStream("/BatchDefination.json")
		request = mapper.readValue(jsonStream, BatchDefinition.class)
		mongoTemplate.save(request, "BatchDefinition")
		
		DBObject o=new BasicDBObject()
		o.put("\$**","text")
		MongoCollection<Document> collection = mongoTemplate.getCollection("BatchDefinition")
		collection.createIndex(o)
		when:
		MvcResult response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/search/projectNameTest/0/50')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}


	def "Get - Search Batchdefination columnwise[Advance search]"() {
		given:
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("projectName", "projectNameTest");
		map.put("workflowName", "workflowNameTest");
		map.put("workflowType", "ETL");

		mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		when:
		MvcResult response = mvc.perform(
				post('/GetScheduleJob/scheduler/batchDefinition/searchbycolumn/all/0/50').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(map))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}


	def "Autocomplete Search Batchdefination columnwise[Advance search]"() {
		given:
		mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		when:
		MvcResult response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/autocomplete/projectName/projectNa')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowId").equals("workflowIdTest") &&
				containerObject.getString("projectName").equals("projectNameTest") &&
				containerObject.getString("workflowName").equals("workflowNameTest") &&
				containerObject.getString("workflowType").equals("ETL")
	}

	def "Update Batch Definition using schedule" (){
		given:
		Map request2 = [
			id : '5ca4de8dfa4c5bb21cca76f9',
			workflowId : 'workflowIdTest',
			projectName : 'projectNameTest',
			workflowName : 'workflowNameTest',
			workflowType : 'ETL',
			workflowConfigId : 'workflowConfigIdTestUpdate',
			nextTriggerTime : '2019-01-02 05:04:06',
			previousTriggerTime : '2019-01-02 05:04:06',
			schedulerPolicy : null,
			groupId : 'groupIdTest',
			checkDuplicateHeader : false,
			checkDuplicateFile : false,
			numberOfExpectedFiles : '2',
			expectedFiles : 1,
			disabled : true
		]

		def res = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		when:
		def response = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request2))
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("status").equals("SUCCESS")
	}


	def "create job and run" (){
		given:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		when:
		MvcResult response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/createjob/projectNameTest/workflowNameTest/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}


	def "cancel running job" (){
		given:
		def response1 = mvc.perform(
				post('/SaveEditSchedulerJob/scheduler/batchDefinition').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		when:
		MvcResult response = mvc.perform(
				get('/GetScheduleJob/scheduler/batchDefinition/cancelJob/5ca4de8dfa4c5bb21cca76f9')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}

	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}