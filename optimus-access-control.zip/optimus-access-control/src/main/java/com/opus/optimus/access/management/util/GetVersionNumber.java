package com.opus.optimus.access.management.util;

import java.sql.Timestamp;

public class GetVersionNumber {

	public static Timestamp getVersion() {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		;
		return timestamp;
	}
}
