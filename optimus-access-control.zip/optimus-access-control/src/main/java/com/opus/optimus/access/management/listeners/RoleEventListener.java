package com.opus.optimus.access.management.listeners;

import static com.opus.optimus.access.management.constent.AccessManagementConstent.DELETE;
import static com.opus.optimus.access.management.constent.AccessManagementConstent.ID;
import static com.opus.optimus.access.management.constent.AccessManagementConstent.SAVE;
import static com.opus.optimus.access.management.constent.AccessManagementConstent._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.access.management.repository.RoleRepository;
import com.opus.optimus.access.management.repository.audit.RoleAuditRepository;
import com.opus.optimus.access.management.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.RoleAudit;
import com.opus.optimus.ui.services.user.Role;

@Component
public class RoleEventListener extends AbstractMongoEventListener<Role> {
	private static final Logger log = LoggerFactory.getLogger(RoleEventListener.class);

	@Autowired
	private RoleAuditRepository roleAuditRepository;
	@Autowired
	private RoleRepository roleRepository;
	private Role roleStore;

	@Override
	public void onAfterSave(AfterSaveEvent<Role> event) {
		RoleAudit roleAudit = getRoleAudit(event.getSource());
		roleAudit.setAction(SAVE);
		roleAuditRepository.save(roleAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<Role> event) {
		storeActivity(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<Role> event) {
		RoleAudit roleAudit = getRoleAudit(roleStore);
		roleAudit.setAction(DELETE);
		roleAuditRepository.save(roleAudit);
	}

	private RoleAudit getRoleAudit(Role role) {
		RoleAudit roleAudit = new RoleAudit();
		BeanUtils.copyProperties(role, roleAudit, ID);
		setAdditionalAuditingFields(role, roleAudit);
		return roleAudit;
	}

	private void setAdditionalAuditingFields(Role role, RoleAudit roleAudit) {
		roleAudit.setDocumentId(role.getRoleId());
		roleAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeActivity(BeforeDeleteEvent<Role> event) {
		Optional<Role> role = roleRepository.findById(event.getDocument().get(_ID).toString());
		if (role.isPresent()) {
			roleStore = role.get();
		}
	}

}
