package com.opus.optimus.access.management.services;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.opus.optimus.ui.services.user.ApiConfig;

/**
 * The Interface IApiConfigService.
 */
public interface IApiConfigService {

	/**
	 * Save api config.
	 *
	 * @param apiConfig the api config
	 */
	void saveApiConfig(ApiConfig apiConfig);

	/**
	 * Gets the api configs.
	 *
	 * @param roleName the role name
	 * @return the api configs
	 */
	Map<String, List<ApiConfig>> getApiConfigs(List<String> roles);

	/**
	 * Gets the api config.
	 *
	 * @param configId the config id
	 * @return the api config
	 */
	ApiConfig getApiConfig(String configId);

	/**
	 * Update api config.
	 *
	 * @param configId the config id
	 * @param apiConfig the api config
	 * @return the string
	 */
	String updateApiConfig(String configId, ApiConfig apiConfig);

	/**
	 * Delete api config.
	 *
	 * @param apiConfig the api config
	 * @return the string
	 */
	String deleteApiConfig(String apiConfig);

	/**
	 * Gets the api configs with sorted.
	 *
	 * @param apiConfigsResult the api configs result
	 * @return the api configs with sorted
	 */
	Map<String, List<ApiConfig>> getApiConfigsWithSorted(List<ApiConfig> apiConfigsResult);

	/**
	 * Gets the api configs.
	 *
	 * @return the api configs
	 */
	List<ApiConfig> getApiConfigs();

	Set<String> getHomeScreenPermissions(List<String> roles);
}
