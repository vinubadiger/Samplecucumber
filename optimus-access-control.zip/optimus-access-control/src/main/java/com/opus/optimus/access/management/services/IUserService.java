package com.opus.optimus.access.management.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.user.User;

/**
 * The Interface IUserService.
 */
@Service
public interface IUserService {

	/**
	 * Save user.
	 *
	 * @param user the user
	 * @return the service response
	 */
	public ServiceResponse saveUser(User user);

	/**
	 * Gets the users.
	 *
	 * @return the users
	 */
	public List<User> getUsers();

	/**
	 * Gets the user.
	 *
	 * @param emailId the email id
	 * @return the user
	 */
	public User getUser(String emailId);

	/**
	 * Update user.
	 *
	 * @param userName the user name
	 * @param user the user
	 * @return the service response
	 */
	public ServiceResponse updateUser(String userName, User user);

	/**
	 * Delete user.
	 *
	 * @param userName the user name
	 * @return the service response
	 */
	public ServiceResponse deleteUser(String userName);

	/**
	 * Assign role.
	 *
	 * @param email the email
	 * @param role the role
	 * @return the string
	 */
	//public String assignRole(String email, @RequestBody List<Role> role);

	/**
	 * Fetch users for selected role.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	List<User> fetchUsersForSelectedRole(String roleName);

	/**
	 * Fetch available users.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	//public List<User> fetchAvailableUsers(String roleName);


	/**
	 * @param userName
	 * @return
	 */
	List<User> searchUser(String userName);
	
	/**
	 * Save Azure user.
	 *
	 * @param jwtToken
	 * @return the service response
	 */
	public ServiceResponse saveAzureUser(String jwtToken);
}
