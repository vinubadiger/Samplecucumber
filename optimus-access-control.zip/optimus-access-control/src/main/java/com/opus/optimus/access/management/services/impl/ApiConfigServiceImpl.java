package com.opus.optimus.access.management.services.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.access.management.repository.ApiConfigRepository;
import com.opus.optimus.access.management.repository.ProfileRepository;
import com.opus.optimus.access.management.services.IApiConfigService;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.ui.services.user.ApiConfig;
import com.opus.optimus.ui.services.user.Profile;

/**
 * The Class ApiConfigServiceImpl.
 */
@Service
public class ApiConfigServiceImpl implements IApiConfigService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(ApiConfigServiceImpl.class);

	/** The restapi deleted. */
	private static final String RESTAPI_DELETED = "REST API deleted";

	/** The restapi not deleted. */
	private static final String RESTAPI_NOT_DELETED = "REST API not deleted";
	
	/** The restapi not updated. */
	private static final String RESTAPI_NOT_UPDATED = "REST API not updated";

	/** The api config repository. */
	@Autowired
	private ApiConfigRepository apiConfigRepository;

	/** The profile repository. */
	@Autowired
	private ProfileRepository profileRepository;
	

	/**
	 * Save api config.
	 *
	 * @param apiConfig the api config
	 */
	@Override
	public void saveApiConfig(ApiConfig apiConfig) {
		try{
			apiConfigRepository.save(apiConfig);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in getHomeScreenPermissions with roleName", e);
		}
	}
	
	/**
	 * Gets the api configs.
	 *
	 * @param roleName the role name
	 * @return the api configs
	 */
	@Override
	public Map<String, List<ApiConfig>> getApiConfigs(List<String> roles) {
		List<ApiConfig> apiConfigs = null;
		List<ApiConfig> apiConfigsResult = new ArrayList<>();
		Set<ApiConfig> apiConfigsResultRolesPermCombined = new HashSet<>();
		try{
			for (String role : roles){
				Profile profileDb = profileRepository.getCurrentUserPermission(role);

				if (profileDb == null){
					apiConfigsResultRolesPermCombined.addAll(this.apiConfigRepository.findAll());
				} else{
					apiConfigsResultRolesPermCombined.addAll(profileDb.getRestApiConfig());
				}

			}

			apiConfigs = this.apiConfigRepository.findAll();

			int found = 0;

			for (ApiConfig apiConfig : apiConfigs){
				for (ApiConfig profile : apiConfigsResultRolesPermCombined){
					if (apiConfig.getConfigId().equals(profile.getConfigId())){
						found = 1;
						break;
					} else{
						found = 0;
					}
				}
				if (found == 1){
					apiConfig.setSelected(true);
					apiConfigsResult.add(apiConfig);
				} else{
					apiConfig.setSelected(false);
					apiConfigsResult.add(apiConfig);
				}
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(RESTAPI_NOT_UPDATED, e);
		}

		return getApiConfigsWithSorted(apiConfigsResult);
	}

	/**
	 * Gets the Home screen icon permissions.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	@Override
	public Set<String> getHomeScreenPermissions(List<String> roles) {
		Set<String> mergedRolePermissions = null;
		try{
			List<Profile> profileDb = profileRepository.getHomeScreenIcons(roles);

			int index = 0;
			List<String> mergeHomeScreenPerm = null;

			for (Profile profile : profileDb){
				if (index == 0){
					mergeHomeScreenPerm = new ArrayList(profile.getHomeScreenIcons());
					index++;
				} else{
					mergeHomeScreenPerm.addAll(profile.getHomeScreenIcons());
				}
			}
			mergedRolePermissions = new HashSet<>(mergeHomeScreenPerm);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(RESTAPI_NOT_UPDATED, e);
		}
		return mergedRolePermissions;

	}

	/**
	 * Gets the api config.
	 *
	 * @param configId the config id
	 * @return the api config
	 */
	@Override
	public ApiConfig getApiConfig(String configId) {
		return this.apiConfigRepository.findByConfigId(configId);
	}

	/**
	 * Update api config.
	 *
	 * @param configId the config id
	 * @param apiConfig the api config
	 * @return the string
	 */
	@Override
	public String updateApiConfig(String configId, ApiConfig apiConfig) {
		try{
			ApiConfig apiConfigDb = getApiConfig(configId);

			if (apiConfigDb != null){
				apiConfig.setConfigId(apiConfigDb.getConfigId());

				saveApiConfig(apiConfig);
				return "REST API updated";
			} else{
				return "REST API not updated";
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(RESTAPI_NOT_UPDATED, e);
		}

	}

	/**
	 * Delete api config.
	 *
	 * @param apiConfig the api config
	 * @return the string
	 */
	@Override
	public String deleteApiConfig(String configId) {
		ApiConfig apiConfigDb;
		try{
			apiConfigDb = this.apiConfigRepository.findByConfigId(configId);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in deleteApiConfig :", e);
		}

		try{
			if (apiConfigDb != null){
				this.apiConfigRepository.delete(apiConfigDb);
				return RESTAPI_DELETED;
			} else{
				return RESTAPI_NOT_DELETED;
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("REST API not deleted :", e);
		}
	}

	/**
	 * Gets the api configs with sorted.
	 *
	 * @param apiConfigsResult the api configs result
	 * @return the api configs with sorted
	 */
	public Map<String, List<ApiConfig>> getApiConfigsWithSorted(List<ApiConfig> apiConfigsResult) {
		return apiConfigsResult.stream().collect(Collectors.groupingBy(ApiConfig::getControllerName));
	}

	/**
	 * Gets the api configs.
	 *
	 * @return the api configs
	 */
	@Override
	public List<ApiConfig> getApiConfigs() {
		return apiConfigRepository.findAll();
	}	

}
