package com.opus.optimus.access.management.services;

import java.util.List;
import java.util.Map;

import com.opus.optimus.ui.services.user.ApiConfig;
import com.opus.optimus.ui.services.user.Profile;

/**
 * The Interface IProfileService.
 */
public interface IProfileService {

	/**
	 * Save profile.
	 *
	 * @param profile the profile
	 */
	void saveProfile(Profile profile);

	/**
	 * Gets the profiles.
	 *
	 * @return the profiles
	 */
	List<Profile> getProfiles();

	/**
	 * Gets the profile.
	 *
	 * @param profileId the profile id
	 * @return the profile
	 */
	Profile getProfile(String profileId);

	/**
	 * Update profile.
	 *
	 * @param profile the profile
	 * @return the string
	 */
	String updateProfile(Profile profile);

	/**
	 * Delete profile.
	 *
	 * @param profileId the profile id
	 * @return the string
	 */
	String deleteProfile(String profileId);

	/**
	 * Gets the profile by role.
	 *
	 * @param roleName the role name
	 * @return the profile by role
	 */
	Profile getProfileByRole(String roleName);

	Map<String, Map<String, List<ApiConfig>>> getPolicy(String roleName);

}
