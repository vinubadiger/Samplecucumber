package com.opus.optimus.access.management;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * The Class EntryPoint that used to bootstrap and launch a application from a Java main.
 */
@SpringBootApplication
@ComponentScan ({ "com.opus.optimus.access.management" })
@EnableMongoRepositories ("com.opus.optimus.access.management.repository")
public class EntryPoint {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(EntryPoint.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		logger.debug("Starting access management application....");
		SpringApplication.run(EntryPoint.class, args);
	}
}
