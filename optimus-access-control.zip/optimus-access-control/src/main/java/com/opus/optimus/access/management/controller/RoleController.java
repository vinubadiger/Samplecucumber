package com.opus.optimus.access.management.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.access.management.services.IRoleService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.user.Role;

/**
 * The Class RoleController exposes api related to user roles.
 */
@RestController
@RequestMapping ("{actionName}/roles")
public class RoleController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(RoleController.class);

	/** The role service. */
	@Autowired
	private IRoleService roleService;

	/**
	 * Registers the role.
	 *
	 * @param role the role
	 * @return the service response
	 */
	@PostMapping
	public ServiceResponse registerRole(@RequestBody Role role) {
		log.debug("RoleController::registerRole");
		return roleService.saveRole(role);
	}

	/**
	 * Get the data for all the roles.
	 *
	 * @return the roles
	 */
	@GetMapping
	public List<Role> getRoles() {
		log.debug("Entered in getRoles");
		return this.roleService.getRoles();
	}

	/**
	 * Get the data for a particular role.
	 *
	 * @param roleName the role name
	 * @return the role
	 */
	@GetMapping (value = "/{roleName}")
	public Role getRole(@PathVariable ("roleName") String roleName) {
		log.debug(roleName);
		return roleService.getRole(roleName);
	}

	/**
	 * Edit the data for particular role.
	 *
	 * @param roleName the role name
	 * @param role the role
	 * @return the service response
	 */
	@PutMapping (value = "/{roleName}")
	public ServiceResponse updateRole(@PathVariable ("roleName") String roleName, @RequestBody Role role) {
		log.debug(roleName);
		return roleService.updateRole(roleName, role);
	}

	/**
	 * Delete the data for particular role.
	 *
	 * @param roleName the role name
	 * @return the service response
	 */
	@DeleteMapping (value = "/{roleName}")
	public ServiceResponse deleteRole(@PathVariable ("roleName") String roleName) {
		log.debug(roleName);
		return roleService.deleteRole(roleName);
	}
}
