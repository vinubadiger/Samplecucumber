package com.opus.optimus.access.management.listeners;

import static com.opus.optimus.access.management.constent.AccessManagementConstent.DELETE;
import static com.opus.optimus.access.management.constent.AccessManagementConstent.ID;
import static com.opus.optimus.access.management.constent.AccessManagementConstent.SAVE;
import static com.opus.optimus.access.management.constent.AccessManagementConstent._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.access.management.repository.ProfileRepository;
import com.opus.optimus.access.management.repository.audit.ProfileAuditRepository;
import com.opus.optimus.access.management.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.ProfileAudit;
import com.opus.optimus.ui.services.user.Profile;

@Component
public class ProfileEventListener extends AbstractMongoEventListener<Profile> {
	private static final Logger log = LoggerFactory.getLogger(ProfileEventListener.class);

	@Autowired
	private ProfileAuditRepository profileAuditRepository;
	@Autowired
	private ProfileRepository profileRepository;
	private Profile profileStore;

	@Override
	public void onAfterSave(AfterSaveEvent<Profile> event) {
		ProfileAudit profileAudit = getRoleAudit(event.getSource());
		profileAudit.setAction(SAVE);
		profileAuditRepository.save(profileAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<Profile> event) {
		storeActivity(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<Profile> event) {
		ProfileAudit profileAudit = getRoleAudit(profileStore);
		profileAudit.setAction(DELETE);
		profileAuditRepository.save(profileAudit);
	}

	private ProfileAudit getRoleAudit(Profile profile) {
		ProfileAudit profileAudit = new ProfileAudit();
		BeanUtils.copyProperties(profile, profileAudit, ID);
		setAdditionalAuditingFields(profile, profileAudit);
		return profileAudit;
	}

	private void setAdditionalAuditingFields(Profile profile, ProfileAudit profileAudit) {
		profileAudit.setDocumentId(profile.getProfileId());
		profileAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeActivity(BeforeDeleteEvent<Profile> event) {
		Optional<Profile> profile = profileRepository.findById(event.getDocument().get(_ID).toString());
		if (profile.isPresent()) {
			profileStore = profile.get();
		}
	}

}
