package com.opus.optimus.access.management.listeners;

import static com.opus.optimus.access.management.constent.AccessManagementConstent.DELETE;
import static com.opus.optimus.access.management.constent.AccessManagementConstent.ID;
import static com.opus.optimus.access.management.constent.AccessManagementConstent.SAVE;
import static com.opus.optimus.access.management.constent.AccessManagementConstent._ID;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.event.AbstractMongoEventListener;
import org.springframework.data.mongodb.core.mapping.event.AfterDeleteEvent;
import org.springframework.data.mongodb.core.mapping.event.AfterSaveEvent;
import org.springframework.data.mongodb.core.mapping.event.BeforeDeleteEvent;
import org.springframework.stereotype.Component;

import com.opus.optimus.access.management.repository.LoginRepository;
import com.opus.optimus.access.management.repository.audit.LoginAuditRepository;
import com.opus.optimus.access.management.util.GetVersionNumber;
import com.opus.optimus.ui.services.audit.LoginAudit;
import com.opus.optimus.ui.services.user.Login;

@Component
public class LoginEventListener extends AbstractMongoEventListener<Login> {
	private static final Logger log = LoggerFactory.getLogger(LoginEventListener.class);

	@Autowired
	private LoginAuditRepository loginAuditRepository;
	@Autowired
	private LoginRepository loginRepository;
	private Login loginStore;

	@Override
	public void onAfterSave(AfterSaveEvent<Login> event) {
		LoginAudit loginAudit = getLoginAudit(event.getSource());
		loginAudit.setAction(SAVE);
		loginAuditRepository.save(loginAudit);
	}

	@Override
	public void onBeforeDelete(BeforeDeleteEvent<Login> event) {
		storeActivity(event);
	}

	@Override
	public void onAfterDelete(AfterDeleteEvent<Login> event) {
		LoginAudit loginAudit = getLoginAudit(loginStore);
		loginAudit.setAction(DELETE);
		loginAuditRepository.save(loginAudit);
	}

	private LoginAudit getLoginAudit(Login login) {
		LoginAudit loginAudit = new LoginAudit();
		BeanUtils.copyProperties(login, loginAudit, ID);
		setAdditionalAuditingFields(login, loginAudit);
		return loginAudit;
	}

	private void setAdditionalAuditingFields(Login login, LoginAudit loginAudit) {
		loginAudit.setDocumentId(login.getUserName());
		loginAudit.setVersion(GetVersionNumber.getVersion());
	}

	private void storeActivity(BeforeDeleteEvent<Login> event) {
		Optional<Login> login = loginRepository.findById(event.getDocument().get(_ID).toString());
		if (login.isPresent()) {
			loginStore = login.get();
		}
	}

}
