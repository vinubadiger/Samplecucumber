package com.opus.optimus.access.management.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.access.management.services.IApiConfigService;
import com.opus.optimus.ui.services.user.ApiConfig;

/**
 * The Class APIConfigController exposes the api for rest api configration for all the endpoints.
 */
@RestController
@RequestMapping ("{actionName}/apiconfigs")
public class APIConfigController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(APIConfigController.class);

	/** The api config service. */
	@Autowired
	private IApiConfigService apiConfigService;

	/**
	 * Registers the REST API.
	 *
	 * @param apiConfig the api config
	 */
	@PostMapping
	public void configRestApi(@RequestBody ApiConfig apiConfig) {
		log.debug("RestAPIConfigController::ConfigRestApi");
		apiConfigService.saveApiConfig(apiConfig);
	}

	/**
	 * Get the data for all the REST APIs.
	 *
	 * @return the api configs
	 */
	@GetMapping (value = "configs")
	public List<ApiConfig> getApiConfigs() {
		log.debug("Entered in getApiConfigs");
		return this.apiConfigService.getApiConfigs();
	}

	/**
	 * Get the data for all the REST APIs for a specific role.
	 *
	 * @param roleName the role name
	 * @return the api configs
	 */
	@PostMapping (value = "configs")
	public Map<String, List<ApiConfig>> getApiConfigs(@RequestBody List<String> roles) {
		log.debug("Entered in getApiConfigs");
		return this.apiConfigService.getApiConfigs(roles);
	}

	/**
	 * Get the data for a particular REST API.
	 *
	 * @param configId the config id
	 * @return the api config
	 */
	@GetMapping (value = "/{configId}")
	public ApiConfig getApiConfig(@PathVariable ("configId") String configId) {
		log.debug(configId);
		return apiConfigService.getApiConfig(configId);
	}

	/**
	 * Edit the data for particular REST API.
	 *
	 * @param configId the config id
	 * @param apiConfig the api config
	 * @return the string
	 */
	@PutMapping (value = "/{configId}")
	public String updateApiConfig(@PathVariable ("configId") String configId, @RequestBody ApiConfig apiConfig) {
		log.debug(configId);
		return apiConfigService.updateApiConfig(configId, apiConfig);
	}

	/**
	 * Delete the data for particular REST API.
	 *
	 * @param configId the config id
	 * @return the string
	 */
	@DeleteMapping (value = "/{configId}")
	public String deleteInstitution(@PathVariable ("configId") String configId) {
		log.debug(configId);
		return apiConfigService.deleteApiConfig(configId);
	}

	/**
	 * Fetch the permissions for menu screen icons
	 * 
	 * @param roleName
	 * @return
	 */
	@PostMapping (value = "configs/homescreenpermissions")
	public Set<String> getHomeScreenPermissions(@RequestBody List<String> roles) {
		log.debug("Entered in getHomeScreenPermissions");
		return this.apiConfigService.getHomeScreenPermissions(roles);
	}
}
