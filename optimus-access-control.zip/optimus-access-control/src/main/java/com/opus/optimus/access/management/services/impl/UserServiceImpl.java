package com.opus.optimus.access.management.services.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.opus.optimus.access.management.repository.LoginRepository;
import com.opus.optimus.access.management.repository.RoleRepository;
import com.opus.optimus.access.management.repository.UserRepository;
import com.opus.optimus.access.management.services.IUserService;
import com.opus.optimus.access.management.util.UserContextUtility;
import com.opus.optimus.offline.config.constants.Constants;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.user.Login;
import com.opus.optimus.ui.services.user.Role;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class UserServiceImpl.
 */
@Service
public class UserServiceImpl implements IUserService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	/** The Constant USER_EXISTS. */
	private static final String USER_EXISTS = "User with this Email ID Already Exists";

	/** The Constant USER_CREATED. */
	private static final String USER_CREATED = "User Registered";

	/** The Constant USER_UPDATED. */
	private static final String USER_UPDATED = "User Updated";

	/** The Constant USER_NOT_EXISTS. */
	private static final String USER_NOT_EXISTS = "User Does not Exists";

	/** The Constant USER_DELETED. */
	private static final String USER_DELETED = "User deleted";

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;

	/** The login repository. */
	@Autowired
	private LoginRepository loginRepository;

	/** The b crypt password encoder. */
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	UserContextUtility userContextUtility;
	
	/** The role repository. */
	@Autowired
	RoleRepository roleRepository;

	/**
	 * Save user.
	 *
	 * @param user the user
	 * @return the service response
	 */
	@Override
	public ServiceResponse saveUser(User user) {
		try{
			User userDb = getUser(user.getEmail());

			if (userDb != null){
				return new ServiceResponse(500, ResponseStatus.DUPLICATE, USER_EXISTS, userDb);
			} else{

				String encodedPassword = bCryptPasswordEncoder.encode(Constants.DEFAULT_PASSOWRD);

				Login login = new Login();
				login.setUserName(user.getEmail());
				login.setPassword(encodedPassword);

				user.setPassword(encodedPassword);
				user.setCreatedBy(user.getEmail());
				user.setCreatedDate(new Date());

				loginRepository.save(login);
				userRepository.save(user);

				return new ServiceResponse(200, ResponseStatus.SUCCESS, USER_CREATED, user);
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in UserServiceImpl saveUser ", e);
		}
	}

	/**
	 * Gets the users.
	 *
	 * @return the users
	 */
	@Override
	public List<User> getUsers() {
		List<User> users = this.userRepository.findAll();
		Collections.sort(users, (u1, u2) -> u1.getEmail().compareTo(u2.getEmail()));
		return users;
	}

	/**
	 * Gets the user.
	 *
	 * @param emailId the email id
	 * @return the user
	 */
	@Override
	public User getUser(String emailId) {
		return this.userRepository.findUserByEmail(emailId);
	}

	/**
	 * Update user.
	 *
	 * @param userName the user name
	 * @param user the user
	 * @return the service response
	 */
	@Override
	public ServiceResponse updateUser(String email, User user) {

		User userDb = getUser(email);
		try{
			if (userDb != null){
				user.setPassword(userDb.getPassword());
				user.setModifiedBy(userContextUtility.getLoggedUsername());
				user.setModifiedDate(new Date());
				user.setEmail(userDb.getEmail());
				this.userRepository.save(user);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, USER_UPDATED, user);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, USER_NOT_EXISTS, userDb);
			}

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in UserServiceImpl updateUser ", e);
		}
	}

	/**
	 * Delete user.
	 *
	 * @param userName the user name
	 * @return the service response
	 */
	@Override
	public ServiceResponse deleteUser(String email) {
		User userDb = this.userRepository.findUserByEmail(email);
		try{
			if (userDb != null){
				this.userRepository.delete(userDb);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, USER_DELETED, userDb);
			} else return new ServiceResponse(500, ResponseStatus.FAILED, USER_NOT_EXISTS, userDb);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in UserServiceImpl deleteUser ", e);
		}
	}

	

	/**
	 * Fetch users for selected role.
	 *
	 * @param roleName the role name
	 * @return the list
	 */
	@Override
	public List<User> fetchUsersForSelectedRole(String roleName) {
		return this.userRepository.findUserByRole(roleName);
	}


	@Override
	public List<User> searchUser(String email) {
		try{
			List<User> users = userRepository.findSearchUserByEmail(email);
			Collections.sort(users, (u1, u2) -> u1.getEmail().compareTo(u2.getEmail()));
			return users;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	@Override
	public ServiceResponse saveAzureUser(String jwtToken) {
		try{
			log.debug("Saving / Updating user record in DB");

			List<?> azureRoles = (List<?>) userContextUtility.getClaimsFromJwt(jwtToken).getClaim("roles");

			List<Role> presentRoles = roleRepository.findByRoleNames(azureRoles);

			if (presentRoles != null && !presentRoles.isEmpty()){
				User user = new User();
				user.setRoles(presentRoles.stream().map(Role::getRoleName).collect(Collectors.toList()));
				user.setFirstName((String) userContextUtility.getClaimsFromJwt(jwtToken).getClaim("given_name"));
				user.setLastName((String) userContextUtility.getClaimsFromJwt(jwtToken).getClaim("family_name"));
				user.setEmail((String) userContextUtility.getClaimsFromJwt(jwtToken).getClaim("unique_name"));
				user.setActive(true);
				user.setProjects(new ArrayList<String>());
				return saveUser(user);
			} else{
				throw new GenericException("User cannot be created as the Role not provisioned in the application");
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in registerUser :", e);
		}
	}
}
