package com.opus.optimus.access.management.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.user.Role;

/**
 * The Interface RoleRepository.
 */
@Repository
public interface RoleRepository extends MongoRepository<Role, String> {

	/**
	 * Find by role name.
	 *
	 * @param roleName the role name
	 * @return the role
	 */
	@Query (value = "{'roleName': {$regex : '^?0$', $options: 'i'}}")
	Role findByRoleName(String roleName);

	/**
	 * Find by role names.
	 *
	 * @param roleNames the role names
	 * @return the list
	 */
	@Query (value = "{'roleName' : {$in : ?0}}")
	List<Role> findByRoleNames(List<?> roleNames);
}
