package com.opus.optimus.access.management.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.access.management.services.IUserService;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class UserController exposes api related to user.
 */
@RestController
@RequestMapping ("{actionName}/users")
public class UserController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(UserController.class);

	/** The user service. */
	@Autowired
	private IUserService userService;

	/**
	 * Registers the user.
	 * 
	 * @param user the user
	 * @return the service response
	 */

	@PostMapping
	public ServiceResponse registerUser(@RequestBody User user) {
		log.debug("UserController::register");
		return userService.saveUser(user);
	}

	/**
	 * Get the data for all the users.
	 *
	 * @return the users
	 */
	@GetMapping
	public List<User> getUsers() {
		log.debug("Entered in getUsers");
		return this.userService.getUsers();
	}

	/**
	 * Gets the user.
	 *
	 * @param userName the user name
	 * @return the user
	 */
	@GetMapping (value = "/{userName}")
	public User getUser(@PathVariable ("userName") String userName) {
		log.debug("getUser : {}", userName);
		return userService.getUser(userName);
	}

	/**
	 * Edit the data for particular user.
	 *
	 * @param userName the user name
	 * @param user the user
	 * @return the service response
	 */
	@PutMapping (value = "/{userName}")
	public ServiceResponse updateUser(@PathVariable ("userName") String userName, @RequestBody User user) {
		log.debug(user.getEmail());
		return userService.updateUser(userName, user);
	}

	/**
	 * Delete the data for particular user.
	 *
	 * @param userName the user name
	 * @return the service response
	 */
	@DeleteMapping (value = "/{userName}")
	public ServiceResponse deleteUser(@PathVariable ("userName") String userName) {
		log.debug("deleteUser : {}", userName);
		return userService.deleteUser(userName);
	}

	/**
	 * API that returns the list of users to whom a particular role is already assigned(This is required for "Assign Role" on Roles screen.
	 *
	 * @param roleName the role name
	 * @return the list
	 */

	@GetMapping (value = "/usersassigned/{roleName}")
	public List<User> fetchUsersForSelectedRole(@PathVariable ("roleName") String roleName) {
		log.debug("fetchUsersForSelectedRole : {}", roleName);
		return userService.fetchUsersForSelectedRole(roleName);
	}

	/**
	 * API to return the data for user search
	 * 
	 * @param search
	 * @param page
	 * @param size
	 * @return
	 */
	@GetMapping ("/searchusers/{userName}")
	public List<User> searchUser(@PathVariable ("userName") String userName) {
		log.debug("searchUser : {}", userName);
		return userService.searchUser(userName);
	}

	@PostMapping ("/saveAzureUser")
	public ServiceResponse saveAzureUser(@RequestHeader (value = "Authorization") String jwtToken) {
		return userService.saveAzureUser(jwtToken);
	}

}
