package com.opus.optimus.access.management.services.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.access.management.repository.RoleRepository;
import com.opus.optimus.access.management.repository.UserRepository;
import com.opus.optimus.access.management.services.IRoleService;
import com.opus.optimus.access.management.services.IUserService;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.user.Role;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class RoleServiceImpl.
 */
@Service
public class RoleServiceImpl implements IRoleService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(RoleServiceImpl.class);

	/** The Constant ROLE_EXISTS. */
	private static final String ROLE_EXISTS = "Role Already Exists";

	/** The Constant ROLE_CREATED. */
	private static final String ROLE_CREATED = "Role Created";

	/** The Constant ROLE_UPDATED. */
	private static final String ROLE_UPDATED = "Role Updated";

	/** The Constant ROLE_NOT_EXISTS. */
	private static final String ROLE_NOT_EXISTS = "Role does not Exists";

	/** The Constant ROLE_DELETED. */
	private static final String ROLE_DELETED = "Role deleted";

	/**
	 * The Constant ROLE_ASSIGNED.
	 */
	private static final String ROLE_ASSIGNED = "Since the Role is already assigned to user, it cannot be deleted";

	/** The role repository. */
	@Autowired
	private RoleRepository roleRepository;

	/** The user service. */
	@Autowired
	private IUserService userService;

	/** The user repository. */
	@Autowired
	private UserRepository userRepository;

	/**
	 * Save role.
	 *
	 * @param role the role
	 * @return the service response
	 */
	@Override
	public ServiceResponse saveRole(Role role) {
		Role roleDb = getRole(role.getRoleName());

		if (roleDb != null){
			return new ServiceResponse(500, ResponseStatus.DUPLICATE, ROLE_EXISTS, roleDb);
		} else{
			role.setCreatedDate(new Date());
			roleRepository.save(role);

			return new ServiceResponse(200, ResponseStatus.SUCCESS, ROLE_CREATED, role);
		}
	}

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	@Override
	public List<Role> getRoles() {
		return this.roleRepository.findAll();
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.services.user.IRoleService#getRole(java.lang.String)
	 */
	@Override
	public Role getRole(String roleName) {
		return this.roleRepository.findByRoleName(roleName);
	}

	/**
	 * Update role.
	 *
	 * @param roleId the role id
	 * @param role the role
	 * @return the service response
	 */
	@Override
	public ServiceResponse updateRole(String roleName, Role role) {
		Role roleDb = getRole(roleName);

		try{
			if (roleDb != null){
				roleDb.setDescription(role.getDescription());
				roleDb.setModifiedDate(new Date());
				this.roleRepository.save(roleDb);
				return new ServiceResponse(200, ResponseStatus.SUCCESS, ROLE_UPDATED, role);
			} else{
				return new ServiceResponse(500, ResponseStatus.FAILED, ROLE_NOT_EXISTS, roleDb);
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			return new ServiceResponse(500, ResponseStatus.FAILED, ROLE_NOT_EXISTS, roleDb);
		}
	}

	/**
	 * Delete role.
	 *
	 * @param roleId the role id
	 * @return the service response
	 */
	@Override
	public ServiceResponse deleteRole(String roleName) {
		Role roleDb = this.roleRepository.findByRoleName(roleName);
		try{
			if (roleDb != null){
				List<User> userDb = this.userRepository.findUserByRole(roleName);

				if (!userDb.isEmpty()){
					return new ServiceResponse(200, ResponseStatus.FAILED, ROLE_ASSIGNED, roleDb);
				} else{
					this.roleRepository.delete(roleDb);
					return new ServiceResponse(200, ResponseStatus.SUCCESS, ROLE_DELETED, roleDb);
				}
			} else return new ServiceResponse(500, ResponseStatus.FAILED, ROLE_NOT_EXISTS, roleDb);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in deleteRole with roleName", e);
		}
	}

	/**
	 * Assign role to user.
	 *
	 * @param roleId the role id
	 * @param emails the emails
	 * @return the string
	 */
	/*public String assignRoleToUser(String roleName, List<String> emails) {

		try{

			Role roleDb = getRole(roleName);
			if (roleDb != null){
				for (String email : emails){
					User userDb = userService.getUser(email);

					if (userDb != null){
						if (!userDb.getRoles().contains(new Role(roleName))){
							userDb.getRoles().add(new Role(roleName));
						}
					}
					userRepository.save(userDb);
				}
				return "Role Assigned";
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in RoleServiceImpl assignRole ", e);
		}
		return roleName;

	}*/

	/**
	 * Revoke role from user.
	 *
	 * @param roleName the role name
	 * @param emails the emails
	 * @return the string
	 */
	/*public String revokeRoleFromUser(String roleName, List<String> emails) {
		try{

			Role roleDb = getRole(roleName);
			if (roleDb != null){
				for (String email : emails){
					User userDb = userService.getUser(email);
					userDb.setRoles(new ArrayList<Role>());
					userRepository.save(userDb);
				}
				return "Role Revoked";
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException("Error in RoleServiceImpl assignRole ", e);
		}
		return roleName;
	}*/

}
