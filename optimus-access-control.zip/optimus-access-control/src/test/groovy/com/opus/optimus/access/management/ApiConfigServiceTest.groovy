package com.opus.optimus.access.management;

import com.opus.optimus.access.management.services.impl.ApiConfigServiceImpl
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.ui.services.user.ApiConfig

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class ApiConfigServiceTest extends Specification {
	
	def "Save Api Config - Exception"(){
		given:
		def apiConfigService = new ApiConfigServiceImpl()
		ApiConfig apiConfig = new ApiConfig();
		apiConfigService.saveApiConfig(apiConfig) >> { throw new NullPointerException() }

		when:
		apiConfigService.saveApiConfig(apiConfig)
		
		then:
		thrown GenericException
	}
	
	def "Get Api Configs - Exception"(){
		given:
		def apiConfigService = new ApiConfigServiceImpl()
		List<String> roles = new ArrayList<>();
		roles.add("Admin")
		apiConfigService.getApiConfigs(roles) >> { throw new NullPointerException() }

		when:
		apiConfigService.getApiConfigs(roles)
		
		then:
		thrown GenericException
	}
	
	def "Get Home Screen Permissions - Exception"(){
		given:
		def apiConfigService = new ApiConfigServiceImpl()
		List<String> roles = new ArrayList<>();
		roles.add("Admin")
		apiConfigService.getHomeScreenPermissions(roles) >> { throw new NullPointerException() }

		when:
		apiConfigService.getHomeScreenPermissions(roles)
		
		then:
		thrown GenericException
	}
	
	def "Update Api Config - Exception"(){
		given:
		def apiConfigService = new ApiConfigServiceImpl()
		List<String> roles = new ArrayList<>();
		roles.add("Admin")
		ApiConfig apiConfig = new ApiConfig();
		apiConfigService.updateApiConfig("configId", apiConfig) >> { throw new NullPointerException() }

		when:
		apiConfigService.updateApiConfig("configId", apiConfig)
		
		then:
		thrown GenericException
	}

	def "Delete Api Config - Exception"(){
		given:
		def apiConfigService = new ApiConfigServiceImpl()

		apiConfigService.deleteApiConfig("id") >> { throw new NullPointerException() }

		when:
		String result = apiConfigService.deleteApiConfig("id")
		println("Result -->" + result)
		then:
		thrown GenericException
	}
}