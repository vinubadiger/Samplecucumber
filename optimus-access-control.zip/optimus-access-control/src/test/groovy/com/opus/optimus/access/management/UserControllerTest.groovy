package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.fasterxml.jackson.databind.ObjectMapper
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.access.management.interceptor.LoginInterceptor
import com.opus.optimus.ui.services.user.User

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class UserControllerTest extends Specification {
	@Autowired
	protected MockMvc mvc

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	MongoTemplate mongoTemplate;

	def requestUser;

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		def jsonStream = getClass().getResourceAsStream("/User.json")
		requestUser = mapper.readValue(jsonStream, User.class)
	}

	def "Registers the user" (){
		given:
		Map request = [
			email : 'user1@gmail.com',
			password : 'password',
			firstName : 'firstName',
			lastName : 'lastName',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'

		]
		when:
		MvcResult response = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Get the data for all the users" (){
		when:
		MvcResult response = mvc.perform(
				get('/GetAllUsers/users')
				).andReturn()

		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}


	def "Get the data for a particular user using email" (){
		given:
		Map request = [
			email : 'user1@gmail.com',
			password : 'password',
			firstName : 'firstName1',
			lastName : 'lastName1',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'

		]
		MvcResult response1 = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status create --> " + response1.getResponse().getStatus())

		when:

		MvcResult response = mvc.perform(
				get('/GetAllUsers/users/user1@gmail.com')
				).andReturn()

		then:
		println("Status get --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Edit the data for particular user"() {
		given:
		Map request = [
			email : 'user3@gmail.com',
			password : 'password',
			firstName : 'firstName1',
			lastName : 'lastName1',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'

		]

		MvcResult response1 = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response1--> " + response1.getResponse().getStatus())

		Map editRequest = [
			password : 'passwordChange',
			firstName : 'firstNameChange',
			lastName : 'lastNameChange',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'

		]

		when:
		MvcResult response = mvc.perform(
				put('/EditUser/users/user3@gmail.com').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editRequest))
				).andReturn()
		println("Status response--> " + response.getResponse().getStatus())
		then:
		response.getResponse().getStatus() == 200
	}

	def "Edit the data for particular user - USER NOT EXISTS"() {
		given:
		Map request = [
			email : 'user3@gmail.com',
			password : 'password',
			firstName : 'firstName1',
			lastName : 'lastName1',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'
		]

		MvcResult response1 = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response1--> " + response1.getResponse().getStatus())

		Map editRequest = [
			password : 'passwordChange',
			firstName : 'firstNameChange',
			lastName : 'lastNameChange',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response = mvc.perform(
				put('/EditUser/users/user4@gmail.com').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editRequest))
				).andReturn()
		println("Status response--> " + response.getResponse().getStatus())
		then:
		response.getResponse().getStatus() == 200
	}

	def "Delete the data for particular user"() {
		given:
		Map request = [
			emaild : 'user4@gmail.com',
			password: 'password',
			firstName : 'firstName1',
			lastName : 'lastName1',
			dateOfBirth : '1998-06-06',
			mobileNumber : '1234567891',
			lastLoginTime : '2019-01-02 05:04:06',
			active : true,
			accountLocked : false,
			createdBy : 'createdBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedBy : 'modifiedBy',
			modifiedDate : '2019-01-02 05:04:06'
		]

		MvcResult response1 = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("User in given Status response1--> " + response1.getResponse().getStatus())
		println("User in given Status response1--> " + response1.getResponse().toString())

		when:
		MvcResult response = mvc.perform(
				delete('/DeleteUsers/users/user4@gmail.com')
				).andReturn()
		println("Status response in when--> " + response.getResponse().getStatus())
		then:
		response.getResponse().getStatus() == 200
	}

	def "Fetch Users For Given Role"() {
		given:
		MvcResult response1 = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestUser))
				).andReturn()
		println("User in given Status response1--> " + response1.getResponse().getStatus())
		println("User in given Status response1--> " + response1.getResponse().toString())

		when:
		MvcResult response = mvc.perform(
				get('/GetUsers/users/usersassigned/ADMIN')
				).andReturn()
		println("Status response in when--> " + response.getResponse().getStatus())
		then:
		response.getResponse().getStatus() == 200
	}

	def "Search User"() {
		given:
		MvcResult response1 = mvc.perform(
				post('/SaveUser/users').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestUser))
				).andReturn()
		println("User in given Status response1--> " + response1.getResponse().getStatus())
		println("User in given Status response1--> " + response1.getResponse().toString())

		when:
		MvcResult response = mvc.perform(
				get('/GetUsers/users/searchusers/user4@gmail.com')
				).andReturn()
		println("Status response in when--> " + response.getResponse().getStatus())
		then:
		response.getResponse().getStatus() == 200
	}
	
	def "Save Azure User"() {
		given:
		DBObject role = BasicDBObjectBuilder.start()
				.add("_id", "5cd123a7497f3e0008f39c93")
				.add("roleName", "RECON_ADM")
				.add("description", "Role for Administrator")
				.get();
		mongoTemplate.save(role, "Role");
		
		String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCIsImtpZCI6IkhCeGw5bUFlNmd4YXZDa2NvT1UyVEhzRE5hMCJ9.eyJhdWQiOiIzM2JlNDQxMi1jMjJhLTQwMmYtODY2Ni0xYjYwNjcwNGQyM2EiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83NzUzNjUyMC05ZjhkLTQ0NTMtOGViMS0xMjZhN2YyMWEyMTMvIiwiaWF0IjoxNTU5MjE4NzQ3LCJuYmYiOjE1NTkyMTg3NDcsImV4cCI6MTU1OTIyMjY0NywiYWlvIjoiNDJaZ1lKaDdRNmg4UitmKzBDQldIU09sRFlaOTVpZjY1anB0M0JsdExPUjFZWTNROGg0QSIsImFtciI6WyJwd2QiXSwiZmFtaWx5X25hbWUiOiJLaGFtYW5rYXIiLCJnaXZlbl9uYW1lIjoiS2FtbGVzaCIsImlwYWRkciI6IjE0LjE0MC40Mi42NyIsIm5hbWUiOiJLYW1sZXNoLktoYW1hbmthciIsIm5vbmNlIjoiYWZiMWE5NTUtYjI4MC00NTFiLTkwNjYtM2E4NDZhZTVhN2QxIiwib2lkIjoiMGIwNGYxN2ItM2QzYi00MjQ2LWJhMzMtNGM1ZGI5YzgzNGNkIiwicHdkX2V4cCI6IjE3MjQ1MCIsInB3ZF91cmwiOiJodHRwczovL3BvcnRhbC5taWNyb3NvZnRvbmxpbmUuY29tL0NoYW5nZVBhc3N3b3JkLmFzcHgiLCJyb2xlcyI6WyJSRUNPTl9BRE0iXSwic3ViIjoiV096d2V4UEtrSkdMSGV0UE1SWUNOeFVpbDV3OUN6RXN1Z0JrT3kwTUstOCIsInRpZCI6Ijc3NTM2NTIwLTlmOGQtNDQ1My04ZWIxLTEyNmE3ZjIxYTIxMyIsInVuaXF1ZV9uYW1lIjoiS2FtbGVzaC5LaGFtYW5rYXJAb3B1c2NvbnN1bHRpbmcuY29tIiwidXBuIjoiS2FtbGVzaC5LaGFtYW5rYXJAb3B1c2NvbnN1bHRpbmcuY29tIiwidXRpIjoiUC03SjdXc0pEazZ2enZ1Q3Z5VUdBUSIsInZlciI6IjEuMCJ9.QPVksS4UURtxUV7mGjtDMA8CR91fIzzVBiUL-SJPIZGB4atuUMYJtpTYB5FsTA7juI5voQDc6bBcJJnj1567uER0qRsn-CRRhW7OWOAleLnO4z11ogxYwxQYrzBdqealDxAZ39jd_ZO2vQbGXHO4H_Pn47bvndbtHQ2hL-5A8jhEmTWnfM8D1-mCQMXbvzIWqNPKjuZszWsV85g_qAXPHBcIceVnL4vTIJb6CxcRkwTAewDcl1tXS5mhTm9ClxwkRxA0QpMoUaZIzdr8gYUvXfLbdmfQJjiNCuBBVfxcL-PS2jqjmYUMLw3DMghRQ_RJ514YiWgh8mv3UaBl__Iigg";
		when:
		MvcResult response = mvc.perform(
			post('/SaveAzureUser/users/saveAzureUser').header("Authorization", token)
			).andReturn()
		println("Status response in when--> " + response.getResponse().getStatus())
		then:
		response.getResponse().getStatus() == 200
	}
	
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}