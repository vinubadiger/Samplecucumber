package com.opus.optimus.access.management;

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.access.management.services.impl.InstitutionImpl
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.config.user.Institution

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class InstitutionTest extends Specification {
	
	def "Save Institution - Exception"(){
		given:
		def institutionImpl = new InstitutionImpl()
		Institution inst = new Institution();
		institutionImpl.saveInstitution(inst) >> { throw new NullPointerException() }

		when:
		institutionImpl.saveInstitution(inst)
		
		then:
		thrown GenericException
	}

	def "Update Institution - Exception"(){
		given:
		def institutionImpl = new InstitutionImpl()
		Institution inst = new Institution();
		institutionImpl.updateInstitution(inst, "instId") >> { throw new NullPointerException() }

		when:
		institutionImpl.updateInstitution(inst, "instId")
		
		then:
		thrown GenericException
	}
	
	def "Delete Institution - Exception"(){
		given:
		def institutionImpl = new InstitutionImpl()
		institutionImpl.deleteInstitution("instId") >> { throw new NullPointerException() }

		when:
		institutionImpl.deleteInstitution("instId")
		
		then:
		thrown GenericException
	}
}