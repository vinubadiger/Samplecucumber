package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.NoSuchBeanDefinitionException
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.access.management.interceptor.LoginInterceptor
import com.opus.optimus.access.management.util.BeanUtilService
import com.opus.optimus.offline.config.exception.GenericException

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class BeanUtilSeviceTest extends Specification {

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def GetVersionNumberdd
	def "BeanUtilService-Thrown NoSuchBeanDefinitionException"() {
		given:
		def beanutilservice = new BeanUtilService()

		when:
		beanutilservice.getBeanObject(GetVersionNumberdd)

		then:
		thrown GenericException
	}

	def "specifying that exception should be thrown-NoSuchBeanDefinitionException"() {
		given:
		def beanutilservice = new BeanUtilService()
		beanutilservice.getBeanObject(GetVersionNumberdd) >> { throw new NoSuchBeanDefinitionException() }
	}
}