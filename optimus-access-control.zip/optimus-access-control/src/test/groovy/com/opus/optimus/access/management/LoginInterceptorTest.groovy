package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.test.context.TestPropertySource

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.access.management.interceptor.LoginInterceptor
import com.opus.optimus.ui.services.user.ApiConfig
import com.opus.optimus.ui.services.user.Role

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class LoginInterceptorTest extends Specification {

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def MockHttpServletRequest request = new MockHttpServletRequest("GET", "/");

	def MockHttpServletResponse response = new MockHttpServletResponse();

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	LoginInterceptor loginInterceptor1;

	def setup() {
		Role role = new Role();
		role.setRoleName("RECON_AYST")

		List<String> homeScreenIcons = new ArrayList<>();
		homeScreenIcons.add("reportsDashBoard");
		homeScreenIcons.add("operationCenter");
		homeScreenIcons.add("ReconDesign");

		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setConfigId("5c62a807c245be6f10558fb3");
		apiConfig.setActionName("GetCollections");
		apiConfig.setControllerName("Settings");
		apiConfig.setMethod("GET");
		apiConfig.setUrl("/recon/settings")
		apiConfig.setShortDesc("API to get the collections");
		apiConfig.setLongDescription("API to get the collections");
		apiConfig.setSelected(true);

		List<ApiConfig> restApiConfig = new ArrayList<>();
		restApiConfig.add(apiConfig);

		DBObject successProfile = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("role", role)
				.add("restApiConfig", restApiConfig)
				.add("homeScreenIcons", homeScreenIcons)
				.get();

		mongoTemplate.save(successProfile, "Profile");
	}

	def "LoginInterceptor prehandle"() {
		given:
		def LoginInterceptor interceptor = new LoginInterceptor()

		when:
		boolean value =interceptor.preHandle(request, response, null)

		then:
		value==false
	}

	def "LoginInterceptor isPermitted"() {
		when:
		boolean value = loginInterceptor1.isPermitted("GetCollections", "GET", "RECON_AYST")

		then:
		value==false
	}
}