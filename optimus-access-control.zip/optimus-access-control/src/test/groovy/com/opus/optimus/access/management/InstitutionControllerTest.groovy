package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Field
import org.springframework.http.MediaType
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.opus.optimus.access.management.interceptor.LoginInterceptor

import groovy.json.JsonOutput
import java.text.SimpleDateFormat
import spock.lang.Ignore
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class InstitutionControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}

	def "Create Institution" (){
		given:
		Map cutOver = [
			hour : 3,
			minute : 5,
			cutOverTime : new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-01-29T00:00:00.000Z")
		]
		Map request = [
			id : 'institutionID',
			institutionName : 'institutionName',
			displayName : 'displayName',
			adminEmail : 'adminEmail',
			mobileNo : 'mobileNo',
			address : 'address',
			businessProcessingDate : '2019-05-22 00:00:00',
			cutoverDetail : cutOver
		]

		when:
		MvcResult response = mvc.perform(post('/SaveEdit/institution').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Get Institution"() {
		when:
		def response = mvc.perform(
				get('/Get/institution')
				).andReturn().response

		then:
		response.status == 200
	}

	def "Get Institution By Institution ID"() {
		given:
		Map request = [
			id : 'institutionID1',
			institutionName : 'institutionName1',
			displayName : 'displayName1',
			adminEmail : 'adminEmail1',
			mobileNo : 'mobileNo1',
			address : 'address1'
		]

		MvcResult response = mvc.perform(post('/SaveEdit/institution').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(
				get('/Get/institution/institutionID1')
				).andReturn()

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Edit the data for particular institution"() {
		given:
		Map request = [
			id : 'institutionID2',
			institutionName : 'institutionName2',
			displayName : 'displayName2',
			adminEmail : 'adminEmail2',
			mobileNo : 'mobileNo2',
			address : 'address2'
		]
		Map editRequest = [
			id : 'institutionID2',
			institutionName : 'institutionNameedit',
			displayName : 'displayNameedit',
			adminEmail : 'adminEmailedit',
			mobileNo : 'mobileNo2',
			address : 'address2'
		]

		MvcResult response = mvc.perform(post('/SaveEdit/institution').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(put('/SaveEdit/institution/institutionID2').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editRequest))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Edit the data for particular institution not updated"() {
		given:
		Map request = [
			id : 'institutionID2',
			institutionName : 'institutionName2',
			displayName : 'displayName2',
			adminEmail : 'adminEmail2',
			mobileNo : 'mobileNo2',
			address : 'address2'
		]
		Map editRequest = [
			id : 'institutionID3',
			institutionName : 'institutionNameedit',
			displayName : 'displayNameedit',
			adminEmail : 'adminEmailedit',
			mobileNo : 'mobileNo2',
			address : 'address2'
		]

		MvcResult response = mvc.perform(post('/SaveEdit/institution').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(put('/SaveEdit/institution/institutionID4').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editRequest))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Delete the data for particular institution"() {
		given:
		Map request = [
			id : 'institutionID3',
			institutionName : 'institutionName3',
			displayName : 'displayName3',
			adminEmail : 'adminEmail3',
			mobileNo : 'mobileNo3',
			address : 'address3'
		]

		MvcResult response = mvc.perform(post('/SaveEdit/institution').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(delete('/Delete/institution/institutionID3')
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Not Deleted the data for particular institution beacuse not present institution id"() {
		given:
		Map request = [
			id : 'institutionID3',
			institutionName : 'institutionName3',
			displayName : 'displayName3',
			adminEmail : 'adminEmail3',
			mobileNo : 'mobileNo3',
			address : 'address3'
		]

		MvcResult response = mvc.perform(post('/SaveEdit/institution').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(delete('/Delete/institution/institutionID4')
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}
}