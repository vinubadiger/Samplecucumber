package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.access.management.interceptor.LoginInterceptor
import com.opus.optimus.ui.services.user.ApiConfig
import com.opus.optimus.ui.services.user.Profile
import com.opus.optimus.ui.services.user.Role

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ProfileControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@Autowired
	MongoTemplate mongoTemplate;

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		DBObject successApiConfig = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("actionName", "DeleteProject")
				.add("controllerName", "Projects")
				.add("method", "DELETE")
				.add("url", "/recon/projects")
				.add("shortDesc", "API to Delete the project")
				.add("longDescription", "API to Delete the Workspace")
				.add("selected", false)
				.get();

		mongoTemplate.save(successApiConfig, "ApiConfig");

		DBObject successApiConfig1 = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a3")
				.add("actionName", "DeleteProject")
				.add("controllerName", "Projects")
				.add("method", "DELETE")
				.add("url", "/recon/projects")
				.add("shortDesc", "API to Delete the project")
				.add("longDescription", "API to Delete the Workspace")
				.add("selected", false)
				.get();

		mongoTemplate.save(successApiConfig1, "ApiConfig");

		DBObject successApiConfig2 = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a4")
				.add("actionName", "DeleteProject")
				.add("controllerName", "Projects")
				.add("method", "GET")
				.add("url", "/recon/projects")
				.add("shortDesc", "API to Delete the project")
				.add("longDescription", "API to Delete the Workspace")
				.add("selected", false)
				.get();

		mongoTemplate.save(successApiConfig2, "ApiConfig");


		Role role = new Role();
		role.setRoleName("Admin")

		List<String> homeScreenIcons = new ArrayList<>();
		homeScreenIcons.add("reportsDashBoard");
		homeScreenIcons.add("operationCenter");
		homeScreenIcons.add("ReconDesign");

		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setConfigId("5c62a807c245be6f10558fb3");
		apiConfig.setActionName("DeleteProject");
		apiConfig.setControllerName("Settings");
		apiConfig.setMethod("GET");
		apiConfig.setUrl("/recon/settings")
		apiConfig.setShortDesc("API to get the collections");
		apiConfig.setLongDescription("API to get the collections");
		apiConfig.setSelected(true);

		ApiConfig apiConfig1 = new ApiConfig();
		apiConfig1.setConfigId("5c62a807c245be6f10558fb3");
		apiConfig1.setActionName("getDataSources");
		apiConfig1.setControllerName("Settings");
		apiConfig1.setMethod("GET");
		apiConfig1.setUrl("/recon/settings")
		apiConfig1.setShortDesc("API to get the data sources");
		apiConfig1.setLongDescription("API to get the data sources");
		apiConfig1.setSelected(true);

		List<ApiConfig> restApiConfig = new ArrayList<>();
		restApiConfig.add(apiConfig);
		restApiConfig.add(apiConfig1);

		DBObject successProfile = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("role", role)
				.add("restApiConfig", restApiConfig)
				.add("homeScreenIcons", homeScreenIcons)
				.get();

		mongoTemplate.save(successProfile, "Profile");
	}

	def "Registers the profile" (){
		given:
		Role role = new Role();
		role.setRoleId("roleId");
		role.setDescription("description");
		role.setRoleName("Admin");
		role.setCreatedBy("CreatedBy");
		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setActionName("actionName");
		apiConfig.setConfigId("ConfigId1");
		List<ApiConfig> list = new ArrayList<>();
		list.add(apiConfig);
		Profile profile = new Profile();
		profile.setProfileId("profileId");
		profile.setRole(role);
		profile.setRestApiConfig(list);
		when:
		MvcResult response = mvc.perform(
				post('/SaveEditPermission/profiles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(profile))
				).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}
	def "Get the data for all the profiles"() {
		when:
		MvcResult response = mvc.perform(
				get('/Get/profiles')
				).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}


	def "Edit the data for particular profile Get the data for a particular profile"() {
		given:
		Role role = new Role();
		role.setRoleId("roleId1");
		role.setDescription("description");
		role.setRoleName("Admin");
		role.setCreatedBy("CreatedBy");
		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setActionName("actionName");
		apiConfig.setConfigId("ConfigId2");
		List<ApiConfig> list = new ArrayList<>();
		list.add(apiConfig);
		Profile profile = new Profile();
		profile.setProfileId("profileId1");
		profile.setRole(role);
		profile.setRestApiConfig(list);
		MvcResult response = mvc.perform(
				post('/SaveEditPermission/profiles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(profile))
				).andReturn()
		println("Status --> " + response.getResponse().getStatus())
		when:

		MvcResult response1 = mvc.perform(
				get('/Get/profiles/profileId1')
				).andReturn()
		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Update profile"() {
		given:
		Role role = new Role();
		role.setRoleId("roleId1");
		role.setDescription("description");
		role.setRoleName("AdminRole");
		role.setCreatedBy("CreatedBy");
		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setActionName("actionName");
		apiConfig.setConfigId("ConfigId2");
		List<ApiConfig> list = new ArrayList<>();
		list.add(apiConfig);
		Profile profile = new Profile();
		profile.setProfileId("profileId1");
		profile.setRole(role);
		profile.setRestApiConfig(list);

		MvcResult response = mvc.perform(
				post('/SaveEditPermission/profiles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(profile))
				).andReturn()
		println("Status --> " + response.getResponse().getStatus())

		Role role1 = new Role();
		role1.setRoleId("roleId1");
		role1.setDescription("description");
		role1.setRoleName("AdminRole");
		role1.setCreatedBy("CreatedBy");
		ApiConfig apiConfig1 = new ApiConfig();
		apiConfig1.setActionName("actionName");
		apiConfig1.setConfigId("ConfigId2");
		List<ApiConfig> list1 = new ArrayList<>();
		list1.add(apiConfig1);
		Profile profile1 = new Profile();
		profile1.setProfileId("profileId1");
		profile1.setRole(role1);
		profile1.setRestApiConfig(list1);
		when:
		MvcResult response1 = mvc.perform(
				put('/SaveEditPermission/profiles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(profile1))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())
		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Delete profile"() {
		given:
		Role role = new Role();
		role.setRoleId("roleId2");
		role.setDescription("description");
		role.setRoleName("Admin");
		role.setCreatedBy("CreatedBy");
		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setActionName("actionName");
		apiConfig.setConfigId("ConfigId3");
		List<ApiConfig> list = new ArrayList<>();
		list.add(apiConfig);
		Profile profile = new Profile();
		profile.setProfileId("profileId3");
		profile.setRole(role);
		profile.setRestApiConfig(list);

		MvcResult response = mvc.perform(
				post('/SaveEditPermission/profiles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(profile))
				).andReturn()
		println("Status --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(
				delete('/Delete/profiles/profileId3')
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())
		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Delete - Profile Not Deleted"() {
		when:
		MvcResult response1 = mvc.perform(
				delete('/Delete/profiles/profileId4')
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())
		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Get the policy data(permission) for the role to be displayed on the Policy screen"() {
		when:
		def response = mvc.perform(
				get('/GetPolicyDetails/profiles/policy/Admin')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		println("Response Body --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}
}