package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.access.management.constent.AccessManagementConstent
import com.opus.optimus.access.management.interceptor.LoginInterceptor

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class ConstantTests extends Specification {

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def "Access Management Constants Tests"() {
		given:
		AccessManagementConstent service = Spy(AccessManagementConstent)
		expect:
		service.SYSTEM_USERNAME== "system" ||
				service.ID== "id" ||
				service.SAVE== "save" ||
				service.DELETE== "delete" ||
				service._ID== "_id"
	}
}