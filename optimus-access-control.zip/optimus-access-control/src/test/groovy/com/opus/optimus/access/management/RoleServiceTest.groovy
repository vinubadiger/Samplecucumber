package com.opus.optimus.access.management;

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.access.management.services.impl.RoleServiceImpl
import com.opus.optimus.ui.constants.ServiceResponse
import com.opus.optimus.ui.services.user.Role

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class RoleServiceTest extends Specification {

	def "Update Role - Exception"(){
		given:
		def roleService = new RoleServiceImpl()
		Role role = new Role()
		roleService.updateRole("roleName", role) >> { throw new NullPointerException() }

		when:
		ServiceResponse serviceResponse = roleService.updateRole("roleName", role)

		then:
		thrown NullPointerException
	}

	def "Delete Role - Exception"(){
		given:
		def roleService = new RoleServiceImpl()
		Role role = new Role()
		roleService.deleteRole("roleName") >> { throw new NullPointerException() }

		when:
		roleService.deleteRole("roleName")

		then:
		thrown NullPointerException
	}
}