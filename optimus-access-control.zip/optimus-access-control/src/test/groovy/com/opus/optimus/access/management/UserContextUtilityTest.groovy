package com.opus.optimus.access.management

import org.spockframework.spring.SpringBean
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContext
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.test.context.TestPropertySource
import com.nimbusds.jwt.JWTClaimsSet
import com.opus.optimus.access.management.util.UserContextUtility
import com.opus.optimus.offline.config.exception.GenericException

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class UserContextUtilityTest extends Specification {

	@SpringBean
	SecurityContextHolder securityContextHolder = Stub(SecurityContextHolder.class);
	
	def userContextUtility
	
	def setup() {
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		GrantedAuthority authority = new SimpleGrantedAuthority("RECON_ADM");
		grantedAuthorities.add(authority);
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("UserNameTest", "", grantedAuthorities));
		SecurityContextHolder.setContext(securityContext);
		
		userContextUtility = new UserContextUtility()
	}
	
	def "Get Logged Username"() {
		when:
		String response = userContextUtility.getLoggedUsername()
		println("Authentication Username --> " + response)
		then:
		response == "UserNameTest"
	}

	def "Check Admin User"() {
		when:
		boolean flag = userContextUtility.checkIfAdminUser()
		println("Flag --> " + flag)
		then:
		flag == false
	}
	
	def "Get Claims From Jwt"() {
		given:
		String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Imk2bEdrM0ZaenhSY1ViMkMzbkVRN3N5SEpsWSJ9.eyJhdWQiOiI2ZTc0MTcyYi1iZTU2LTQ4NDMtOWZmNC1lNjZhMzliYjEyZTMiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vNzJmOTg4YmYtODZmMS00MWFmLTkxYWItMmQ3Y2QwMTFkYjQ3L3YyLjAiLCJpYXQiOjE1MzcyMzEwNDgsIm5iZiI6MTUzNzIzMTA0OCwiZXhwIjoxNTM3MjM0OTQ4LCJhaW8iOiJBWFFBaS84SUFBQUF0QWFaTG8zQ2hNaWY2S09udHRSQjdlQnE0L0RjY1F6amNKR3hQWXkvQzNqRGFOR3hYZDZ3TklJVkdSZ2hOUm53SjFsT2NBbk5aY2p2a295ckZ4Q3R0djMzMTQwUmlvT0ZKNGJDQ0dWdW9DYWcxdU9UVDIyMjIyZ0h3TFBZUS91Zjc5UVgrMEtJaWpkcm1wNjlSY3R6bVE9PSIsImF6cCI6IjZlNzQxNzJiLWJlNTYtNDg0My05ZmY0LWU2NmEzOWJiMTJlMyIsImF6cGFjciI6IjAiLCJuYW1lIjoiQWJlIExpbmNvbG4iLCJvaWQiOiI2OTAyMjJiZS1mZjFhLTRkNTYtYWJkMS03ZTRmN2QzOGU0NzQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJhYmVsaUBtaWNyb3NvZnQuY29tIiwicmgiOiJJIiwic2NwIjoiYWNjZXNzX2FzX3VzZXIiLCJzdWIiOiJIS1pwZmFIeVdhZGVPb3VZbGl0anJJLUtmZlRtMjIyWDVyclYzeERxZktRIiwidGlkIjoiNzJmOTg4YmYtODZmMS00MWFmLTkxYWItMmQ3Y2QwMTFkYjQ3IiwidXRpIjoiZnFpQnFYTFBqMGVRYTgyUy1JWUZBQSIsInZlciI6IjIuMCJ9.pj4N-w_3Us9DrBLfpCt";
		when:
		JWTClaimsSet object = userContextUtility.getClaimsFromJwt(token)
		then:
		println("Data --> " + object.getClaims())
		Map<String,Object> map = object.getClaims()
		map.get("scp").equals("access_as_user") && map.get("sub").equals("HKZpfaHyWadeOouYlitjrI-KffTm222X5rrV3xDqfKQ")
	}
	
	def "Exception - Get Claims From Jwt"() {
		given:
		userContextUtility.getClaimsFromJwt(_ as String)  >> { throw new NullPointerException() }
		when:
		userContextUtility.getClaimsFromJwt(null)
		then:
		thrown GenericException
	}
}