package com.opus.optimus.access.management;

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.access.management.services.impl.ProfileServiceImpl
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.ui.services.user.ApiConfig
import com.opus.optimus.ui.services.user.Profile

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class ProfileServiceTest extends Specification {
	
	def "Save Profile - Exception"(){
		given:
		def profileService = new ProfileServiceImpl()
		Profile profile = new Profile()
		profileService.saveProfile(profile) >> { throw new NullPointerException() }

		when:
		profileService.saveProfile(profile)
		
		then:
		thrown GenericException
	}
	
	def "Update Profile - Exception"(){
		given:
		def profileService = new ProfileServiceImpl()
		Profile profile = new Profile()
		profileService.updateProfile(profile) >> { throw new NullPointerException() }

		when:
		profileService.updateProfile(profile)
		
		then:
		thrown GenericException
	}
	
	def "Delete Profile - Exception"(){
		given:
		def profileService = new ProfileServiceImpl()
		profileService.deleteProfile("profileId") >> { throw new NullPointerException() }

		when:
		profileService.deleteProfile("profileId")
		
		then:
		thrown GenericException
	}
	
	def "Get Policy - Exception"(){
		given:
		def profileService = new ProfileServiceImpl()
		profileService.getPolicy("roleName") >> { throw new NullPointerException() }

		when:
		profileService.getPolicy("roleName")
		
		then:
		thrown GenericException
	}
	
	def "Check Action Permission - Exception"(){
		given:
		def profileService = new ProfileServiceImpl()
		ApiConfig apiConfig = new ApiConfig();
		profileService.checkActionPermission(apiConfig, "roleName") >> { throw new NullPointerException() }

		when:
		profileService.checkActionPermission(apiConfig, "roleName")
		
		then:
		thrown GenericException
	}
}