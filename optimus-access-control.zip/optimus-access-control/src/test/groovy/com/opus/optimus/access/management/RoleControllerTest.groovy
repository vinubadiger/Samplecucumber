package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.access.management.interceptor.LoginInterceptor

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class RoleControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	@Autowired
	MongoTemplate mongoTemplate;

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}

	def "Create Role" (){
		given:
		Map request = [
			roleId : 'roleId1',
			roleName : 'roleName1',
			description : 'description',
			createdBy : 'createdBy',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Duplicate Role" (){
		given:
		Map request = [
			roleId : 'roleId1',
			roleName : 'roleName1',
			description : 'description',
			createdBy : 'createdBy',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		MvcResult response = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		then:
		println("Status --> " + response1.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}


	def "Get roles" (){
		when:
		MvcResult response = mvc.perform(get('/GetAllRoles/roles')
				).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}


	def "Get the data for a particular role" (){
		given:
		Map request = [
			roleId : 'roleId2',
			roleName : 'roleName2',
			description : 'description',
			createdBy : 'createdBy',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response1 = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())
		MvcResult response = mvc.perform(get('/GetAllRoles/roles/roleName2')
				).andReturn()

		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Edit the data for particular role"() {
		given:
		Map request = [
			roleId : 'roleId3',
			roleName : 'roleName3',
			description : 'description1',
			createdBy : 'createdBy1',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		Map editedRequest = [
			roleId : 'roleId3',
			roleName : 'roleName3',
			description : 'description2',
			createdBy : 'createdBy2',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response1 = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		MvcResult response = mvc.perform(put('/EditRole/roles/roleName3').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editedRequest))
				).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Edit the data for particular role - role not exist"() {
		given:
		Map request = [
			roleId : 'roleId3',
			roleName : 'roleName3',
			description : 'description1',
			createdBy : 'createdBy1',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		Map editedRequest = [
			roleId : 'roleId3',
			roleName : 'roleName4',
			description : 'description2',
			createdBy : 'createdBy2',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response1 = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		MvcResult response = mvc.perform(put('/EditRole/roles/roleName4').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editedRequest))
				).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Delete the data for particular role"() {
		given:
		Map request = [
			roleId : 'roleId4',
			roleName : 'roleName4',
			description : 'description4',
			createdBy : 'createdBy4',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response1 = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		MvcResult response = mvc.perform(delete('/DeleteRole/roles/roleName4')).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Delete the data for particular role - role not exit"() {
		given:
		Map request = [
			roleId : 'roleId4',
			roleName : 'roleName4',
			description : 'description4',
			createdBy : 'createdBy4',
			modifiedBy : 'modifiedBy',
			createdDate : '2019-01-02 05:04:06',
			modifiedDate : '2019-01-02 05:04:06'
		]

		when:
		MvcResult response1 = mvc.perform(post('/SaveRole/roles').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		MvcResult response = mvc.perform(delete('/DeleteRole/roles/roleName5')).andReturn()
		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}
}