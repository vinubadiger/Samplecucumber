package com.opus.optimus.access.management;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.MvcResult

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.access.management.interceptor.LoginInterceptor
import com.opus.optimus.access.management.services.impl.ApiConfigServiceImpl
import com.opus.optimus.ui.services.user.ApiConfig
import com.opus.optimus.ui.services.user.Role

import groovy.json.JsonOutput
import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class APIConfigControllerTest extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;

		Role role = new Role();
		role.setRoleName("Admin")

		List<String> homeScreenIcons = new ArrayList<>();
		homeScreenIcons.add("reportsDashBoard");
		homeScreenIcons.add("operationCenter");
		homeScreenIcons.add("ReconDesign");

		ApiConfig apiConfig = new ApiConfig();
		apiConfig.setConfigId("5c62a807c245be6f10558fb3");
		apiConfig.setActionName("GetCollections");
		apiConfig.setControllerName("Settings");
		apiConfig.setMethod("GET");
		apiConfig.setUrl("/recon/settings")
		apiConfig.setShortDesc("API to get the collections");
		apiConfig.setLongDescription("API to get the collections");
		apiConfig.setSelected(true);

		ApiConfig apiConfig1 = new ApiConfig();
		apiConfig1.setConfigId("5c62a807c245be6f10558fb3");
		apiConfig1.setActionName("getDataSources");
		apiConfig1.setControllerName("Settings");
		apiConfig1.setMethod("GET");
		apiConfig1.setUrl("/recon/settings")
		apiConfig1.setShortDesc("API to get the data sources");
		apiConfig1.setLongDescription("API to get the data sources");
		apiConfig1.setSelected(true);


		List<ApiConfig> restApiConfig = new ArrayList<>();
		restApiConfig.add(apiConfig);
		restApiConfig.add(apiConfig1);

		DBObject successProfile = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("role", role)
				.add("restApiConfig", restApiConfig)
				.add("homeScreenIcons", homeScreenIcons)
				.get();

		mongoTemplate.save(successProfile, "Profile");
	}

	def "Create - Registers the REST API" (){
		given:
		Map request = [
			configId : 'configId',
			actionName : 'actionName',
			controllerName : 'controllerName',
			method : 'method',
			url : 'url',
			shortDesc : 'shortDesc',
			created : '2019-01-02 05:04:06',
			modified : '2019-01-02 05:04:06',
			longDescription : 'longDescription',
			selected : true
		]

		when:
		MvcResult response = mvc.perform(
				post('/SaveEdit/apiconfigs').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()

		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Get the data for all the REST APIs"() {
		when:
		MvcResult response = mvc.perform(get('/GetAccessList/apiconfigs/configs')).andReturn()

		then:
		println("Status --> " + response.getResponse().getStatus())
		response.getResponse().getStatus() == 200
	}

	def "Get the data for a particular REST API"() {
		given:
		Map request = [
			configId : 'configId1',
			actionName : 'actionName1',
			controllerName : 'controllerName1',
			method : 'method',
			url : 'url',
			shortDesc : 'shortDesc',
			created : '2019-01-02 05:04:06',
			modified : '2019-01-02 05:04:06',
			longDescription : 'longDescription',
			selected : true
		]
		MvcResult response = mvc.perform(
				post('/SaveEdit/apiconfigs').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status response --> " + response.getResponse().getStatus())

		when:
		MvcResult response1 = mvc.perform(get('/PermissionList/apiconfigs/configId1')
				).andReturn()

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}
	
	def "Edit the data for particular REST API - Not Updated"() {
		given:
		Map editRequest = [
			actionName : 'actionNameChange',
			controllerName : 'controllerNameChange',
			method : 'method',
			url : 'url',
			shortDesc : 'shortDesc',
			created : '2019-01-02 05:04:06',
			modified : '2019-01-02 05:04:06',
			longDescription : 'longDescription',
			selected : true
		]
		when:
		MvcResult response1 = mvc.perform(
				put('/SaveEdit/apiconfigs/configId3').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editRequest))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Edit the data for particular REST API"() {
		given:
		Map request = [
			configId : 'configId3',
			actionName : 'actionName',
			controllerName : 'controllerName',
			method : 'method',
			url : 'url',
			shortDesc : 'shortDesc',
			created : '2019-01-02 05:04:06',
			modified : '2019-01-02 05:04:06',
			longDescription : 'longDescription',
			selected : true
		]
		MvcResult response = mvc.perform(
				post('/SaveEdit/apiconfigs').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response.getResponse().getStatus())

		Map editRequest = [
			actionName : 'actionNameChange',
			controllerName : 'controllerNameChange',
			method : 'method',
			url : 'url',
			shortDesc : 'shortDesc',
			created : '2019-01-02 05:04:06',
			modified : '2019-01-02 05:04:06',
			longDescription : 'longDescription',
			selected : true
		]
		when:
		MvcResult response1 = mvc.perform(
				put('/SaveEdit/apiconfigs/configId3').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(editRequest))
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Delete the data for particular REST API"() {
		given:
		Map request = [
			configId : 'configId4',
			actionName : 'actionName',
			controllerName : 'controllerName',
			method : 'method',
			url : 'url',
			shortDesc : 'shortDesc',
			created : '2019-01-02 05:04:06',
			modified : '2019-01-02 05:04:06',
			longDescription : 'longDescription',
			selected : true
		]
		MvcResult response = mvc.perform(
				post('/SaveEdit/apiconfigs').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("Status --> " + response.getResponse().getStatus())
		when:
		MvcResult response1 = mvc.perform(
				delete('/Delete/apiconfigs/configId4')
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}
	
	def "Delete the data for particular REST API - Not Deleted"() {
		when:
		MvcResult response1 = mvc.perform(
				delete('/Delete/apiconfigs/configId4')
				).andReturn()
		println("Status --> " + response1.getResponse().getStatus())

		then:
		println("Status --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}

	def "Get Api Configs using roles"() {
		given:
		List<String> requestList = new ArrayList<>();
		requestList.add("Admin");
		when:
		MvcResult response1 = mvc.perform(post('/SpecificRoleAllData/apiconfigs/configs').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestList))
				).andReturn()

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}
	
	def "Get Api Configs using roles - ApiConfigFound"() {
		given:
		DBObject apiConfigDB = BasicDBObjectBuilder.start()
		.add("_id", "5c62a807c245be6f10558fb3")
		.add("actionName", "getDataSources")
		.add("controllerName", "Settings")
		.add("method", "GET")
		.add("url", "/recon/settings")
		.add("shortDesc", "API to get the data sources")
		.add("longDescription", "API to get the data sources")
		.add("selected", true)
		.get();
		
		mongoTemplate.save(apiConfigDB, "ApiConfig");
		
		List<String> requestList = new ArrayList<>();
		requestList.add("Admin");
		when:
		MvcResult response1 = mvc.perform(post('/SpecificRoleAllData/apiconfigs/configs').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestList))
				).andReturn()

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}
	
	def "Get Home Screen Permissions using roles"() {
		given:
		List<String> requestList = new ArrayList<>();
		requestList.add("Admin");
		when:
		MvcResult response1 = mvc.perform(post('/SpecificRoleAllData/apiconfigs/configs/homescreenpermissions').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(requestList))
				).andReturn()

		then:
		println("Status response1 --> " + response1.getResponse().getStatus())
		response1.getResponse().getStatus() == 200
	}
}