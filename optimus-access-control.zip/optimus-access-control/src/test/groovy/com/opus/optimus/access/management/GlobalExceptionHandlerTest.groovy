package com.opus.optimus.access.management;

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class GlobalExceptionHandlerTest extends Specification {
	
	def "GlobalExceptionHandler Test - handleException"(){
		given:
		def globalExceptionHandler = new GlobalExceptionHandler()
		when:
		def response = globalExceptionHandler.handleException(new NullPointerException("Null Pointer Exception"))
		println("Response --> " + response)
		
		then:
		println("Response --> " + response.getStatusCodeValue())
		response.getStatusCodeValue() == 500
	}
}