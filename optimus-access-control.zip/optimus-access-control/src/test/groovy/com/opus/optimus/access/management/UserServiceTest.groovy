package com.opus.optimus.access.management;

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.access.management.services.impl.UserServiceImpl
import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.ui.constants.ServiceResponse
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class UserServiceTest extends Specification {
	
	def "Save User - Exception"(){
		given:
		def userService = new UserServiceImpl()
		User user = new User()
		userService.saveUser(user) >> { throw new NullPointerException() }

		when:
		userService.saveUser(user) 
		
		then:
		thrown GenericException
	}
	
	def "Update User - Exception"(){
		given:
		def userService = new UserServiceImpl()
		User user = new User()
		userService.updateUser("email", user) >> { throw new NullPointerException() }

		when:
		userService.updateUser("email", user)
		
		then:
		thrown NullPointerException
	}
	
	def "Delete User - Exception"(){
		given:
		def userService = new UserServiceImpl()
		userService.deleteUser("email") >> { throw new NullPointerException() }

		when:
		userService.deleteUser("email")
		
		then:
		thrown NullPointerException
	}
	
	def "Search User - Exception"(){
		given:
		def userService = new UserServiceImpl()
		userService.searchUser("email") >> { throw new NullPointerException() }

		when:
		userService.searchUser("email")
		
		then:
		thrown GenericException
	}
}