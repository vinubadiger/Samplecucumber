package com.opus.optimus.reporting.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.mongodb.Block;
import com.mongodb.client.FindIterable;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig;
import com.opus.optimus.reporting.repository.PublishedWorkflowRepository;
import com.opus.optimus.reporting.service.IDataExportService;
import com.opus.optimus.reporting.service.IReconWorkflowService;
import com.opus.optimus.reporting.service.IWorkflowService;
import com.opus.optimus.reporting.util.CSVUtils;
import com.opus.optimus.ui.services.util.CommonUtil;

@Service
public class DataExportServiceImpl implements IDataExportService {
	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(DataExportServiceImpl.class);

	/** The mongo template. */
	@Autowired
	MongoTemplate mongoTemplate;

	/** The published service repo. */
	@Autowired
	private PublishedWorkflowRepository publishedServiceRepo;

	/** The workflow service. */
	@Autowired
	private IWorkflowService workflowService;

	/** The ignorable headers. */
	private List<String> ignorableHeaders = Arrays.asList("_class", "reconControlFields", "_id");

	/** The recon wf service. */
	@Autowired
	private IReconWorkflowService reconWfService;

	@Override
	public void exportasCsv(String projectName, String activityName, String sourceName, String status, String subStatus, Date startDate, Date endDate, HttpServletResponse response) {
		try{
			logger.debug("Getting Activity Summary");
			PublishedService publishedService = publishedServiceRepo.get(projectName, activityName, "RECON");
			WorkflowConfig wkconfig = getWorkflowConfig(publishedService);
			Optional<IStepConfig> step = findMongoDBReaderStep(sourceName, wkconfig);
			MongoDBReaderConfig config;
			if (step.isPresent()){
				config = (MongoDBReaderConfig) step.get();
			} else{
				throw new GenericException("DataSource not found to generate the report");
			}
			String dataSourceName = config.getSourceDefinition().getDataSourceName();
			String collectionName = config.getSourceDefinition().getCollectionName();
			logger.debug("dataSourceName {}. collectionName {}.", dataSourceName, collectionName);
			response.setContentType("text/csv");
			response.setHeader("Content-Disposition", "attachment; file=Result.csv");

			// Criteria
			Document document = getDocument(activityName, status, subStatus, startDate, endDate);
			long count = mongoTemplate.getCollection(collectionName).countDocuments(document);
			logger.debug("Number of records found {}", count);
			if (count > CSVUtils.LIMIT_TO_WRITE){
				throw new GenericException("Requested data for download has more than 10,000 records. Please update your filter criteria");
			} else{
				FindIterable<Document> iterable = mongoTemplate.getCollection(collectionName).find(document);
				if (!iterable.iterator().hasNext()){
					throw new GenericException("No records found");
				}

				logger.debug("Generating Header for file...");
				List<String> fileHeaders = getHeadersForRecords(iterable.first(), "");
				logger.debug("Header to be printed on file - {}", fileHeaders);
				CSVUtils.writeLine(response.getOutputStream(), fileHeaders);

				List<Object> dataRecords = Arrays.asList(new Object[fileHeaders.size()]);
				iterable.forEach((Block<? super Document>) (Document doc) -> {
					try{
						setDataRecordsForFile(doc, dataRecords, fileHeaders, "");
						CSVUtils.writeLine(response.getOutputStream(), dataRecords);
						dataRecords.forEach(elm -> dataRecords.set(dataRecords.indexOf(elm), "-"));
					} catch (Exception e){
						throw new GenericException(e);
					}
				});
			}
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
		finally{
			try{
				response.getOutputStream().flush();
			} catch (IOException e){
				logger.error(e.getMessage(), e);
			}
		}

	}

	/**
	 * Gets the data records for file.
	 *
	 * @param document the document
	 * @param dataRecords the data records
	 * @param fileHeaders the file headers
	 * @param prefix the prefix
	 * @return the data records for file
	 */
	private void setDataRecordsForFile(Document document, List<Object> dataRecords, List<String> fileHeaders, String prefix) {
		try{
			document.keySet().forEach(headerKey -> {
				Object value = document.get(headerKey);
				String fileHeader = prefix == null || prefix.isEmpty() ? headerKey : new StringBuilder(prefix).append(".").append(headerKey).toString().toUpperCase();
				if (value instanceof Document && value.getClass().isAssignableFrom(Document.class)){
					setDataRecordsForFile((Document) value, dataRecords, fileHeaders, fileHeader);
				} else if (ignorableHeaders.contains(headerKey)){
					logger.debug("Value for {} property will not be printed", headerKey);
				} else{
					int insertIndex = fileHeaders.indexOf(fileHeader);
					if (insertIndex >= 0){
						dataRecords.set(insertIndex, value);
					}
				}
			});
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the headers for records.
	 *
	 * @param document the document
	 * @param prefix the prefix
	 * @return the headers for records
	 */
	private List<String> getHeadersForRecords(Document document, String prefix) {
		try{
			logger.debug("Received Document to print Header - {}", document);
			List<String> headerKeyList = new ArrayList<>();
			document.keySet().forEach(headerKey -> {
				Object value = document.get(headerKey);
				String fileHeader = prefix == null || prefix.isEmpty() ? headerKey : new StringBuilder(prefix).append(".").append(headerKey).toString().toUpperCase();
				if (value instanceof Document && value.getClass().isAssignableFrom(Document.class)){
					headerKeyList.addAll(getHeadersForRecords((Document) value, fileHeader));
				} else if (ignorableHeaders.contains(headerKey)){
					logger.debug("Header for {} property will not be printed", headerKey);
				} else{
					headerKeyList.add(fileHeader);
				}
			});
			return headerKeyList;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the document.
	 *
	 * @param activityName the activity name
	 * @param status the status
	 * @param subStatus the sub status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the document
	 */
	private Document getDocument(String activityName, String status, String subStatus, Date startDate, Date endDate) {
		try{
			List<Document> andConditions = new ArrayList<>();
			final String activityKey = new StringBuilder("reconControlFields").append(".").append(activityName).toString();
			andConditions.add(new Document(activityKey, new Document("$exists", Boolean.TRUE)));
			if (null != status && !status.isEmpty()){
				andConditions.add(new Document(activityKey + ".status", status));
			}
			if (null != subStatus && !subStatus.isEmpty()){
				andConditions.add(new Document(activityKey + ".subStatus", subStatus));
			}
			if (null != startDate){
				andConditions.add(new Document(activityKey + ".processingDate", new Document("$gte", startDate)));
			}
			if (null != endDate){
				Date endDate1 = CommonUtil.returnNextDay(endDate);
				andConditions.add(new Document(activityKey + ".processingDate", new Document("$lte", endDate1)));
			}
			logger.debug("and condition {}", andConditions);
			return new Document("$and", andConditions);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Find mongo DB reader step.
	 *
	 * @param sourceName the source name
	 * @param wkconfig the wkconfig
	 * @return the optional
	 */
	private Optional<IStepConfig> findMongoDBReaderStep(String sourceName, WorkflowConfig wkconfig) {
		try{
			return wkconfig.getStepConfigs().stream().filter(stepConfig -> stepConfig.getStepType().equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) && ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getSourceName().equals(sourceName)).findAny();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the workflow config.
	 *
	 * @param publishedService the published service
	 * @return the workflow config
	 */
	private WorkflowConfig getWorkflowConfig(PublishedService publishedService) {
		try{
			if (publishedService == null){
				throw new GenericException("Activity not found");
			} else if (publishedService.getWorkflowConfig() == null){
				throw new GenericException("Workflow configuration not found");
			}
			return publishedService.getWorkflowConfig();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
