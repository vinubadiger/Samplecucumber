package com.opus.optimus.reporting.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.reporting.repository.WorkflowRepository;
import com.opus.optimus.reporting.service.IWorkflowService;
import com.opus.optimus.ui.services.project.Workflow;

/**
 * The Class WorkflowServiceImpl.
 */
@Service
public class WorkflowServiceImpl implements IWorkflowService {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(WorkflowServiceImpl.class);

	/** The workflow repository. */
	@Autowired
	private WorkflowRepository workflowRepository;

	/**
	 * Get Workflow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	@Override
	public Workflow get(String projectName, String workflowName, String workflowType) {
		try{
			return this.workflowRepository.findWorkFlowByProjectName(projectName, workflowName, workflowType);
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
