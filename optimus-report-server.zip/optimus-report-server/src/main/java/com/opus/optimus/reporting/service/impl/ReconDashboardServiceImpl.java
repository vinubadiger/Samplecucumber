package com.opus.optimus.reporting.service.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;
import com.opus.optimus.reporting.repository.UserRepository;
import com.opus.optimus.reporting.service.IReconDashboardService;
import com.opus.optimus.reporting.util.CalenderUtil;
import com.opus.optimus.reporting.util.UserContextUtility;
import com.opus.optimus.ui.services.report.recon.SummaryResponse;
import com.opus.optimus.ui.services.report.recon.TranSummaryResponseDaily;
import com.opus.optimus.ui.services.report.recon.TranSummaryResponseMonthly;
import com.opus.optimus.ui.services.report.recon.TranSummaryResponseYearly;
import com.opus.optimus.ui.services.report.recon.UnitValue;
import com.opus.optimus.ui.services.user.User;

/**
 * The Class ReconDashboardServiceImpl.
 */
@Service
public class ReconDashboardServiceImpl implements IReconDashboardService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconDashboardServiceImpl.class);

	/** The Constant RECONCILED_STATUS. */
	private static final String RECONCILED_STATUS = "RECONCILED";
	
	/** The Constant STATUS. */
	private static final String STATUS = "status";
	
	/** The Constant PROJECT_FIELD. */
	private static final String PROJECT_FIELD = "projectName";
	
	/** The Constant TRANSACTION_DATE. */
	private static final String TRANSACTION_DATE = "transactionDate";
	
	/** The Constant RECON_TYPE_FIELD. */
	private static final String RECON_TYPE_FIELD = "reconType";
	
	/** The Constant VARIANCE_AMT. */
	private static final String VARIANCE_AMT = "totalVarianceAmount";
	
	/** The Constant AMOUNT_FIELD. */
	private static final String AMOUNT_FIELD = "sourceASummary.totalAmount";
	
	/** The Constant MONTH. */
	private static final String MONTH = "month";
	
	/** The Constant YEAR. */
	private static final String YEAR = "year";

	/** The Constant POSTING. */
	public static final String POSTING = "POSTING";
	
	/** The Constant FUNDING. */
	public static final String FUNDING = "FUNDING";

	/** The mongo template. */
	@Autowired
	private MongoTemplate mongoTemplate;
	
	/** The User repository. */
	@Autowired
	private UserRepository userRepository;
	
	/** The UserContextUtility repository. */
	@Autowired
	private UserContextUtility userContextUtility;

	/* (non-Javadoc)
	 * @see com.opus.optimus.reporting.service.IReconDashboardService#getDailySummary(java.lang.String, java.util.Date, java.util.Date)
	 */
	@Override
	public Map<String, SummaryResponse> getDailySummary(String projectName, Date startDate, Date endDate) {

		Map<String, SummaryResponse> projectSummary = new HashMap<>();

		TypedAggregation<ReconSummaryByTrnDate> aggregation = Aggregation.newAggregation(ReconSummaryByTrnDate.class, getMatchingCriteria(projectName, startDate, endDate), getGroupOperationforDaily());
		logger.debug("Performing aggregate in Summary collection in DB!!");
		AggregationResults<TranSummaryResponseDaily> output = mongoTemplate.aggregate(aggregation, TranSummaryResponseDaily.class);

		List<TranSummaryResponseDaily> results = new ArrayList<>(output.getMappedResults());
		return populatingDailySummaryResponse(results, projectSummary);

	}

	/**
	 * Gets the matching criteria.
	 *
	 * @param projectName the project name
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the matching criteria
	 */
	private MatchOperation getMatchingCriteria(String projectName, Date startDate, Date endDate) {
		logger.debug("Preparing match stage!!");
		Criteria matchCriteria = Criteria.where(STATUS).is(RECONCILED_STATUS);
		if (projectName != null){
			matchCriteria.and(PROJECT_FIELD).is(projectName);
		}else {
			User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
			if (!userContextUtility.checkIfAdminUser()){ //if non admin user
				matchCriteria.and(PROJECT_FIELD).in(user.getProjects());
			}
		}
		matchCriteria.andOperator(Criteria.where(TRANSACTION_DATE).lte(endDate), Criteria.where(TRANSACTION_DATE).gte(startDate));
		return Aggregation.match(matchCriteria);
	}

	/**
	 * Gets the group operationfor daily.
	 *
	 * @return the group operationfor daily
	 */
	private GroupOperation getGroupOperationforDaily() {
		logger.debug("Preparing group stage for DayWise Summary!!");
		return Aggregation.group(RECON_TYPE_FIELD, TRANSACTION_DATE, PROJECT_FIELD).sum(AMOUNT_FIELD).as(VARIANCE_AMT);
	}

	/**
	 * Populating daily summary response.
	 *
	 * @param results the results
	 * @param projectSummary the project summary
	 * @return the map
	 */
	private Map<String, SummaryResponse> populatingDailySummaryResponse(List<TranSummaryResponseDaily> results, Map<String, SummaryResponse> projectSummary) {
		logger.debug("populating variance amount & percentage!!");
		results.forEach(tsr -> {
			if (!projectSummary.containsKey(tsr.getProjectName())){
				SummaryResponse newSummaryObj = new SummaryResponse();
				newSummaryObj.setUnitType(SummaryResponse.DAYWISE);
				newSummaryObj.setUnitValue(new ArrayList<>());
				projectSummary.put(tsr.getProjectName(), newSummaryObj);
			}

			SummaryResponse summary = projectSummary.get(tsr.getProjectName());

			Optional<UnitValue> newUnitValueOption = summary.getUnitValue().stream().filter(uv -> uv.getDateOfTransaction().equals(tsr.getTransactionDate())).findAny();

			UnitValue unitValue;
			if (newUnitValueOption.isPresent()){
				unitValue = newUnitValueOption.get();
			} else{
				unitValue = new UnitValue();
				summary.getUnitValue().add(unitValue);
				unitValue.setDateOfTransaction(tsr.getTransactionDate());
				GregorianCalendar calendar = new GregorianCalendar();
				calendar.setTime(tsr.getTransactionDate());
				unitValue.setDay(calendar.get(Calendar.DAY_OF_MONTH));
				unitValue.setMonth(CalenderUtil.getMonth(calendar.get(Calendar.MONTH) + 1));
				unitValue.setYear(calendar.get(Calendar.YEAR));
			}
			if (tsr.getReconType().equals(POSTING)){
				unitValue.setPostingAmount(tsr.getTotalVarianceAmount());
			}
			if (tsr.getReconType().equals(FUNDING)){
				unitValue.setFundingAmount(tsr.getTotalVarianceAmount());
			}
		});

		projectSummary.values().stream().forEach(unitValues -> unitValues.getUnitValue().forEach(uv -> {
			uv.setVarianceAmount(uv.getPostingAmount() - uv.getFundingAmount());
			uv.setVariancePercentage(uv.getVarianceAmount() / uv.getPostingAmount() * 100);

		}));

		return projectSummary;

	}

	/* (non-Javadoc)
	 * @see com.opus.optimus.reporting.service.IReconDashboardService#getMonthlySummary(java.lang.String, java.util.Date, java.util.Date)
	 */
	@Override
	public Map<String, SummaryResponse> getMonthlySummary(String projectName, Date startDate, Date endDate) {

		Map<String, SummaryResponse> projectSummary = new HashMap<>();

		TypedAggregation<ReconSummaryByTrnDate> aggregation = Aggregation.newAggregation(ReconSummaryByTrnDate.class, getMatchingCriteria(projectName, startDate, endDate), getProjectionOperationForMonthly(), getGroupOperationForMonthly());
		logger.debug("Performing aggregate in Monthly Summary collection in DB!!");
		AggregationResults<TranSummaryResponseMonthly> output = mongoTemplate.aggregate(aggregation, TranSummaryResponseMonthly.class);

		List<TranSummaryResponseMonthly> results = new ArrayList<>(output.getMappedResults());
		return populatingSummaryResponseMonthly(results, projectSummary);
	}

	/**
	 * Gets the projection operation for monthly.
	 *
	 * @return the projection operation for monthly
	 */
	private ProjectionOperation getProjectionOperationForMonthly() {
		logger.debug("Preparing project stage for month wise Summary!!");
		return project(RECON_TYPE_FIELD, PROJECT_FIELD).and(AMOUNT_FIELD).as(VARIANCE_AMT).andExpression(TRANSACTION_DATE).extractYear().as(YEAR).andExpression(TRANSACTION_DATE).extractMonth().as(MONTH);
	}

	/**
	 * Gets the group operation for monthly.
	 *
	 * @return the group operation for monthly
	 */
	private GroupOperation getGroupOperationForMonthly() {
		logger.debug("Preparing group stage for month wise Summary!!");
		return Aggregation.group(MONTH, YEAR, RECON_TYPE_FIELD, PROJECT_FIELD).sum(VARIANCE_AMT).as(VARIANCE_AMT);
	}

	/**
	 * Populating summary response monthly.
	 *
	 * @param results the results
	 * @param projectSummary the project summary
	 * @return the map
	 */
	private Map<String, SummaryResponse> populatingSummaryResponseMonthly(List<TranSummaryResponseMonthly> results, Map<String, SummaryResponse> projectSummary) {
		logger.debug("Populating variance amount & percentage for Monthy summary!!");
		results.forEach(tsr -> {
			if (!projectSummary.containsKey(tsr.getProjectName())){
				SummaryResponse newSummaryObj = new SummaryResponse();
				newSummaryObj.setUnitType(SummaryResponse.MONTHWISE);
				newSummaryObj.setUnitValue(new ArrayList<>());
				projectSummary.put(tsr.getProjectName(), newSummaryObj);
			}

			SummaryResponse summary = projectSummary.get(tsr.getProjectName());
			Optional<UnitValue> newUnitValueOption = summary.getUnitValue().stream().filter(uv -> uv.getMonth().equals(CalenderUtil.getMonth(Integer.parseInt(tsr.getMonth()))) && uv.getYear() == Integer.parseInt(tsr.getYear())).findAny();

			UnitValue unitValue;
			if (newUnitValueOption.isPresent()){
				unitValue = newUnitValueOption.get();
			} else{
				unitValue = new UnitValue();
				summary.getUnitValue().add(unitValue);
				unitValue.setMonth(CalenderUtil.getMonth(Integer.parseInt(tsr.getMonth())));
				unitValue.setYear(Integer.parseInt(tsr.getYear()));
			}
			if (tsr.getReconType().equals(POSTING)){
				unitValue.setPostingAmount(tsr.getTotalVarianceAmount());
			}
			if (tsr.getReconType().equals(FUNDING)){
				unitValue.setFundingAmount(tsr.getTotalVarianceAmount());
			}
		});

		projectSummary.values().stream().forEach(unitValues -> unitValues.getUnitValue().forEach(uv -> {
			uv.setVarianceAmount(uv.getPostingAmount() - uv.getFundingAmount());
			uv.setVariancePercentage(uv.getVarianceAmount() / uv.getPostingAmount() * 100);

		}));

		return projectSummary;

	}

	/* (non-Javadoc)
	 * @see com.opus.optimus.reporting.service.IReconDashboardService#getYearlySummary(java.lang.String, java.util.Date, java.util.Date)
	 */
	@Override
	public Map<String, SummaryResponse> getYearlySummary(String projectName, Date startDate, Date endDate) {
		Map<String, SummaryResponse> projectSummary = new HashMap<>();

		TypedAggregation<ReconSummaryByTrnDate> aggregation = Aggregation.newAggregation(ReconSummaryByTrnDate.class, getMatchingCriteria(projectName, startDate, endDate), getProjectionOperationForYearly(), getGroupOperationForYearly());
		logger.debug("Performing aggregate in Monthly Summary collection in DB!!");
		AggregationResults<TranSummaryResponseYearly> output = mongoTemplate.aggregate(aggregation, TranSummaryResponseYearly.class);

		List<TranSummaryResponseYearly> results = new ArrayList<>(output.getMappedResults());
		return populatingSummaryResponseYearly(results, projectSummary);
	}

	/**
	 * Gets the projection operation for yearly.
	 *
	 * @return the projection operation for yearly
	 */
	private ProjectionOperation getProjectionOperationForYearly() {
		logger.debug("Preparing project stage for month wise Summary!!");
		return project(RECON_TYPE_FIELD, PROJECT_FIELD).and(AMOUNT_FIELD).as(VARIANCE_AMT).andExpression(TRANSACTION_DATE).extractYear().as(YEAR);
	}

	/**
	 * Gets the group operation for yearly.
	 *
	 * @return the group operation for yearly
	 */
	private GroupOperation getGroupOperationForYearly() {
		logger.debug("Preparing group stage for month wise Summary!!");
		return Aggregation.group(YEAR, RECON_TYPE_FIELD, PROJECT_FIELD).sum(VARIANCE_AMT).as(VARIANCE_AMT);
	}

	/**
	 * Populating summary response yearly.
	 *
	 * @param results the results
	 * @param projectSummary the project summary
	 * @return the map
	 */
	private Map<String, SummaryResponse> populatingSummaryResponseYearly(List<TranSummaryResponseYearly> results, Map<String, SummaryResponse> projectSummary) {
		logger.debug("Populating variance amount & percentage for Yearly summary!!");
		results.forEach(tsr -> {
			if (!projectSummary.containsKey(tsr.getProjectName())){
				SummaryResponse newSummaryObj = new SummaryResponse();
				newSummaryObj.setUnitType(SummaryResponse.YEARWISE);
				newSummaryObj.setUnitValue(new ArrayList<>());
				projectSummary.put(tsr.getProjectName(), newSummaryObj);
			}

			SummaryResponse summary = projectSummary.get(tsr.getProjectName());
			Optional<UnitValue> newUnitValueOption = summary.getUnitValue().stream().filter(uv -> uv.getYear() == Integer.parseInt(tsr.getYear())).findAny();

			UnitValue unitValue;
			if (newUnitValueOption.isPresent()){
				unitValue = newUnitValueOption.get();
			} else{
				unitValue = new UnitValue();
				summary.getUnitValue().add(unitValue);
				unitValue.setYear(Integer.parseInt(tsr.getYear()));
			}
			if (tsr.getReconType().equals(POSTING)){
				unitValue.setPostingAmount(tsr.getTotalVarianceAmount());
			}
			if (tsr.getReconType().equals(FUNDING)){
				unitValue.setFundingAmount(tsr.getTotalVarianceAmount());
			}
		});

		projectSummary.values().stream().forEach(unitValues -> unitValues.getUnitValue().forEach(uv -> {
			uv.setVarianceAmount(uv.getPostingAmount() - uv.getFundingAmount());
			uv.setVariancePercentage(uv.getVarianceAmount() / uv.getPostingAmount() * 100);

		}));

		return projectSummary;

	}

}
