package com.opus.optimus.reporting.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.config.casemanagement.CaseGetResponse;
import com.opus.optimus.offline.config.casemanagement.CasePriorityCountResponse;
import com.opus.optimus.reporting.service.ISalesForceDashboardService;
import com.opus.optimus.reporting.util.CalenderUtil;

/**
 * The Class SalesForceDashboardController is responsible to get list of case as per filter provided by UI.
 */
@RestController
@RequestMapping ("{actionName}/salesforceDashboard")
public class SalesForceDashboardController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(SalesForceDashboardController.class);
	
	@Autowired
	ISalesForceDashboardService salesForceDashboardService;

	/**
	 * Get all the cases associated for a single recon activity on a particular date
	 *
	 * @param projectName the project name
	 * @param activity the activity
	 * @param transactionDate the transaction date
	 * @return the case get response
	 */
	@GetMapping (value = { "/getCaseList/{projectName}/{activity}/{transactionDate}/{urlRecordsFrom}/{urlRecordsTo}", "/getCaseList/{projectName}/{activity}/{urlRecordsFrom}/{urlRecordsTo}" })
	public CaseGetResponse listofCases(@PathVariable String projectName, @PathVariable String activity, @PathVariable (value = "transactionDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date transactionDate, @PathVariable String urlRecordsFrom, @PathVariable String urlRecordsTo) {
		String transDate = null;
		if (null != transactionDate){
			transDate = CalenderUtil.formatDate(transactionDate);
		}
		return salesForceDashboardService.prepareCaseList(projectName, activity, transDate, urlRecordsFrom, urlRecordsTo);
	}

	/**
	 * Get open cases count by priority associated with every recon activity in a project.
	 *
	 * @param projectName the project name
	 * @param activity the activity
	 * @param userName the user name
	 * @return the case priority count response
	 */
	@GetMapping (value = "/caseCountOnpririoty/{projectName}/{activity}/{userName}")
	public CasePriorityCountResponse caseCountOnpririoty(@PathVariable String projectName, @PathVariable String activity, @PathVariable String userName) {
		return salesForceDashboardService.getCountfromSalesforce(projectName, activity, userName);
	}
}
