package com.opus.optimus.reporting.service;

import java.util.Date;

import javax.servlet.http.HttpServletResponse;

public interface IDataExportService {
	public void exportasCsv(String projectName, String activityName, String sourceName, String status, String subStatus, Date startDate, Date endDate, HttpServletResponse response);
}
