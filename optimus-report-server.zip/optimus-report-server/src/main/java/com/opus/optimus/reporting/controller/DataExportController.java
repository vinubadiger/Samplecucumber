package com.opus.optimus.reporting.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.reporting.service.IDataExportService;
import com.opus.optimus.reporting.service.IReconWorkflowService;
import com.opus.optimus.reporting.service.IWorkflowService;
import com.opus.optimus.ui.constants.ResponseStatus;
import com.opus.optimus.ui.constants.ServiceResponse;
import com.opus.optimus.ui.services.project.Workflow;
import com.opus.optimus.ui.services.recon.Activity;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class DataExportController.
 */
@RestController
@RequestMapping ("{actionName}/download")
public class DataExportController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(DataExportController.class);

	@Autowired
	private IDataExportService dataExportService;
	
	/** The workflow service. */
	@Autowired
	private IWorkflowService workflowService;

	/** The recon wf service. */
	@Autowired
	private IReconWorkflowService reconWfService;

	/**
	 * Download as csv.
	 *
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @param sourceName the source name
	 * @param status the status
	 * @param subStatus the sub status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param response the response
	 */
	@GetMapping (value = "/downloadAsCsv/{projectName}/{activityName}/{sourceName}")
	public void downloadAsCsv(@PathVariable ("projectName") String projectName, @PathVariable ("activityName") String activityName, @PathVariable ("sourceName") String sourceName, @RequestParam (value = "status", required = false) String status, @RequestParam (value = "subStatus", required = false) String subStatus, @RequestParam (value = "startDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date startDate, @RequestParam (value = "endDate", required = false) @DateTimeFormat (iso = ISO.DATE) Date endDate, HttpServletResponse response) {
		dataExportService.exportasCsv(projectName, activityName, sourceName, status, subStatus, startDate, endDate, response);
	}

	/**
	 * Gets the project workflows.
	 *
	 * @param projectName the project name
	 * @return the project workflows
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonGenerationException
	 */
	@ApiOperation (value = "export Workflow as json ", response = Workflow.class, tags = "Get Workflow list using project name")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@GetMapping (value = "/exportWorkflow/{projectname}/{workflowname}/{workflowType}")
	public ResponseEntity<InputStreamResource> exportWorkflow(@PathVariable ("projectname") String projectName, @PathVariable ("workflowname") String workflowName, @PathVariable ("workflowType") String workflowType) throws JsonGenerationException, JsonMappingException, IOException {
		logger.debug("Get all workflows of project -- {}", projectName);
		ObjectMapper mapper = new ObjectMapper();
		byte[] buffer = mapper.writeValueAsBytes(this.workflowService.get(projectName, workflowName, workflowType));
		return ResponseEntity.ok().contentLength(buffer.length).contentType(MediaType.APPLICATION_JSON).body(new InputStreamResource(new ByteArrayInputStream(buffer)));
	}

	/**
	 * Gets the.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the activity
	 * @throws JsonProcessingException
	 */
	@ApiOperation (value = "export Activity as json", response = Activity.class, tags = "Get Activity")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully retrieved list"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping (value = "/exportActivity/{projectName}/{workflowName}/{workflowType}")
	public ResponseEntity<InputStreamResource> exportActivity(@PathVariable ("projectName") String projectName, @PathVariable ("workflowName") String workflowName, @PathVariable ("workflowType") String workflowType) throws JsonProcessingException {
		logger.debug("Get Recon activity -- {}", workflowName);
		ObjectMapper mapper = new ObjectMapper();
		byte[] buffer = mapper.writeValueAsBytes(reconWfService.get(projectName, workflowName, workflowType));
		return ResponseEntity.ok().contentLength(buffer.length).contentType(MediaType.APPLICATION_JSON).body(new InputStreamResource(new ByteArrayInputStream(buffer)));
	}

	/**
	 * Save.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Import Workflow", response = Workflow.class, tags = "Import Workflow")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping (value = "/importWorkflow")
	public ServiceResponse importWorkflow(@RequestBody Workflow workflow) {
		logger.debug("Importing workflow -- {}", workflow);
		if (workflow.validate()){
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Valid Workflow", null);
		}
		return new ServiceResponse(500, ResponseStatus.FAILED, "Invalid Workflow", null);

	}

	/**
	 * Save.
	 *
	 * @param workflow the workflow
	 * @return the service response
	 */
	@ApiOperation (value = "Import Activity", response = Workflow.class, tags = "Import Activity")
	@ApiResponses (value = { @ApiResponse (code = 200, message = "Successfully Saved"), @ApiResponse (code = 401, message = "You are not authorized to view the resource"), @ApiResponse (code = 403, message = "Accessing the resource you were trying to reach is forbidden"), @ApiResponse (code = 404, message = "The resource you were trying to reach is not found")

	})
	@PostMapping (value = "/importActivity")
	public ServiceResponse importActivity(@RequestBody Activity activity) {
		logger.debug("importing activity -- {}", activity);
		if (activity.validate()){
			return new ServiceResponse(200, ResponseStatus.SUCCESS, "Valid Activity", null);
		}
		return new ServiceResponse(500, ResponseStatus.FAILED, "Invalid Workflow", null);

	}

}
