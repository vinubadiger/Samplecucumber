package com.opus.optimus.reporting.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;
import com.opus.optimus.reporting.service.IJobErrorDetailService;

/**
 * The Class JobErrorController is used to get job error details on the basis of job id.
 */
@RestController
@RequestMapping ("{actionName}/jobError")
public class JobErrorController {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(JobErrorController.class);

	/** The job error detail service. */
	@Autowired
	private IJobErrorDetailService jobErrorDetailService;

	/**
	 * Gets the error details.
	 *
	 * @param jobId the job id
	 * @param page the page
	 * @param size the size
	 * @return the error details
	 */
	@GetMapping (value = "/{jobId}/{page}/{size}")
	public Page<JobErrorDetails> getErrorDetails(@PathVariable ("jobId") String jobId, @PathVariable ("page") int page, @PathVariable ("size") int size) {
		logger.debug("Getting error details of job id  -- {}", jobId);
		return jobErrorDetailService.getErrorDetails(jobId, page, size);

	}

}
