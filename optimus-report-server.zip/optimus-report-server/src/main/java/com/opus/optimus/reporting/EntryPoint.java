package com.opus.optimus.reporting;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.reporting.service.MapperFactory;

/**
 * The Class EntryPoint that used to bootstrap and launch a application from a Java main.
 */
@SpringBootApplication
@ComponentScan ({ "com.opus.optimus.reporting" })
@EntityScan ("com.opus.optimus.reporting")
@EnableMongoRepositories ("com.opus.optimus.reporting")
public class EntryPoint {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(EntryPoint.class);

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		logger.debug("Service 'optimus-reporting' started");
		SpringApplication.run(EntryPoint.class, args);
	}

	@Bean
	@Primary
	public ObjectMapper optimusObjectMapper(MapperFactory mapperFactory) {
		return mapperFactory.getMapper();
	}
}
