package com.opus.optimus.reporting.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.opus.optimus.ui.services.report.recon.DailyActivitySummaryResponse;

public interface IReconDashboardL1Service {

	public Map<String, List<DailyActivitySummaryResponse>> getDailyActivitySummary(String projectname, Date startDate, Date endDate);

}
