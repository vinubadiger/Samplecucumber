package com.opus.optimus.reporting.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;
import com.opus.optimus.reporting.service.IReconDashboardL2Service;

/**
 * The Class ReconDashboardL2Controller is for Level2 Recon summary based on each activity and transaction date.
 */
@RestController
@RequestMapping ("{actionName}/reconDashboardL2")
public class ReconDashboardL2Controller {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconDashboardL2Controller.class);

	/** The dashboard service. */
	@Autowired
	private IReconDashboardL2Service dashboardService;

	/**
	 * Gets the summary day wise.
	 *
	 * @param transactionDate the transaction date
	 * @param activityName the activity name
	 * @return the summary day wise
	 */
	@GetMapping (value = { "/summary/{transactionDate}/{activityName}" })
	public List<ReconSummaryByTrnDate> getSummaryDayWise(@PathVariable ("transactionDate") @DateTimeFormat (iso = ISO.DATE) Date transactionDate, @PathVariable String activityName) {
		logger.debug("Getting Recon dashboard summary of activity -- {}", activityName);
		return dashboardService.getActivityDashboardSummary(transactionDate, activityName);

	}

}
