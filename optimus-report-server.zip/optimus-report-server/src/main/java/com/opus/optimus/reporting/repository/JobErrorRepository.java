package com.opus.optimus.reporting.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;

/**
 * The Interface JobErrorRepository.
 */
@Repository
public interface JobErrorRepository extends MongoRepository<JobErrorDetails, String>{
	
	/**
	 * Find details by job id.
	 *
	 * @param jobId the job id
	 * @param pageable the pagination object
	 * @return the page
	 */
	@Query ("{jobId:'?0'}")
	Page<JobErrorDetails> findDetailsByJobId(String jobId, Pageable pageable);

}
