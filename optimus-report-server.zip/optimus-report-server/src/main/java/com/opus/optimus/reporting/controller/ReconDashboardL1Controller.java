package com.opus.optimus.reporting.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.reporting.service.IReconDashboardL1Service;
import com.opus.optimus.ui.services.report.recon.DailyActivitySummaryResponse;

@RestController
@RequestMapping("{actionName}/reconDashboardL1")
public class ReconDashboardL1Controller {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconDashboardL1Controller.class);

	@Autowired
	IReconDashboardL1Service iReconDashboardL1Service;

	@GetMapping(value = { "/dayWise/{startDate}/{endDate}/{projectName}" })
	public Map<String, List<DailyActivitySummaryResponse>> getSummaryDayWise(
			@PathVariable("startDate") @DateTimeFormat(iso = ISO.DATE) Date startDate,
			@PathVariable("endDate") @DateTimeFormat(iso = ISO.DATE) Date endDate,
			@PathVariable(required = false) String projectName) {
		logger.debug("Getting Activity Summary details day wise !!");
		return iReconDashboardL1Service.getDailyActivitySummary(projectName, startDate, endDate);
	}

}
