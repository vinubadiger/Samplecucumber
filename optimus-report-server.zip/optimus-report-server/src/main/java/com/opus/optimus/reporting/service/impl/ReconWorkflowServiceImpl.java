package com.opus.optimus.reporting.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.reporting.repository.ActivityRepository;
import com.opus.optimus.reporting.service.IReconWorkflowService;
import com.opus.optimus.ui.services.recon.Activity;

/**
 * The Class ReconWorkflowServiceImpl.
 */
@Service
public class ReconWorkflowServiceImpl implements IReconWorkflowService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconWorkflowServiceImpl.class);

	/** The recon wf repo. */
	@Autowired
	private ActivityRepository activeRepository;

	@Override
	public Activity get(String projectName, String workflowName, String workflowType) {
		try{
			return activeRepository.findReconSource(projectName, workflowName, workflowType);
		} catch (GenericException ge){
			throw ge;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
