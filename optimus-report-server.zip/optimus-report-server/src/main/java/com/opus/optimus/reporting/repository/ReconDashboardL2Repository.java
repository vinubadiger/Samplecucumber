package com.opus.optimus.reporting.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;

/**
 * The Interface ReconDashboardL2Repository is for Level2 Recon summary based on each activity and transaction date.
 */
@Repository
public interface ReconDashboardL2Repository extends MongoRepository<ReconSummaryByTrnDate, String> {

	/**
	 * Find summary by trans date.
	 *
	 * @param transactionDate the transaction date
	 * @param activityName the activity name
	 * @return the list
	 */
	@Query (value = "{ $and:[{'transactionDate':?0}, { 'activityName' : ?1}] }")
	List<ReconSummaryByTrnDate> findSummaryByTransDate(Date transactionDate, String activityName,Sort sort);

}
