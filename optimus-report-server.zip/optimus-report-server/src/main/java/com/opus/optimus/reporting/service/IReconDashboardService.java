package com.opus.optimus.reporting.service;

import java.util.Date;
import java.util.Map;

import com.opus.optimus.ui.services.report.recon.SummaryResponse;

/**
 * The Interface IReconDashboardService.
 */
public interface IReconDashboardService {
	
	/**
	 * Gets the daily summary.
	 *
	 * @param projectname the projectname
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the daily summary
	 */
	public Map<String, SummaryResponse> getDailySummary(String projectname, Date startDate, Date endDate);

	/**
	 * Gets the monthly summary.
	 *
	 * @param projectName the project name
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the monthly summary
	 */
	public Map<String, SummaryResponse> getMonthlySummary(String projectName, Date startDate, Date endDate);

	/**
	 * Gets the yearly summary.
	 *
	 * @param projectName the project name
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the yearly summary
	 */
	public Map<String, SummaryResponse> getYearlySummary(String projectName, Date startDate, Date endDate);
}
