package com.opus.optimus.reporting.service.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;
import com.opus.optimus.reporting.constant.Constants;
import com.opus.optimus.reporting.repository.BatchDefinitionRepository;
import com.opus.optimus.reporting.repository.JobInfoDataRepository;
import com.opus.optimus.reporting.repository.JobTaskExecutorResultRepository;
import com.opus.optimus.reporting.repository.UserRepository;
import com.opus.optimus.reporting.service.ReportingService;
import com.opus.optimus.reporting.util.UserContextUtility;
import com.opus.optimus.ui.services.report.api.BatchExpectedCountStore;
import com.opus.optimus.ui.services.report.api.FailedFiles;
import com.opus.optimus.ui.services.report.api.FailedFilesWithSource;
import com.opus.optimus.ui.services.report.api.FailureAnalysisWithSourceAndFile;
import com.opus.optimus.ui.services.report.api.FailureInfo;
import com.opus.optimus.ui.services.report.api.FailureInfoSummary;
import com.opus.optimus.ui.services.report.api.FailureSummaryWithProject;
import com.opus.optimus.ui.services.report.api.FileProcessedTable;
import com.opus.optimus.ui.services.report.api.FileProcessedWithActualFile;
import com.opus.optimus.ui.services.report.api.FileStatistics;
import com.opus.optimus.ui.services.report.api.JobInfoData;
import com.opus.optimus.ui.services.report.api.JobInfoSummary;
import com.opus.optimus.ui.services.report.api.RootCauseAnalysisTable;
import com.opus.optimus.ui.services.report.api.WigdetResult;
import com.opus.optimus.ui.services.scheduler.BatchDefinition;
import com.opus.optimus.ui.services.scheduler.SchedulerPolicy;
import com.opus.optimus.ui.services.scheduler.TimeBased;
import com.opus.optimus.ui.services.user.User;
import com.opus.optimus.ui.services.util.CommonUtil;

/**
 * The Class JobInfoDataServiceImpl.
 * 
 * @author manjusha.dhamdhere
 */
@Service
public class ReportingServiceImpl implements ReportingService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReportingServiceImpl.class);

	/** The job info data repository. */
	@Autowired
	private JobInfoDataRepository jobInfoDataRepository;

	/** The jobtaskexecutorresultrepository. */
	@Autowired
	private JobTaskExecutorResultRepository jobtaskexecutorresultrepository;

	/** The batch definition repository. */
	@Autowired
	private BatchDefinitionRepository batchDefinitionRepository;

	/** The mongo template. */
	@Autowired
	private MongoTemplate mongoTemplate;

	/** The total records processed. */
	private Long totalRecordsProcessed = 0L;

	/** The User repository. */
	@Autowired
	private UserRepository userRepository;

	/** The UserContextUtility repository. */
	@Autowired
	private UserContextUtility userContextUtility;

	/**
	 * Builds the optional date range project criteria.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectname the projectname
	 * @param workflowType the workflow type
	 * @return the criteria
	 */
	private Criteria buildOptionalDateRangeProjectCriteria(Date startDate, Date endDate, String projectname, String workflowType) {
		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowCheckCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			if (projectname != null){
				dateRangeCriteria.andOperator(Criteria.where(Constants.PROJECTNAME).is(projectname), workflowCheckCriteria);
			} else{
				User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
				if (userContextUtility.checkIfAdminUser()){
					dateRangeCriteria.andOperator(workflowCheckCriteria);
				} else{
					dateRangeCriteria.andOperator(Criteria.where(Constants.PROJECTNAME).in(user.getProjects()), workflowCheckCriteria);
				}

			}
			return dateRangeCriteria;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Aggregate.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Override
	public List<WigdetResult> aggregate(Date startDate, Date endDate, String projectName, String workflowType) {
		try{
			Criteria dateRangeProjectOptionalCriteria = buildOptionalDateRangeProjectCriteria(startDate, endDate, projectName, workflowType);
			GroupOperation groupOpeartion = group(Constants.STATUS).count().as(Constants.COUNT);
			ProjectionOperation projection = project(Constants.COUNT).and(Constants.STATUS).previousOperation();
			SortOperation sortOperation = sort(Sort.Direction.DESC, Constants.COUNT);

			Aggregation agg = newAggregation(Aggregation.match(dateRangeProjectOptionalCriteria), groupOpeartion, projection, sortOperation);
			AggregationResults<WigdetResult> groupResults = mongoTemplate.aggregate(agg, JobInfo.class, WigdetResult.class);
			return groupResults.getMappedResults();

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Workflow statistics.
	 *
	 * @param status the status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<JobInfoSummary> workflowStatistics(String status, Date startDate, Date endDate, String workflowType, String projectName) {

		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workFlowCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria statusCriteria = Criteria.where(Constants.STATUS).is(status);

			GroupOperation aggregationGroup = Aggregation.group(Constants.WORKFLOWNAME, Constants.WORKFLOWTYPE).count().as(Constants.COUNT);

			MatchOperation matchOperation;
			if (projectName != null){
				Criteria projectCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workFlowCriteria, projectCriteria, statusCriteria));
			} else{
				User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
				if (userContextUtility.checkIfAdminUser()){
					matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workFlowCriteria, statusCriteria));
				} else{
					Criteria projectCriteria = Criteria.where(Constants.PROJECTNAME).in(user.getProjects());
					matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workFlowCriteria, projectCriteria, statusCriteria));
				}

			}
			TypedAggregation<JobInfo> aggregation = Aggregation.newAggregation(JobInfo.class, matchOperation, aggregationGroup);
			AggregationResults<JobInfoSummary> result = mongoTemplate.aggregate(aggregation, JobInfoSummary.class);
			List<JobInfoSummary> sortedCopy = new ArrayList<>(result.getMappedResults());
			Collections.sort(sortedCopy, Comparator.comparingInt(JobInfoSummary::getCount).reversed());
			return sortedCopy;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * @param startDate
	 * @param endDate1
	 * @param workflowType
	 * @param projectName
	 * @param workflowName
	 * @param sourceFile
	 * @return
	 */
	private FailureInfo failureStatisticsForTopBar(Date startDate, Date endDate1, String workflowType, String projectName, String workflowName, String sourceFile) {
		try{
			List<String> jobInfoList = getJobInfoIdList(startDate, endDate1, workflowType, projectName, workflowName, sourceFile);
			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoList);

			List<Long> recordCount = new ArrayList<>();
			jobResultList.stream().forEach(jobResult -> jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
				if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
					long countData = stepInstanceStats.getOutbound().getErrorCount();
					recordCount.add(countData);
				}
			})));

			List<Long> recordsProcessed = new ArrayList<>();
			jobResultList.stream().forEach(jbRslt -> jbRslt.getStepExecutorResults().stream().filter(stpExRslt -> Optional.ofNullable(stpExRslt.getStepType()).orElse("").equals(StepTypeConstants.FILE_READER_STEPTYPE) || Optional.ofNullable(stpExRslt.getStepType()).orElse("").equals(StepTypeConstants.MONGO_DBREADER_STEP_TYPE) || Optional.ofNullable(stpExRslt.getStepType()).orElse("").equals(StepTypeConstants.DBREADER_STEP_TYPE) || Optional.ofNullable(stpExRslt.getStepType()).orElse("").equals(StepTypeConstants.EXCEL_READER_STEPTYPE) && Optional.ofNullable(stpExRslt.getStatus()).orElse(OperationStatus.ABORTED).equals(OperationStatus.COMPLETED)).collect(Collectors.toList()).stream().forEach(stpExRslt -> stpExRslt.getInstanceStats().forEach(stepInstStat -> {
				recordsProcessed.add(stepInstStat.getOutbound().getDataCount());
				recordsProcessed.add(stepInstStat.getOutbound().getErrorCount());
			})));

			return new FailureInfo(recordCount.stream().reduce(0L, Long::sum), recordsProcessed.stream().reduce(0L, Long::sum));

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Failure statistics.
	 *
	 * @param startDate the start date
	 * @param endDate1 the end date 1
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the map
	 */
	@Override
	public Map<String, Long> failureStatistics(Date startDate, Date endDate1, String workflowType, String projectName, String workflowName, String sourceFile) {
		try{
			List<String> jobInfoList = getJobInfoIdList(startDate, endDate1, workflowType, projectName, workflowName, sourceFile);

			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoList);

			Map<String, Long> outputMap = new HashMap<>();

			jobResultList.stream().forEach(jobResult -> jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> {
				String step = changeStepName(stepExecutorResult.getStepType());
				stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
					if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
						long countData = stepInstanceStats.getOutbound().getErrorCount();
						outputMap.put(step, Optional.ofNullable(outputMap.get(step)).orElse(Long.valueOf(0)) + countData);
					}
				});
			}));

			return outputMap;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Gets the job info id list.
	 *
	 * @param startDate the start date
	 * @param endDate1 the end date 1
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the job info id list
	 */
	private List<String> getJobInfoIdList(Date startDate, Date endDate1, String workflowType, String projectName, String workflowName, String sourceFile) {
		try{
			List<String> response = new ArrayList<>();
			Date endDate = CommonUtil.returnNextDay(endDate1);
			List<String> result;
			User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
			if (projectName == null && workflowName == null){
				if (userContextUtility.checkIfAdminUser()){
					result = this.jobInfoDataRepository.findAllIdsByWorkflowType(workflowType, startDate, endDate);
				} else{
					result = this.jobInfoDataRepository.findAllIdsByWorkflowTypeUserProjects(workflowType, startDate, endDate, user.getProjects());
				}
			} else if (projectName != null && workflowName == null){
				result = this.jobInfoDataRepository.findAllIdsByWorkflowTypeProject(workflowType, startDate, endDate, projectName);
			} else if (projectName == null && sourceFile == null){
				if (userContextUtility.checkIfAdminUser()){
					result = this.jobInfoDataRepository.findAllIdsByWorkflowNameType(workflowType, startDate, endDate, workflowName);
				} else{
					result = this.jobInfoDataRepository.findAllIdsByWorkflowNameTypeUserProjects(workflowType, startDate, endDate, workflowName, user.getProjects());
				}
			} else if (projectName != null && sourceFile == null){
				result = this.jobInfoDataRepository.findAllIdsByProjectWorkflowNameType(workflowType, startDate, endDate, projectName, workflowName);
			} else{
				result = this.jobInfoDataRepository.findAllIdsByProjectWorkflowNameTypeFile(workflowType, startDate, endDate, projectName, workflowName, sourceFile);
			}
			result.stream().forEach(jsonString -> response.add(CommonUtil.getJsonFromString(jsonString).get("_id").asText()));
			return response;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failure analysis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the failure info summary
	 */
	@Override
	public FailureInfoSummary failureAnalysis(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			FailureInfoSummary failureSummary = new FailureInfoSummary();

			failureSummary.setRecords(failureStatisticsForTopBar(startDate, endDate, workflowType, projectName, null, null));

			// for Failure Record Count
			Map<String, Long> outputMap = this.failureStatistics(startDate, endDate, workflowType, projectName, null, null);
			Long totalRecordValues = 0L;
			for (Long val : outputMap.values()){
				totalRecordValues += val;
			}
			// set Failed Records
			failureSummary.setRecords(new FailureInfo(totalRecordValues, totalRecordsProcessed));
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Long failedFiles;
			Long allProcessedFiles;

			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria dateRangeCriteria1 = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria statusCriteria = Criteria.where(Constants.STATUS).is(JobStatus.COMPLETED_FAILED);
			GroupOperation groupByWorkflowName = Aggregation.group(Constants.WORKFLOWNAME).count().as("filesFailed");
			MatchOperation matchCriteriaTotalFiles;
			MatchOperation matchCriteriaFailedFiles;
			if (projectName == null){
				failedFiles = this.jobInfoDataRepository.countOfFailedFiles(workflowType, startDate, endDate1);
				allProcessedFiles = this.jobInfoDataRepository.countOfAllFiles(workflowType, startDate, endDate1);

				User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
				if (userContextUtility.checkIfAdminUser()){
					matchCriteriaFailedFiles = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, statusCriteria));
					matchCriteriaTotalFiles = Aggregation.match(dateRangeCriteria1.andOperator(workflowTypeCriteria));
				} else{
					Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).in(user.getProjects());
					matchCriteriaFailedFiles = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, statusCriteria, projectNameCriteria));
					matchCriteriaTotalFiles = Aggregation.match(dateRangeCriteria1.andOperator(workflowTypeCriteria, projectNameCriteria));
				}
			} else{

				Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
				failedFiles = this.jobInfoDataRepository.countOfFailedFilesWithProjectName(workflowType, startDate, endDate1, projectName);
				allProcessedFiles = this.jobInfoDataRepository.countOfAllFilesWithProjectName(workflowType, startDate, endDate1, projectName);

				matchCriteriaFailedFiles = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, statusCriteria, projectNameCriteria));
				matchCriteriaTotalFiles = Aggregation.match(dateRangeCriteria1.andOperator(workflowTypeCriteria, projectNameCriteria));
			}

			failureSummary.setFiles(new FailureInfo(failedFiles, allProcessedFiles));

			TypedAggregation<JobInfo> aggregationFailed = Aggregation.newAggregation(JobInfo.class, matchCriteriaFailedFiles, groupByWorkflowName);
			TypedAggregation<JobInfo> aggregationTotal = Aggregation.newAggregation(JobInfo.class, matchCriteriaTotalFiles, groupByWorkflowName);

			AggregationResults<FailureInfoSummary> resultFailedFiles = mongoTemplate.aggregate(aggregationFailed, JobInfo.class, FailureInfoSummary.class);
			AggregationResults<FailureInfoSummary> resultTotalFiles = mongoTemplate.aggregate(aggregationTotal, JobInfo.class, FailureInfoSummary.class);

			failureSummary.setSource(new FailureInfo((long) resultFailedFiles.getMappedResults().size(), (long) resultTotalFiles.getMappedResults().size()));

			return failureSummary;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failure analysis pie chart.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param workflowName the workflow name
	 * @param stepName the step name
	 * @return the map
	 */
	@Override
	public Map<String, Long> failurerAnalysisPieChart(Date startDate, Date endDate, String workflowType, String workflowName, String stepName) {
		try{
			List<String> jobInfoList = getJobInfoIdList(startDate, endDate, workflowType, workflowName, null, null);
			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoList);

			List<FailureSummaryWithProject> listSummary = new ArrayList<>();
			jobResultList.stream().forEach(jobResult -> {
				FailureSummaryWithProject failureSummaryObj = new FailureSummaryWithProject();
				if (jobResult.getWorkflowName() != null){
					failureSummaryObj.setProjectName(jobResult.getWorkflowName());
				}
				Map<String, Long> outputMap = new HashMap<>();
				jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
					String step = changeStepName(stepExecutorResult.getStepType());
					if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
						long countData = stepInstanceStats.getOutbound().getErrorCount();
						outputMap.put(step, Optional.ofNullable(outputMap.get(step)).orElse(Long.valueOf(0)) + countData);
					}
				}));

				failureSummaryObj.setOutputMap(outputMap);
				listSummary.add(failureSummaryObj);
			});
			return mapOfProjectNameAndFailedRecordsCount(listSummary, stepName);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * This return map of project name and count of failed records.
	 *
	 * @param listSummary the list summary
	 * @param stepName the step name
	 * @return the map
	 */
	private Map<String, Long> mapOfProjectNameAndFailedRecordsCount(List<FailureSummaryWithProject> listSummary, String stepName) {
		Map<String, Long> outputMapProject = new HashMap<>();
		listSummary.stream().forEach(summary -> {
			Long totalCount = 0L;
			if (stepName == null || stepName.isEmpty()){
				for (Long val : summary.getOutputMap().values()){
					totalCount += val;
				}
			} else{
				for (Map.Entry<String, Long> entry : summary.getOutputMap().entrySet()){
					switch (stepName) {
					case Constants.EXTRACTION:
						if (entry.getKey().equals(Constants.EXTRACTION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.VALIDATION:
						if (entry.getKey().equals(Constants.VALIDATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.TRANSFORMATION:
						if (entry.getKey().equals(Constants.TRANSFORMATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.LOADER:
						if (entry.getKey().equals(Constants.LOADER)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.GLOBLEERROR:
						if (entry.getKey().equals(Constants.GLOBLEERROR)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.SALESFORCECASECREATION:
						if (entry.getKey().equals(Constants.SALESFORCECASECREATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.RECONCILATION:
						if (entry.getKey().equals(Constants.RECONCILATION)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.RECONSOURCEREADER:
						if (entry.getKey().equals(Constants.RECONSOURCEREADER)){
							totalCount += entry.getValue();
						}
						break;
					case Constants.RECONSTATUSUPDATOR:
						if (entry.getKey().equals(Constants.RECONSTATUSUPDATOR)){
							totalCount += entry.getValue();
						}
						break;
					default:
						break;
					}
				}
			}
			outputMapProject.put(summary.getProjectName(), Optional.ofNullable(outputMapProject.get(summary.getProjectName())).orElse(Long.valueOf(0)) + totalCount);
		});

		return sortByValue(outputMapProject);
	}

	/**
	 * Sort by value.
	 *
	 * @param wordCounts the word counts
	 * @return the map
	 */
	private static Map<String, Long> sortByValue(final Map<String, Long> wordCounts) {
		try{
			return wordCounts.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failure analysis root cause analysis table.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@Override
	public List<RootCauseAnalysisTable> failureAnalysisRootCauseAnalysisTable(Date startDate, Date endDate, String workflowType, String projectName, String workflowName) {
		try{
			List<RootCauseAnalysisTable> rootCauseList = new ArrayList<>();
			List<RootCauseAnalysisTable> listSummary = new ArrayList<>();

			List<String> jobInfoIdList = getJobInfoIdList(startDate, endDate, workflowType, projectName, workflowName, null);
			List<JobTaskExecutorResult> jobResultList = this.jobtaskexecutorresultrepository.findByIds(jobInfoIdList);

			Iterable<JobInfo> jobInfoList = jobInfoDataRepository.findAllById(jobInfoIdList);
			jobInfoList.forEach(jobInfo -> {
				jobInfo.getId();
				if (jobInfo.getErrorReason() != null && jobInfo.getErrorReason().getErrorCode() != null && jobInfo.getSourceInfo() != null && jobInfo.getSourceInfo().getSource() != null && jobInfo.getStartedTime() != null){
					RootCauseAnalysisTable rootCauseAnalysis = rootCauseAnalysisData(jobInfo.getSourceInfo().getSource(), jobInfo.getStartedTime(), 0L, "File Level", getErrorReason(jobInfo.getErrorReason().getErrorCode()));
					rootCauseList.add(rootCauseAnalysis);
				}

			});

			jobResultList.stream().forEach(jobResult -> {
				RootCauseAnalysisTable rootCauseObj = new RootCauseAnalysisTable();
				long tmp = jobResult.getStartTime();
				Date d = new Date(tmp);
				rootCauseObj.setExecutionDate(d);
				if (jobResult.getSourceFile() != null) rootCauseObj.setFileName(jobResult.getSourceFile());
				Map<String, Long> outputMap = stepTypeErrorCountMap(jobResult);
				rootCauseObj.setOutputMap(outputMap);
				listSummary.add(rootCauseObj);

			});

			listSummary.stream().forEach(summaryObject -> {
				if (summaryObject.getFileName() != null){
					summaryObject.getOutputMap().forEach((errorStepType, errorCount) -> {
						if (errorCount != 0){
							RootCauseAnalysisTable rootCauseAnalysis = rootCauseAnalysisData(summaryObject.getFileName(), summaryObject.getExecutionDate(), errorCount, "Record Level", errorStepType.concat(" error"));
							rootCauseList.add(rootCauseAnalysis);
						}
					});
				}
			});

			Collections.sort(rootCauseList, Comparator.comparing(RootCauseAnalysisTable::getExecutionDate).reversed());
			return rootCauseList;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Root cause analysis data.
	 *
	 * @param fileName the file name
	 * @param executionDate the execution date
	 * @param recordsImpacted the records impacted
	 * @param errorType the error type
	 * @param description the description
	 * @return the root cause analysis table
	 */
	public RootCauseAnalysisTable rootCauseAnalysisData(String fileName, Date executionDate, long recordsImpacted, String errorType, String description) {
		try{
			RootCauseAnalysisTable rootCauseAnalysis = new RootCauseAnalysisTable();
			rootCauseAnalysis.setFileName(fileName);
			rootCauseAnalysis.setExecutionDate(executionDate);
			rootCauseAnalysis.setRecordsImpacted(recordsImpacted);
			rootCauseAnalysis.setErrorType(errorType);
			rootCauseAnalysis.setDescription(description);
			return rootCauseAnalysis;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Step type error count map.
	 *
	 * @param jobResult the job result
	 * @return the map
	 */
	public Map<String, Long> stepTypeErrorCountMap(JobTaskExecutorResult jobResult) {
		try{
			Map<String, Long> outputMap = new HashMap<>();
			jobResult.getStepExecutorResults().stream().forEach(stepExecutorResult -> {
				String step = changeStepName(stepExecutorResult.getStepType());
				stepExecutorResult.getInstanceStats().forEachValue(stepInstanceStats -> {
					if (stepInstanceStats.getOutbound().getErrorCount() != null && stepInstanceStats.getStatus() != null && stepInstanceStats.getStatus().equals(OperationStatus.COMPLETED)){
						long countData = stepInstanceStats.getOutbound().getErrorCount();
						outputMap.put(step, Optional.ofNullable(outputMap.get(step)).orElse(Long.valueOf(0)) + countData);
					}
				});
			});
			return outputMap;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Change step name for UI.
	 *
	 * @param stepName the step name
	 * @return the string
	 */
	public String changeStepName(String stepName) {
		switch (stepName) {
		case StepTypeConstants.FILE_READER_STEPTYPE:
		case StepTypeConstants.EXCEL_READER_STEPTYPE:
		case StepTypeConstants.DBREADER_STEP_TYPE:
			return Constants.EXTRACTION;
		case StepTypeConstants.MONGODB_WRITER_STEPTYPE:
			return Constants.LOADER;
		case StepTypeConstants.TRANSFORMER_STEPTYPE:
			return Constants.TRANSFORMATION;
		case StepTypeConstants.VALIDATOR_STEPTYPE:
			return Constants.VALIDATION;
		case StepTypeConstants.DEFAULT_GLOBAL_ERROR_HANDLER_STEP_TYPE:
			return Constants.GLOBLEERROR;
		case StepTypeConstants.SALESFORCE_CASE_CREATOR:
			return Constants.SALESFORCECASECREATION;
		case StepTypeConstants.RECON_CONFIG_STEP:
			return Constants.RECONCILATION;
		case StepTypeConstants.MONGO_DBREADER_STEP_TYPE:
			return Constants.RECONSOURCEREADER;
		case StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE:
			return Constants.RECONSTATUSUPDATOR;
		case StepTypeConstants.RECONCASECREATION_STEPTYPE:
			return Constants.SALESFORCECASECREATION;
		default:
			return "";
		}
	}

	/**
	 * Gets the error reason (user readable) using error code.
	 *
	 * @param errorCode the error code
	 * @return the error reason
	 */
	public String getErrorReason(String errorCode) {
		switch (errorCode) {
		case "RDR-GEN-005":
			return "File Not Found";
		case "RDR-GEN-006":
			return "Duplicate File";
		case "RDR-GEN-001":
			return "Reader General Exception";
		case "RDR-GEN-008":
			return "Empty File";
		case "RDR-GEN-009":
			return "File Access Denied";
		case "RDR-GEN-007":
			return "Exception while File stream release";
		case "RDR-DAT-001":
			return "File end";
		case "RDR-DAT-002":
			return "File field formate problem";
		case "RDR-DAT-003":
			return "Invalid field formate";
		case "RDR-DAT-004":
			return "Missing fields from record";
		case "SYS-GEN-001":
			return "System General Exception";
		case "DB-GEN-001":
			return "Database general exception";
		case "DS-INIT-001":
			return "Exception during DB initialization";
		case "DS-NOSUCH-001":
			return "No such data source found";
		default:
			return "";
		}
	}

	/**
	 * Source files group by workflow name.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<FailureAnalysisWithSourceAndFile> sourceFilesGroupByWorkflowName(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			Criteria dateRangeProjectOptionalCriteria = buildOptionalDateRangeProjectCriteria(startDate, endDate, projectName, workflowType);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).push("sourceInfo.source").as("sourceFiles");
			ProjectionOperation projection = project("sourceFiles").and(Constants.WORKFLOWNAME).previousOperation();

			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(dateRangeProjectOptionalCriteria), groupOperation, projection);
			AggregationResults<FailureAnalysisWithSourceAndFile> result = mongoTemplate.aggregate(agg, JobInfo.class, FailureAnalysisWithSourceAndFile.class);

			return result.getMappedResults();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failure analysis failed files.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	@Override
	public List<FailedFiles> failureAnalysisFailedFiles(Date startDate, Date endDate, String workflowType, String projectName, String workflowName) {
		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
			Criteria workflowNameCriteria = Criteria.where(Constants.WORKFLOWNAME).is(workflowName);
			GroupOperation groupOperation = Aggregation.group(Constants.ERRORCODE).count().as(Constants.COUNT);
			ProjectionOperation projection = project(Constants.COUNT).and(Constants.FAILEDREASON).previousOperation();
			MatchOperation matchCriteria;

			User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
			Criteria projectNameCriteriaIn = Criteria.where(Constants.PROJECTNAME).in(user.getProjects());

			if (projectName == null){
				if (userContextUtility.checkIfAdminUser()){
					matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria));
				} else{
					matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteriaIn));
				}
			} else if (workflowName == null){
				matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria));
			} else{
				matchCriteria = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria, workflowNameCriteria));
			}
			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, matchCriteria, groupOperation, projection);
			AggregationResults<FailedFiles> result = mongoTemplate.aggregate(agg, JobInfo.class, FailedFiles.class);

			result.getMappedResults().stream().forEach(resultData -> {
				if (resultData.getFailedReason() != null){
					resultData.setFailedReason(getErrorReason(resultData.getFailedReason()));
				}
			});
			return result.getMappedResults();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failure analysis failed files and projects.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param errorCode the error code
	 * @return the list
	 */
	@Override
	public List<FailedFilesWithSource> failureAnalysisFailedFilesAndProjects(Date startDate, Date endDate, String workflowType, String projectName, String errorCode) {
		try{
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			Criteria dateRangeCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria errorCodeExist = Criteria.where(Constants.ERRORCODE).exists(true);
			Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
			Criteria errorCodeCriteria = Criteria.where(Constants.ERRORCODE).is(errorCode);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).count().as(Constants.COUNT);
			ProjectionOperation projection = project(Constants.COUNT).and(Constants.WORKFLOWNAME).previousOperation();

			MatchOperation matchOperation;
			if (errorCode == null && projectName == null){
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, errorCodeExist));
			} else if (projectName != null && errorCode == null){
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria, errorCodeExist));
			} else if (projectName == null){
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, errorCodeCriteria));
			} else{
				matchOperation = Aggregation.match(dateRangeCriteria.andOperator(workflowTypeCriteria, projectNameCriteria, errorCodeCriteria));
			}

			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, matchOperation, groupOperation, projection);
			AggregationResults<FailedFilesWithSource> result = mongoTemplate.aggregate(agg, JobInfo.class, FailedFilesWithSource.class);

			List<FailedFilesWithSource> sortedCopy = new ArrayList<>(result.getMappedResults());
			Collections.sort(sortedCopy, Comparator.comparingInt(FailedFilesWithSource::getCount).reversed());
			return sortedCopy;

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the job info processed data day wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the job info processed data day wise
	 */
	@Override
	public List<FileProcessedWithActualFile> getJobInfoProcessedDataDayWise(Date startDate, Date endDate, String workflowType, String projectName) {
		try{
			Date todaysDate = CommonUtil.getFormattedDate(new Date(), null);
			Date endDate1 = CommonUtil.returnNextDay(endDate);
			List<BatchDefinition> batchDefinition = batchDefinitionRepository.getExpectedFilesCounts();
			logger.debug("Recieved Batch list : {}", CommonUtil.getJsonFromObject(batchDefinition));
			Map<BatchExpectedCountStore, Integer> batchInfo = new HashMap<>();
			batchDefinition.forEach(batch -> {
				logger.debug("Batch detail : {}", CommonUtil.getJsonFromObject(batch));
				batchInfo.put(getBatchKey(batch.getProjectName(), batch.getWorkflowName(), batch.getWorkflowType(), Optional.ofNullable(batch.getSchedulerPolicy()).orElse(null)), Integer.valueOf(batch.getNumberOfExpectedFiles() == 0 ? 1 : batch.getNumberOfExpectedFiles()));
			});
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria todaysDateCriteria = Criteria.where(Constants.STARTEDTIME).gte(todaysDate);
			Criteria dateCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria matchingCriteria;
			if (projectName != null){
				Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
				matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria).andOperator(projectNameCriteria);
			} else{
				User user = userRepository.findUserByEmail(userContextUtility.getLoggedUsername());
				if (userContextUtility.checkIfAdminUser()){
					matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria);
				} else{
					Criteria projectNameCriteria = Criteria.where(Constants.PROJECTNAME).in(user.getProjects());
					matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria).andOperator(projectNameCriteria);
				}
			}
			MatchOperation matchOperation = Aggregation.match(matchingCriteria);
			GroupOperation groupOperation = Aggregation.group(Constants.PROJECTNAME, Constants.WORKFLOWNAME, Constants.WORKFLOWTYPE, Constants.STARTEDTIME, Constants.STATUS, Constants.SOURCEFILE, Constants.ERRORCODE).count().as("count");

			TypedAggregation<JobInfo> aggregation = Aggregation.newAggregation(JobInfo.class, matchOperation, groupOperation);
			AggregationResults<JobInfoData> jobInfoAggregation = mongoTemplate.aggregate(aggregation, JobInfo.class, JobInfoData.class);
			List<JobInfoData> jobInfoList = jobInfoAggregation.getMappedResults();
			logger.debug("Recevied JobInfoList : {}", CommonUtil.getJsonFromObject(jobInfoList));
			return populateDashboardStatistics(jobInfoList, batchInfo);

		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Populate dashboard statistics.
	 *
	 * @param jobInfoList the job info list
	 * @param batchInfo the batch info
	 * @return the list
	 */
	private List<FileProcessedWithActualFile> populateDashboardStatistics(List<JobInfoData> jobInfoList, Map<BatchExpectedCountStore, Integer> batchInfo) {
		try{
			List<FileProcessedWithActualFile> result = new ArrayList<>();
			jobInfoList.stream().forEach(jobInfo -> {
				logger.debug("Fetching JobInfo : {}", CommonUtil.getJsonFromObject(jobInfo));
				BatchExpectedCountStore batchKey = getBatchKey(jobInfo.getProjectName(), jobInfo.getWorkflowName(), jobInfo.getWorkflowType(), null);
				if (batchKey == null){
					return;
				}
				Integer batchRecord = Optional.ofNullable(batchInfo.get(batchKey)).orElse(Integer.valueOf(0));
				logger.debug("Corresponding Batch record found is : {}", CommonUtil.getJsonFromObject(batchRecord));

				List<Object> batchInfoKeyAsList = Arrays.asList(batchInfo.keySet().toArray());
				BatchExpectedCountStore batchKeyData = batchInfoKeyAsList.contains(batchKey) ? (BatchExpectedCountStore) batchInfoKeyAsList.get(batchInfoKeyAsList.indexOf(batchKey)) : null;
				logger.debug("Batch Defination key : {}", CommonUtil.getJsonFromObject(batchKeyData));

				FileProcessedWithActualFile fileProcessedWithActualFile = FileProcessedWithActualFile.builder().projectName(jobInfo.getProjectName()).workflowName(jobInfo.getWorkflowName()).workflowType(jobInfo.getWorkflowType()).activeFrom((batchKeyData != null) ? batchKeyData.getActiveFrom() : "").build();
				if (result.contains(fileProcessedWithActualFile)){
					fileProcessedWithActualFile = result.get(result.indexOf(fileProcessedWithActualFile));
				} else{
					result.add(fileProcessedWithActualFile);
					fileProcessedWithActualFile.setStatistics(new HashMap<String, FileStatistics>());
				}
				String startedDate = CommonUtil.getTimeZoneDateFormat().format(jobInfo.getStartedTime());
				if (!fileProcessedWithActualFile.getStatistics().containsKey(startedDate)){
					FileStatistics newFileStat = new FileStatistics();
					newFileStat.setStatus(true);
					fileProcessedWithActualFile.getStatistics().put(startedDate, newFileStat);
				}
				FileStatistics fileStatistics = fileProcessedWithActualFile.getStatistics().get(startedDate);
				fileStatistics.setFilesExpected(batchRecord.intValue());
				fileStatistics.setTotalFiles(fileStatistics.getTotalFiles() + jobInfo.getCount());
				if (null == fileStatistics.getProcessedFiles() || fileStatistics.getProcessedFiles().isEmpty()){
					fileStatistics.setProcessedFiles(new ArrayList<FileProcessedTable>());
				}
				FileProcessedTable fileProcessedTable = new FileProcessedTable();
				fileProcessedTable.setFileName(jobInfo.getSource());
				fileProcessedTable.setJobStatus(jobInfo.getStatus());
				fileProcessedTable.setStartedTime(jobInfo.getStartedTime());
				if (!jobInfo.getStatus().equals(JobStatus.COMPLETED_SUCCESS) && jobInfo.getErrorCode() != null){
					fileProcessedTable.setErrorMessage(getErrorReason(jobInfo.getErrorCode()));
				}

				if (jobInfo.getStatus().equals(JobStatus.COMPLETED_SUCCESS)){
					fileStatistics.setFilesProcessed(fileStatistics.getFilesProcessed() + 1);
					fileStatistics.setStatus(getFileStatus(fileStatistics, Boolean.TRUE));
				} else{
					fileStatistics.setStatus(getFileStatus(fileStatistics, Boolean.FALSE));
				}
				fileStatistics.getProcessedFiles().add(fileProcessedTable);
				Collections.sort(fileStatistics.getProcessedFiles(), Comparator.comparing(FileProcessedTable::getStartedTime).reversed());
			});
			logger.debug("Dashboard results : {}", CommonUtil.getJsonFromObject(result));
			return result;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}

	}

	/**
	 * Gets the file status.
	 *
	 * @param fileStatistics the file statistics
	 * @param status the status
	 * @return the file status
	 */
	private boolean getFileStatus(FileStatistics fileStatistics, Boolean status) {
		try{
			return (fileStatistics.isStatus() && fileStatistics.getFilesProcessed() >= fileStatistics.getFilesExpected()) || status;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Gets the batch key.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @param schedulerPolicy the scheduler policy
	 * @return the batch key
	 */
	private BatchExpectedCountStore getBatchKey(String projectName, String workflowName, String workflowType, SchedulerPolicy schedulerPolicy) {
		try{
			BatchExpectedCountStore countStore = BatchExpectedCountStore.builder().projectName(projectName).workflowName(workflowName).workFlowType(workflowType).build();
			if (!(schedulerPolicy instanceof TimeBased)){
				return countStore;
			}
			TimeBased timeBasedPolicy = (TimeBased) schedulerPolicy;
			Date activeFrom = Optional.ofNullable(timeBasedPolicy.getActiveFrom()).orElse(new Date());
			String activeFromString = new SimpleDateFormat("HH:mm").format(activeFrom);
			countStore.setActiveFrom(activeFromString);
			return countStore;
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Failed source.
	 *
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	@Override
	public List<JobInfo> failedSource(String workflowType, String projectName) {
		try{
			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria failedSourceCriteria = Criteria.where(Constants.STATUS).is(JobStatus.COMPLETED_FAILED);
			Criteria projectCriteria = Criteria.where(Constants.PROJECTNAME).is(projectName);
			Criteria matchingCriteria = workflowTypeCriteria.andOperator(projectCriteria, failedSourceCriteria);
			GroupOperation groupOperation = Aggregation.group(Constants.WORKFLOWNAME).count().as("Count");
			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(matchingCriteria), groupOperation);
			AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class);
			return result.getMappedResults();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * Project within date range.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @return the list
	 */
	@Override
	public List<JobInfo> projectWithinDateRange(Date startDate, Date endDate, String workflowType) {
		try{
			Date todaysDate = CommonUtil.getFormattedDate(new Date(), null);
			Date endDate1 = CommonUtil.returnNextDay(endDate);

			Criteria workflowTypeCriteria = Criteria.where(Constants.WORKFLOWTYPE).is(workflowType);
			Criteria todaysDateCriteria = Criteria.where(Constants.STARTEDTIME).gte(todaysDate);
			Criteria dateCriteria = Criteria.where(Constants.STARTEDTIME).gte(startDate).lte(endDate1);
			Criteria matchingCriteria = workflowTypeCriteria.orOperator(dateCriteria, todaysDateCriteria);
			GroupOperation groupOperation = Aggregation.group(Constants.PROJECTNAME).count().as("Count");
			TypedAggregation<JobInfo> agg = Aggregation.newAggregation(JobInfo.class, Aggregation.match(matchingCriteria), groupOperation);
			AggregationResults<JobInfo> result = mongoTemplate.aggregate(agg, JobInfo.class);
			return result.getMappedResults();
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

}
