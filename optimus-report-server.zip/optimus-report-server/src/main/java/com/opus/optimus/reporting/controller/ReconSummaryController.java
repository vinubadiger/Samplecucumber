package com.opus.optimus.reporting.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.reporting.service.IReconSummaryService;

import io.swagger.annotations.Api;

/**
 * The Class ReconSummaryController exposes api related to Reconciliation.
 */
@RestController
@Api (value = "/reconSummary")
@RequestMapping ("{actionName}/reconSummary")
public class ReconSummaryController {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(ReconSummaryController.class);

	/** The recon summary service. */
	@Autowired
	private IReconSummaryService iReconSummaryService;

	/**
	 * Access reconciliation summary.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the list
	 */
	@GetMapping (path = { "/accessReconcillationSummary/{startDate}/{endDate}", "/accessReconcillationSummary/{startDate}/{endDate}/{projectName}" })
	public List<ReconAcitivitySummary> accessReconcillationSummary(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable (required = false) String projectName) {
		return iReconSummaryService.findReconActivitySummary(projectName, startDate, endDate);
	}

	/**
	 * Gets the reconciliation summaries.
	 *
	 * @return the reconciliation summaries
	 */
	@GetMapping (value = "/getReconcillationSummaries")
	public List<ReconAcitivitySummary> getReconcillationSummaries() {
		return iReconSummaryService.findAll();
	}

}
