package com.opus.optimus.reporting.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.ui.services.report.api.FailedFiles;
import com.opus.optimus.ui.services.report.api.FailedFilesWithSource;
import com.opus.optimus.ui.services.report.api.FailureAnalysisWithSourceAndFile;
import com.opus.optimus.ui.services.report.api.FailureInfoSummary;
import com.opus.optimus.ui.services.report.api.FileProcessedWithActualFile;
import com.opus.optimus.ui.services.report.api.JobInfoSummary;
import com.opus.optimus.ui.services.report.api.RootCauseAnalysisTable;
import com.opus.optimus.ui.services.report.api.WigdetResult;

/**
 * The Interface JobInfoDataService.
 *
 * @author manjusha.dhamdhere
 */

@Service
public interface ReportingService {

	/**
	 * Aggregate.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectname the projectname
	 * @param workflowType the workflow type
	 * @return the list
	 */
	List<WigdetResult> aggregate(Date startDate, Date endDate, String projectname, String workflowType);

	/**
	 * Workflow statistics.
	 *
	 * @param status the status
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<JobInfoSummary> workflowStatistics(String status, Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failure statistics.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param sourceFile the source file
	 * @return the map
	 */
	Map<String, Long> failureStatistics(Date startDate, Date endDate, String workflowType, String projectName, String workflowName, String sourceFile);

	/**
	 * Failure analysis.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the failure info summary
	 */
	FailureInfoSummary failureAnalysis(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failurer analysis pie chart.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param stepName the step name
	 * @return the map
	 */
	Map<String, Long> failurerAnalysisPieChart(Date startDate, Date endDate, String workflowType, String projectName, String stepName);

	/**
	 * Failure analysis root cause analysis table.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	List<RootCauseAnalysisTable> failureAnalysisRootCauseAnalysisTable(Date startDate, Date endDate, String workflowType, String projectName, String workflowName);

	/**
	 * Source files group by workflow name.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<FailureAnalysisWithSourceAndFile> sourceFilesGroupByWorkflowName(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failure analysis failed files.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @return the list
	 */
	List<FailedFiles> failureAnalysisFailedFiles(Date startDate, Date endDate, String workflowType, String projectName, String workflowName);

	/**
	 * Failure analysis failed files and projects.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @param errorCode the error code
	 * @return the list
	 */
	List<FailedFilesWithSource> failureAnalysisFailedFilesAndProjects(Date startDate, Date endDate, String workflowType, String projectName, String errorCode);

	/**
	 * Gets the job info processed data day wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the job info processed data day wise
	 */
	List<FileProcessedWithActualFile> getJobInfoProcessedDataDayWise(Date startDate, Date endDate, String workflowType, String projectName);

	/**
	 * Failed source.
	 *
	 * @param workflowType the workflow type
	 * @param projectName the project name
	 * @return the list
	 */
	List<JobInfo> failedSource(String workflowType, String projectName);

	/**
	 * Project within date range.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param workflowType the workflow type
	 * @return the list
	 */
	List<JobInfo> projectWithinDateRange(Date startDate, Date endDate, String workflowType);
}