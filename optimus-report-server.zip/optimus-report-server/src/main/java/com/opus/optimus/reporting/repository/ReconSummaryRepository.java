package com.opus.optimus.reporting.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;

/**
 * The Interface ReconSummaryRepository.
 */
@Repository
public interface ReconSummaryRepository extends MongoRepository<ReconAcitivitySummary, String> {

	/**
	 * Find by processing date between.
	 *
	 * @param from the from
	 * @param to the to
	 * @param projectName the project name
	 * @return the list
	 */
	@Query (value = "{ $and: [ {'processingDate':{ $lte: ?1, $gte: ?0}}, { 'projectName' : ?2}] }")
	List<ReconAcitivitySummary> findByProcessingDateBetween(Date from, Date to, String projectName, Sort sort);

	/**
	 * Find by processing date between.
	 *
	 * @param from the from
	 * @param to the to
	 * @return the list
	 */
	@Query (value = "{'processingDate':{ $lte: ?1, $gte: ?0}}")
	List<ReconAcitivitySummary> findByProcessingDateBetween(Date from, Date to, Sort sort);

}
