package com.opus.optimus.reporting.service;

import com.opus.optimus.ui.services.project.Workflow;

/**
 * The Interface IWorkflowService.
 */
public interface IWorkflowService {

	/**
	 * Get Workflow.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */
	Workflow get(String projectName, String workflowName, String workflowType);

}
