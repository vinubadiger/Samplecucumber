package com.opus.optimus.reporting.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;
import com.opus.optimus.reporting.repository.ReconDashboardL2Repository;
import com.opus.optimus.reporting.service.IReconDashboardL2Service;

/**
 * The Class ReconDashboardL2ServiceImpl is for Level2 Recon summary based on each activity and transaction date.
 */
@Service
public class ReconDashboardL2ServiceImpl implements IReconDashboardL2Service {

	public static final String TRANSACTION_DATE = "transactionDate";

	/** The dashboard repo. */
	@Autowired
	private ReconDashboardL2Repository dashboardRepo;

	@Override
	public List<ReconSummaryByTrnDate> getActivityDashboardSummary(Date transactionDate, String activityName) {
		Sort sort = new Sort(Sort.Direction.DESC, TRANSACTION_DATE);
		return dashboardRepo.findSummaryByTransDate(transactionDate, activityName, sort);
	}

}
