package com.opus.optimus.reporting.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;
import com.opus.optimus.reporting.repository.JobErrorRepository;
import com.opus.optimus.reporting.service.IJobErrorDetailService;

/**
 * The Class JobErrorDetailServiceImpl.
 */
@Service
public class JobErrorDetailServiceImpl implements IJobErrorDetailService {

	@Autowired
	private JobErrorRepository jobErrorRepository;

	@Override
	public Page<JobErrorDetails> getErrorDetails(String jobId, int page, int size) {
		Pageable pageable = PageRequest.of(page, size);
		return jobErrorRepository.findDetailsByJobId(jobId, pageable);
	}

}
