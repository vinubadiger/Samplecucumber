package com.opus.optimus.reporting.service;

import org.springframework.stereotype.Service;

import com.opus.optimus.ui.services.recon.Activity;

/**
 * The Interface IReconWorkflowService.
 */
@Service
public interface IReconWorkflowService {

	/**
	 * Gets the Recon Activity of a project
	 * 
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the activity
	 */
	Activity get(String projectName, String workflowName, String workflowType);

}
