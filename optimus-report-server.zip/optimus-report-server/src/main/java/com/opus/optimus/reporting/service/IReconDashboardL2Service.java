package com.opus.optimus.reporting.service;

import java.util.Date;
import java.util.List;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;

/**
 * The Interface IReconDashboardL2Service.
 */
public interface IReconDashboardL2Service {

	/**
	 * Gets the activity dashboard summary.
	 *
	 * @param transactionDate the transaction date
	 * @param activityName the activity name
	 * @return the activity dashboard summary
	 */
	List<ReconSummaryByTrnDate> getActivityDashboardSummary(Date transactionDate, String activityName);

}
