package com.opus.optimus.reporting.service;

import org.springframework.data.domain.Page;

import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;

/**
 * The Interface IJobErrorDetailService.
 */
public interface IJobErrorDetailService {
	
	/**
	 * Gets the error details.
	 *
	 * @param jobId the job id
	 * @param page the page
	 * @param size the size
	 * @return the error details
	 */
	public Page<JobErrorDetails> getErrorDetails(String jobId, int page, int size);

}
