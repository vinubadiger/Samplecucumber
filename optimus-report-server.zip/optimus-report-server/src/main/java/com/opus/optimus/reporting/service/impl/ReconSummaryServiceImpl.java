package com.opus.optimus.reporting.service.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;
import com.opus.optimus.reporting.repository.ReconSummaryRepository;
import com.opus.optimus.reporting.service.IReconSummaryService;

/**
 * The Class ReconSummaryServiceImpl.
 */
@Service
public class ReconSummaryServiceImpl implements IReconSummaryService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconSummaryServiceImpl.class);

	/** The recon summary repository. */
	@Autowired
	private ReconSummaryRepository reconSummaryRepository;

	@Override
	public List<ReconAcitivitySummary> findReconActivitySummary(String projectName, Date startDate, Date endDate) {
		try{
			Sort sort = new Sort(Sort.Direction.DESC, "processingDate");
			if (projectName == null || projectName.isEmpty()){
				return reconSummaryRepository.findByProcessingDateBetween(startDate, endDate,sort);
			} else 
				return reconSummaryRepository.findByProcessingDateBetween(startDate, endDate, projectName,sort);
		} catch (Exception e){
			logger.error(e.getMessage());
			throw new GenericException(e);
		}
	}

	@Override
	public List<ReconAcitivitySummary> findAll() {
		try{
			return reconSummaryRepository.findAll();
		} catch (Exception e){
			logger.error(e.getMessage());
			throw new GenericException(e);
		}
	}
}
