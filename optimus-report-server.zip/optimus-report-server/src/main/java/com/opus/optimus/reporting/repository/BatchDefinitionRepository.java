package com.opus.optimus.reporting.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.scheduler.BatchDefinition;

/**
 * The Interface BatchDefinitionRepository.
 */
@Repository ("batchDefinitionRepository")
public interface BatchDefinitionRepository extends MongoRepository<BatchDefinition, String> {

	/**
	 * Gets the expected files counts.
	 *
	 * @return the expected files counts
	 */
	@Query (value = "{'workflowtype' : {$eq:'ETL'}}", fields = "{'project_name': 1, 'workflowname':1, 'workflowtype':1, 'numberOfExpectedFiles':1, 'schedulerPolicy':1, '_id':0}")
	List<BatchDefinition> getExpectedFilesCounts();

}