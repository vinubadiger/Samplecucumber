package com.opus.optimus.reporting.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.user.Profile;

/**
 * The Interface ProfileRepository.
 */
@Repository
public interface ProfileRepository extends MongoRepository<Profile, String> {

	/**
	 * Find by profile id.
	 *
	 * @param profileId the profile id
	 * @return the profile
	 */
	@Query ("{profileId:'?0'}")
	Profile findByProfileId(String profileId);

	/**
	 * Gets the current user permission.
	 *
	 * @param roleName the role name
	 * @return the current user permission
	 */
	@Query ("{'role.roleName' : '?0' }")
	Profile getCurrentUserPermission(String roleName);

	/**
	 * Find profile by role name.
	 *
	 * @param roleName the role name
	 * @return the profile
	 */
	@Query ("{'role.roleName' : '?0'}")
	Profile findProfileByRoleName(String roleName);
}
