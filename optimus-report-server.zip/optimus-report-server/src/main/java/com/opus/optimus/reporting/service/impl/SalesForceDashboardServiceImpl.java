package com.opus.optimus.reporting.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.casemanagement.CaseGetResponse;
import com.opus.optimus.offline.config.casemanagement.CasePriorityCountResponse;
import com.opus.optimus.offline.config.exception.GenericException;
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper;
import com.opus.optimus.reporting.service.ISalesForceDashboardService;
import com.opus.optimus.reporting.util.BeanUtilService;

@Service
public class SalesForceDashboardServiceImpl implements ISalesForceDashboardService {

	/** The Constant logger. */
	public static final Logger logger = LoggerFactory.getLogger(SalesForceDashboardServiceImpl.class);

	/**
	 * Gets the countfrom salesforce.
	 *
	 * @param projectName the project name
	 * @param activity the activity
	 * @param userName the user name
	 * @return the countfrom salesforce
	 */
	@Override
	public CasePriorityCountResponse getCountfromSalesforce(String projectName, String activity, String userName) {
		try {
			SalesforceCaseHelper salesforceCaseHelper = BeanUtilService.getBeanObject(SalesforceCaseHelper.class);
			logger.debug(salesforceCaseHelper.authenticate().getAccessToken());
			return salesforceCaseHelper.getCount(salesforceCaseHelper.authenticate().getAccessToken(), activity, projectName, userName);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}

	/**
	 * For prepareCaseList from Salesforce.
	 *
	 * @param projectName the project name
	 * @param activity the activity
	 * @param transDate the transDate
	 * @return the case get response
	 */
	@Override
	public CaseGetResponse prepareCaseList(String projectName, String activity, String transDate, String urlRecordsFrom, String urlRecordsTo) {
		try {
			SalesforceCaseHelper salesforceCaseHelper = BeanUtilService.getBeanObject(SalesforceCaseHelper.class);
			logger.debug(salesforceCaseHelper.authenticate().getAccessToken());
			return salesforceCaseHelper.getCaseList(salesforceCaseHelper.authenticate().getAccessToken(), activity, transDate, projectName, urlRecordsFrom, urlRecordsTo);
		} catch (GenericException e){
			throw e;
		} catch (Exception e){
			throw new GenericException(e);
		}
	}
}