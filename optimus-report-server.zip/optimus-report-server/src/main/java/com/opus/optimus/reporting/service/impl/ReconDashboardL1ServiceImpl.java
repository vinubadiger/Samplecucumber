package com.opus.optimus.reporting.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.config.recon.ReconSummaryByTrnDate;
import com.opus.optimus.reporting.service.IReconDashboardL1Service;
import com.opus.optimus.ui.services.report.recon.DailyActivitySummaryResponse;

@Service
public class ReconDashboardL1ServiceImpl implements IReconDashboardL1Service {
	private static final Logger logger = LoggerFactory.getLogger(ReconDashboardL1ServiceImpl.class);

	private static final String UNRECONCILED = "UNRECONCILED";
	private static final String RECONCILED = "RECONCILED";
	private static final String PROJECT_FIELD = "projectName";
	private static final String TRANSACTION_DATE = "transactionDate";
	private static final String RECON_TYPE_FIELD = "reconType";
	private static final String AMOUNT_FIELD = "sourceASummary.totalAmount";
	private static final String TOTAL_AMOUNT = "totalAmount";
	private static final String TOTAL_RECORD_COUNT = "sourceASummary.recordCount";
	private static final String TOTAL_COUNT = "totalCount";
	private static final String TOTAL_VARIANCE_AMNT = "sourceASummary.totalVarianceAmnt";
	private static final String TOTAL_VARIANCE_AMOUNT = "totalVarianceAmnt";
	private static final String ACTIVITY_NAME = "activityName";
	private static final String STATUS = "status";

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Map<String, List<DailyActivitySummaryResponse>> getDailyActivitySummary(String projectName, Date startDate, Date endDate) {
		TypedAggregation<ReconSummaryByTrnDate> aggregation = Aggregation.newAggregation(ReconSummaryByTrnDate.class, getMatchingCriteria(projectName, startDate, endDate), getGroupOperationforDaily());
		logger.debug("Performing aggregate in Summary collection in DB!!");
		AggregationResults<DailyActivitySummaryResponse> output = mongoTemplate.aggregate(aggregation, DailyActivitySummaryResponse.class);
		List<DailyActivitySummaryResponse> dailyActivitySummaries = new ArrayList<>(output.getMappedResults());
		return populateDailyActivitysummary(dailyActivitySummaries, projectName);

	}

	private MatchOperation getMatchingCriteria(String projectName, Date startDate, Date endDate) {
		logger.debug("Preparing match stage!!");
		Criteria matchCriteria = Criteria.where(PROJECT_FIELD).is(projectName);
		matchCriteria.andOperator(Criteria.where(TRANSACTION_DATE).lte(endDate), Criteria.where(TRANSACTION_DATE).gte(startDate));
		return Aggregation.match(matchCriteria);
	}

	private GroupOperation getGroupOperationforDaily() {
		logger.debug("Preparing group stage for DayWise Summary!!");
		return Aggregation.group(ACTIVITY_NAME, RECON_TYPE_FIELD, TRANSACTION_DATE, STATUS).sum(AMOUNT_FIELD).as(TOTAL_AMOUNT).sum(TOTAL_RECORD_COUNT).as(TOTAL_COUNT).sum(TOTAL_VARIANCE_AMNT).as(TOTAL_VARIANCE_AMOUNT);
	}

	private Map<String, List<DailyActivitySummaryResponse>> populateDailyActivitysummary(List<DailyActivitySummaryResponse> dailyActivitySummaries, String projectName) {
		logger.debug("Grouping DailyActivitySummaryResponse by activity name !!");
		Map<String, List<DailyActivitySummaryResponse>> byActivityName = dailyActivitySummaries.stream().collect(Collectors.groupingBy(DailyActivitySummaryResponse::getActivityName));
		Map<String, List<DailyActivitySummaryResponse>> summaryResponse = new HashMap<>();
		for (Entry<String, List<DailyActivitySummaryResponse>> entry : byActivityName.entrySet()){
			String activityName = entry.getKey();
			List<DailyActivitySummaryResponse> txnSummaries = new ArrayList<>();
			List<DailyActivitySummaryResponse> summaries = entry.getValue();
			logger.debug("Grouping DailyActivitySummaryResponse by transactions date !!");
			Map<Object, List<DailyActivitySummaryResponse>> summariesByTransactionDate = summaries.stream().collect(Collectors.groupingBy(date -> date.getTransactionDate()));
			for (Entry<Object, List<DailyActivitySummaryResponse>> summaryByDate : summariesByTransactionDate.entrySet()){
				List<DailyActivitySummaryResponse> summarByDate = summaryByDate.getValue();
				DailyActivitySummaryResponse txn = mergeAndCreateDailyActivitySummary(summarByDate, projectName);
				if (txn != null){
					txnSummaries.add(txn);
				}
			}
			if (!txnSummaries.isEmpty()){
				summaryResponse.put(activityName, txnSummaries);
			}
		}
		return summaryResponse;
	}

	private DailyActivitySummaryResponse mergeAndCreateDailyActivitySummary(List<DailyActivitySummaryResponse> summarByDate, String projectName) {
		logger.debug("Merging reconsiled and unreconsiled summary to create base response object!!");
		DailyActivitySummaryResponse dailyActivitysummary = null;
		double varianceAmount = 0;
		double unReconcilledAmount = 0;
		double reconcilledAmount = 0;
		int reconcilledCount = 0;
		int unReconcilledTransactionCount = 0;
		for (DailyActivitySummaryResponse transaction : summarByDate){
			if (transaction.getStatus().equals(RECONCILED)){
				dailyActivitysummary = transaction;
				varianceAmount = transaction.getVarianceAmount();
				reconcilledAmount = transaction.getTotalAmount();
				reconcilledCount = transaction.getTotalCount();
			} else if (transaction.getStatus().equals(UNRECONCILED)){
				unReconcilledAmount = transaction.getTotalAmount();
				unReconcilledTransactionCount = transaction.getTotalCount();
			}
		}
		if (dailyActivitysummary != null){
			createDailyActivitySummary(projectName, dailyActivitysummary, varianceAmount, unReconcilledAmount, reconcilledAmount, reconcilledCount, unReconcilledTransactionCount);
		}
		return dailyActivitysummary;
	}

	private void createDailyActivitySummary(String projectName, DailyActivitySummaryResponse dailyActivitysummary, double varianceAmount, double unReconcilledAmount, double reconcilledAmount, int reconcilledCount, int unReconcilledTransactionCount) {
		logger.debug("Creating daily activity summary object!!");
		dailyActivitysummary.setVarianceAmount(calculateVarianceAmount(varianceAmount, unReconcilledAmount));
		dailyActivitysummary.setTotalAmount(calculateTotalAmount(reconcilledAmount, unReconcilledAmount));
		dailyActivitysummary.setTotalCount(calculateTotalCount(reconcilledCount, unReconcilledTransactionCount));
		dailyActivitysummary.setUnReconcilledAmount(unReconcilledAmount);
		dailyActivitysummary.setUnReconcilledCount(reconcilledCount);
		dailyActivitysummary.setReconcilledAmount(reconcilledAmount);
		dailyActivitysummary.setReconcilledCount(reconcilledCount);
		dailyActivitysummary.setProjectName(projectName);
	}

	private int calculateTotalCount(int reconcilledTransactionCount, int unReconcilledTransactionCount) {
		return reconcilledTransactionCount + unReconcilledTransactionCount;
	}

	private double calculateTotalAmount(double reconcilledAmount, double unReconcilledAmount) {
		return reconcilledAmount + unReconcilledAmount;
	}

	private double calculateVarianceAmount(double varianceAmount, double unReconcilledAmount) {
		return varianceAmount + unReconcilledAmount;

	}

}
