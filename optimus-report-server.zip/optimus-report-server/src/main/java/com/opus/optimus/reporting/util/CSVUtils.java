package com.opus.optimus.reporting.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Optional;

/**
 * The Class CSVUtils.
 */
public class CSVUtils {

	/** The Constant DEFAULT_SEPARATOR. */
	private static final char DEFAULT_SEPARATOR = ',';
	
	public static final int LIMIT_TO_WRITE = 1000000;

	/**
	 * Instantiates a new CSV utils.
	 */
	private CSVUtils() {}

	/**
	 * Write line.
	 *
	 * @param outputStream the output stream
	 * @param values the values
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void writeLine(OutputStream outputStream, List<?> values) throws IOException {
		writeLine(outputStream, values, DEFAULT_SEPARATOR, ' ');
	}

	/**
	 * Write line.
	 *
	 * @param w the w
	 * @param values the values
	 * @param separators the separators
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void writeLine(OutputStream w, List<?> values, char separators) throws IOException {
		writeLine(w, values, separators, ' ');
	}

	/**
	 * Follow CV sformat.
	 *
	 * @param value the value
	 * @return the string
	 */
	private static String followCVSformat(Object value) {
		String result = null;
		Optional<Object> checkNull = Optional.ofNullable(value);
		if (checkNull.isPresent()) {
			result = value.toString();
			if (result.contains("\"")) {
				result = result.replace("\"", "\"\"");
			}
		}
		return result;
	}

	/**
	 * Write line.
	 *
	 * @param w the w
	 * @param values the values
	 * @param separators the separators
	 * @param customQuote the custom quote
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void writeLine(OutputStream w, List<?> values, char separators, char customQuote) throws IOException {
		boolean first = true;
		// default customQuote is empty
		if (separators == ' '){
			separators = DEFAULT_SEPARATOR;
		}

		StringBuilder sb = new StringBuilder();
		for (Object value : values){
			if (!first){
				sb.append(separators);
			}
			if (customQuote == ' '){
				sb.append(followCVSformat(value));
			} else{
				sb.append(customQuote).append(followCVSformat(value)).append(customQuote);
			}

			first = false;
		}
		sb.append("\n");
		w.write(sb.toString().getBytes());
	}
}
