package com.opus.optimus.reporting.service;

import com.opus.optimus.offline.config.casemanagement.CaseGetResponse;
import com.opus.optimus.offline.config.casemanagement.CasePriorityCountResponse;

public interface ISalesForceDashboardService {
	
	/**
	 * Gets the countfrom salesforce.
	 *
	 * @param projectName the project name
	 * @param activity the activity
	 * @param userName the user name
	 * @return the countfrom salesforce
	 */
	public CasePriorityCountResponse getCountfromSalesforce(String projectName, String activity, String userName);
	
	/**
	 * For prepareCaseList from Salesforce.
	 *
	 * @param projectName the project name
	 * @param activity the activity
	 * @param transDate the transDate
	 * @return the case get response
	 */
	public CaseGetResponse prepareCaseList(String projectName, String activity, String transDate, String urlRecordsFrom, String urlRecordsTo);
}
