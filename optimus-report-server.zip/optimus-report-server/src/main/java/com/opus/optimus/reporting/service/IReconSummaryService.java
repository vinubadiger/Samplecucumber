package com.opus.optimus.reporting.service;

import java.util.Date;
import java.util.List;

import com.opus.optimus.offline.config.recon.ReconAcitivitySummary;

/**
 * The Interface ReconSummaryService.
 */
public interface IReconSummaryService {

	/**
	 * Find recon acitivity summary.
	 *
	 * @param activityId the activity id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return the list
	 */
	List<ReconAcitivitySummary> findReconActivitySummary(String activityId, Date startDate, Date endDate);

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	List<ReconAcitivitySummary> findAll();

}
