package com.opus.optimus.reporting.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.ui.services.project.Workflow;

/**
 * The Interface WorkflowRepository.
 */
@Repository
public interface WorkflowRepository extends MongoRepository<Workflow, String> {

	/**
	 * Find work flow by project name.
	 *
	 * @param projectName the project name
	 * @param workflowName the workflow name
	 * @param workflowType the workflow type
	 * @return the workflow
	 */

	@Query (value = "{ $and: [ { 'projectName' : ?0 },{'workflowName' : ?1 },{'workflowType' : ?2} ] }")
	Workflow findWorkFlowByProjectName(String projectName, String workflowName, String workflowType);

}
