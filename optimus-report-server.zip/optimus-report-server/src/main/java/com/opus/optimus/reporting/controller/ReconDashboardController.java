package com.opus.optimus.reporting.controller;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opus.optimus.reporting.service.IReconDashboardService;
import com.opus.optimus.ui.services.report.recon.SummaryResponse;

/**
 * The Class ReconDashboardController is for getting Recon Summary on daily/monthly/yearly wise for all projects.
 */
@RestController
@RequestMapping ("{actionName}/reconDashboard")
public class ReconDashboardController {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ReconDashboardController.class);

	/** The dashboard service. */
	@Autowired
	private IReconDashboardService dashboardService;

	/**
	 * Gets the summary day wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the summary day wise
	 */
	@GetMapping (value = { "/dayWise/{startDate}/{endDate}/{projectName}", "/dayWise/{startDate}/{endDate}" })
	public Map<String, SummaryResponse> getSummaryDayWise(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable (required = false) String projectName) {
		logger.debug("Getting Summary details day wise !!");
		return dashboardService.getDailySummary(projectName, startDate, endDate);

	}

	/**
	 * Gets the summary month wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the summary month wise
	 */
	@GetMapping (value = { "/monthWise/{startDate}/{endDate}/{projectName}", "/monthWise/{startDate}/{endDate}" })
	public Map<String, SummaryResponse> getSummaryMonthWise(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable (required = false) String projectName) {
		logger.debug("Getting Summary details month wise !!");
		return dashboardService.getMonthlySummary(projectName, startDate, endDate);

	}

	/**
	 * Gets the summar year wise.
	 *
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param projectName the project name
	 * @return the summar year wise
	 */
	@GetMapping (value = { "/yearWise/{startDate}/{endDate}/{projectName}", "/yearWise/{startDate}/{endDate}" })
	public Map<String, SummaryResponse> getSummarYearWise(@PathVariable ("startDate") @DateTimeFormat (iso = ISO.DATE) Date startDate, @PathVariable ("endDate") @DateTimeFormat (iso = ISO.DATE) Date endDate, @PathVariable (required = false) String projectName) {
		logger.debug("Getting Summary details year wise !!");
		return dashboardService.getYearlySummary(projectName, startDate, endDate);

	}
}
