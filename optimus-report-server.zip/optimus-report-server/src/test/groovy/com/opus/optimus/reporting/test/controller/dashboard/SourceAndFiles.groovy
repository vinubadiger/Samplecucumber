package com.opus.optimus.reporting.test.controller.dashboard

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.reporting.interceptor.LoginInterceptor
import com.opus.optimus.reporting.repository.UserRepository
import com.opus.optimus.reporting.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class SourceAndFiles extends Specification{

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;
	
	@SpringBean

	UserRepository userRepository = Stub(UserRepository.class);
	
	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);
	
	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'
	def user = null;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {
		DBObject failedFile = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("status", "COMPLETED_FAILED")
				.add("workflowType", "ETL")
				.add("projectName", "test1")
				.add("workflowName", "src1")
				.add("startedTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-01-28T00:00:00.000Z"))
				.add("sourceInfo", BasicDBObjectBuilder.start().add("source", "fatalerror.csv").get())
				.get();

		mongoTemplate.save(failedFile, "JobInfo");
		

		List<String> projects = new ArrayList<String>();
		projects.add("test1");
						
		user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		
		userRepository.findUserByEmail(_ as String) >> user;
		
		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");
		

		
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
		
		userContextUtility.checkIfAdminUser() >> true

	}

	def "sourceandfile by startDate,endDate,workflowType"() {
		when:
		def response = mvc.perform(
				get('/GetSourceAndFiles_FOR_DASHBOARD/jobinfo/sourceandfile/2019-01-25/2019-01-30/ETL')
				).andReturn()

		then:
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowName").equals("src1")
	}

	def "sourceandfile by startDate,endDate,workflowType,projectName"() {
		when:
		def response = mvc.perform(
				get('/GetSourceAndFiles_FOR_DASHBOARD/jobinfo/sourceandfile/2019-01-25/2019-01-30/ETL/test1')
				).andReturn()

		then:
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("workflowName").equals("src1")
	}
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
