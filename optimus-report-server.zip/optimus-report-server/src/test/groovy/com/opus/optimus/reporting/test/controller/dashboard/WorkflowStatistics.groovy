package com.opus.optimus.reporting.test.controller.dashboard

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.reporting.interceptor.LoginInterceptor
import com.opus.optimus.reporting.repository.UserRepository
import com.opus.optimus.reporting.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class WorkflowStatistics extends Specification{

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;
	
	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);
	
	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);
	
	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'
	def user = null;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);
	
	def setup() {

		DBObject successJobToSave = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("status", "COMPLETED_SUCCESS")
				.add("workflowType", "ETL")
				.add("projectName", "Airtime")
				.add("startedTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-01-29T00:00:00.000Z"))
				.get();
				
		mongoTemplate.save(successJobToSave, "JobInfo");
		

		List<String> projects = new ArrayList<String>();
		projects.add("Airtime");
						
		user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		
		userRepository.findUserByEmail(_ as String) >> user;
		
		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");
		
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}
	def "workflow statisctics by startDate,endDate,workflowType"() {
		given:
		userContextUtility.checkIfAdminUser() >> true
		when:
		def response = mvc.perform(
				get('/GetAllETLWorkflows_FOR_DASHBOARD/jobinfo/workflow/statistics/COMPLETED_SUCCESS/2019-01-25/2019-01-30/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 && containerObject.getInt("count") == 1
	}

	def "workflow by statistics startDate,endDate,workflowType,projectName"() {
		given:
		userContextUtility.checkIfAdminUser() >> true
		when:
		def response = mvc.perform(
				get('/GetAllETLWorkflows_FOR_DASHBOARD/jobinfo/workflow/statistics/COMPLETED_SUCCESS/2019-01-25/2019-01-30/ETL/Airtime')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 && containerObject.getInt("count") == 1
	}
	
	def "workflow statisctics by startDate,endDate,workflowType - false condition"() {
		given:
		userContextUtility.checkIfAdminUser() >> false
		when:
		def response = mvc.perform(
				get('/GetAllETLWorkflows_FOR_DASHBOARD/jobinfo/workflow/statistics/COMPLETED_SUCCESS/2019-01-25/2019-01-30/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 && containerObject.getInt("count") == 1
	}
}
