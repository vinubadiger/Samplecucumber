package com.opus.optimus.reporting.test.controller.reconsummary

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.http.MediaType
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.web.util.NestedServletException

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.runtime.taskmanager.mongo.model.PublishedService
import com.opus.optimus.reporting.controller.DataExportController
import com.opus.optimus.reporting.interceptor.LoginInterceptor
import com.opus.optimus.reporting.service.MapperFactory
import com.opus.optimus.ui.services.project.Workflow
import com.opus.optimus.ui.services.recon.Activity

import groovy.json.JsonOutput
import spock.lang.Specification


@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class DataExport extends Specification{

	@Autowired
	protected MockMvc mvc


	@Autowired
	MapperFactory mapperFactory;

	@Autowired
	MongoTemplate mongoTemplate;


	@Autowired
	ObjectMapper mapper;

	def request

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def object;
	def MockHttpServletResponse mockHttpServletResponse

	def setup() {
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}

	def "Download ReconSummary as csv"() {
		setup:
		println("In setup")
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/PublishService.json")
		object = mapper.readValue(jsonStream, PublishedService.class)
		println("Before save "+ object)
		def savedObj = mongoTemplate.save(object, "PublishedService");
		println("After save " + savedObj)

		File file = new File(getClass().getResource("/Samson.json").getPath())
		String fileContent = file.text
		def dbObject = Document.parse(fileContent)
		mongoTemplate.save(dbObject, "Samson")
		println("Document saved :" + fileContent)

		file = new File(getClass().getResource("/Samson1.json").getPath())
		fileContent = file.text
		dbObject = Document.parse(fileContent)
		mongoTemplate.save(dbObject, "Samson")
		println("Document saved :" + fileContent)

		println("In setup completed")
		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/downloadAsCsv/test/test/Samson')
				.param("status", "RECONCILED")
				.param("subStatus","ForceMatch")
				).andReturn()
		println("In setup completed")
		then:
		println("Response Body --> " + response.getResponse().contentAsString)

		response.getResponse().getStatus() == 200
	}
	
	def "Exception - 'Activity not found' - Download ReconSummary as csv"() {
		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/downloadAsCsv/test/test/Samson')
				).andReturn()
		then:
		thrown NestedServletException
	}
	
	def "Exception - 'Workflow configuration not found'- Download ReconSummary as csv"() {
		setup:
		println("In setup")
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/PublishService1.json")
		object = mapper.readValue(jsonStream, PublishedService.class)
		println("Before save "+ object)
		def savedObj = mongoTemplate.save(object, "PublishedService");
		println("After save - WorkflowConfig Not Present " + savedObj)

		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/downloadAsCsv/test/test/Samson')
				).andReturn()
		then:
		thrown NestedServletException
	}
	
	def "Exception - 'DataSource not found to generate the report'- Download ReconSummary as csv"() {
		setup:
		println("In setup")
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/PublishService.json")
		object = mapper.readValue(jsonStream, PublishedService.class)
		println("Before save "+ object)
		def savedObj = mongoTemplate.save(object, "PublishedService");
		println("Wrong SourceName - DataSource not found to generate the report ")

		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/downloadAsCsv/test/test/Samson22')
				).andReturn()
		then:
		thrown NestedServletException
	}
	
	def "Exception - 'No records found' Download ReconSummary as csv"() {
		setup:
		println("In setup")
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/PublishService2.json")
		object = mapper.readValue(jsonStream, PublishedService.class)
		println("Before save "+ object)
		def savedObj = mongoTemplate.save(object, "PublishedService");
		println("Wrong Collection Name into PublishService2 file")

		File file = new File(getClass().getResource("/Samson.json").getPath())
		String fileContent = file.text
		def dbObject = Document.parse(fileContent)
		mongoTemplate.save(dbObject, "Samson")
		println("Document saved :" + fileContent)
		
		file = new File(getClass().getResource("/Samson1.json").getPath())
		fileContent = file.text
		dbObject = Document.parse(fileContent)
		mongoTemplate.save(dbObject, "Samson")
		println("Document saved :" + fileContent)

		println("In setup completed")
		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/downloadAsCsv/test/test/Samson')
				).andReturn()
		then:
		thrown NestedServletException
	}

	def "Get workflow and export" (){
		setup:
		def jsonStream = getClass().getResourceAsStream("/ETLWorkflowAmex.json")
		request = mapper.readValue(jsonStream, Workflow.class)
		mongoTemplate.save(request, "Workflow")
		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/exportWorkflow/Sanity280519/Amex28/ETL')
				).andReturn()
		println("In setup completed")
		then:
		response.getResponse().getStatus()
	}
	def "Get activity and export" (){
		setup:
		def jsonStream = getClass().getResourceAsStream("/activity.json")
		request = mapper.readValue(jsonStream, Workflow.class)
		mongoTemplate.save(request, "Activity")
		when:
		println("In when clause")
		def response = mvc.perform(
				get('/testactionname/download/exportActivity/Amex/Ptech_Amex/RECON')
				).andReturn()
		println("In setup completed")
		then:
		response.getResponse().getStatus()
	}
	def "Get activity and import" (){
		setup:
		def jsonStream = getClass().getResourceAsStream("/activity.json")
		request = mapper.readValue(jsonStream, Activity.class)

		when:
		println("In when clause")

		def response = mvc.perform(
				post('/testactioname/download/importActivity').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("In setup completed")
		then:
		response.getResponse().getStatus()
	}

	def "Get workflow and import" (){
		setup:
		def jsonStream = getClass().getResourceAsStream("/ETLWorkflowAmex.json")
		request = mapper.readValue(jsonStream, Workflow.class)

		when:
		println("In when clause")

		def response = mvc.perform(
				post('/testactioname/download/importWorkflow').contentType(MediaType.APPLICATION_JSON).content(JsonOutput.toJson(request))
				).andReturn()
		println("In setup completed")
		then:
		response.getResponse().getStatus()
	}
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
