package com.opus.optimus.reporting.util

import org.springframework.beans.factory.NoSuchBeanDefinitionException

import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper

import spock.lang.Specification

class BeanUtilServiceSpec extends Specification {
	def GetVersionNumberdd
	def "BeanUtilService-Thrown NoSuchBeanDefinitionException"() {
		given:
		def beanutilservice = new BeanUtilService()

		when:
		beanutilservice.getBeanObject(GetVersionNumberdd)

		then:
		thrown GenericException
	}

	def "specifying that exception should be thrown-NoSuchBeanDefinitionException"() {
		given:
		def beanutilservice = new BeanUtilService()
		beanutilservice.getBeanObject(GetVersionNumberdd) >> { throw new NoSuchBeanDefinitionException() }
	}
}
