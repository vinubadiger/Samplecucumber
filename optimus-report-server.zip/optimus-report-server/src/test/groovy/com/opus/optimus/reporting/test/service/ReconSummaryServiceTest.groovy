package com.opus.optimus.reporting.test.service

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.reporting.service.impl.ReconSummaryServiceImpl

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ReconSummaryServiceTest extends Specification{
	
	def reconSummaryServiceService = new ReconSummaryServiceImpl();
	
	def "Exception - Find Recon Activity Summary"() {
		given:
		reconSummaryServiceService.findReconActivitySummary(_, _, _ as Date) >> { throw new NullPointerException() }
		when:
		reconSummaryServiceService.findReconActivitySummary("projectName", new Date(), new Date())
		then:
		thrown GenericException
	}
	
	def "Exception - findAll"() {
		given:
		reconSummaryServiceService.findAll() >> { throw new NullPointerException() }
		when:
		reconSummaryServiceService.findAll()
		then:
		thrown GenericException
	}
}
