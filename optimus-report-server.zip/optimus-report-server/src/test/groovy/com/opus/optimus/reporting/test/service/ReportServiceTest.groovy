package com.opus.optimus.reporting.test.service

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.offline.config.exception.GenericException
import com.opus.optimus.offline.constants.StepTypeConstants
import com.opus.optimus.reporting.constant.Constants

import com.opus.optimus.reporting.service.impl.ReportingServiceImpl

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ReportServiceTest extends Specification{
	def reportingService = new ReportingServiceImpl();
	def "Get Error Reason (user readable) Using Error Code"(){
		expect: ""
		reportingService.getErrorReason("RDR-GEN-005").equals("File Not Found") &&
		reportingService.getErrorReason("RDR-GEN-006").equals("Duplicate File") &&
		reportingService.getErrorReason("RDR-GEN-001").equals("Reader General Exception") &&
		reportingService.getErrorReason("RDR-GEN-008").equals("Empty File") &&
		reportingService.getErrorReason("RDR-GEN-009").equals("File Access Denied") &&
		reportingService.getErrorReason("RDR-GEN-007").equals("Exception while File stream release") &&
		reportingService.getErrorReason("RDR-DAT-001").equals("File end") &&
		reportingService.getErrorReason("RDR-DAT-002").equals("File field formate problem") &&
		reportingService.getErrorReason("RDR-DAT-003").equals("Invalid field formate") &&
		reportingService.getErrorReason("RDR-DAT-004").equals("Missing fields from record") &&
		reportingService.getErrorReason("SYS-GEN-001").equals("System General Exception") &&
		reportingService.getErrorReason("DB-GEN-001").equals("Database general exception") &&
		reportingService.getErrorReason("DS-INIT-001").equals("Exception during DB initialization") &&
		reportingService.getErrorReason("DS-NOSUCH-001").equals("No such data source found") &&
		reportingService.getErrorReason("DefaultTest").equals("")
	}
	
	def "Change step name for UI"() {
		expect: ""
		reportingService.changeStepName(StepTypeConstants.DBREADER_STEP_TYPE).equals(Constants.EXTRACTION) &&
		reportingService.changeStepName(StepTypeConstants.MONGODB_WRITER_STEPTYPE).equals(Constants.LOADER) &&
		reportingService.changeStepName(StepTypeConstants.TRANSFORMER_STEPTYPE).equals(Constants.TRANSFORMATION) &&
		reportingService.changeStepName(StepTypeConstants.VALIDATOR_STEPTYPE).equals(Constants.VALIDATION) &&
		reportingService.changeStepName(StepTypeConstants.DEFAULT_GLOBAL_ERROR_HANDLER_STEP_TYPE).equals(Constants.GLOBLEERROR) &&
		reportingService.changeStepName(StepTypeConstants.SALESFORCE_CASE_CREATOR).equals(Constants.SALESFORCECASECREATION) &&
		reportingService.changeStepName(StepTypeConstants.RECON_CONFIG_STEP).equals(Constants.RECONCILATION) &&
		reportingService.changeStepName(StepTypeConstants.MONGO_DBREADER_STEP_TYPE).equals(Constants.RECONSOURCEREADER) &&
		reportingService.changeStepName(StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE).equals(Constants.RECONSTATUSUPDATOR) &&
		reportingService.changeStepName(StepTypeConstants.RECONCASECREATION_STEPTYPE).equals(Constants.SALESFORCECASECREATION) &&
		reportingService.changeStepName("DefaultTest").equals("")
	}
	
	def "Exception - Aggregate"() {
		given:
		reportingService.aggregate(_, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportingService.aggregate(new Date(), new Date(), "projectName", "workflowType")
		then:
		thrown GenericException
	}
	
	def "Exception - Workflow statistics"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.workflowStatistics(_,_, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.workflowStatistics("status", new Date(), new Date(), "workflowType", "projectName")
		then:
		thrown GenericException
	}
	
	def "Exception - Failure statistics"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failureStatistics(_, _, _, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failureStatistics(new Date(), new Date(), "workflowType", "projectName", "workflowName", "sourceFile")
		then:
		thrown GenericException
	}
	
	def "Exception - Failure analysis"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failureAnalysis(_, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failureAnalysis(new Date(), new Date(), "workflowType", "projectName")
		then:
		thrown GenericException
	}
	
	def "Exception - Failure analysis pie chart"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failurerAnalysisPieChart(_, _, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failurerAnalysisPieChart(new Date(), new Date(), "workflowType", "projectName", "stepName")
		then:
		thrown GenericException
	}
	
	def "Exception - Failure analysis root cause analysis table"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failureAnalysisRootCauseAnalysisTable(_, _, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failureAnalysisRootCauseAnalysisTable(new Date(), new Date(), "workflowType", "projectName", "workflowName")
		then:
		thrown GenericException
	}
	
	def "Exception - Step type error count map"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.stepTypeErrorCountMap(_ as Object) >> { throw new NullPointerException() }
		when:
		reportService.stepTypeErrorCountMap(null)
		then:
		thrown GenericException
	}
	
	def "Exception - Source files group by workflow name"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.sourceFilesGroupByWorkflowName(_, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.sourceFilesGroupByWorkflowName(new Date(), new Date(), "workflowType", "projectName")
		then:
		thrown GenericException
	}
	
	def "Exception - Failure analysis failed files"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failureAnalysisFailedFiles(_, _, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failureAnalysisFailedFiles(new Date(), new Date(), "workflowType", "projectName", "workflowName")
		then:
		thrown GenericException
	}

	def "Exception - Failure analysis failed files and projects"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failureAnalysisFailedFilesAndProjects(_, _, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failureAnalysisFailedFilesAndProjects(new Date(), new Date(), "workflowType", "projectName", "errorCode")
		then:
		thrown GenericException
	}
	
	def "Exception - Gets the job info processed data day wise"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.getJobInfoProcessedDataDayWise(_, _, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.getJobInfoProcessedDataDayWise(new Date(), new Date(), "workflowType", "projectName")
		then:
		thrown GenericException
	}

	def "Exception - Failed source"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.failedSource(_, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.failedSource("workflowType", "projectName")
		then:
		thrown GenericException
	}
	
	def "Exception - Project within date range"() {
		given:
		def reportService = new ReportingServiceImpl();
		reportService.projectWithinDateRange(_, _, _ as String) >> { throw new NullPointerException() }
		when:
		reportService.projectWithinDateRange(new Date(), new Date(), "workflowType")
		then:
		thrown GenericException
	}
	
	def "Exception - Get File Status"() {
		given:
		def reportService = new ReportingServiceImpl();
		when:
		reportService.getFileStatus(null, true)
		then:
		thrown GenericException
	}

	def "Exception - Populate Dashboard Statistics"() {
		given:
		def reportService = new ReportingServiceImpl();
		when:
		reportService.populateDashboardStatistics(null, null)
		then:
		thrown GenericException
	}

	def "Exception - Sort By Value"() {
		given:
		ReportingServiceImpl.sortByValue(_ as Object) >> { throw new NullPointerException() }
		when:
		ReportingServiceImpl.sortByValue(null)
		then:
		thrown GenericException
	}
}
