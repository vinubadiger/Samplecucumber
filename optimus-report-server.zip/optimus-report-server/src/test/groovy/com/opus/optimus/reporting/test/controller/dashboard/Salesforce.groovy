package com.opus.optimus.reporting.test.controller.dashboard

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.setup.MockMvcBuilders

import com.opus.optimus.offline.config.casemanagement.CaseGetResponse
import com.opus.optimus.offline.config.casemanagement.CasePriorityCountResponse
import com.opus.optimus.reporting.controller.SalesForceDashboardController
import com.opus.optimus.reporting.interceptor.LoginInterceptor

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class Salesforce extends Specification{

	@Autowired
	protected MockMvc mvc
	
	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def setup() {

		loginInterceptor.preHandle(_, _, _ as Object) >> true;
		mvc = MockMvcBuilders.standaloneSetup(new SalesForceDashboardController()).build();
	}


	def "Get Salesforcecaselist using activity,batchsize,date"() {
		given :
		def mvcc = CaseGetResponse.builder().hasError("false").build();

		when:
		def response = mvc.perform(
				get('/getcaselist/salesfoceDashboard/getCaseList/testproject/testactivity/0/1')
				).andReturn()

		then:
		println("size "+mvcc.hasError)
		mvcc.hasError=="false"
	}
	def "Get cout using activity,projectName,username"() {
		given :
		def mvcc = CasePriorityCountResponse.builder().message("Successfully Retrived.").hasError("false")build();

		when:
		def response = mvc.perform(
				get('/getcaselist/salesfoceDashboard/caseCountOnpririoty/AMEX/Paymentech_KB/Sapan Panda')
				).andReturn()

		then:
		println("size "+mvcc.hasError)
		mvcc.message=="Successfully Retrived." || mvcc.hasError=="false"
	}
}
