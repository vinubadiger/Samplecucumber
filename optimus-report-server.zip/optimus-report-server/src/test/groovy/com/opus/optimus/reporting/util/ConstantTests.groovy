package com.opus.optimus.reporting.util

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.TestPropertySource

import com.opus.optimus.reporting.constant.Constants

import spock.lang.Specification

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
class ConstantTests extends Specification {

	def "Constants Tests"() {
		given:
		Constants constants = new Constants();
		expect:
				constants.INSTITUTION_ID == "institution_id" ||
				constants.INSTITUTION_NAME == "institution_name" ||
				constants.DISPLAY_NAME == "display_name" ||
				constants.ADMIN_EMAIL == "admin_email" ||
				constants.MOBILE_NO == "admin_mobile" ||

				constants.PROJECT_COLLECTION_NAME == "Project" ||
				constants.PROJECT_DESCRIPTION == "project_desc" ||

				constants.PROJECT_NAME == "project_name" ||
				constants.WORKFLOW_COLLECTION_NAME == "Workflow" ||
				constants.PROJECT_ID == "project_id" ||
				constants.WORKFLOW_DESCRIPTION == "workflow_desc" ||
				constants.CREATED_DATE == "created_date" ||
				constants.MODIFIED_DATE == "modified_date" ||
				constants.CREATED_BY == "created_by" ||
				constants.LAST_UPDATED_BY == "last_updated_by" ||
				constants.FLOW_DATA == "flow_data" ||
				constants.WORKFLOW_ID == "workflowid" ||
				constants.WORKFLOW_NAME == "workflowname" ||
				constants.WORKFLOW_TYPE == "workflowtype" ||

				constants.BATCH_DEFINATION_COLLECTION_NAME == "batch_definition" ||
				constants.NEXT_TRIGGER_TIME == "next_trigger_time" ||
				constants.PREVIOUS_TRIGGER_TIME == "previous_trigger_time" ||
				constants.SCHEDULAR_POLICY == "scheduler_policy" ||

				constants.BATCH_MONITOR_COLLECTION_NAME == "batch_monitor" ||
				constants.BATCH_INSTANCE_ID == "batch_instance_id" ||
				constants.CREATED_TIME == "created_time" ||
				constants.START_TIME == "start_time" ||
				constants.END_TIME == "end_time" ||
				constants.TRIGGER_TYPE == "trigger_type" ||
				constants.EXECUTION_STATUS == "execution_status" ||
				constants.RECORDS_PROCESSED == "records_processed" ||
				constants.RECORDS_PASSED == "records_passed" ||
				constants.RECORDS_FAILED == "records_failed" ||
				constants.SOURCE_INFORMATION == "source_information" ||
				constants.EXCEPTION_LOGS == "exception_logs" ||
				constants.STEP_INPUT == "step_input" ||
				constants.GROUP_ID == "group_id" ||
				constants.JOB_INFO == "jobInfo" ||
				constants.STEP_NAMES == "step_names" ||
				constants.DEFAULT_PASSOWRD == "Welcome" ||
				constants.ACTIVITY_STATUS == "activity_status" ||

				constants.PROJECTNAME == "projectName" ||
				constants.WORKFLOWNAME == "workflowName" ||
				constants.WORKFLOWTYPE == "workflowType" ||
				constants.STARTEDTIME == "startedTime" ||
				constants.STATUS == "status" ||
				constants.COUNT == "count" ||
				constants.PROCESSINGTIME == "processingTime" ||
				constants.FAILEDREASON == "failedReason" ||
				constants.ERRORCODE == "errorReason.errorCode" ||
				constants.SOURCEFILE == "sourceInfo.source" ||

				constants.EXTRACTION == "Extraction" ||
				constants.LOADER == "Loader" ||
				constants.TRANSFORMATION == "Transformation" ||
				constants.VALIDATION == "Validation" ||
				constants.GLOBLEERROR == "Global Error" ||
				constants.SALESFORCECASECREATION == "Case Creation" ||
				constants.RECONCILATION == "Reconciliation" ||
				constants.RECONSOURCEREADER == "Recon Source Reader" ||
				constants.RECONSTATUSUPDATOR == "Recon Status Updator" ||

				constants.USERNAME == "userName"
	}
}