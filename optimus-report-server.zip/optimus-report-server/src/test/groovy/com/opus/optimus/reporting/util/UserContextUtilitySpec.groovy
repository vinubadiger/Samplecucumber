package com.opus.optimus.reporting.util

import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.Authentication
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContext
import org.springframework.security.core.context.SecurityContextHolder

import spock.lang.Specification

class UserContextUtilitySpec extends Specification {

	private static AuthenticationManager am = new SampleAuthenticationManager();

	def setup() {
		Authentication request = new UsernamePasswordAuthenticationToken("bob", "password");
		Authentication result = am.authenticate(request);
		SecurityContextHolder.getContext().setAuthentication(result);
	}

	def "get Logged in user name"() {
		expect: ""
		UserContextUtility userContextUtility= new UserContextUtility();
		userContextUtility.getLoggedUsername().equals("bob")
	}
	
	def "Check Admin User"() {
		given: 
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		GrantedAuthority authority = new SimpleGrantedAuthority("RECON_ADM");
		grantedAuthorities.add(authority);
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("UserNameTest", "", grantedAuthorities));
		SecurityContextHolder.setContext(securityContext);
		UserContextUtility userContextUtility= new UserContextUtility();
		
		when:
		boolean flag = userContextUtility.checkIfAdminUser()
		println("Flag --> " + flag)
		then:
		flag == false
	}
}
