package com.opus.optimus.reporting.test.controller.jobError

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.reporting.interceptor.LoginInterceptor

import spock.lang.Specification


@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class JobErrorDetails extends Specification {

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;

	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);

	def setup() {
		DBObject jobErrorDetail = BasicDBObjectBuilder.start()
				.add("jobId","123")
				.add("rowIndex", 0)
				.add("errorType", "ERROR")
				.add("errorMessage" , "Format Error on:AUTH_DATE, Error: Unparseable date")
				.add("reasonCode" , "RDR-DAT-002")
				.get();
		mongoTemplate.save(jobErrorDetail, "JobErrorDetails")
		println("collection exists: "+mongoTemplate.collectionExists("JobErrorDetails"))

		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}

	def "Get Job Error Details by job Id"(){
		when:
		def  response=mvc.perform(get('/ErrorDetails/jobError/123/0/2')).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		response.getResponse().getStatus() == 200 &&
				containerObject.getString("errorMessage").equals("Format Error on:AUTH_DATE, Error: Unparseable date") &&
				containerObject.getString("jobId").equals("123") &&
				containerObject.getString("errorType").equals("ERROR") &&
				containerObject.getString("reasonCode").equals("RDR-DAT-002")
	}

	def "Get Job Error Details by invalid job Id"(){
		when:
		def  response=mvc.perform(get('/ErrorDetails/jobError/1233/0/2')).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject1 = new JSONObject(response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(containerObject1.getString("content"));

		response.getResponse().getStatus() == 200
	}
}
