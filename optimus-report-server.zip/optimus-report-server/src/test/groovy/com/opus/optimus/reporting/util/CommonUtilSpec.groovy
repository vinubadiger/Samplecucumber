package com.opus.optimus.reporting.util

import com.fasterxml.jackson.databind.JsonNode;
import com.opus.optimus.ui.services.util.CommonUtil

import spock.lang.Specification

class CommonUtilSpec extends Specification {

	def "get Json From Object"(){
		expect:
		CommonUtil commonUtil = new CommonUtil();
		String json = commonUtil.getJsonFromObject("{\"name\" : \"Dev\"}")
		json != null
	}


	def "get Json From String"(){
		expect:
		JsonNode node = CommonUtil.getJsonFromString("{\"name\" : \"Dev\"}")
		node != null
	}

	def "get Object From String"(){

		expect:
		Person person = CommonUtil.getObjectFromString("{\"name\" : \"Dev\"}", Person.class)
		person != null
	}

	def "get Object From String, String is not in expected formate"(){

		expect:
		Person person = CommonUtil.getObjectFromString("{'name' : 'Dev'}", Person.class)
		person == null
	}

	def "Return Next Day"(){

		expect:
		Date currentDate = new Date();
		Date  nextDay = CommonUtil.returnNextDay(currentDate);
		nextDay != null
	}

	def "Date format"(){
		expect:
		Date  formatedDate = CommonUtil.getFormattedDate(new Date(), "yyyy-MM-dd")
		formatedDate != null
	}
}
