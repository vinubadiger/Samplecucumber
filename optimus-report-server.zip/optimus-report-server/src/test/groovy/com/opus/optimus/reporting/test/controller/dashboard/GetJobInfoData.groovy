package com.opus.optimus.reporting.test.controller.dashboard

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.json.JSONArray
import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc
import org.springframework.web.util.NestedServletException

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.reporting.interceptor.LoginInterceptor
import com.opus.optimus.reporting.repository.UserRepository
import com.opus.optimus.reporting.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class GetJobInfoData extends Specification{

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;
	
	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);
	
	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);
	
	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'
	def user = null;

	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);

	def setup() {

		DBObject failedFile = BasicDBObjectBuilder.start()
				.add("_id", "a6aeb541-9429-48df-974c-a26bbc25b5a2")
				.add("status", "COMPLETED_SUCCESS")
				.add("workflowType", "ETL")
				.add("projectName", "test1")
				.add("workflowName", "src1")
				.add("startedTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-01-28T00:00:00.000Z"))
				.add("sourceInfo", BasicDBObjectBuilder.start().add("source", "fatalerror.csv").get())
				.get();

		DBObject batchDefinition = BasicDBObjectBuilder.start()
				.add("_id", "5c9df4dd130db900072a110b")
				.add("workflowtype", "ETL")
				.add("project_name", "test1")
				.add("workflowname", "src1")
				.add("numberOfExpectedFiles", 1)
				.get();

		mongoTemplate.save(failedFile, "JobInfo");
		mongoTemplate.save(batchDefinition, "BatchDefinition");
		

		List<String> projects = new ArrayList<String>();
		projects.add("test1");
						
		user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		
		userRepository.findUserByEmail(_ as String) >> user;
		
		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");
		
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
	}

	def "getJobInfoProcessedDataDayWise by startDate,endDate,workflowType"() {
		given:
		userContextUtility.checkIfAdminUser() >> true
		when:
		def response = mvc.perform(
				get('/GetOverviewStats_FOR_DASHBOARD/jobinfo/getJobInfodata/Jan-25-2019/Jan-30-2019/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		JSONObject processedData = containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").getJSONArray("processedFiles").get(0);
		response.getResponse().getStatus() == 200 &&
		containerObject.getString("projectName").equals("test1") &&
		containerObject.getString("workflowName").equals("src1") &&
		containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").getInt("filesExpected") == 1 &&
		processedData.getString("fileName").equals("fatalerror.csv") &&
		containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").get("status") == true
	}
	def "getJobInfoProcessedDataDayWise by startDate,endDate,workflowType,projectName"() {
		given:
		userContextUtility.checkIfAdminUser() >> true
		when:
		def response = mvc.perform(
				get('/GetOverviewStats_FOR_DASHBOARD/jobinfo/getJobInfodata/Jan-25-2019/Jan-30-2019/ETL/test1')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		JSONObject processedData = containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").getJSONArray("processedFiles").get(0);
		response.getResponse().getStatus() == 200 &&
		containerObject.getString("projectName").equals("test1") &&
		containerObject.getString("workflowName").equals("src1") &&
		containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").getInt("filesExpected") == 1 &&
		processedData.getString("fileName").equals("fatalerror.csv") &&
		containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").get("status") == true
	}
	
	def "Exception - getJobInfoProcessedDataDayWise by startDate,endDate,workflowType,projectName"() {
		given:
		userContextUtility.checkIfAdminUser() >> true
		when:
		def response = mvc.perform(
				get('/GetOverviewStats_FOR_DASHBOARD/jobinfo/getJobInfodata/ /Jan-30-2019/ETL/test1')
				).andReturn()
		then:
		thrown NestedServletException
	}
	
	def "getJobInfoProcessedDataDayWise by startDate,endDate,workflowType - checkIfAdminUser condition false"() {
		given:
		userContextUtility.checkIfAdminUser() >> false
		when:
		def response = mvc.perform(
				get('/GetOverviewStats_FOR_DASHBOARD/jobinfo/getJobInfodata/Jan-25-2019/Jan-30-2019/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONArray newJArray = new JSONArray(response.getResponse().getContentAsString());
		JSONObject containerObject = (JSONObject) newJArray.get(0);
		JSONObject processedData = containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").getJSONArray("processedFiles").get(0);
		response.getResponse().getStatus() == 200 &&
		containerObject.getString("projectName").equals("test1") &&
		containerObject.getString("workflowName").equals("src1") &&
		containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").getInt("filesExpected") == 1 &&
		processedData.getString("fileName").equals("fatalerror.csv") &&
		containerObject.getJSONObject("statistics").getJSONObject("Jan-28-2019").get("status") == true
	}
	
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}