package com.opus.optimus.reporting.test.controller.dashboard

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.json.JSONObject
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.reporting.interceptor.LoginInterceptor
import com.opus.optimus.reporting.repository.UserRepository
import com.opus.optimus.reporting.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class FailureResult extends Specification{

	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;
	
	@SpringBean

	UserRepository userRepository = Stub(UserRepository.class);
	
	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);
	
	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'
	def user = null;
	
	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);
	
	def setup() {
		String jobResult = "{\r\n" + 
		"    \"jobId\" : \"c3c9b1cc-90f2-4eb5-9ec4-854772b3296c\",\r\n" + 
		"    \"workflowName\" : \"src\",\r\n" + 
		"    \"projectName\" : \"test\",\r\n" + 
		"    \"workflowType\" : \"ETL\",\r\n" + 
		"    \"groupId\" : \"5c9df4dd130db900072a110a\",\r\n" + 
		"    \"sourceFile\" : \"data.csv\",\r\n" + 
		"    \"stepExecutorResults\" : [ \r\n" + 
		"        {\r\n" + 
		"            \"workflowName\" : \"Workflow1\",\r\n" + 
		"            \"stepName\" : \"ebe47332-2e95-46ee-a4a8-b663307e6899\",\r\n" + 
		"            \"stepType\" : \"FileReader\",\r\n" + 
		"            \"instanceStats\" : {\r\n" + 
		"                \"0\" : {\r\n" + 
		"                    \"inbound\" : {\r\n" + 
		"                        \"dataCount\" : 20,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"outbound\" : {\r\n" + 
		"                        \"dataCount\" : 18,\r\n" + 
		"                        \"errorCount\" : 2,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"exceptionCounts\" : {},\r\n" + 
		"                    \"status\" : \"COMPLETED\"\r\n" + 
		"                },\r\n" + 
		"                \"1\" : {\r\n" + 
		"                    \"inbound\" : {\r\n" + 
		"                        \"dataCount\" : 0,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"outbound\" : {\r\n" + 
		"                        \"dataCount\" : 0,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 1,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"exceptionCounts\" : {},\r\n" + 
		"                    \"status\" : \"COMPLETED\"\r\n" + 
		"                },\r\n" + 
		"                \"2\" : {\r\n" + 
		"                    \"inbound\" : {\r\n" + 
		"                        \"dataCount\" : 0,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"outbound\" : {\r\n" + 
		"                        \"dataCount\" : 0,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"exceptionCounts\" : {},\r\n" + 
		"                    \"status\" : \"COMPLETED\"\r\n" + 
		"                },\r\n" + 
		"                \"3\" : {\r\n" + 
		"                    \"inbound\" : {\r\n" + 
		"                         \"dataCount\" : 0,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"outbound\" : {\r\n" + 
		"                        \"dataCount\" : 0,\r\n" + 
		"                        \"errorCount\" : 0,\r\n" + 
		"                        \"endCount\" : 0,\r\n" + 
		"                        \"unknownCount\" : 0\r\n" + 
		"                    },\r\n" + 
		"                    \"exceptionCounts\" : {},\r\n" + 
		"                    \"status\" : \"COMPLETED\"\r\n" + 
		"                }\r\n" + 
		"            }\r\n" + 
		"        }\r\n" + 
		"    ]\r\n" + 
		"}";

		DBObject failedJobToSave = BasicDBObjectBuilder.start()
				.add("_id", "c3c9b1cc-90f2-4eb5-9ec4-854772b3296c")
				.add("status", "COMPLETED_FAILED")
				.add("workflowType", "ETL")
				.add("projectName", "test")
				.add("workflowName", "src")
				.add("startedTime", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-01-28T00:00:00.000Z"))
				.get();
				
		DBObject dbObject = (DBObject) BasicDBObject.parse(jobResult);
		
		mongoTemplate.save(failedJobToSave, "JobInfo");
		mongoTemplate.save(dbObject,"JobResult");
		

		List<String> projects = new ArrayList<String>();
		projects.add("test");
						
		user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		
		userRepository.findUserByEmail(_ as String) >> user;
		
		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");
		

		
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
		
		userContextUtility.checkIfAdminUser() >> true

	}

	def "failureResult by startDate,endDate,workflowType"() {
		when:
		def response = mvc.perform(
				get('/GetFailureReasonCodeStats_FOR_DASHBOARD/jobinfo/failureResult/2019-01-25/2019-01-30/ETL')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString());
		response.getResponse().getStatus() == 200 && containerObject.getInt("Extraction") == 2
	}

	def "failureResult by startDate,endDate,workflowType,projectName"() {
		when:
		def response = mvc.perform(
				get('/GetFailureSummaryStats_FOR_DASHBOARD/jobinfo/failureResult/2019-01-25/2019-01-30/ETL?projectName=test')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString());
		response.getResponse().getStatus() == 200 && containerObject.getInt("Extraction") == 2
	}
	
	def "failureResult by startDate,endDate,workflowType,workflowName"() {
		when:
		def response = mvc.perform(
				get('/GetFailureSummaryStats_FOR_DASHBOARD/jobinfo/failureResult/2019-01-25/2019-01-30/ETL?workflowName=src')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString());
		response.getResponse().getStatus() == 200 && containerObject.getInt("Extraction") == 2
	}
	
	def "failureResult by startDate,endDate,workflowType,workflowName and projectname"() {
		when:
		def response = mvc.perform(
				get('/GetFailureSummaryStats_FOR_DASHBOARD/jobinfo/failureResult/2019-01-25/2019-01-30/ETL?projectName=test&workflowName=src')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		JSONObject containerObject = new JSONObject(response.getResponse().getContentAsString());
		response.getResponse().getStatus() == 200 && containerObject.getInt("Extraction") == 2
	}

	def cleanup() {
		mongoTemplate.getDb().drop(); 
	}
}
