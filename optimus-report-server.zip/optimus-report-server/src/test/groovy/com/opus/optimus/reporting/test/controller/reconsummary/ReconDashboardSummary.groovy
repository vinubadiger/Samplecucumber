package com.opus.optimus.reporting.test.controller.reconsummary

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

import java.text.SimpleDateFormat

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.TestPropertySource
import org.springframework.test.web.servlet.MockMvc

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.reporting.interceptor.LoginInterceptor
import com.opus.optimus.reporting.repository.UserRepository
import com.opus.optimus.reporting.util.UserContextUtility
import com.opus.optimus.ui.services.user.User

import spock.lang.Specification

@SpringBootTest
@AutoConfigureMockMvc
@EnableAutoConfiguration
@TestPropertySource(locations="classpath:application-test.properties")
class ReconDashboardSummary extends Specification {


	@Autowired
	protected MockMvc mvc

	@Autowired
	MongoTemplate mongoTemplate;
	
	@SpringBean
	LoginInterceptor loginInterceptor = Stub(LoginInterceptor.class);
	
	@SpringBean
	UserContextUtility userContextUtility = Stub(UserContextUtility.class);
	def user = null;
	
	@SpringBean
	UserRepository userRepository = Stub(UserRepository.class);
	
	static final String email = 'user1@gmail.com'
	static final String firstName = 'firstName'
	static final String lastName = 'lastName'

	def setup() {
		given:

		DBObject sourceASummary=BasicDBObjectBuilder.start()
				.add("totalAmount", 300.0)
				.add("stepName", "Source-A")
				.add("sourceName", "Amex")
				.add("recordCount", 100)
				.add("totalVarianceAmnt", 0.0)
				.get();
		DBObject reconObj = BasicDBObjectBuilder.start()
				.add("projectName", "test1")
				.add("activityName", "activity")
				.add("transactionDate", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2019-02-05T05:30:00.000Z"))
				.add("activityType","OneToOne")
				.add("status","RECONCILED")
				.add("subStatus", "Exact")
				.add("reconType", "POSTING")
				.add("sourceASummary", sourceASummary)
				.get();

		mongoTemplate.save(reconObj, "ReconSummaryByTrnDate");
		
		List<String> projects = new ArrayList<String>();
		projects.add("test1");
		
		user = User.builder()
		.email(email)
		.firstName(firstName)
		.lastName(lastName)
		.active(true)
		.projects(projects)
		.build()
		
		userRepository.findUserByEmail(_ as String) >> user;
		
		List<String> adminRole = new ArrayList<String>();
		adminRole.add("RECON_ADM");
		
		loginInterceptor.preHandle(_, _, _ as Object) >> true;
		
		userContextUtility.checkIfAdminUser() >> true
	}

	def "Access Recon Summary dayWise by startDate,endDate"() {

		when:
		def response = mvc.perform(
				get('/DBReportDayWise/reconDashboard/dayWise/2017-01-01/2019-04-18/')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}


	def "Access Recon Summary month wise by startDate,endDate"() {


		when:
		def response = mvc.perform(
				get('/DBReportMonthWise/reconDashboard/monthWise/2017-01-01/2019-04-18/')
				).andReturn()
		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}

	def "Access Recon Summary year wise by startDate,endDate"() {

		when:
		def response = mvc.perform(
				get('/DBReportYearWise/reconDashboard/yearWise/2017-01-01/2019-04-18/')
				).andReturn()

		then:
		println("Response Body --> " + response.getResponse().getContentAsString())
		response.getResponse().getStatus() == 200
	}
	def cleanup() {
		mongoTemplate.getDb().drop();
	}
}
