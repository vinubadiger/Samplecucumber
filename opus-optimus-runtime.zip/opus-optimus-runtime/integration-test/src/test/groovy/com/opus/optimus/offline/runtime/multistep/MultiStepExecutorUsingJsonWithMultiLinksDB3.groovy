package com.opus.optimus.offline.runtime.multistep

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.IntegrationTestConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = IntegrationTestConfiguration.class)
class MultiStepExecutorUsingJsonWithMultiLinksDB3 extends Specification {

	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	def "Reader - Writter multistep execution using JSON"() {
		setup:
		def databaseName = "local";//"samsonDb";
		def collectionNameHeader = "Header";
		def collectionNameData = "Data";
		def collectionNametemp = "temp";
		def jobId="RDWRJSONDB2_JOB"

		def mongo = new MongoClient(mongoHost, mongoPort);
		def mongoDataBase = mongo.getDatabase(databaseName);

		//Step names from json
		def Reader = "Source"
		def MongoDBWriterHeader = "DB"
		def MongoDBWriterData = "Database"
		def MongoDBWritertemp = "DBtemp"

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}
		mongoDataSource.init();

		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

		jsonStream = getClass().getResourceAsStream("/MultiStepJsonWithLinksDB3.json")
		def workflowConfig = mapper.readValue(jsonStream, WorkflowConfig.class)

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		println(getClass().getResource("/testFileForLinks.csv").getFile())

		String inputFileLocation = "./src/test/resources/testFileForLinks.csv";

		when:
		def result = localJobTaskExecutor.execute()

		def emitter = localJobTaskExecutor.getInBoundQueue(Reader).getEmitter()
		emitter.emit(messageFactory.createMessage(inputFileLocation))
		emitter.end(messageFactory.createEndMessage()) // Need to remove

		def jobTaskExecutorResult = result.get()

		then:
		notThrown(TimeoutException)

		//		For DB Header
		println("---------------------" + MongoDBWriterHeader + "-------------------------------")
		def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriterHeader).get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 2
		MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionNameHeader);
		Document searchDocument = new Document();
		searchDocument.append("NO", 111);
		println("Document Filter: " + searchDocument);
		Document searchResult = resultCollection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		searchResult != null
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()


		// For DB Data
		println("---------------------" + MongoDBWriterData + "-------------------------------")
		def receiver1 = localJobTaskExecutor.getOutBoundQueue(MongoDBWriterData).get(0).getReceiver()
		def receivedData1 = ReceiverUtil.collectDataFromReceiver(receiver1)
		receivedData1.size() == 8
		MongoCollection<Document> resultCollection1 = mongoDataBase.getCollection(collectionNameData);
		Document searchDocument1 = new Document();
		searchDocument1.append("NO", 4);
		println("Document Filter: " + searchDocument1);
		Document searchResult1 = resultCollection1.find(searchDocument1).first();
		println("Document Found: " + searchResult1);
		searchResult1 != null
		def searchCurrJobDocument1 = new Document();
		searchCurrJobDocument1.append("_jobId", jobId);
		def currJobDocuments1 = resultCollection1.find(searchCurrJobDocument1)
		receivedData1.size() == currJobDocuments1.size()


		//		for DB temp
		println("---------------------" + MongoDBWritertemp + "-------------------------------")
		def receiver2 = localJobTaskExecutor.getOutBoundQueue(MongoDBWritertemp).get(0).getReceiver()
		def receivedData2 = ReceiverUtil.collectDataFromReceiver(receiver2)
		receivedData2.size() == 0
		MongoCollection<Document> resultCollection2 = mongoDataBase.getCollection(collectionNametemp);
		println("record count: " + resultCollection2.count());
		receivedData2.size() == resultCollection2.count()

		println jobTaskExecutorResult
		cleanup:
		if (mongo != null)
			mongo.close()
	}

}