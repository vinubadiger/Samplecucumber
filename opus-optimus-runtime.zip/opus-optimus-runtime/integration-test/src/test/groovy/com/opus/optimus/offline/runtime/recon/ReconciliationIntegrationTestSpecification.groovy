package com.opus.optimus.offline.runtime.recon

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus
import com.opus.optimus.offline.configuration.IntegrationTestConfiguration
import com.opus.optimus.offline.constants.StepTypeConstants
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.db.MongoDBReaderHelper
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.PublishedWorkflowConfigService
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.WorkflowConfigRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil

import spock.lang.Specification

@ContextConfiguration(classes = IntegrationTestConfiguration.class)
class ReconciliationIntegrationTestSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	MongoDBReaderHelper mongoDBReaderHelper

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	IMessageFactory messageFactory

	@SpringBean
	IJobInfoService jobService = Mock();

	@SpringBean
	ReconCaseTemplatesRepository reconcaseTemplatesRepo = Mock()

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;
	
	@SpringBean
	SalesforceCaseHelper salesforceCaseHelper = Mock()
	
	@Autowired
	PublishedWorkflowConfigService publishedWorkflowConfigService

	def "Reconciliation All Scenarios - Success"() {
		setup:
		def activityName = "test1"
		def defaultErrorHandlerFlowName = "defaultInMemoryGlobalErrorWorkflow"
		def templateCollection = "ReconCaseTemplate"
		def sourceACollection = "srcA"
		def sourceBCollection = "srcB"
		def publishedServicesCollection = "PublishedService"
		def mapper = mapperFactory.getMapper()
		//register the data source
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}
		
		MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

		//set up embedded mongo
		def dbHostIP = mongoHost;
		def dbPort = mongoPort;

		//initialize data source factory
		mongoDataSource.init();
		dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);
		def mongoDataBase = mongoDataSource.getDatabase();

		def workflowConfigStream = getClass().getResourceAsStream("/reconTest/ReconciliationWorkflowConfig.json")
		def workflowConfig = mapper.readValue(workflowConfigStream, WorkflowConfig.class)

		def workflowExecutionConfig = new WorkflowExecutionConfig()
		//insert Amex sample records to mongo db
		loadSampleData(sourceACollection, "/reconTest/sampleSrcATransData.txt", mongoDataBase)
		loadSampleData(sourceBCollection, "/reconTest/sampleSrcBTransData.txt", mongoDataBase)
		
		//insert the templates
		loadSampleData(templateCollection, "/reconTest/sampleCaseTemplate.txt", mongoDataBase)
		
		//insert the published services
		def groupId = loadPublishedServices(publishedServicesCollection, "/reconTest/samplePublishedService.txt", mongoDataBase)

		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_2", new JobConfig(activityName, defaultErrorHandlerFlowName), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		jobService.findById(_ as String) >> { 
			return JobInfo.builder().id("JOB1").createdTime(new Date()).duplicateFileValidationCheckRequired(false)
				.errorCount(0).groupId(groupId).name("JUnitJob").projectName("test")
				.workflowName(activityName).workflowType("RECON").build();
		}
		
		mockSalesForceAuthentication()

		when:
		def result = localJobTaskExecutor.execute()
		def source1Emitter = localJobTaskExecutor.getInBoundQueue(activityName, "Source-A").getEmitter()
		def source2Emitter = localJobTaskExecutor.getInBoundQueue(activityName, "Source-B").getEmitter()

		source1Emitter.emit(messageFactory.createMessage(""))
		source2Emitter.emit(messageFactory.createMessage(""))

		source1Emitter.emit(messageFactory.createEndMessage())
		source2Emitter.emit(messageFactory.createEndMessage())

		def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

		then:
		//mock the sales forcer request
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			def parentCaseRefId = arguments[0].records[0].referenceId
			def parentCaseId = UUID.randomUUID().toString()
			def successListSalesforceCaseDetails = []
			arguments[0].records[0].childcases.eachWithIndex { childCase, caseIndex ->
				def caseId = UUID.randomUUID().toString()
				successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(caseId).caseNumber(String.valueOf(caseIndex)).referenceId(childCase.referenceId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())
			}
			successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(parentCaseId).caseNumber(String.valueOf(successListSalesforceCaseDetails.size())).referenceId(parentCaseRefId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())

			def successList = new ArrayList(successListSalesforceCaseDetails)

			return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}

		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue(activityName, "ReconStatusUpdateStepName").get(1).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 6 // One PERFECT, One MatchWithinTolerance, and Four No-Match (out of four two due to null key, as in case No match no exception thorws)
		
		workflowConfig.getStepConfigs().stream().filter { stepConfig -> StepTypeConstants.MONGO_DBREADER_STEP_TYPE.equalsIgnoreCase(stepConfig.getStepType())}.each { stepConfig ->
			def sourceCollection = ((MongoDBReaderConfig)stepConfig).getSourceDefinition().getCollectionName()
			def reconActivityName = ((MongoDBReaderConfig)stepConfig).getSourceDefinition().getActivityName()
			verifySourceRecordsForReconControlInfo(mongoDataBase, sourceCollection, reconActivityName)
		}
	}

    def "Reconciliation one-2- many - Success"() {
        setup:
        def activityName = "test1"
        def defaultErrorHandlerFlowName = "defaultInMemoryGlobalErrorWorkflow"
        def templateCollection = "ReconCaseTemplate"
        def sourceACollection = "srcA"
        def sourceBCollection = "srcB"
        def publishedServicesCollection = "PublishedService"
        def mapper = mapperFactory.getMapper()
        //register the data source
        def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)
        //change the dynamic port with meta data.
        mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
            addressMeta.setPort(mongoPort)
        }

        MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

        //set up embedded mongo
        def dbHostIP = mongoHost;
        def dbPort = mongoPort;

        //initialize data source factory
        mongoDataSource.init();
        dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);
        def mongoDataBase = mongoDataSource.getDatabase();

        def workflowConfigStream = getClass().getResourceAsStream("/reconTest/one2Many/ReconciliationWorkflowConfig.json")
        def workflowConfig = mapper.readValue(workflowConfigStream, WorkflowConfig.class)

        def workflowExecutionConfig = new WorkflowExecutionConfig()
        //insert Amex sample records to mongo db
        loadSampleData(sourceACollection, "/reconTest/one2Many/srcA.txt", mongoDataBase)
        loadSampleData(sourceBCollection, "/reconTest/one2Many/srcB.txt", mongoDataBase)

        //insert the templates
        loadSampleData(templateCollection, "/reconTest/one2Many/sampleCaseTemplate.txt", mongoDataBase)

        //insert the published services
		def groupId = loadPublishedServices_12N(publishedServicesCollection, "/reconTest/one2Many/publishedService12N.txt", mongoDataBase)

//		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_2", new JobConfig(activityName, defaultErrorHandlerFlowName), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        jobService.findById(_ as String) >> {
            return JobInfo.builder().id("JOB1").createdTime(new Date()).duplicateFileValidationCheckRequired(false)
                    .errorCount(0).groupId(groupId).name("JUnitJob").projectName("test")
                    .workflowName(activityName).workflowType("RECON").build();
        }

        mockSalesForceAuthentication()

        when:
        def result = localJobTaskExecutor.execute()
        def source1Emitter = localJobTaskExecutor.getInBoundQueue(activityName, "Source-A").getEmitter()
        def source2Emitter = localJobTaskExecutor.getInBoundQueue(activityName, "Source-B").getEmitter()

        source1Emitter.emit(messageFactory.createMessage(""))
        source2Emitter.emit(messageFactory.createMessage(""))

        source1Emitter.emit(messageFactory.createEndMessage())
        source2Emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			def parentCaseRefId = arguments[0].records[0].referenceId
            def parentCaseId = UUID.randomUUID().toString()
            def successListSalesforceCaseDetails = []
            arguments[0].records[0].childcases.eachWithIndex { childCase, caseIndex ->
                def caseId = UUID.randomUUID().toString()
                successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(caseId).caseNumber(String.valueOf(caseIndex)).referenceId(childCase.referenceId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())
            }
            successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(parentCaseId).caseNumber(String.valueOf(successListSalesforceCaseDetails.size())).referenceId(parentCaseRefId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())

            def successList = new ArrayList(successListSalesforceCaseDetails)

            return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}
		
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(activityName, "ReconStatusUpdateStepName").get(1).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1

        workflowConfig.getStepConfigs().stream().filter { stepConfig -> StepTypeConstants.MONGO_DBREADER_STEP_TYPE.equalsIgnoreCase(stepConfig.getStepType()) }.each { stepConfig ->
            def sourceCollection = ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getCollectionName()
            def reconActivityName = ((MongoDBReaderConfig) stepConfig).getSourceDefinition().getActivityName()
            verifySourceRecordsForReconControlInfo(mongoDataBase, sourceCollection, reconActivityName)
        }
    }


    def loadSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			println("db object" + dbObject)
			collection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
	}
	
	def verifySourceRecordsForReconControlInfo(def mongoDatabase, def sourceCollection, def activityName) {
		MongoCollection<Document> sourceAMgCollection = mongoDatabase.getCollection(sourceCollection);
		Document searchSourceA = new Document();
		searchSourceA.append("reconControlFields."+activityName, new Document("\$exists", true));
		println("Document Filter Source A: " + searchSourceA);
		FindIterable<Document> resultsSourceA = sourceAMgCollection.find(searchSourceA);
		println("Document Found -Source A: " + resultsSourceA);
		resultsSourceA != null
		resultsSourceA.each { document ->
			Map<String, Object> reconControlField = document.get("reconControlFields")
			Map<String, Object> activityReconControlField = reconControlField.get(activityName)
			println("activityReconControlField = > " + activityReconControlField)
			def subStatus = activityReconControlField.get("subStatus")
			def tolerance = activityReconControlField.get("tolerance")
			assert subStatus != null
			if(ReconSubStatus.MatchBeyondTolerance.name().equalsIgnoreCase(subStatus)) {
				assert tolerance != 0.0
			} else if(ReconSubStatus.Exact.name().equalsIgnoreCase(subStatus)) {
				assert tolerance == 0.0
			}
			
			// Check for null and blank field mark as No Match
			def invoiceNumber = document.get("INVOICE_NUMBER")
			if(sourceCollection == "srcA" && (invoiceNumber == null || invoiceNumber == "")) {
				assert subStatus == ReconSubStatus.NoMatch.name()
			}
			
			//only assert if the sub status is not Aged
			if(!ReconSubStatus.Aged.name().equalsIgnoreCase(subStatus)
				&& !ReconSubStatus.Exact.name().equalsIgnoreCase(subStatus)
				&& !ReconSubStatus.MatchWithinTolerance.name().equalsIgnoreCase(subStatus)) {
				Map<String, Object> caseInfo = activityReconControlField.get("caseInfo")
				assert caseInfo != null
				assert caseInfo.get("caseID") != null
				assert caseInfo.get("status").toString() == CaseStatus.OPEN.toString()
			}
		}
	}
	
	def mockSalesForceAuthentication() {
		def accessToken = "abcd1234"
		
		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();

		salesforceCaseHelper.authenticate() >> {
			return salesForceAuthResponse 
		}
	}
	
	def loadPublishedServices(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		def groupId = ""
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			collection.insertOne(dbObject)
			if (!"000000000000000000000000".equals(dbObject.get("_id").toHexString())) {
				groupId = dbObject.get("_id").toHexString()
			}
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
		return groupId
	}

	def loadPublishedServices_12N(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		def groupId = ""
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			collection.insertOne(dbObject)
			if (!"000000000000000000000001".equals(dbObject.get("_id").toHexString())) {
				groupId = dbObject.get("_id").toHexString()
			}
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
		return groupId
	}
}
