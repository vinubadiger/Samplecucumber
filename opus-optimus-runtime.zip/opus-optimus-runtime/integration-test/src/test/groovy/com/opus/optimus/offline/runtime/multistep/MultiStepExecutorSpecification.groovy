package com.opus.optimus.offline.runtime.multistep

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.datasource.ServerAddressMetadata
import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.DelimitedFieldConfig
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig
import com.opus.optimus.offline.config.fieldextractor.impl.DelimitedFieldExtractorConfig
import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig
import com.opus.optimus.offline.configuration.IntegrationTestConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.script.api.IScriptConfig
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = IntegrationTestConfiguration.class)
class MultiStepExecutorSpecification extends Specification {

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    DataSourceFactory dataSourceFactory;

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    String mongoHost;

	@Autowired
    Integer mongoPort;

    def "Linking reader - Writer step execution - new"() {
        setup:
		def databaseName = "local";
		def collectionName = "samson";
		def jobId="RDWR_JOB"

		MongoClient mongo = new MongoClient(mongoHost, mongoPort);
		MongoDatabase mongoDataBase = mongo.getDatabase(databaseName);

		List<ServerAddressMetadata> serverAddresses = new ArrayList<>();
		serverAddresses.add(ServerAddressMetadata.builder().ipAddress("localhost").port(mongoPort).build());
        MongoDataSourceMeta mongoDbDataSourceMetaData = MongoDataSourceMeta.builder()
				.dataSourceName("samsonMongoDataSource")
				.databaseType("MongoDB")
				.databaseName("local")
				.authenticationRequired(false)
				.addressMetadatas(serverAddresses).build();

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		mongoDataSource.init();

		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);
        def workflowConfig = new WorkflowConfig()

        def delimitefFileReader = "DelimitedReader"
        def mongoDBWriter = "MongoDBWriter"

        //file reader config
        List<IFieldConfig> readerFieldConfigs = new ArrayList<IFieldConfig>();
        readerFieldConfigs.add(DelimitedFieldConfig.builder().fieldIndex((short) 1)
                .name("Column1")
                .type(FieldType.STRING)
                .maxSize(24)
                .build());
        readerFieldConfigs.add(DelimitedFieldConfig.builder().fieldIndex((short) 2)
                .name("Column2")
                .type(FieldType.LONG)
                .maxSize(12)
                .build());

        DelimitedFieldExtractorConfig fieldExtractorConfig = DelimitedFieldExtractorConfig.builder()
                .sectionName("DATA")
                .delimiter(",")
                .fieldConfigs(readerFieldConfigs)
                .build();

        def fieldExtractorMap = new HashMap<String, ITextFieldExtractorConfig>();
        fieldExtractorMap.put("DATA", fieldExtractorConfig);

        ExcelScriptConfig excelScriptConfig = ExcelScriptConfig.builder()
                .conditional(true)
                .type("excel.rawtext-script")
                .formulaText("STARTSWITH(\"DR\")")
                .build();

        def sectionDetails = new HashMap<String, IScriptConfig>();
        sectionDetails.put("DATA", excelScriptConfig);

        DelimitedRecordExtractorConfig recordExtractorConfig = DelimitedRecordExtractorConfig.builder()
                .recordSeperator("\n")
                .rowsToSkip(0)
                .build();

        def delimitefFileReaderConfig = new TextFileReaderConfig(delimitefFileReader);
        delimitefFileReaderConfig.setCharEncoding("US-ASCII"); //UTF8
        delimitefFileReaderConfig.setRecordExtractorConfig(recordExtractorConfig);
        delimitefFileReaderConfig.setFieldExtractorConfig(fieldExtractorMap);
        delimitefFileReaderConfig.setSectionDetails(sectionDetails);

        //writer config
        List<MongoDBFieldConfig> writerFieldConfigs = new ArrayList<MongoDBFieldConfig>();

        writerFieldConfigs.add(MongoDBFieldConfig.builder()
                .fieldIndex((short) 1)
                .targetFieldName("Column1")
                .sourceFieldName("Column1")
                .sourceDataType(FieldType.STRING)
                .targetDataType(FieldType.STRING)
                .primaryField(true)
                .build());
        writerFieldConfigs.add(MongoDBFieldConfig.builder()
                .fieldIndex((short) 1)
                .targetFieldName("Column2")
                .sourceFieldName("Column2")
                .sourceDataType(FieldType.LONG)
                .targetDataType(FieldType.LONG)
                .primaryField(false)
                .build());

        def mongoDbWriterConfig = MongoDBWriterConfig.builder()
                .name(mongoDBWriter)
                .dataBaseType("MongoDB")
                .dataSourceName("samsonMongoDataSource")
                .collectionName(collectionName)
                .fieldConfigs(writerFieldConfigs).build();

        //update the workflow config with reader and writer configs
        workflowConfig.stepConfigs = [delimitefFileReaderConfig, mongoDbWriterConfig]
        workflowConfig.stepLinks = [new StepLink(delimitefFileReader, mongoDBWriter)]

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        String inputFileLocation = "./src/test/resources/testFile.csv";

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(delimitefFileReader).getEmitter()
        emitter.emit(messageFactory.createMessage(inputFileLocation)) // Need to remove
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get(200, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(mongoDBWriter).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 8
        MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
        Document searchDocument = new Document();
        searchDocument.append("Column2", 4l);
        println("Document Filter: " + searchDocument);
        Document searchResult = resultCollection.find(searchDocument).first();
        println("Document Found: " + searchResult);
        searchResult != null
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()


        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 2
        for (def i = 0; i < stepExecutionResults.size(); i++) {
            def stepExecResult = stepExecutionResults.get(i)
            stepExecResult.getStatus() == OperationStatus.COMPLETED
            if (stepExecResult.getStepName().equalsIgnoreCase("MongoDBWriter")) {
                stepExecResult.getInstanceStats().asList().inject(0) { sum, val -> sum + val.inbound.dataCount } == 8
                stepExecResult.getInstanceStats().asList().inject(0) { sum, val -> sum + val.outbound.dataCount } == 8
            }
        }
		cleanup:
			if (mongo != null)
				mongo.close()
	}
}