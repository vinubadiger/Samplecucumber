package com.opus.optimus.offline.runtime.multistep

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.IntegrationTestConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = IntegrationTestConfiguration.class)
class MultiStepExecutorUsingJsonWithMultiLinks extends Specification {

	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	def "Reader - Writter multistep execution using JSON"() {
		setup:
		def Reader = "Source"
		def MongoDBWriterHeader = "DB"
		def MongoDBWriterData = "Database"
		def databaseName = "local";
		def collectionNameHeader = "Header";
		def collectionNameData = "Data";
		def jobId="RDWRJSON_JOB2"

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		MongoClient mongo = new MongoClient(mongoHost, mongoPort);
		MongoDatabase mongoDataBase = mongo.getDatabase(databaseName);

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}
		mongoDataSource.init();

		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

		jsonStream = getClass().getResourceAsStream("/MultiStepJsonWithLinks.json")
		def workflowConfig = mapper.readValue(jsonStream, WorkflowConfig.class)

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		println(getClass().getResource("/testFileForLinks.csv").getFile())

		String inputFileLocation = "./src/test/resources/testFileForLinks.csv";

		when:
		def result = localJobTaskExecutor.execute()

		def emitter = localJobTaskExecutor.getInBoundQueue(Reader).getEmitter()
		emitter.emit(messageFactory.createMessage(inputFileLocation))
		emitter.end(messageFactory.createEndMessage()) // Need to remove

		def jobTaskExecutorResult = result.get()

		then:
		notThrown(TimeoutException)

		//		For DB Header
		def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriterHeader).get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 2
		MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionNameHeader);
		Document searchDocument = new Document();
		searchDocument.append("NO", 111);
		println("Document Filter: " + searchDocument);
		Document searchResult = resultCollection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		searchResult != null
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()

		println jobTaskExecutorResult

		// For DB Data
		def receiver1 = localJobTaskExecutor.getOutBoundQueue(MongoDBWriterData).get(0).getReceiver()
		def receivedData1 = ReceiverUtil.collectDataFromReceiver(receiver1)
		receivedData1.size() == 8
		MongoCollection<Document> resultCollection1 = mongoDataBase.getCollection(collectionNameData);
		Document searchDocument1 = new Document();
		searchDocument1.append("NO", 4);
		println("Document Filter: " + searchDocument1);
		Document searchResult1 = resultCollection1.find(searchDocument1).first();
		println("Document Found: " + searchResult1);
		searchResult1 != null
		Document searchCurrJobDocument1 = new Document();
		searchCurrJobDocument1.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments1 = resultCollection1.find(searchCurrJobDocument1)
		receivedData1.size() == currJobDocuments1.size()

		println jobTaskExecutorResult
		cleanup:
		if (mongo != null)
			mongo.close()

	}
}