package com.opus.optimus.offline.configuration;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.opus.optimus.offline.config.exception.EngineException;

import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.IMongodConfig;
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;
import de.flapdoodle.embed.process.runtime.Network;

@Configuration
@ComponentScan(basePackages = {"com.opus.optimus.offline", "com.opusconsulting.pegasus.formula"})
@EnableMongoRepositories({ "com.opus.optimus.offline.runtime.common.reader.repository",
		"com.opus.optimus.offline.runtime.common.writer.repository",
		"com.opus.optimus.offline.runtime.exception.repository",
		"com.opus.optimus.offline.runtime.taskmanager.mongo.repository" })
public class IntegrationTestConfiguration {

	private static final String MONGO_HOST_IP = "localhost";
	private int port = 0;
	private MongodExecutable mongodExecutable;
	private MongodProcess mongod;
	private static final Logger logger = LoggerFactory.getLogger(IntegrationTestConfiguration.class);
	
    @Bean
    public ExecutorService createExecutorService() {
        return Executors.newCachedThreadPool();
    }
    
    @Bean
    public String mongoHost() {
    	return MONGO_HOST_IP;
    }
    
    @Bean
    public Integer mongoPort() {
    	try {
			this.port = Network.getFreeServerPort();
		} catch (IOException e) {
			logger.error("Error finding the free port for embedded mongo. Default to 27018");
			this.port = 27018;
		}
    	return this.port;
    }
    
    @Bean
    public MongoClient mongo() {
        return new MongoClient(new ServerAddress(mongoHost(), mongoPort()));
    }
 
    @Bean
    public MongoTemplate mongoTemplate() throws EngineException {
        return new MongoTemplate(mongo(), "local");
    }
    
    @PostConstruct
    public void startEmbeddedMongo() throws IOException {
    	if(this.port == 0) this.port = mongoPort();
    	logger.info("Starting embedded mongo process on {}:{}", mongoHost(), this.port);
    	MongodStarter starter = MongodStarter.getDefaultInstance();
		try {
	    	IMongodConfig mongodConfig = new MongodConfigBuilder()
					.version(Version.Main.V3_5)
					.net(new Net(MONGO_HOST_IP, this.port, Network.localhostIsIPv6()))
					.build();
			this.mongodExecutable = starter.prepare(mongodConfig);
			this.mongod = mongodExecutable.start();
		} catch (IOException e) {
			logger.error("Error while stating the mongo server. Host: {}, Port: {} Error Message: {}", MONGO_HOST_IP,
					this.port, e.getMessage(), e);
			throw e;
		}
    }
    
    @PreDestroy
    public void stopEnbeddedMongo() {
    	if(this.mongod != null) {
    		this.mongod.stopInternal();
    	}
    	if(this.mongodExecutable != null) {
    		this.mongodExecutable.stop();
    	}
    }
    
    @Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate(new HttpComponentsClientHttpRequestFactory());
		final List<HttpMessageConverter<?>> messageConverters = restTemplate.getMessageConverters();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		final MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(mapper);
		// Note: here we are making this converter to process any kind of response,
		// not only application/*json, which is the default behavior
		converter.setSupportedMediaTypes(Arrays.asList(MediaType.ALL));
		messageConverters.add(converter);
		restTemplate.setMessageConverters(messageConverters);  
		return restTemplate;
	}
}
