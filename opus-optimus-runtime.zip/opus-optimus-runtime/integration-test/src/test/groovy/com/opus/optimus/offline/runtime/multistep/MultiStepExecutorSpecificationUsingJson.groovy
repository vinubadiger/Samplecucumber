package com.opus.optimus.offline.runtime.multistep

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.IntegrationTestConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = IntegrationTestConfiguration.class)
class MultiStepExecutorSpecificationUsingJson extends Specification {

    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    DataSourceFactory dataSourceFactory;

    @Autowired
    MapperFactory mapperFactory

	@Autowired
    String mongoHost;

	@Autowired
    Integer mongoPort;


    def "Reader - Writter multistep execution using JSON"() {
        setup:
		def databaseName = "local";
		def collectionName = "samson";
		def jobId="RDWRJSON_JOB"

		MongoClient mongo = new MongoClient(mongoHost, mongoPort);
		MongoDatabase mongoDataBase = mongo.getDatabase(databaseName);

		def DelimitedReader = "DelimitedReader"
        def MongoDBWriter = "MongoDBWriter"

        def mapper = mapperFactory.getMapper()
        def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
        def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta -> 
			addressMeta.setPort(mongoPort)
		}
		
        def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
        mongoDataSource.init();

        dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

        jsonStream = getClass().getResourceAsStream("/MultiStepJson.json")
        def workflowConfig = mapper.readValue(jsonStream, WorkflowConfig.class)

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        println(getClass().getResource("/testFile.csv").getFile())

        String inputFileLocation = "./src/test/resources/testFile.csv";

        when:
        def result = localJobTaskExecutor.execute()

        def emitter = localJobTaskExecutor.getInBoundQueue(DelimitedReader).getEmitter()
        emitter.emit(messageFactory.createMessage(inputFileLocation))
        emitter.end(messageFactory.createEndMessage()) // Need to remove

        def jobTaskExecutorResult = result.get()

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriter).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 8
        MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
        Document searchDocument = new Document();
        searchDocument.append("Column2", 4l);
        println("Document Filter: " + searchDocument);
        Document searchResult = resultCollection.find(searchDocument).first();
        println("Document Found: " + searchResult);
        searchResult != null
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()

        println jobTaskExecutorResult
		cleanup:
		if (mongo != null)
			mongo.close()
    }
}