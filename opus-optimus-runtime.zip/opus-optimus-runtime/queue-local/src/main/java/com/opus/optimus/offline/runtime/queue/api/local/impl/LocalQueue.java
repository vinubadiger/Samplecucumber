package com.opus.optimus.offline.runtime.queue.api.local.impl;

import com.opus.optimus.offline.runtime.queue.api.*;

import java.io.Serializable;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class LocalQueue implements IQueue, IReceiver, IEmitter {
    LocalQueueConfig config;
    BlockingQueue queue;
    AtomicBoolean abort = new AtomicBoolean(false);

    public LocalQueue(LocalQueueConfig config) {
        this.config = config;
        queue = new LinkedBlockingQueue(config.maxQueueSize);
    }

    @Override
    public IReceiver getReceiver(IReceiverConfig config) {
        return this;
    }

    @Override
    public IEmitter getEmitter(IEmitterConfig config) {
        return this;
    }

    @Override
    public <T extends Serializable> T getNext() throws Exception {
        return (T) queue.poll(config.pollTimeoutInMs, TimeUnit.MICROSECONDS);
    }

    @Override
    public <T extends Serializable> void emit(T data) {
        try {
            if (abort.get()) {
                return;
            }

            queue.put(data);
        } catch (InterruptedException e) {
            e.printStackTrace();    // TODO Need to find a way to notify the error
        }
    }

    @Override
    public <T extends Serializable> void end(T data) {
        emit(data);
    }

    @Override
    public <T extends Serializable> void abort() {
        abort.set(true);
        queue.clear();
    }

}
