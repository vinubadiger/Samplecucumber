package com.opus.optimus.offline.runtime.script.api;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME;

/**
 * The Interface IScriptConfig.
 */
@FunctionalInterface
@JsonTypeInfo(use = NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "type", visible = true)
public interface IScriptConfig {
    
    /**
     * Gets the type.
     *
     * @return the type
     */
    String getType();
    
}
