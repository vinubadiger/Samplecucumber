package com.opus.optimus.offline.runtime.script.api;

/**
 * The Interface IScript.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
@FunctionalInterface
public interface IScript<T, R> {
    
    /**
     * Execute.
     *
     * @param data the data
     * @return the r
     */
    R execute(T data);
}
