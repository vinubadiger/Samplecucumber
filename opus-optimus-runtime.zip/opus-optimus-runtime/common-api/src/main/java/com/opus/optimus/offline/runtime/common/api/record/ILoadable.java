package com.opus.optimus.offline.runtime.common.api.record;

/**
 * The Interface ILoadable.
 */
@FunctionalInterface
public interface ILoadable {
    
    /**
     * Load.
     */
    void load();
}
