package com.opus.optimus.offline.runtime.common.api.record;

/**
 * The Interface IDetachable.
 */
@FunctionalInterface
public interface IDetachable {
    
    /**
     * Detach.
     */
    void detach();
}
