package com.opus.optimus.offline.runtime.common.api.record;

import org.eclipse.collections.api.list.ImmutableList;

/**
 * The Interface ISchema.
 */
public interface ISchema {

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	String getName();

	/**
	 * Gets the fields.
	 *
	 * @return the fields
	 */
	ImmutableList<IFieldSchema> getFields();
}
