package com.opus.optimus.offline.runtime.common.api.record;

/**
 * A factory for creating IRecord objects.
 */
public interface IRecordFactory {
    
    /**
     * Creates a new IRecord object.
     *
     * @param schemaName the schema name
     * @return the i record
     */
    IRecord createRecord(String schemaName);
    
    /**
     * Register schema.
     *
     * @param schema the schema
     */
    void registerSchema(ISchema schema);
}
