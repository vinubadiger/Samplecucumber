package com.opus.optimus.offline.runtime.common.api.record;

import java.io.Serializable;

/**
 * The Interface IRecord.
 */
public interface IRecord extends Serializable {
    
    /**
     * Gets the field id.
     *
     * @param fieldName the field name
     * @return the field id
     */
    int getFieldId(String fieldName);

    /**
     * Gets the value.
     *
     * @param <T> the generic type
     * @param fieldId the field id
     * @return the value
     */
    <T> T getValue(int fieldId);

    /**
     * Sets the value.
     *
     * @param <T> the generic type
     * @param fieldId the field id
     * @param value the value
     */
    <T> void setValue(int fieldId, T value);

    /**
     * Field exists.
     *
     * @param fieldId the field id
     * @return true, if successful
     */
    boolean fieldExists(int fieldId);

    /**
     * Gets the field schema.
     *
     * @param fieldId the field id
     * @return the field schema
     */
    IFieldSchema getFieldSchema(int fieldId);

    /**
     * Gets the schema.
     *
     * @return the schema
     */
    ISchema getSchema();
}
