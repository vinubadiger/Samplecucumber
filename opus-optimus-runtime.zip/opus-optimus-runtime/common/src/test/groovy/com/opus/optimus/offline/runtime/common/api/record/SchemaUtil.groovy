package com.opus.optimus.offline.runtime.common.api.record

import com.opus.optimus.offline.runtime.common.api.record.impl.FieldSchema
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema
import org.spockframework.util.Pair

@Singleton
class SchemaUtil {
    ISchema createSchema(String name, def fields) {
        def schemaBuilder = new Schema.Builder()
                .name(name);
        fields.each {
            switch (it.second()) {
                case FieldType:
                    schemaBuilder.addField(new FieldSchema(it.first(), it.second()))
                    break
                case Pair:
                    def isCollection = it.second().first()
                    switch (it.second().second()) {
                        case FieldType:
                            schemaBuilder.addField(new FieldSchema(it.first(),
                                    isCollection,
                                    it.second().second()))
                            break
                        case List:
                            schemaBuilder.addField(new FieldSchema(it.first(),
                                    isCollection,
                                    createSchema("__inner__", it.second().second())))
                            break;
                    }
            }
        }
        return schemaBuilder.build()
    }
}
