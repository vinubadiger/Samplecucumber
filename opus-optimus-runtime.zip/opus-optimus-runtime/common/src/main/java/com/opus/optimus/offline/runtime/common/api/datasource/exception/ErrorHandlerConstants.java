package com.opus.optimus.offline.runtime.common.api.datasource.exception;

public class ErrorHandlerConstants {

	// Constants for Error handling
	public static final String ERR_UNIQUE_REC_IDS_KEY = "errorDetailsUniqueRecIds";
	public static final String ERR_ACTIVITY_NAME_KEY = "errorActivityName";
	public static final String ERR_RECON_STATUS_KEY = "errorReconStatus";
	public static final String ERR_SOURCE_A_NAME_KEY = "errorSourceA";
	public static final String ERR_SOURCE_B_NAME_KEY = "errorSourceB";
	public static final String ERR_RECON_TOLERANCE_KEY = "errorReconActualTolerance";
	public static final String ERR_RECON_SOURCE_A_ALL_NOMATCH_CNT_KEY = "sourceANoMatchCount";
	public static final String ERR_RECON_SOURCE_B_ALL_NOMATCH_CNT_KEY = "sourceBNoMatchCount";
	public static final String ERR_RECON_IS_ALL_NOMATCH_CASE_KEY = "allNoMatchCase";
	public static final String ERR_RECON_CONF_TOLERANCE_KEY = "errorReconConfiguredTolerance";
	public static final String ERR_RECON_UUID_KEY = "uniqueReconRecordRefId";
	public static final String ERR_RECON_CLOSE_CASES_KEY = "closeCases";
	public static final String ERR_ERROR_CODE_KEY = "errorCode";
	

	public static final String TEMPLATE_ACTIVITY_NAME = "activityName";
	public static final String TEMPLATE_JOB_ID = "jobId";
	public static final String TEMPLATE_JOB_DATE = "jobDate";
	public static final String TEMPLATE_SOURCE_A = "sourceA";
	public static final String TEMPLATE_SOURCE_B = "sourceB";
	public static final String TEMPLATE_SOURCE_A_TRANS = "sourceATransRecord";
	public static final String TEMPLATE_SOURCE_B_TRANS = "sourceBTransRecord";
	public static final String TEMPLATE_REASON_CODE = "reasonCode";
	public static final String TEMPLATE_ACTUAL_VARIANCE = "tolerance";
	public static final String TEMPLATE_RECON_STATUS = "reasonCode";
	public static final String TEMPLATE_MESSAGE = "message";
	public static final String TEMPLATE_SOURCE_A_NOMATCH_CNT = "srcANoMatchCnt";
	public static final String TEMPLATE_SOURCE_B_NOMATCH_CNT = "srcBNoMatchCnt";
	public static final String TEMPLATE_ALL_NOMATCH_CASE = "allNoMatchCase";
	public static final String TEMPLATE_CONFIGURED_VARIANCE = "confTolerance";
	public static final String TEMPLATE_RECON_REC_UUID = "uniqueReconRecordRefId";
	public static final String ERR_RECON_PROC_DATE_KEY = "processingDateString";
	
	public static final String ERROR_FILE_PATH = "errorFilePath";
	public static final String ERROR_EXCEPTION_TYPE = "errorExceptionType";
	

	
	
	
	
	
	
	private ErrorHandlerConstants() {
	}
}
