package com.opus.optimus.offline.runtime.common.api.record.impl;

import com.opus.optimus.offline.runtime.common.api.record.*;
import org.eclipse.collections.api.map.primitive.MutableIntObjectMap;
import org.eclipse.collections.impl.map.mutable.primitive.IntObjectHashMap;

/**
 * The Class Record.
 */
public class Record implements IRecord, ILoadable, IDetachable {
  
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The schema name. */
	String schemaName;
    
    /** The record meta data. */
    transient RecordMetaData recordMetaData;

    /** The data. */
    //MutableIntObjectMap<Object> data = new IntObjectHashMap(0);
    Object[] data = null;
    
    /**
     * Instantiates a new record.
     *
     * @param recordMetaData the record meta data
     */
    Record(RecordMetaData recordMetaData) {
        this.recordMetaData = recordMetaData;
        data = new Object[recordMetaData.getSchema().getFields().size()];
    }

    @Override
    public int getFieldId(String fieldName) {
        return recordMetaData.getFieldId(fieldName);
    }

    @Override
    public <T> T getValue(int fieldId) {
        //return (T) data.get(fieldId);
    	if (fieldId < 0 || (fieldId >= data.length)) {
    		return null;
    	}
    	
        return (T) data[fieldId];    	
    }

    @Override
    public <T> void setValue(int fieldId, T value) {
        //data.put(fieldId, value);
    	if (fieldId < 0 || (fieldId >= data.length)) {
    		throw new ArrayIndexOutOfBoundsException(fieldId);
    	}
    	
    	data[fieldId] = value;
    }

    @Override
    public boolean fieldExists(int fieldId) {
        //return data.contains(fieldId);
    	if (fieldId < 0 || (fieldId >= data.length)) {
    		return false;
    	}

    	return (data[fieldId] != null);
    }

    @Override
    public IFieldSchema getFieldSchema(int fieldId) {
        return recordMetaData.getFieldSchema(fieldId);
    }

    @Override
    public ISchema getSchema() {
        return recordMetaData.getSchema();
    }

    @Override
    public void detach() {
        schemaName = recordMetaData.getSchema().getName();
    }

    @Override
    public void load() {
        // TODO inject job related RecordFactory
        // Introduce IJobAware interface
        // job.getRecordFactory().getRecordMetaData(schemaName)
    }
}
