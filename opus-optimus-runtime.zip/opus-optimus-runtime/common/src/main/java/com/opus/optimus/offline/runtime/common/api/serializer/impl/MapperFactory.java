package com.opus.optimus.offline.runtime.common.api.serializer.impl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * A factory for creating Mapper objects.
 */
@Component
public class MapperFactory {

    /**
     * The mapper.
     */
    private final ObjectMapper mapper = new ObjectMapper();

    /**
     * The customizers.
     */
    @Autowired(required = false)
    List<IMapperCustomizer<ObjectMapper>> customizers;

    /**
     * Initialize the mapper factory.
     */
    @PostConstruct
    protected void init() {
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        if (customizers != null) {
            customizers.stream().forEach(customizer -> customizer.customize(mapper));
        }
    }

    /**
     * Gets the mapper.
     *
     * @return the mapper object
     */
    public ObjectMapper getMapper() {
        return mapper;
    }
}
