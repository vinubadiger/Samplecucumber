package com.opus.optimus.offline.runtime.common.api.record.impl;


import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.api.record.IFieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import lombok.Getter;

@Getter
public class FieldSchema implements IFieldSchema {
    
    /** The field name */
    String name;
    
    /** The field type. */
    FieldType type;
    
    /** The collection type. */
    FieldType collectionType;
    
    /** The collection or record schema. */
    ISchema collectionOrRecordSchema;

    /**
     * Instantiates a new field schema.
     *
     * @param name the name
     * @param type the type
     */
    public FieldSchema(String name, FieldType type) {
        this.name = name;
        this.type = type;

        if (type.equals(FieldType.ARRAY) || type.equals(FieldType.RECORD)) {
            throw new IllegalArgumentException("Collection or record schema expected.  Use FieldSchema(name, type, collectionOrRecordSchema) constructor");
        }
    }

    /**
     * Instantiates a new field schema.
     *
     * @param name - The field name
     * @param recordSchema - The record schema
     */
    public FieldSchema(String name, ISchema recordSchema) {
        this.name = name;
        this.type = FieldType.RECORD;
        this.collectionOrRecordSchema = recordSchema;
    }

    /**
     * Instantiates a new field schema.
     *
     * @param name - The field name
     * @param isCollection - The is collection boolean flag 
     * @param typeOrCollectionType - The type or collection type of field
     */
    public FieldSchema(String name, boolean isCollection, FieldType typeOrCollectionType) {
        this.name = name;
        this.type = isCollection ? FieldType.ARRAY : typeOrCollectionType;
        this.collectionType = isCollection ? typeOrCollectionType : null;

        if (typeOrCollectionType.equals(FieldType.ARRAY)) {
            throw new IllegalArgumentException("Collection of collection not allowed");
        }

        if ((isCollection) && (typeOrCollectionType.equals(FieldType.RECORD))) {
            throw new IllegalArgumentException("Record collection schema expected.  Use FieldSchema(name, isCollection, collectionOrRecordSchema) constructor");
        }

        if (!(isCollection) && typeOrCollectionType.equals(FieldType.RECORD)) {
            throw new IllegalArgumentException("Record collection schema expected.  Use FieldSchema(name, recordSchema) constructor");
        }
    }

    /**
     * Instantiates a new field schema.
     *
     * @param name - The field name
     * @param isCollection - The is collection boolean flag
     * @param recordSchema - The record schema
     */
    public FieldSchema(String name, boolean isCollection, ISchema recordSchema) {
        this.name = name;
        this.type = isCollection ? FieldType.ARRAY : FieldType.RECORD;
        this.collectionType = isCollection ? FieldType.RECORD : null;
        this.collectionOrRecordSchema = recordSchema;
    }
}
