package com.opus.optimus.offline.runtime.common.api.record.impl;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.common.api.record.IFieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import org.eclipse.collections.api.list.ImmutableList;
import org.eclipse.collections.api.map.primitive.ImmutableIntObjectMap;
import org.eclipse.collections.api.map.primitive.ImmutableObjectIntMap;
import org.eclipse.collections.api.map.primitive.MutableIntObjectMap;
import org.eclipse.collections.api.map.primitive.MutableObjectIntMap;
import org.eclipse.collections.impl.map.mutable.primitive.IntObjectHashMap;
import org.eclipse.collections.impl.map.mutable.primitive.ObjectIntHashMap;

/**
 * The Class RecordMetaData.
 */
public class RecordMetaData {
    
    /** The schema. */
    ISchema schema;

    /** The field name mapping. */
    transient ImmutableObjectIntMap<String> fieldNameMapping = null;
    
    /** The field mapping. */
    transient ImmutableIntObjectMap<Entry> fieldMapping = null;

    /**
     * Instantiates a new record meta data.
     *
     * @param schema the schema
     */
    public RecordMetaData(ISchema schema) {
        this.schema = schema;

        initialize(this.schema);
    }

    /**
     * Initialize.
     *
     * @param schema - The field schema
     */
    private void initialize(ISchema schema) {
        ImmutableList<IFieldSchema> fields = schema.getFields();
        if (fields == null) {
            return;
        }

        MutableObjectIntMap<String> fieldNameMappings = new ObjectIntHashMap<>();
        MutableIntObjectMap<Entry> fieldMappings = new IntObjectHashMap<>();

        fields.collectWithIndex((field, index) -> mapToEntry(index, field))
                .forEach(entry -> {
                    fieldNameMappings.put(entry.fieldSchema.getName(), entry.getFieldId());
                    fieldMappings.put(entry.getFieldId(), entry);
                });

        this.fieldMapping = fieldMappings.toImmutable();
        this.fieldNameMapping = fieldNameMappings.toImmutable();
    }

    /**
     * Map to entry.
     *
     * @param currentFieldId - The current field id
     * @param field - The field
     * @return the entry
     */
    private Entry mapToEntry(int currentFieldId, IFieldSchema field) {
        FieldType type = field.getType();

        if (type.equals(FieldType.RECORD)) {
            RecordMetaData recordMetaData = new RecordMetaData(field.getCollectionOrRecordSchema());
            return new Entry(currentFieldId, field, recordMetaData);
        }

        if (type.equals(FieldType.STRING) ||
                type.equals(FieldType.BYTES) ||
                type.equals(FieldType.INT) ||
                type.equals(FieldType.LONG) ||
                type.equals(FieldType.FLOAT) ||
                type.equals(FieldType.DOUBLE) ||
                type.equals(FieldType.BOOLEAN) ||
                type.equals(FieldType.DATETIME) ||
                type.equals(FieldType.OBJECT)) {
            return new Entry(currentFieldId, field);
        }

        throw new EngineException(type + " format not supported ...Field name : " + field.getName());
    }

    /**
     * Gets the schema.
     *
     * @return the schema
     */
    public ISchema getSchema() {
        return schema;
    }

    /**
     * Gets the field id.
     *
     * @param fieldName - The field name
     * @return the field id
     */
    public int getFieldId(String fieldName) {
        return fieldNameMapping.get(fieldName);
    }

    /**
     * Gets the field schema.
     *
     * @param fieldId - The field id
     * @return the field schema
     */
    public IFieldSchema getFieldSchema(int fieldId) {
        Entry entry = fieldMapping.get(fieldId);
        return (entry == null) ? null : entry.getFieldSchema();
    }

    /**
     * Gets the record meta data.
     *
     * @param fieldId - The field id
     * @return the record meta data
     */
    public RecordMetaData getRecordMetaData(int fieldId) {
        Entry entry = fieldMapping.get(fieldId);
        return (entry == null) ? null : entry.getRecordMetaData();
    }

    /**
     * The Class Entry.
     */
    public class Entry {
        
        /** The field id. */
        int fieldId;
        
        /** The field schema. */
        IFieldSchema fieldSchema;
        
        /** The record meta data. */
        RecordMetaData recordMetaData;

        /**
         * Instantiates a new entry.
         *
         * @param fieldId - The field id
         * @param fieldSchema - The field schema
         */
        public Entry(int fieldId, IFieldSchema fieldSchema) {
            this.fieldId = fieldId;
            this.fieldSchema = fieldSchema;
        }

        /**
         * Instantiates a new entry.
         *
         * @param fieldId - The field id
         * @param fieldSchema - The field schema
         * @param recordMetaData - The record meta data
         */
        public Entry(int fieldId, IFieldSchema fieldSchema, RecordMetaData recordMetaData) {
            this.fieldId = fieldId;
            this.fieldSchema = fieldSchema;
            this.recordMetaData = recordMetaData;
        }

        /**
         * Gets the field id.
         *
         * @return the field id
         */
        public int getFieldId() {
            return fieldId;
        }

        /**
         * Gets the field schema.
         *
         * @return the field schema
         */
        public IFieldSchema getFieldSchema() {
            return fieldSchema;
        }

        /**
         * Gets the record meta data.
         *
         * @return the record meta data
         */
        public RecordMetaData getRecordMetaData() {
            return recordMetaData;
        }
    }

}
