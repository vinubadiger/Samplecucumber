package com.opus.optimus.offline.runtime.common.api.record.impl;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * A factory for creating Record objects.
 */
@Component
public class RecordFactory implements IRecordFactory {
    
    /** The schema based record meta data. */
    Map<String, RecordMetaData> schemaBasedRecordMetaData = new ConcurrentHashMap<>();
    
    @Override
    public Record createRecord(String schemaName) {
        RecordMetaData recordMetaData = schemaBasedRecordMetaData.get(schemaName);
        if (recordMetaData == null) {
            throw new EngineException("Invalid " + schemaName + " to create the record");
        }

        return new Record(recordMetaData);
    }
    
    @Override
    public void registerSchema(ISchema schema) {
        schemaBasedRecordMetaData.put(schema.getName(), new RecordMetaData(schema));
    }

    /**
     * Gets the schema.
     *
     * @param name - The field name
     * @return the schema
     */
    public ISchema getSchema(String name) {
        RecordMetaData recordMetaData = schemaBasedRecordMetaData.get(name);
        return (recordMetaData == null) ? null : recordMetaData.getSchema();
    }
}
