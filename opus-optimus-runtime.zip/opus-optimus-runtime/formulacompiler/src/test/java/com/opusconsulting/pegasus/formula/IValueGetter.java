package com.opusconsulting.pegasus.formula;

public interface IValueGetter {
    <T> T get(IRecord record);
}
