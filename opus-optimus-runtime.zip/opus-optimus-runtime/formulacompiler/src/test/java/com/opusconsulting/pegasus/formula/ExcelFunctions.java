package com.opusconsulting.pegasus.formula;


import org.apache.commons.lang.StringUtils;

public class ExcelFunctions {
    public static String CONCAT(String... vals) {
        return StringUtils.join(vals);
    }

    public static <T> Boolean EQUAL(T lhs, T rhs) {
        return lhs == rhs;
    }

    public static String STR(int val) {
        return String.valueOf(val);
    }
}
