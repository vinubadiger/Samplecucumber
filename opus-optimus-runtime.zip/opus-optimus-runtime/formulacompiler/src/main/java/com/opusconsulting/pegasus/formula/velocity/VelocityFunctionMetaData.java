package com.opusconsulting.pegasus.formula.velocity;

import java.util.List;

public class VelocityFunctionMetaData {
    String name;
    String returnType;
    List<String> paramsWithType;
    List<String> params;
    String code;

    public VelocityFunctionMetaData(String name, String returnType, List<String> paramsWithType, List<String> params) {
        this.name = name;
        this.returnType = returnType;
        this.paramsWithType = paramsWithType;
        this.params = params;
    }

    public VelocityFunctionMetaData(String name, String returnType, List<String> paramsWithType, List<String> params, String code) {
        this(name, returnType, paramsWithType, params);
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReturnType() {
        return returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public List<String> getParamsWithType() {
        return paramsWithType;
    }

    public void setParamsWithType(List<String> paramsWithType) {
        this.paramsWithType = paramsWithType;
    }

    public List<String> getParams() {
        return params;
    }

    public void setParams(List<String> params) {
        this.params = params;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
