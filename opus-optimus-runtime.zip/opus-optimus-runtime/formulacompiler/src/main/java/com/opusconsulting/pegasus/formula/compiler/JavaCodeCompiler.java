package com.opusconsulting.pegasus.formula.compiler;

import java.io.PrintWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JavaCodeCompiler {

	private static final Logger _logger = LoggerFactory.getLogger(JavaCodeCompiler.class);

	public <T> Class<?> compile(String className, String code) {

		// JavaCompiler javac = new EclipseCompiler()
		/* For eclipse change the compiler version from project run configuration */ 
		JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
		try (StandardJavaFileManager sjfm = javac.getStandardFileManager(null, null, null)){

			SpecialClassLoader cl = new SpecialClassLoader();
			try (SpecialJavaFileManager fileManager = new SpecialJavaFileManager(sjfm, cl)){
				List<String> options = Collections.emptyList();

				List<MemorySource> compilationUnits = Arrays.asList(new MemorySource(className, code));
				// DiagnosticListener<?> dianosticListener = null
				Iterable<String> classes = null;
				Writer out = new PrintWriter(System.err);
				JavaCompiler.CompilationTask compile = javac.getTask(out, fileManager, null, options, classes, compilationUnits);
				boolean res = compile.call();
				if (res){
					return (Class<?>) cl.findClass(className);
				}
			}
		} catch (Exception e){
			_logger.error("Unable to find the class for compilation  ", e);
		}
		return null;
	}
}
