package com.opusconsulting.pegasus.formula.excel.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder;
import com.opusconsulting.pegasus.formula.exception.FormulaExceptionCodes;
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException;

/**
 * This class includes all EXCEL base function implementations used as a part of formulas
 * 
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
public class ExcelFunctions {

	private static final Logger logger = LoggerFactory.getLogger(ExcelFunctions.class);

	public static final String STATEMENT_ERROR = "Input string is null or non string type";
	public static final String STATEMENT_ERROR_NUMBER = "Input value is not numbers !";

	private static IMappingDataHolder mappingDataHolder;

	public static void setMappingDataHolder(IMappingDataHolder mappingDataHolder) {
		ExcelFunctions.mappingDataHolder = mappingDataHolder;
	}

	private ExcelFunctions() {
	}

	public static <T> boolean EXACT(T lhs, T rhs) {
		if (lhs == null || rhs == null){
			return false;
		}
		if (String.class.isAssignableFrom(lhs.getClass()) && String.class.isAssignableFrom(rhs.getClass())){
			return ((String) lhs).equalsIgnoreCase((String) rhs);
		} else{
			return lhs.equals(rhs);
		}
	}

	public static <T> String SUBSTR(T str, int startIndex, int endIndex) {
		if (str == null){
			logger.warn("Input string is null");
			return null;
		} else if (String.class.isAssignableFrom(str.getClass())){
			return ((String) str).substring(startIndex, endIndex);
		} else{
			logger.warn("Input string is not castable to string");
			return null;
		}

	}

	public static String PEEK(String sourceText, int startIndex, int endIndex) {
		if (sourceText == null || !String.class.isAssignableFrom(sourceText.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		}
		return sourceText.substring(startIndex, endIndex);
	}

	public static String CONCAT(Object ... vals) {
		StringBuilder resultBuilder = new StringBuilder();
		if (vals == null){
			logger.warn("Input string is null");
			return resultBuilder.toString();
		}
		for (Object value : vals){
			if (value != null && value.getClass().isAssignableFrom(String.class)){
				resultBuilder.append(value);
			}
		}
		return resultBuilder.toString();
	}

	public static Integer INDEXOF(Object sourceTarget, String subString) {
		if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())){
			logger.warn(STATEMENT_ERROR);
			return -1;
		}
		return ((String) sourceTarget).indexOf(subString);
	}

	public static Integer LENGTH(Object sourceTarget) {
		if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())){
			logger.warn(STATEMENT_ERROR);
			return -1;
		}
		return ((String) sourceTarget).length();
	}

	public static <T> Integer INT(T sourceTarget) {
		try{
			if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())){
				logger.warn(STATEMENT_ERROR);
				return 0;
			}
			return Integer.parseInt((String) sourceTarget);
		} catch (NumberFormatException exception){
			logger.error("Error while convereting to INT. Error message:" + exception.getMessage());
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while convereting to INT. Error message:" + exception.getMessage(), exception);
		}

	}

	public static <T> Long LONG(T sourceTarget) {
		try{
			if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())){
				logger.warn(STATEMENT_ERROR);
				return 0l;
			}
			return Long.parseLong((String) sourceTarget);
		} catch (NumberFormatException exception){
			logger.error("Error while convereting to LONG. Error message:" + exception.getMessage());
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while convereting to LONG. Error message:" + exception.getMessage(), exception);
		}
	}

	public static <T> String LOWER(T sourceTarget) {
		if (sourceTarget == null || !String.class.isAssignableFrom(sourceTarget.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		}
		return ((String) sourceTarget).toLowerCase();
	}

	public static Date NOW() {
		final ZonedDateTime now = ZonedDateTime.now();
		return Date.from(now.toInstant());
	}

	public static <T> String REPLACE(T oldStr, String matchStr, String replaceStr) {
		if (oldStr == null || !String.class.isAssignableFrom(oldStr.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		} else if (matchStr == null || replaceStr == null){
			logger.warn("Matching, replace string is null or non string type");
			return (String) oldStr;
		} else{
			return ((String) oldStr).replace(matchStr, replaceStr);
		}
	}

	public static <T> String REPLACEALL(T oldStr, String matchStr, String replaceStr) {
		if (oldStr == null || !String.class.isAssignableFrom(oldStr.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		} else if (matchStr == null || replaceStr == null){
			logger.warn("Matching, replace string is null or non string type");
			return (String) oldStr;
		} else{
			return ((String) oldStr).replaceAll(matchStr, replaceStr);
		}
	}

	public static boolean STARTSWITH(String str, String pattern) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())){
			logger.warn(STATEMENT_ERROR);
			return false;
		}
		return str.startsWith(pattern);
	}

	public static <T> String STR(T val) {
		if (val == null){
			logger.warn(STATEMENT_ERROR);
			return null;
		}
		return String.valueOf(val);
	}

	@SafeVarargs
	public static Double SUM(Object ... is) {
		if (is == null){
			logger.warn(STATEMENT_ERROR);
			return 0.0;
		} else{
			double sum = 0;
			for (Object t : is){
				try{
					sum += Double.parseDouble(t.toString());
				} catch (Exception exception){
					logger.error("Error while Sum formula. Error for:", t.toString());
					throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while Sum formula. Error message:" + exception.getMessage(), exception);
				}
			}
			return sum;
		}
	}

	public static <T> String UPPER(T str) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		}
		return ((String) str).toUpperCase();
	}

	public static <T> String TRIM(T str) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		}
		return ((String) str).trim();
	}

	public static Boolean NOT(Object bool) {
		if (bool == null || !Boolean.class.isAssignableFrom(bool.getClass())){
			logger.warn("Input is non boolean type or not produce boolean result");
			return false;
		}
		return !((boolean) bool);
	}

	public static <T> String LPAD(T str, int count, String ch) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		} else if (ch == null){
			logger.warn("Input for padding string is null or non string type");
			return (String) str;
		} else{
			StringBuilder resultBuilder = new StringBuilder();
			for (int i = 0; i < count; i++){
				resultBuilder.append(ch);
			}
			resultBuilder.append(str);
			return resultBuilder.toString();
		}
	}

	public static <T> String RPAD(T str, int count, String ch) {
		if (str == null || !String.class.isAssignableFrom(str.getClass())){
			logger.warn(STATEMENT_ERROR);
			return null;
		} else if (ch == null){
			logger.warn("Input for padding string is null or non string type");
			return (String) str;
		} else{
			StringBuilder resultBuilder = new StringBuilder();
			resultBuilder.append(str);
			for (int i = 0; i < count; i++){
				resultBuilder.append(ch);
			}
			return resultBuilder.toString();
		}
	}

	public static Date MANIPULATEDATE(Date date, String numbers, String dmy) {
		LocalDateTime dateTime = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
		try{
			int number = Integer.parseInt(numbers);
			switch (dmy) {
			case "dd":
				LocalDateTime days = dateTime.plusDays(number);
				return Date.from(days.atZone(ZoneId.systemDefault()).toInstant());
			case "MM":
				LocalDateTime month = dateTime.plusMonths(number);
				return Date.from(month.atZone(ZoneId.systemDefault()).toInstant());
			case "yyyy":
				LocalDateTime year = dateTime.plusYears(number);
				return Date.from(year.atZone(ZoneId.systemDefault()).toInstant());
			case "HH":
				LocalDateTime hours = dateTime.plusHours(number);
				return Date.from(hours.atZone(ZoneId.systemDefault()).toInstant());
			case "mm":
				LocalDateTime minutes = dateTime.plusMinutes(number);
				return Date.from(minutes.atZone(ZoneId.systemDefault()).toInstant());
			case "ss":
				LocalDateTime seconds = dateTime.plusSeconds(number);
				return Date.from(seconds.atZone(ZoneId.systemDefault()).toInstant());
			default:
				LocalDateTime blank = dateTime.plusDays(number);
				return Date.from(blank.atZone(ZoneId.systemDefault()).toInstant());
			}
		} catch (NumberFormatException exception){
			logger.error("Error while executing MANIPULATEDATE function. Input Value: {}, Specified Format: {}", numbers);
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_NUMBER_FORMAT_EXCEPTION, "Error while executing MANIPULATEDATE function. Error message:" + exception.getMessage(), exception);
		}
	}

	public static <T> Date STRTODATE(T inputDateInString, String inputDateStringFormat) {
		if (String.class.isAssignableFrom(inputDateInString.getClass())){
			try{
				SimpleDateFormat dateFormat = new SimpleDateFormat(inputDateStringFormat);
				return dateFormat.parse((String) inputDateInString);
			} catch (IllegalArgumentException exception){
				logger.error("Invalid date formate date in STRTODATE. Input Value: {}, Specified Format: {}", inputDateInString, inputDateStringFormat);
				throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Invalid date formate date in STRTODATE.. Error message:" + exception.getMessage(), exception);
			} catch (ParseException exception){
				logger.error("Error while conveting string to date in STRTODATE. Input Value: {}, Specified Format: {}", inputDateInString, inputDateStringFormat);
				throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while conveting string to date in STRTODATE.. Error message:" + exception.getMessage(), exception);
			}
		} else{
			logger.error("Error while conveting string to date in STRTODATE. Expected data type is String, Given data type is : {}, value - {}, Format - {}", inputDateInString.getClass(), inputDateInString, inputDateStringFormat);
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while conveting string to date in STRTODATE.. Error message: Expected data type is String, Given data type is : " + inputDateInString.getClass(), null);
		}

	}

	public static <T> Boolean ISEMAIL(T emailInput) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		if (!String.class.isAssignableFrom(emailInput.getClass()) || StringUtils.isEmpty(emailInput.toString())){
			logger.error(STATEMENT_ERROR);
			return false;
		} else{
			Pattern pat = Pattern.compile(emailRegex);
			return pat.matcher((String) emailInput).matches();
		}
	}

	public static <T> Boolean ISNUMBER(T inputValue) {
		if (inputValue == null){
			logger.error("Input value is null or string type");
			return false;
		} else if (Integer.class.isAssignableFrom(inputValue.getClass()) || Float.class.isAssignableFrom(inputValue.getClass()) || Double.class.isAssignableFrom(inputValue.getClass()) || Long.class.isAssignableFrom(inputValue.getClass())){
			return true;
		} else if (String.class.isAssignableFrom(inputValue.getClass())){
			String numberRegex = "^-?\\d+(,\\d+)*(\\.\\d+(e\\d+)?)?$";
			Pattern pat = Pattern.compile(numberRegex);
			return pat.matcher((String) inputValue).matches();
		} else{
			logger.error("Input value is type of: {}", inputValue.getClass());
			return false;
		}
	}

	@SafeVarargs
	public static Double MUL(Object ... is) {
		if (is == null){
			logger.warn(STATEMENT_ERROR);
			return 0.0;
		} else{
			double total = 1;
			for (Object t : is){
				try{
					total *= Double.parseDouble(t.toString());
				} catch (Exception exception){
					logger.error("Error while Multiplication formula. Error for:", t.toString());
					throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while Multiplication formula. Error message:" + exception.getMessage(), exception);
				}
			}
			return total;
		}
	}

	public static <T> Double DIV(T dividend, T divisor) {
		if (dividend == null || divisor == null){
			logger.warn(STATEMENT_ERROR);
			return 0.0;
		} else{
			double total = 0;
			try{
				total = Double.parseDouble(dividend.toString()) / Double.parseDouble(divisor.toString());
				total = BigDecimal.valueOf(total).setScale(2, RoundingMode.HALF_UP).doubleValue();
			} catch (Exception exception){
				logger.error("Error while Division formula. Error for: dividend ={} , divisor={}", dividend, divisor);
				throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while Division formula. Error message:" + exception.getMessage(), exception);
			}
			return total;
		}
	}

	@SafeVarargs
	public static Double SUB(Object ... is) {
		if (is == null){
			logger.warn(STATEMENT_ERROR);
			return 0.0;
		} else{
			double total = 0.0;
			for (Object t : is){
				try{
					if (Double.compare(total, 0.0d) == 0)
						total = Double.parseDouble(t.toString());
					else total -= Double.parseDouble(t.toString());
				} catch (Exception exception){
					logger.error("Error while Subtraction formula. Error for:", t.toString());
					throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while Subtraction formula. Error message:" + exception.getMessage(), exception);
				}
			}
			return total;
		}
	}

	public static <T> Boolean ISBLANK(T inputString) {
		return (inputString == null || inputString.toString().trim().isEmpty()) ? true : false;
	}

	public static <T> Boolean REGEX(T inputString, T pattern) {
		if (String.class.isAssignableFrom(pattern.getClass())){
			try{
				Pattern pat = Pattern.compile((String)pattern);
				return pat.matcher((String) inputString).matches();
			} catch (PatternSyntaxException exception){
				logger.error("Invalid REGEX pattern syntax, Error for: {} , {}", exception, pattern);
				throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_PATTERN_SYNTAX_EXCEPTION, "Invalid REGEX pattern syntax. Error message:" + exception.getMessage(), exception);
			} catch (Exception exception){
				logger.error("Error while REGEX formula. Error for:", exception);
				throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_GENERAL_EXCEPTION, "Error while REGEX formula. Error message:" + exception.getMessage(), exception);
			}
		} else{
			logger.error(STATEMENT_ERROR);
			return false;
		}
	}

	public static <T> Boolean COMPARE(T firstField, T operator, T secondField) {
		if (firstField == null || secondField == null){
			logger.error(STATEMENT_ERROR);
			return false;
		} else if (ISNUMBER(firstField) && ISNUMBER(secondField)){
			String tempFirstField = firstField.toString().replaceAll(",", "");
			String tempSecondField = secondField.toString().replaceAll(",", "");
			switch (operator.toString()) {
			case ">":
				return (Double.parseDouble(tempFirstField) > Double.parseDouble(tempSecondField)) ? true : false;
			case ">=":
				return (Double.parseDouble(tempFirstField) >= Double.parseDouble(tempSecondField)) ? true : false;
			case "<":
				return (Double.parseDouble(tempFirstField) < Double.parseDouble(tempSecondField)) ? true : false;
			case "<=":
				return (Double.parseDouble(tempFirstField) <= Double.parseDouble(tempSecondField)) ? true : false;
			case "=":
				return (Double.compare(Double.parseDouble(tempFirstField), Double.parseDouble(tempSecondField)) == 0) ? true : false;
			case "<>":
			case "!=":
				return (Double.compare(Double.parseDouble(tempFirstField), Double.parseDouble(tempSecondField)) != 0) ? true : false;

			default:
				logger.error("Given Operator not supported: {}", operator);
				return false;
			}
		} else{
			logger.error("Given inputs are first_field:{} second_field:{}, which is not supported.", firstField.getClass(), secondField.getClass());
			return false;
		}
	}

	/**
	 * @param lookUpSource
	 * @param lookUpKey
	 * @param lookUpValueField
	 * @return
	 */
	public static <T> String VLOOKUP(T lookUpSource, T lookUpKey, T lookUpValueField) {
		logger.debug("--------------Executing Vlook Up Formula -------------------");
		if (lookUpSource == null || lookUpKey == null || lookUpValueField == null){
			logger.error(STATEMENT_ERROR);
			return null;
		} else{
			if (!String.class.isAssignableFrom(lookUpSource.getClass()) || !String.class.isAssignableFrom(lookUpKey.getClass()) || !String.class.isAssignableFrom(lookUpValueField.getClass())){
				logger.error(STATEMENT_ERROR);
				return null;
			} else{
				logger.debug("Lookup Source - {} ,lookUpKey - {} , lookupValueField - {}", lookUpSource, lookUpKey, lookUpValueField);
				String value = (String) mappingDataHolder.getLookupValue(lookUpSource.toString(), lookUpKey.toString(), lookUpValueField.toString());
				logger.debug("Corresponding value in look up table - {}", value);
				return value;
			}
		}

	}
}
