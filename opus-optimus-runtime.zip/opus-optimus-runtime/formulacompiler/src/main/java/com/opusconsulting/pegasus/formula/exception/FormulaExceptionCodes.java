package com.opusconsulting.pegasus.formula.exception;

import java.util.HashMap;
import java.util.Map;

public final class FormulaExceptionCodes {
	
	public static final Map<String, String> CASE_REASON_CODE = new HashMap<>();
	
	public static final String FORMULA_GENERAL_EXCEPTION = "FRM-GEN-001";
	public static final String FORMULA_COMPILATION_EXCEPTION = "FRM-COM-001";
	
	public static final String FORMULA_PATTERN_SYNTAX_EXCEPTION = "FRM-PSY-001";
	public static final String FORMULA_NUMBER_FORMAT_EXCEPTION = "FRM-NUF-001";
	
	// Default
	public static final String DEFAULT = "DEFAULT";
	
	private FormulaExceptionCodes() {}
	
	
	static{
		CASE_REASON_CODE.put(FORMULA_GENERAL_EXCEPTION, "General Exception occured during Formula Execution !");
		CASE_REASON_CODE.put(FORMULA_COMPILATION_EXCEPTION, "Error while compiling given formula!");
		CASE_REASON_CODE.put(FORMULA_PATTERN_SYNTAX_EXCEPTION, "Formula pattern, Syntax exception!");
		CASE_REASON_CODE.put(FORMULA_NUMBER_FORMAT_EXCEPTION, "Number format exception in formula!");
		
		CASE_REASON_CODE.put(DEFAULT, "Default Exception. This is not properly handled in Engine. Please contact developer !");
	}
}
