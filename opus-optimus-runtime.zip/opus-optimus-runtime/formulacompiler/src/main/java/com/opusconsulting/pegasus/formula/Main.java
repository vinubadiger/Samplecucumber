package com.opusconsulting.pegasus.formula;

import org.springframework.beans.factory.annotation.Autowired;

import com.opusconsulting.optimus.core.excelformula.models.Model;
import com.opusconsulting.pegasus.formula.parser.FormulaParser;
import com.opusconsulting.pegasus.formula.parser.ParseException;

public class Main {

    @Autowired
    private FormulaParser parser;

    public Model parse(String code) throws ParseException {
        return parser.parse(code);
    }

    public static void main(String[] args) throws Exception {
        Main main = new Main();

        long startTime = System.currentTimeMillis();
        Model mdl = main.parse("STR(v1.v2, v1.v3, \"Test\")");
        System.out.println("Parse time : " + (System.currentTimeMillis() - startTime));

        startTime = System.currentTimeMillis();
        mdl = main.parse("STR(CONCAT(v1.v2, v1.v3), \"Test\")");
        System.out.println("Parse time : " + (System.currentTimeMillis() - startTime));
    }

}
