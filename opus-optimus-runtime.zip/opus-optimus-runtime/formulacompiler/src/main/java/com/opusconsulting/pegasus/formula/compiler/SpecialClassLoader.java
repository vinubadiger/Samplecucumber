package com.opusconsulting.pegasus.formula.compiler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class SpecialClassLoader extends ClassLoader {

	private static final Logger LOGGER = LoggerFactory.getLogger(SpecialClassLoader.class);

	private Map<String, MemoryByteCode> m = new HashMap<String, MemoryByteCode>();

	protected Class<?> findClass(String name) throws ClassNotFoundException {
		MemoryByteCode mbc = null;
		try{
			mbc = m.get(name);
			if (mbc == null){
				mbc = m.get(name.replace(".", "/"));
				if (mbc == null){
					return super.findClass(name);
				}
			}
			return defineClass(name, mbc.getBytes(), 0, mbc.getBytes().length);
		} catch (Exception e){
			throw new RuntimeException(e);
		}
		finally{
			if (mbc != null){
				try{
					mbc.close();
				} catch (IOException e){
					LOGGER.error(e.getMessage(), e);
				}
			}
		}
	}

	public void addClass(String name, MemoryByteCode mbc) {
		m.put(name, mbc);
	}
}