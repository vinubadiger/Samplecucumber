package com.opusconsulting.pegasus.formula.codegen.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opusconsulting.optimus.core.excelformula.models.Constant;
import com.opusconsulting.optimus.core.excelformula.models.Expression;
import com.opusconsulting.optimus.core.excelformula.models.ExpressionType;
import com.opusconsulting.optimus.core.excelformula.models.Function;
import com.opusconsulting.optimus.core.excelformula.models.Model;
import com.opusconsulting.optimus.core.excelformula.models.NumberConstant;
import com.opusconsulting.optimus.core.excelformula.models.StringConstant;
import com.opusconsulting.optimus.core.excelformula.models.Variable;
import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.GetterCode;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.INameGenerator;
import com.opusconsulting.pegasus.formula.parser.FormulaParser;
import com.opusconsulting.pegasus.formula.velocity.VelocityCodeGenInfo;
import com.opusconsulting.pegasus.formula.velocity.VelocityFunctionMetaData;
import com.opusconsulting.pegasus.formula.velocity.VelocityUtil;


@Component
public class FormulaCodeGenerator {

    private static final String FILENAME = "template/excel.vm";
    
    private static final String TYPE_FORMAT1 = "<T> T";
    
    private static final String THIS_VALUE = "this::";
    
    private static final String RETURN_OUT = "return (";
    
    private static final String BOOLEAN_RETURN_TYPE = "boolean";

    @Autowired
    FormulaParser parser;

    @Autowired
    VelocityUtil velocityUtil;

    @Autowired
    INameGenerator nameGenerator;

    public FormulaCodeInfo create(String formula, CodeMetaData codeMetaData, ICodeProvider provider) throws Exception {
        VelocityCodeGenInfo velocityCodeGenInfo = new VelocityCodeGenInfo();
        velocityCodeGenInfo.setPackageName(codeMetaData.getPackageName());

        String className = codeMetaData.getClassName();
        className = StringUtils.isEmpty(className) ? nameGenerator.getNewName() : className;
        velocityCodeGenInfo.setClassName(className);

        codeMetaData.getImplementClasses().forEach(velocityCodeGenInfo::addImplementClass);
        codeMetaData.getImports().forEach(velocityCodeGenInfo::addImport);
        velocityCodeGenInfo.setExtendClass(codeMetaData.getExtendClass());

        FunctionMetaData callFunctionMetaData = codeMetaData.getCallFunctionMetaData();
        velocityCodeGenInfo.setCallFunctionMetaData(new VelocityFunctionMetaData(callFunctionMetaData.getName(), "T".equals(callFunctionMetaData.getReturnType()) ? TYPE_FORMAT1 : callFunctionMetaData.getReturnType(),
                callFunctionMetaData.getParams().stream().map(param -> param.type + " " + param.name).collect(Collectors.toList()),
                callFunctionMetaData.getParams().stream().map(param -> param.name).collect(Collectors.toList())));

        Model model = parser.parse(formula);

        Expression expression = model.getExpression();
        String expressionCode = processExpression(expression, velocityCodeGenInfo, provider);
        velocityCodeGenInfo.setExpressionCode("return " + ("T".equals(callFunctionMetaData.getReturnType()) ? "(T) " : "") + expressionCode + ";");

        Map<String, Object> variables = new HashMap<>();
        variables.put("_", velocityCodeGenInfo);
        String code = velocityUtil.execute(FILENAME, variables);

        String qualifiedClassName = StringUtils.isEmpty(codeMetaData.getPackageName()) ? className : codeMetaData.getPackageName() + "." + className;

        return new FormulaCodeInfo(qualifiedClassName, code, codeMetaData);
    }

    private String processExpression(Expression expression, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
        
    	ExpressionType type = expression.getType();
        if (type == ExpressionType.Function) {
            return processFunction((Function) expression, velocityCodeGenInfo, provider);
        } else if (type == ExpressionType.Variable) {
            return processVariable((Variable) expression, velocityCodeGenInfo, provider);
        } else if (type == ExpressionType.Constant) {
            return processConstant((Constant) expression, velocityCodeGenInfo, provider);
        } else {
            throw new EngineException("Invalid expression type ..." +  type.getClass());
        }
    }

    private String processConstant(Constant type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
        if (type instanceof StringConstant) {
            return processStringConstant((StringConstant) type, velocityCodeGenInfo);
        } else if (type instanceof NumberConstant) {
            return processNumberConstant((NumberConstant) type, velocityCodeGenInfo);
        } else {            
        	throw new EngineException("Invalid expression type ..." +  type.getClass());
        }
    }

    private String processNumberConstant(NumberConstant value, VelocityCodeGenInfo velocityCodeGenInfo) {
        String newName = nameGenerator.getNewName().toUpperCase();
        String fractionPart = value.getFraction();
        if (StringUtils.isNotEmpty(fractionPart) ) {
            velocityCodeGenInfo.addConstantCode(getConstantCode("float", newName, value.getInteger() + "." + value.getFraction(), false));
        } else {
            velocityCodeGenInfo.addConstantCode(getConstantCode("int", newName, String.valueOf(value.getInteger()), false));
        }
        return newName;
    }

    private String processStringConstant(StringConstant value, VelocityCodeGenInfo velocityCodeGenInfo) {
        String newName = nameGenerator.getNewName().toUpperCase();
        velocityCodeGenInfo.addConstantCode(getConstantCode("String", newName, value.getValue(), false));
        return newName;
    }

    private String getConstantCode(String type, String key, String value, boolean withQuote) {
        return "private final static " + type + " " + key + " = " +
                ((withQuote) ? "\"" : "") +
                value +
                ((withQuote) ? "\"" : "") + ";";
    }

    private String processVariable(Variable type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
        GetterCode getterCode = provider.getGetterCode(type.getName());
        return getterCode.getCode();
    }

    private String processFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
        if (type.getName().equals("IF")) {
            return processIFFunction(type, velocityCodeGenInfo, provider);
        } else if(type.getName().equals("AND")){
        	return processANDFunction(type, velocityCodeGenInfo, provider);
        }else if (type.getName().equals("OR")) {
			return processORFunction(type,velocityCodeGenInfo,provider);
		} else if(type.getName().equalsIgnoreCase("CONTEXT")){
			return processCONTEXTFunction(type, velocityCodeGenInfo, provider);
		} else if(type.getName().equalsIgnoreCase("FIND_XPATH_VALUE")){
			return processFIND_XPATH_VALUEFunction(type, velocityCodeGenInfo, provider);
		} else if(isTypeRequireImplicitRequestParam(type)) {
			return processImpliciteRequestParamFunction(type, velocityCodeGenInfo, provider);
		}

        String code = type.getName();
        List<String> paramCodes = type.getParams().stream().map(param -> processExpression(param, velocityCodeGenInfo, provider)).collect(Collectors.toList());
        return code + "(" + String.join(", ", paramCodes) + ")";
    }
    
    private boolean isTypeRequireImplicitRequestParam(Function type) {
		return (type.getName().equalsIgnoreCase("STARTSWITH")
				|| type.getName().equalsIgnoreCase("PEEK")
				|| type.getName().equalsIgnoreCase("RECORDTYPE"));		
		
	}
    
	private String processImpliciteRequestParamFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo,
			ICodeProvider provider) {
    	String code = type.getName();
    	List<Expression> paramsWithRequestParam = new ArrayList<>();
    	final Variable requestVariable = new Variable();
    	requestVariable.setName("request");
    	paramsWithRequestParam.add(requestVariable);
    	paramsWithRequestParam.addAll(type.getParams());
    	List<String> paramCodes = paramsWithRequestParam.stream().map(param -> processExpression(param, velocityCodeGenInfo, provider)).collect(Collectors.toList());
		return code + "(" + String.join(", ", paramCodes) + ")";
	}

	private String processFIND_XPATH_VALUEFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo,
			ICodeProvider provider) {
    	velocityCodeGenInfo.setXpathReaderRequired(true);
    	velocityCodeGenInfo.setLambdaSupported(true);
    	
    	List<Expression> params = type.getParams();
        if (params.size() != 1) {
            throw new EngineException("FIND_XPATH_VALUE should have 1 parameter instead it has " + params.size());
        }
        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder andExpresssionBuilder = new StringBuilder("FIND_XPATH_VALUE(");
        andExpresssionBuilder.append(baseFunctionParams.stream().map(paramWithType -> paramWithType).collect(Collectors.joining(",")));
        andExpresssionBuilder.append(",");
        andExpresssionBuilder.append(
        	params.stream().map(expression -> {
	        	final StringBuilder andIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	        	andIndividualExpresssionBuilder.append(THIS_VALUE);
	        	andIndividualExpresssionBuilder.append(conditionFn);
	            
	        	VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "String", baseFunctionParamsWithType,
	                    baseFunctionParams,
	                    RETURN_OUT + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	            velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            
	            return andIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        
        andExpresssionBuilder.append(")");
        return andExpresssionBuilder.toString();
	}

	private String processANDFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
    	velocityCodeGenInfo.setLambdaSupported(true);
        velocityCodeGenInfo.setFunctionName(type.getName());
        velocityCodeGenInfo.setLogicalOperationRequired(true);
        
        List<Expression> params = type.getParams();
        if (params.size() < 2) {
            throw new EngineException("AND should have atleast 2 parameters instead it has " + params.size());
        }

        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder andExpresssionBuilder = new StringBuilder("AND(");
        andExpresssionBuilder.append(baseFunctionParams.stream().map(paramWithType -> paramWithType).collect(Collectors.joining(",")));
        andExpresssionBuilder.append(",");
        andExpresssionBuilder.append(
        	params.stream().map(expression -> {
	        	final StringBuilder andIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	        	andIndividualExpresssionBuilder.append(THIS_VALUE);
	        	andIndividualExpresssionBuilder.append(conditionFn);
	            
	        	VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, BOOLEAN_RETURN_TYPE, baseFunctionParamsWithType,
	                    baseFunctionParams,
	                    RETURN_OUT + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	            velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            
	            return andIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        
        andExpresssionBuilder.append(")");
        return andExpresssionBuilder.toString();
    }

    private String processIFFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
        velocityCodeGenInfo.setLambdaSupported(true);
        velocityCodeGenInfo.setIfSupportedRequired(true);
        
        List<Expression> params = type.getParams();
        if (params.size() != 3) {
            throw new EngineException("IF should have 3 parameters instead it has " + params.size());
        }

        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();

        String conditionFn = nameGenerator.getNewName();
        VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, BOOLEAN_RETURN_TYPE, baseFunctionParamsWithType,
                baseFunctionParams,
                RETURN_OUT + processExpression(params.get(0), velocityCodeGenInfo, provider) + ");");
        velocityCodeGenInfo.addSupportFunction(conditionMetaData);

        String trueFn = nameGenerator.getNewName();
        VelocityFunctionMetaData trueMetaData = new VelocityFunctionMetaData(trueFn, TYPE_FORMAT1, baseFunctionParamsWithType,
                baseFunctionParams,
                "return (T)(" + processExpression(params.get(1), velocityCodeGenInfo, provider) + ");");
        velocityCodeGenInfo.addSupportFunction(trueMetaData);

        String falseFn = nameGenerator.getNewName();
        VelocityFunctionMetaData falseMetaData = new VelocityFunctionMetaData(falseFn, TYPE_FORMAT1, baseFunctionParamsWithType,
                baseFunctionParams,
                "return (T)(" + processExpression(params.get(2), velocityCodeGenInfo, provider) + ");");
        velocityCodeGenInfo.addSupportFunction(falseMetaData);
        
		return "IF(this::" + conditionFn + ", this::" + trueFn + ", this::" + falseFn + ","
				+ baseFunctionParams.stream().map(paramWithType -> paramWithType).collect(Collectors.joining(","))
				+ ")";
    }
    
    private String processORFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
    	velocityCodeGenInfo.setLambdaSupported(true);
        velocityCodeGenInfo.setFunctionName(type.getName());
        velocityCodeGenInfo.setLogicalOperationRequired(true);
        
        List<Expression> params = type.getParams();
        if (params.size() < 2) {
            throw new EngineException("OR should have atleast 2 parameters instead it has " + params.size());
        }
        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder orExpresssionBuilder = new StringBuilder("OR(");
        orExpresssionBuilder.append(baseFunctionParams.stream().map(paramWithType -> paramWithType).collect(Collectors.joining(",")));
        orExpresssionBuilder.append(",");
        orExpresssionBuilder.append(
        	params.stream().map(expression -> {
	        	final StringBuilder orIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	        	orIndividualExpresssionBuilder.append(THIS_VALUE);
	        	orIndividualExpresssionBuilder.append(conditionFn);
	            
	        	VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, BOOLEAN_RETURN_TYPE, baseFunctionParamsWithType,
	                    baseFunctionParams,
	                    RETURN_OUT + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	            velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            
	            return orIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        orExpresssionBuilder.append(")");
        return orExpresssionBuilder.toString();
	}

    private String processCONTEXTFunction(Function type, VelocityCodeGenInfo velocityCodeGenInfo, ICodeProvider provider) {
    	velocityCodeGenInfo.setLambdaSupported(true);
    	velocityCodeGenInfo.setContextFunction(true);
    	velocityCodeGenInfo.addImport("com.opusconsulting.pegasus.runtime.IConstants");
        
        List<Expression> params = type.getParams();
        if (params.size() != 1) {
            throw new EngineException("CONTEXT should have 1 parameters instead it has " + params.size());
        }
        List<String> baseFunctionParamsWithType = velocityCodeGenInfo.getCallFunctionMetaData().getParamsWithType();
        List<String> baseFunctionParams = velocityCodeGenInfo.getCallFunctionMetaData().getParams();
        
        final StringBuilder orExpresssionBuilder = new StringBuilder("CONTEXT(");
        orExpresssionBuilder.append(baseFunctionParams.stream().map(paramWithType -> paramWithType).collect(Collectors.joining(",")));
        orExpresssionBuilder.append(",");
        orExpresssionBuilder.append(
        	params.stream().map(expression -> {
	        	final StringBuilder orIndividualExpresssionBuilder = new StringBuilder();
	        	String conditionFn = nameGenerator.getNewName();
	    		orIndividualExpresssionBuilder.append(THIS_VALUE);
	    		orIndividualExpresssionBuilder.append(conditionFn);
	    		
	    		VelocityFunctionMetaData conditionMetaData = new VelocityFunctionMetaData(conditionFn, "Object", baseFunctionParamsWithType,
	    		        baseFunctionParams,
	    		        RETURN_OUT + processExpression(expression, velocityCodeGenInfo, provider) + ");");
	    		velocityCodeGenInfo.addSupportFunction(conditionMetaData);
	            return orIndividualExpresssionBuilder.toString();
	        }).collect(Collectors.joining(",")));
        
        orExpresssionBuilder.append(")");
        return orExpresssionBuilder.toString();
	}
}