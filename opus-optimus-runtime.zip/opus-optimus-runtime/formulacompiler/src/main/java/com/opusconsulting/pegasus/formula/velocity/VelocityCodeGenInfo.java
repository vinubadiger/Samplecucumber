package com.opusconsulting.pegasus.formula.velocity;

import java.util.ArrayList;
import java.util.List;

public class VelocityCodeGenInfo {
    String packageName;
    String className;
    List<String> imports = new ArrayList<>();
    List<String> implementClasses = new ArrayList<>();
    String extendClass;
    String expressionCode;
    boolean lambdaSupported;
    boolean ifSupportedRequired;

    List<String> constantCodes = new ArrayList<>();
    VelocityFunctionMetaData callFunctionMetaData;
    List<VelocityFunctionMetaData> supportedFunctions = new ArrayList<>();
    
    String functionName;
    boolean logicalOperationRequired;
    
    boolean isContextFunction;
    boolean isXpathReaderRequired;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public List<String> getImports() {
        return imports;
    }

    public void addImport(String importVal) {
        if (imports.indexOf(importVal) == -1) {
            imports.add(importVal);
        }
    }

    public List<String> getImplementClasses() {
        return implementClasses;
    }

    public void addImplementClass(String implementClass) {
        if (implementClasses.indexOf(implementClass) == -1) {
            implementClasses.add(implementClass);
        }
    }

    public String getExtendClass() {
        return extendClass;
    }

    public void setExtendClass(String extendClass) {
        this.extendClass = extendClass;
    }

    public VelocityFunctionMetaData getCallFunctionMetaData() {
        return callFunctionMetaData;
    }

    public void setCallFunctionMetaData(VelocityFunctionMetaData callFunctionMetaData) {
        this.callFunctionMetaData = callFunctionMetaData;
    }

    public String getExpressionCode() {
        return expressionCode;
    }

    public void setExpressionCode(String expressionCode) {
        this.expressionCode = expressionCode;
    }

    public boolean isLambdaSupported() {
        return lambdaSupported;
    }

    public void setLambdaSupported(boolean lambdaSupported) {
        this.lambdaSupported = lambdaSupported;
    }

    public boolean isIfSupportedRequired() {
        return ifSupportedRequired;
    }

    public void setIfSupportedRequired(boolean ifSupportedRequired) {
        this.ifSupportedRequired = ifSupportedRequired;
    }

    public List<String> getConstantCodes() {
        return constantCodes;
    }

    public void addConstantCode(String constantCode) {
        constantCodes.add(constantCode);
    }

    public void addSupportFunction(VelocityFunctionMetaData functionMetaData) {
        supportedFunctions.add(functionMetaData);
    }

    public List<VelocityFunctionMetaData> getSupportedFunctions() {
        return supportedFunctions;
    }

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public boolean isLogicalOperationRequired() {
		return logicalOperationRequired;
	}

	public void setLogicalOperationRequired(boolean logicalOperationRequired) {
		this.logicalOperationRequired = logicalOperationRequired;
	}

	public boolean isContextFunction() {
		return isContextFunction;
	}

	public void setContextFunction(boolean isContextFunction) {
		this.isContextFunction = isContextFunction;
	}

	public boolean isXpathReaderRequired() {
		return isXpathReaderRequired;
	}

	public void setXpathReaderRequired(boolean isXpathReaderRequired) {
		this.isXpathReaderRequired = isXpathReaderRequired;
	}
	
	
}
