package com.opusconsulting.pegasus.formula.parser;

import org.springframework.stereotype.Component;

import com.opusconsulting.optimus.core.excelformula.models.Model;
import com.opusconsulting.optimus.core.excelgrammer.parser.ParserFacade;

import javax.annotation.PostConstruct;
import java.io.StringReader;

@Component
public class FormulaParser {

	ParserFacade parser;
	
    @PostConstruct
    private void init() {
        parser = new ParserFacade();
    }

    public Model parse(String code) throws ParseException {
    	try {
    		Model mdl = parser.parse(code);
    		if (parser.hasSyntaxErrors()) {
        		throw new ParseException();    			
    		}
    		
    		return mdl;
    	} catch (Exception e) {
    		throw new ParseException();
    	}
    }

}
