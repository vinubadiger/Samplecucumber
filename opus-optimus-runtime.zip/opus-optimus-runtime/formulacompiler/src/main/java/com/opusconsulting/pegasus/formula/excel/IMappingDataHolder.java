/**
 * 
 */
package com.opusconsulting.pegasus.formula.excel;

/**
 * @author Ranjana.Yadav
 */
public interface IMappingDataHolder {

	Object getLookupValue(String sourceName, String key, String valueFieldName);
}
