package com.opusconsulting.pegasus.formula.resource.impl.handler;

import org.springframework.stereotype.Component;

@Component
public class FormulaHandler {
    //TODO FormulaHandler implementation
	
}
