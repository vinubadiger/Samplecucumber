package com.opusconsulting.pegasus.formula.parser;

public class ParseException extends Exception {
    //Iterable<INode> syntaxErrors;

    public ParseException() {
        super("Parse exception");
        //this.syntaxErrors = syntaxErrors;
    }

/*    public Iterable<INode> getSyntaxErrors() {
        return syntaxErrors;
    }

    public void setSyntaxErrors(Iterable<INode> syntaxErrors) {
        this.syntaxErrors = syntaxErrors;
    }
*/
}
