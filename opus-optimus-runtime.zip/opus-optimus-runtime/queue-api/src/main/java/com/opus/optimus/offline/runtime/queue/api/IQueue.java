package com.opus.optimus.offline.runtime.queue.api;

public interface IQueue {
    IReceiver getReceiver(IReceiverConfig config);

    IEmitter getEmitter(IEmitterConfig config);
}
