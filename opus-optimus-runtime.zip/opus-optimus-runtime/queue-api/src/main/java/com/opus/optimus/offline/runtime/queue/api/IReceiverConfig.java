package com.opus.optimus.offline.runtime.queue.api;

public interface IReceiverConfig {
}
