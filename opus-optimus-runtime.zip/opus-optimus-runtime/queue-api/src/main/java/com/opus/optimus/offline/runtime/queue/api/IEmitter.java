package com.opus.optimus.offline.runtime.queue.api;

import java.io.Serializable;

public interface IEmitter {
    <T extends Serializable> void emit(T data);

    <T extends Serializable> void end(T data);

    <T extends Serializable> void abort();
}
