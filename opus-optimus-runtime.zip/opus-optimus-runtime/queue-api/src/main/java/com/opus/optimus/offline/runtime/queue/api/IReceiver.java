package com.opus.optimus.offline.runtime.queue.api;

import java.io.Serializable;

public interface IReceiver {
    <T extends Serializable> T getNext() throws Exception;
}
