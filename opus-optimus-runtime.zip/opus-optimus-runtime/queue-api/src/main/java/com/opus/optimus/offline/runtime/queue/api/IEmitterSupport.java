package com.opus.optimus.offline.runtime.queue.api;

public interface IEmitterSupport {
    <T extends IEmitter> void setEmitter(T emitter);
}
