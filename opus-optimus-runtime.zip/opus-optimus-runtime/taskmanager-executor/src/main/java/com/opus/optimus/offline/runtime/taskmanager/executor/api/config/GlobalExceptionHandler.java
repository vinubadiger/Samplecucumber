package com.opus.optimus.offline.runtime.taskmanager.executor.api.config;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.opus.optimus.offline.runtime.taskmanager.exception.CustomException;

@ControllerAdvice
public class GlobalExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler (Exception.class)
	public ResponseEntity<?> handleException(final Exception e) {
		logger.error("Inside Global Exception Handler");
		e.printStackTrace();
		logger.error(e.getMessage(), e);
		String message = Optional.of(e.getMessage()).orElse(e.getClass().getSimpleName());
		return new ResponseEntity<>(new CustomException(message, HttpStatus.INTERNAL_SERVER_ERROR.value()), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
