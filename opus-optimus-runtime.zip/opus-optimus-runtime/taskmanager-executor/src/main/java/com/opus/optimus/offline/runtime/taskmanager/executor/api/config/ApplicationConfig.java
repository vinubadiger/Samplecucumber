/**
 *
 */
package com.opus.optimus.offline.runtime.taskmanager.executor.api.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskReceiver;
import com.opus.optimus.offline.runtime.taskmanager.mongo.IDataSourceConfigService;
import com.opus.optimus.offline.runtime.taskmanager.mongo.datasource.DataSourceOperation;
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder;
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions;

/**
 * The Class ApplicationConfig.
 */
@Component
public class ApplicationConfig {

	/**
	 * The Constant log.
	 */
	private static final Logger log = LoggerFactory.getLogger(ApplicationConfig.class);

	public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String JDBC_URL = "jdbc:oracle:thin:@//";

	/**
	 * The task manager admin.
	 */
	@Autowired
	ITaskManagerAdmin taskManagerAdmin;

	/**
	 * The task receiver.
	 */
	@Autowired
	ITaskReceiver taskReceiver;

	/**
	 * The data source config service.
	 */
	@Autowired
	IDataSourceConfigService dataSourceConfigService;

	/**
	 * The data source factory.
	 */
	@Autowired
	DataSourceFactory dataSourceFactory;

	/**
	 * The script creator factory.
	 */
	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	@Autowired
	IJobInfoService jobInfoService;

	@Autowired
	IMappingDataHolder mappingDataHolder;
	
	@Autowired
	DataSourceOperation dataSourceOperation;

	/**
	 * Load configs.
	 */
	@PostConstruct
	private void loadConfigs() {
		log.debug("Building and registering data source factories..");
		dataSourceOperation.buildAndRegisterDataSourceFactory();

		log.debug("Starting Task manager..");
		startTaskExecutor();

		log.debug("Updating the status of previously hanged Jobs..");
		updateInProgressJobs();

		log.debug("Testing Script engine..");
		testClasspathIssue();

		log.debug("Initialising data mapping holder for look up table");
		initializeExcelFunctions(mappingDataHolder);
	}

	public void initializeExcelFunctions(IMappingDataHolder mappingDataHolder) {
		ExcelFunctions.setMappingDataHolder(mappingDataHolder);
	}

	/**
	 * 
	 */
	private void updateInProgressJobs() {
		log.debug("Updating Job Status...");
		jobInfoService.updateInProgressJobs();
	}

	/**
	 * Start task manager.
	 */
	private void startTaskExecutor() {
		try{
			taskReceiver.start();
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}
	
	@PreDestroy
	public void destroy() {
		dataSourceOperation.releaseDataSource();
	}

	/**
	 * Test classpath issue.
	 */
	// TODO TO be removed
	private void testClasspathIssue() {
		try{
			String formulaText = "PEEK(5,13)";
			String rawText = "DT10020181601TESTOPUS";

			IScriptConfig excelScriptConfig = ExcelScriptConfig.builder().formulaText(formulaText).conditional(false).type("excel.rawtext-script").build();

			IScript<? super String, ?> valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig);
			if (valueProviderScript != null){
				String output = (String) valueProviderScript.execute(rawText);
				log.debug("Formula output: {}", output);
			}
		} catch (EngineException e){
			throw e;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

}
