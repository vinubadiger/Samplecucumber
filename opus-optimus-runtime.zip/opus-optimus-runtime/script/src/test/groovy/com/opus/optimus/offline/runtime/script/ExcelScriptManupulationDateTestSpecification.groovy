package com.opus.optimus.offline.runtime.script

import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.core.CollectionOptions
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.script.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.script.util.Utility
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconSummaryByTrnDateRepo
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.DataSourceConfigAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.JobInfoAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.PublishedWorkflowConfigAuditRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.test.TestMessageFactory
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException

import spock.lang.Ignore
import spock.lang.Specification


/**
 * Test class for testing MANIPULATEDATE function
 * 
 * @author Yashkumar.Thakur
 *
 */
class ExcelScriptManupulationDateTestSpecification extends AbstractScriptSpecification { 

	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	@Autowired
	TestMessageFactory messageFactory

	@Autowired
	@Qualifier("scriptUtility")
	Utility utility;

	@Autowired
	MongoTemplate mongoTemplate;

	
	def "ExcelScript IRecordCondition MANIPULATEDATE for Date for minus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"-4\",\"dd\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusDays(-4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for Date for plus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"dd\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusDays(4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for year minus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"-4\",\"yyyy\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusYears(-4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for year plus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"yyyy\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusYears(4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for month minus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"-4\",\"MM\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusMonths(-4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for month plus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"MM\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusMonths(4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for hr minus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"-4\",\"HH\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusHours(-4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for hr plus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"HH\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusHours(4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for minut minus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"-4\",\"mm\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		result.toString() != localDate.toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for minut plus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"mm\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		result.toString() != localDate.toString();
	}
	
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for second minus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"-4\",\"ss\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		result.toString() != localDate.toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE for second plus execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"ss\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		result.toString() != localDate.toString();
	}
	
	
	def "ExcelScript IRecordCondition MANIPULATEDATE invalid datetime obj execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4\",\"yk\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		conditionScript != null
		println(result)
		LocalDateTime localDate = LocalDateTime.now();
		LocalDateTime days = localDate.plusDays(4);
		result.toString() == (Date.from(days.atZone(ZoneId.systemDefault()).toInstant())).toString();
	}
	
	def "ExcelScript IRecordCondition MANIPULATEDATE invalid date displacement execution"() {
		setup:
		def formulaText = "MANIPULATEDATE(NOW(),\"4s\",\"yk\")";
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:

		if(conditionScript != null)
			result = conditionScript.execute(null)
		then:
		thrown FormulaExecutionException
	}
	
	
}
