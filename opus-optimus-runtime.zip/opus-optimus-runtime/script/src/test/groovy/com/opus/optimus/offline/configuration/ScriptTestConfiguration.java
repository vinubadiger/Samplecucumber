package com.opus.optimus.offline.configuration;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.MappingDataHolder;
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder;
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions;

import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.IMongodConfig;
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;
import de.flapdoodle.embed.process.runtime.Network;

@Configuration
@PropertySource ("classpath:application-junit.properties")
@ComponentScan (basePackages = { "com.opus.optimus.offline", "com.opusconsulting.pegasus.formula" })
@EnableMongoRepositories ({ "com.opus.optimus.offline.runtime.common.reader.repository", "com.opus.optimus.offline.runtime.common.writer.repository" })
public class ScriptTestConfiguration {

	private static final String MONGO_HOST_IP = "localhost";
	private int port = 0;
	private MongodExecutable mongodExecutable;
	private MongodProcess mongod;
	private static final Logger logger = LoggerFactory.getLogger(ScriptTestConfiguration.class);

	@Autowired
	@Lazy
	IMappingDataHolder mappingDataHolder;

	@Value ("${vlook.mapping.lookUpSources}")
	private String lookUpSourceList;

	@Bean
	public MongoClient mongo() {
		return new MongoClient(new ServerAddress(MONGO_HOST_IP, port));
	}

	@Bean
	public MongoTemplate mongoTemplate() {
		return new MongoTemplate(mongo(), "local");
	}

	@Bean
	public String mongoHost() {
		return MONGO_HOST_IP;
	}

	@Bean
	public Integer mongoPort() {
		try{
			this.port = Network.getFreeServerPort();
		} catch (IOException e){
			logger.error("Error finding the free port for embedded mongo. Default to 27018");
			this.port = 27018;
		}
		return this.port;
	}

	@PostConstruct
	public void init() throws IOException {
		startEmbeddedMongo();

		vlookUpSetup();
	}

	private void vlookUpSetup() {
		MongoTemplate mongotemplate = new MongoTemplate(mongo(), "local");
		List<String> lookUpSources = Arrays.asList(lookUpSourceList.split(","));
		lookUpSources.forEach(lookUpTable -> {
			if (!mongotemplate.collectionExists(lookUpTable)){
				mongotemplate.createCollection(lookUpTable);
			}
		});

		DBObject mappingTable = BasicDBObjectBuilder.start().add("_id", "5caef7b0ad3c44999512e4fc").add("key", "5460732563").add("EquivalentValue", "1234").add("Detail", "this is for test of vlook up").get();

		mongotemplate.save(mappingTable, "MID_LOOKUP_TABLE");

		ExcelFunctions.setMappingDataHolder(mappingDataHolder);
	}

	public void startEmbeddedMongo() throws IOException {
		if (this.port == 0) this.port = mongoPort();
		logger.info("Starting embedded mongo process on {}:{}", mongoHost(), this.port);
		MongodStarter starter = MongodStarter.getDefaultInstance();
		try{
			IMongodConfig mongodConfig = new MongodConfigBuilder().version(Version.Main.V3_5).net(new Net(MONGO_HOST_IP, this.port, Network.localhostIsIPv6())).build();
			this.mongodExecutable = starter.prepare(mongodConfig);
			this.mongod = mongodExecutable.start();
		} catch (IOException e){
			logger.error("Error while stating the mongo server. Host: {}, Port: {} Error Message: {}", MONGO_HOST_IP, this.port, e.getMessage(), e);
			throw e;
		}
	}

	@PreDestroy
	public void stopEnbeddedMongo() {
		if (this.mongod != null){
			this.mongod.stopInternal();
		}
		if (this.mongodExecutable != null){
			this.mongodExecutable.stop();
		}
	}

	@Bean
	public IMappingDataHolder initializeExcelFunctions() {
		return new MappingDataHolder();
	}

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		final List<HttpMessageConverter<?>> messageConverters = restTemplate.getMessageConverters();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		final MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(mapper);
		// Note: here we are making this converter to process any kind of response,
		// not only application/*json, which is the default behavior
		converter.setSupportedMediaTypes(Arrays.asList(MediaType.ALL));
		messageConverters.add(converter);
		restTemplate.setMessageConverters(messageConverters);
		return restTemplate;
	}

	@Bean
	public ExecutorService createExecutorService() {
		return Executors.newCachedThreadPool();
	}

}
