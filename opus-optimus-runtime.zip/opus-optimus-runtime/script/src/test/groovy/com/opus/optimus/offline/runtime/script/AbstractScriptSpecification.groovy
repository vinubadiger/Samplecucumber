package com.opus.optimus.offline.runtime.script

import org.spockframework.spring.SpringBean
import org.springframework.context.annotation.PropertySource
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconSummaryByTrnDateRepo
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.DataSourceConfigAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.JobInfoAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.PublishedWorkflowConfigAuditRepository

import spock.lang.Specification

@ContextConfiguration(classes= ScriptTestConfiguration.class)
class AbstractScriptSpecification extends Specification {
	@SpringBean
	DataSourceConfigRepository dataSourceConfigRepository = Mock()

	@SpringBean
	JobInfoRepository jobInfoRepository = Mock()

	@SpringBean
	JobErrorDetailsRepository jobErrorDetailsRepository = Mock()

	@SpringBean
	PublishedWorkflowConfigRepository publishedWorkflowConfigRepository = Mock()

	@SpringBean
	ReconAcitivitySummaryRepository reconAcitivitySummaryRepository = Mock()

	@SpringBean
	JobResultRepository jobResultRepository = Mock()
	
	@SpringBean
	ReconCaseTemplatesRepository reconCaseTemplatesRepository = Mock()
	
	@SpringBean
	ReconSummaryByTrnDateRepo reconSummaryByTrnDateRepo = Mock()
	
	@SpringBean
	DataSourceConfigAuditRepository dataSourceConfigAuditRepository = Mock()
	
	@SpringBean
	PublishedWorkflowConfigAuditRepository publishedWorkflowConfigAuditRepository = Mock()
	
	@SpringBean
	JobInfoAuditRepository jobInfoAuditRepository = Mock()
}
