package com.opus.optimus.offline.runtime.script

import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.core.CollectionOptions
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords
import com.opus.optimus.offline.config.exception.EngineException
import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.script.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.script.util.Utility
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconSummaryByTrnDateRepo
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.DataSourceConfigAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.JobInfoAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.PublishedWorkflowConfigAuditRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.test.TestMessageFactory
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException

import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

class ExcelScriptTestSpecificationForFx extends AbstractScriptSpecification {

	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	@Autowired
	@Qualifier("scriptUtility")
	Utility utility;

	@Autowired
	TestMessageFactory messageFactory

	def "ExcelScript for null object"() {
		setup:
		def formulaText = "IF(EXACT(transType, \"settlement\"), \"0\", \"1\")"
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-scrisadpt").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "settlement");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		when:
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)

		then:
		thrown EngineException
	}

	@Unroll
	def "#RECORDCONDITION"() {
		setup:
		def formulaText = formula
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(condition)
				.type(formulatype).build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "settlement");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		when:
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)

		then:
		thrown expectedOutput

		where:
		RECORDCONDITION | formulatype | condition | formula |expectedOutput
		"RECORDCONDITION excel.IRecord-script execution T" | "excel.IRecord-script" | true | "INT(\"12g3\")" |FormulaExecutionException
		"RECORDCONDITION excel.IRecord-script execution F" | "excel.IRecord-script" | false | "STARTSWITH(TEXT1)" |FormulaExecutionException
	}


	@Unroll
	def "#IMESSAGE"() {
		setup:
		def formulaText = formula
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(condition)
				.type(formulatype).build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "settlement");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, recordName);
		IMessage message = messageFactory.createMessage(null);

		when:
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(message)

		then:
		thrown expectedOutput

		where:
		IMESSAGE | formulatype | condition | formula |expectedOutput | recordName
		"IMESSAGE excel.imessage-script execution T" | "excel.imessage-script" | true | "RECORDTYPE()" |FormulaExecutionException | "data"
		"IMESSAGE excel.imessage-script execution F" | "excel.imessage-script" | false | "RECORDTYsPE()" |FormulaExecutionException | "data"
	}

	@Unroll
	def "#RAWRECORD"() {
		setup:
		def formulaText = formula
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(condition)
				.type(formulatype).build()

		def record = null;

		when:
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)

		then:
		thrown expectedOutput

		where:
		RAWRECORD | formulatype | condition | formula |expectedOutput
		"RECORDCONDITION excel.rawtext-script execution T" | "excel.rawtext-script" | true | "STARTSWITH(TEXT1)" | FormulaExecutionException
		"RECORDCONDITION excel.rawtext-script execution F" | "excel.rawtext-script" | false | "STARTSWITH(TEXT1)" | FormulaExecutionException
	}
}
