package com.opus.optimus.offline.runtime.script

import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.core.CollectionOptions
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords
import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.script.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.script.util.Utility
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconSummaryByTrnDateRepo
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.DataSourceConfigAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.JobInfoAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.PublishedWorkflowConfigAuditRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.test.TestMessageFactory
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException

import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

class ExcelScriptTestSpecification extends AbstractScriptSpecification {

	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	@Autowired
	TestMessageFactory messageFactory

	@Autowired
	@Qualifier("scriptUtility")
	Utility utility;

	@Autowired
	MongoTemplate mongoTemplate;

	//	SUBSTR execution for valid data
	def "ExcelScript IRecordValueProvider SUBSTR execution"() {
		setup:
		def formulaText = "SUBSTR(processingCode, 0, 2)"
		def fieldName = "processingCode"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "100000");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		result == "10"
	}

	//	SUBSTR execution for null data
	def "ExcelScript IRecordValueProvider SUBSTR execution for null data "() {
		setup:
		def formulaText = "SUBSTR(processingCode, 0, 2)"
		def fieldName = "processingCode"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, null);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		result == null
	}

	//	SUBSTR execution for date time data
	def "ExcelScript IRecordValueProvider SUBSTR execution for date time data"() {
		setup:
		def formulaText = "SUBSTR(processingDate, 0, 2)"
		def fieldName = "processingDate"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, LocalDateTime.now());
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		result == null
	}


	def "ExcelScript IRecordCondition PEEK execution"() {
		setup:
		def formulaText = "PEEK(5,13)"
		def rawText = "DT10020181601TESTOPUS"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.rawtext-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueProviderScript != null)
			result = valueProviderScript.execute(rawText)
		then:
		valueProviderScript != null
		result == "20181601"
	}

	@Unroll
	def "#testCase"() {
		setup:
		def formulaText = "PEEK(5,13)"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.rawtext-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueProviderScript != null)
			result = valueProviderScript.execute(testData)
		then:
		valueProviderScript != null
		result == expectedOutput

		where:
		testCase | testData | expectedOutput
		"Valid execution" | "DT10020181601TESTOPUS" | "20181601"
		"InValid execution" | null | null
	}

	@Unroll
	def "#CONCAT"() {
		setup:
		def formulaText = formula
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData );
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		CONCAT | formula | testData| expectedOutput
		"CONCAT Valid execution" | "CONCAT(Name,\"Recon\")" |"Opus" | "OpusRecon"
		"CONCAT Invalid execution" | "CONCAT(Name)" |null | ""
	}


	@Unroll
	def "#INDEXOF"() {
		setup:
		def formulaText = "INDEXOF(Name,\"P\")"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData );
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		INDEXOF | testData | expectedOutput
		"Valid execution" | "OPUS-RECON-2019" | 1
		"Invalid execution" | null | -1
	}

	@Unroll
	def "#LENGTH"() {
		setup:
		def formulaText = "LENGTH(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		LENGTH | testData | expectedOutput
		"ExcelScript IRecordCondition LENGTH execution" | "OPUS-RECON-2019" | 15
		"Invalid execution" | null | -1
	}

	def "ExcelScript IRecordCondition INT execution foe exception"() {
		setup:
		def formulaText = "INT(Age)"
		def fieldName = "Age"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "abc");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		thrown FormulaExecutionException
	}

	@Unroll
	def "#INT"() {
		setup:
		def formulaText = "INT(Age)"
		def fieldName = "Age"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput
		result.getClass() == expectedClass

		where:
		INT | inputData | expectedOutput | expectedClass
		"ExcelScript IRecordCondition INT execution" | "10" | 10 | java.lang.Integer
		"INT execution with null" | null | 0 | java.lang.Integer
	}


	def "ExcelScript IRecordCondition LONG execution for exception"() {
		setup:
		def formulaText = "LONG(Age)"
		def fieldName = "Age"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "yk");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		thrown FormulaExecutionException
	}

	@Unroll
	def "#LONG"() {
		setup:
		def formulaText = "LONG(Age)"
		def fieldName = "Age"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput
		result.getClass() == expectedClass

		where:
		LONG | inputData | expectedOutput | expectedClass
		"ExcelScript IRecordCondition LONG execution" | "35" | 35 | java.lang.Long
		"LONG execution with null" | null | 0 | java.lang.Long
	}

	@Unroll
	def "#LOWER"() {
		setup:
		def formulaText = "LOWER(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedData

		where:
		LOWER | testData | expectedData
		"ExcelScript IRecordCondition LOWER execution" | "Opus-Y-Recon-K." | "opus-y-recon-k."
		"LOWER execution for null" | null | null
	}

	@Unroll
	def "#UPPER"() {
		setup:
		def formulaText = "UPPER(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedData

		where:
		UPPER | testData | expectedData
		"ExcelScript IRecordCondition UPPER execution" | "Opus-Y-Recon-K." | "OPUS-Y-RECON-K."
		"UPPER execution for null" | null | null
	}

	def "ExcelScript IRecordCondition NOW execution"() {
		setup:
		def formulaText = "NOW()"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build();
		DateTimeFormatter dtfs = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm:ss");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
		SimpleDateFormat mdyFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm");
		LocalDateTime now = LocalDateTime.now();

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(now)
		println(mdyFormat.format(result))
		(dtfs.format(now))!=null
		(dtf.format(now))==(mdyFormat.format(result))
	}

	@Unroll
	def "#REPLACE"() {
		setup:
		def formulaText = testDataFormula
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		REPLACE | testDataFormula | testData | expectedOutput
		"REPLACE valid execution" | "REPLACE(Name,\"Mr.\",\" \")" | "Mr.John Willy" | " John Willy"
		"REPLACE execution with null input" | "REPLACE(Name,\"Mr.\",\" \")" | null | null
		"REPLACE execution with null matching" | "REPLACE(\"Mr.John Willy\",Name,\" \")" | null | "Mr.John Willy"
	}

	@Unroll
	def "#REPLACEALL"() {
		setup:
		def formulaText = testDataFormula
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, testData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		REPLACEALL | testDataFormula | testData | expectedOutput
		"REPLACEALL valid execution" | "REPLACEALL(Web,\"com\",\"net\")" | "Our .com site : https://www.opusconsulting.com" | "Our .net site : https://www.opusconsulting.net"
		"REPLACEALL execution with null input" | "REPLACEALL(Web,\"com\",\"net\")" | null | null
		"REPLACEALL execution with null matching" | "REPLACEALL(\"Our .com site : https://www.opusconsulting.com\",Web,\"net\")" | null |"Our .com site : https://www.opusconsulting.com"
	}


	@Unroll
	def "#STR"() {
		setup:
		def formulaText = "STR(Contacts)"
		def fieldName = "Contacts"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(inputDataType)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName,inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput
		result.getClass() == expectedClass

		where:
		STR | inputData | inputDataType | expectedOutput | expectedClass
		"STR valid execution for long" | 8983112800l |FieldType.LONG | "8983112800" | java.lang.String
		"STR valid execution for int" | 898311 |FieldType.INT | "898311" | java.lang.String
		"STR valid execution for float" | 8983.11f |FieldType.FLOAT | "8983.11" | java.lang.String
		"STR Invalid execution for null" | null |FieldType.STRING | null | org.codehaus.groovy.runtime.NullObject

	}


	def "ExcelScript IRecordCondition SUM execution for exception"() {
		setup:
		def formulaText = "SUM(\"5.5\",\"abc\",\"8\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		thrown Exception
	}

	@Unroll
	def "#SUM"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "no"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(inputDataType)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName,inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedoutput

		where:
		SUM | inputFormula | inputDataType | inputData | expectedoutput
		"SUM valid execution" | "SUM(\"5.5\",\"6.0\",\"8\")" | FieldType.STRING | null | 19.5
		"SUM Invalid execution" | "SUM(no)" |FieldType.STRING | null |  0.0
	}

	def "ExcelScript IRecordCondition TRIM execution"() {
		setup:
		def formulaText = "TRIM(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "      Opus-Y-Recon-K.        ");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "Opus-Y-Recon-K."
	}

	@Unroll
	def "#TRIM"() {
		setup:
		def formulaText = "TRIM(Name)"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		TRIM | inputData | expectedOutput
		"TRIM valid execution" | "      Opus-Y-Recon-K.        " | "Opus-Y-Recon-K."
		"TRIM valid execution" | null | null
	}

	def "ExcelScript IRecordCondition Right PAD execution"() {
		setup:
		def formulaText = "RPAD(Name,10,\"0\")"
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "Alex");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == "Alex0000000000"
	}

	@Unroll
	def "#RPAD"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		RPAD | inputFormula| inputData | expectedOutput
		"RPAD Valid execution" | "RPAD(Name,10,\"0\")" | "Alex" | "Alex0000000000"
		"RPAD InValid execution replace char" | "RPAD(\"Alex\",10,Name)" | null | "Alex"
		"RPAD InValid execution for null input" | "RPAD(Name,10,\"0\")" | null | null
	}

	@Unroll
	def "#LPAD"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "Name"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		LPAD | inputFormula | inputData | expectedOutput
		"LPAD Valid execution" | "LPAD(Name,10,\"0\")" | "Alex" | "0000000000Alex"
		"LPAD InValid execution for null replace char" | "LPAD(\"Alex\",10,Name)" | null | "Alex"
		"LPAD InValid execution for null input" | "LPAD(Name,10,\"0\")" | null | null
	}

	def "ExcelScript IRecordCondition Literal execution"() {
		setup:
		def formulaText = "\"settlement\""
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueScript != null)
			result = valueScript.execute(null)
		then:
		valueScript != null
		result == "settlement"
	}

	def "ExcelScript IRecordCondition STRTODATE execution"() {
		setup:
		def formulaText = "STRTODATE(\"06-Dec-18\",\"dd-MMM-yy\")"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueScript != null) {
			try {
				result = valueScript.execute(null)
			} catch(Exception e) {
				//e.printStackTrace()
			}
		}
		then:
		valueScript != null
		println(result)
		(result instanceof java.util.Date) == true
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.DAY_OF_MONTH) == 06
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.MONTH_OF_YEAR) == 12
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.YEAR) == 2018
	}

	@Unroll
	def "#STRTODATEException"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "date"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(inputDataType)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueScript != null) {
			result = valueScript.execute(record)
		}
		then:
		thrown expectedException

		where:
		STRTODATEException | inputFormula | expectedException | inputDataType |inputData
		"STRTODATE Invalid date time field" |  "STRTODATE(\"abc\",\"dd-MMM-yy\")" | FormulaExecutionException | FieldType.STRING | null
		"STRTODATE Invalid date time parse" |  "STRTODATE(date,\"MMM-dd-yy\")" | FormulaExecutionException | FieldType.DATETIME | LocalDateTime.now()
		"STRTODATE Invalid formate" |  "STRTODATE(\"06-Dec-18\",\"aabcs\")" | FormulaExecutionException | FieldType.STRING | null
	}

	@Unroll
	def "#STRTODATE"() {
		setup:
		def formulaText = inputFormula
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = "";
		if(valueScript != null) {
			try {
				result = valueScript.execute(null)
			} catch(Exception e) {
			}
		}
		then:
		valueScript != null
		println(result)
		(result instanceof java.util.Date) == true
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.DAY_OF_MONTH) == eOMONTH
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.MONTH_OF_YEAR) == eOYEAR
		result.toInstant().atZone(ZoneId.systemDefault()).get(ChronoField.YEAR) == eODAY

		where:
		STRTODATE | inputFormula | eOMONTH | eOYEAR | eODAY
		"STRTODATE valid execution" |  "STRTODATE(\"06-Dec-18\",\"dd-MMM-yy\")" | 06 | 12 | 2018
	}

	def "ExcelScript IRecordCondition MUL execution"() {
		setup:
		def formulaText = "MUL(\"5.5\",\"6.0\",\"8\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == 264
	}

	def "ExcelScript IRecordCondition MUL execution for exception"() {
		setup:
		def formulaText = "MUL(\"5.5\",\"abc\",\"8\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		thrown Exception
	}

	@Unroll
	def "#MUL"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "no"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(inputDataType)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName,inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedoutput

		where:
		MUL | inputFormula | inputDataType | inputData | expectedoutput
		"MUL valid execution" | "MUL(\"5.5\",\"6.0\",\"8\")" | FieldType.STRING | null | 264
		"MUL execution double data type" | "MUL(\"5.5\",no)" | FieldType.DOUBLE | 13.12d | 72.16
		"MUL Invalid execution" | "MUL(no)" |FieldType.STRING | null |  0.0
	}

	def "ExcelScript IRecordCondition DIV execution"() {
		setup:
		def formulaText = "DIV(\"5.5\",\"abc\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		thrown FormulaExecutionException
	}

	@Unroll
	def "#DIV"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "no"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(inputDataType)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName,inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedoutput

		where:
		DIV | inputFormula | inputDataType | inputData | expectedoutput
		"DIV valid execution" | "DIV(\"50.0\",\"5.0\")" | FieldType.STRING | null | 10.0
		"DIV execution double data type" | "DIV(\"50.0\",no)" | FieldType.DOUBLE | 5.0d | 10.0
		"DIV Invalid execution" | "DIV(no,\"10.5\")" |FieldType.STRING | null |  0.0
	}



	def "ExcelScript IRecordCondition SUB execution"() {
		setup:
		def formulaText = "SUB(\"50.5\",\"6.0\",\"8.5\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()



		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == 36
	}

	def "ExcelScript IRecordCondition SUB execution for exception"() {
		setup:
		def formulaText = "SUB(\"5.5\",\"abc\",\"8\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		thrown FormulaExecutionException
	}

	@Unroll
	def "#SUB"() {
		setup:
		def formulaText = inputFormula
		def fieldName = "no"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(inputDataType)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName,inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedoutput

		where:
		SUB | inputFormula | inputDataType | inputData | expectedoutput
		"SUB valid execution" | "SUB(\"50.5\",\"6.0\",\"8.5\")" | FieldType.STRING | null | 36
		"SUB execution double data type" | "SUB(\"5.5\",no)" | FieldType.DOUBLE | 13.12d | -7.619999999999999
		"SUB Invalid execution" | "SUB(no)" |FieldType.STRING | null |  0.0
	}

	def "ExcelScript IF Condition test"() {
		setup:
		def formulaText = "IF(EXACT(transType, \"settlement\"), \"0\", \"1\")"
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "settlement");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		int result = 1;
		if(conditionScript != null)
			result = conditionScript.execute(record)
		then:
		conditionScript != null
		result == "0"
	}

	@Unroll
	def "#VLOOKUP"() {
		setup:
		println("Count of records------------->>"+mongoTemplate.getCollection("MID_LOOKUP_TABLE").count())
		def formulaText = formula
		def fieldName = "key"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(datatype)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put("key", inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		def result
		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		if(conditionScript != null)
			result = conditionScript.execute(record)

		then:
		conditionScript != null
		println(result)
		result == expectedoutput
		
		where:
		VLOOKUP | formula | inputData | datatype | expectedoutput
		"VLOOKUP valid execution" | "VLOOKUP(\"MID_LOOKUP_TABLE\",key,\"EquivalentValue\")" | "5460732563" | FieldType.STRING | "1234"
		"VLOOKUP Invalid execution with null" | "VLOOKUP(\"MID_LOOKUP_TABLE\",key,\"EquivalentValue\")" | null | FieldType.STRING | null
		"VLOOKUP Invalid execution with invalid datatype" | "VLOOKUP(\"MID_LOOKUP_TABLE\",key,\"EquivalentValue\")" | LocalDateTime.now() | FieldType.DATETIME | null
	}
}
