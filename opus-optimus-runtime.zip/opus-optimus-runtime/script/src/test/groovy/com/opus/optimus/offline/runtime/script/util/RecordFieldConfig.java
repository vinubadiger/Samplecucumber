package com.opus.optimus.offline.runtime.script.util;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class RecordFieldConfig implements IFieldConfig {
    private short fieldIndex;
    private String name;
    private FieldType type;

    @Override
    public String getFormat() {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public boolean validate() {
		return true;
	}

}
