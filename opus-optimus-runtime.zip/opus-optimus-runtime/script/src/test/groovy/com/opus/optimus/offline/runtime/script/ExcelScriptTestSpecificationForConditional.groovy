package com.opus.optimus.offline.runtime.script

import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.core.CollectionOptions
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.script.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.script.util.Utility
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconSummaryByTrnDateRepo
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.DataSourceConfigAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.JobInfoAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.PublishedWorkflowConfigAuditRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.test.TestMessageFactory
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException

import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

class ExcelScriptTestSpecificationForConditional extends AbstractScriptSpecification {

	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	@Autowired
	TestMessageFactory messageFactory

	@Autowired
	@Qualifier("scriptUtility")
	Utility utility;

	@Autowired
	MongoTemplate mongoTemplate;

	@Unroll
	def "#EXACT"() {
		setup:
		def formulaText = formula
		def fieldName = "transType"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(true)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, null);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(conditionScript != null)
			result = conditionScript.execute(record)
		then:
		conditionScript != null
		result == false

		where:
		EXACT | inputDataType | inputData | formula| expectedOutput
		"EXACT valid execution" | FieldType.STRING |"settlement" | "EXACT(transType, \"settlement\")" | true
		"EXACT Invalid execution" | FieldType.STRING | null | "EXACT(transType, \"settlement\")" | false
		"EXACT Invalid execution for different data" | FieldType.INT | 12 | "EXACT(transType, 12)" | true
	}

	//	STARTSWITH valid execution with raw data
	def "ExcelScript IRecordCondition STARTSWITH execution"() {
		setup:
		def formulaText = "STARTSWITH(\"DT\")"
		def rawText = "DT10020181601TESTOPUS"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(true)
				.type("excel.rawtext-script").build()

		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(conditionScript != null)
			result = conditionScript.execute(rawText)
		then:
		conditionScript != null
		result == true
	}

	//	STARTSWITHwith throws condition
	def "ExcelScript IRecordCondition STARTSWITH execution with rawtext exception "() {
		setup:
		def formulaText = "STARTSWITH(TEXT1)"
		def rawText = "DT10020181601TESTOPUS"

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(true)
				.type("excel.rawtext-script").build()

		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(conditionScript != null)
			result = conditionScript.execute(rawText)
		then:
		conditionScript != null
		result == false
		thrown FormulaExecutionException
	}

	//	STARTSWITH Invalid execution with raw data
	def "ExcelScript IRecordCondition STARTSWITH Invalid execution"() {
		setup:
		def formulaText = "STARTSWITH(\"DT\")"
		def rawText = null;

		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(true)
				.type("excel.rawtext-script").build()

		def conditionScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = false;
		if(conditionScript != null)
			result = conditionScript.execute(rawText)
		then:
		conditionScript != null
		result == false
	}

	//	NOT for valid execution
	def "ExcelScript IRecordCondition NOT execution"() {
		setup:
		def formulaText = "NOT(EXACT(1,1))"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == false
	}

	//	NOT for Invalid execution
	def "ExcelScript IRecordCondition NOT Invalid execution"() {
		setup:
		def formulaText = "NOT(\"yk\")"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(true)
				.type("excel.IRecord-script").build()

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		def result = 0;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(null)
		then:
		valueProviderScript != null
		println(result)
		result == false
	}

	//	ISEMAIL valid execution
	def "ExcelScript IRecordCondition ISEMAIL execution"() {
		setup:
		def formulaText = "ISEMAIL(Email)"
		def fieldName = "Email"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "admin_IT@t-mobile.com");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == true
	}

	//	ISEMAIL Invalid execution
	def "ExcelScript IRecordCondition ISEMAIL Invalid execution"() {
		setup:
		def formulaText = "ISEMAIL(Email)"
		def fieldName = "Email"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.INT)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, 132);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == false
	}

	//	ISNUMBER valid execution
	def "ExcelScript IRecordCondition ISNUMBER execution"() {
		setup:
		def formulaText = "ISNUMBER(Value)"
		def fieldName = "Value"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.DOUBLE)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, 132.12d);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == true
	}

	//	ISNUMBER valid execution with regex
	def "ExcelScript IRecordCondition ISNUMBER valid execution with regex"() {
		setup:
		def formulaText = "ISNUMBER(Value)"
		def fieldName = "Value"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "123,132");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == true
	}

	//	ISNUMBER Invalid execution with null
	def "ExcelScript IRecordCondition ISNUMBER Invalid execution"() {
		setup:
		def formulaText = "ISNUMBER(Value)"
		def fieldName = "Value"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.DOUBLE)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, null);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == false
	}

	//	ISNUMBER Invalid execution for diff data type
	def "ExcelScript IRecordCondition ISNUMBER Invalid execution for data type"() {
		setup:
		def formulaText = "ISNUMBER(Value)"
		def fieldName = "Value"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();

		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.DATETIME)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, LocalDateTime.now());
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == false
	}

	@Unroll
	def "#ISBLANK"() {
		setup:
		def formulaText = formula
		def fieldName = "Value"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName,inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)
		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		ISBLANK | formula | inputData | expectedOutput
		"ISBLANK Invalid execution" | "ISBLANK(Value)" | "abc" | false
		"ISBLANK valid execution" | "ISBLANK(Value)" | "abc" | false
	}

	@Unroll
	def "#REGEXException"() {
		setup:
		def formulaText = formula
		def fieldName = "MoNumber"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(datatype)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		thrown expectedOutput

		where :
		REGEXException | inputData | datatype | formula | expectedOutput
		"REGX execution with wrong data type for input" | LocalDateTime.now() |FieldType.DATETIME |"REGEX(MoNumber,\"\\\\d{10}\")" | FormulaExecutionException
		"REGX execution with wrong pattern" | "8983115" | FieldType.STRING | "REGEX(MoNumber,\"  {{{  \")" | FormulaExecutionException
	}


	@Unroll
	def "#REGEX"() {
		setup:
		def formulaText = formula
		def fieldName = "MoNumber"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(datatype)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where :
		REGEX | inputData | datatype | formula | expectedOutput
		"REGEX valid execution" | "8983112505" |FieldType.STRING |"REGEX(MoNumber,\"\\\\d{10}\")" | true
		"REGEX Invalid execution" | "8983115" | FieldType.STRING |"REGEX(MoNumber,\"\\\\d{10}\")" | false
		"REGEX Invalid execution for pattern" | LocalDateTime.now() | FieldType.DATETIME | "REGEX(\"132\",MoNumber)" | false
	}

	@Unroll
	def "#COMPARE"() {
		setup:
		def formulaText = formula
		def fieldName = "input"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.IRecord-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(datatype)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, inputData);
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		boolean result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(record)
		then:
		valueProviderScript != null
		println(result)
		result == expectedOutput

		where:
		COMPARE | formula | expectedOutput | datatype  | inputData
		"ExcelScript IRecordCondition COMPARE non numeric execution" | "COMPARE(\"123\",\"<->\",5)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE default execution"| "COMPARE(5,\"<->\",5)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE Not equal Invalid execution"| "COMPARE(5,\"<>\",5)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE Not equal valid execution"| "COMPARE(5,\"!=\",55)" | true | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE  equal Invalid execution" |"COMPARE(5,\"=\",55)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE equal valid execution" | "COMPARE(5,\"=\",5)" | true | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE less than equal Invalid execution" |"COMPARE(5,\"<=\",2)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE less than equal valid execution" |"COMPARE(5,\"<=\",5)" | true | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE less than Invalid execution" | "COMPARE(555555,\"<\",\"2,122\")" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE less than valid execution" |"COMPARE(5,\"<\",\"2,122\")" | true | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE greter than equal Invalid execution" | "COMPARE(5,\">=\",22)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE greter than equal valid execution" | "COMPARE(2,\">=\",2)" | true | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE greter than Invalid execution" | "COMPARE(5,\">\",22)" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE greter than valid execution" | "COMPARE(\"5,132\",\">\",2)" | true | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE greter than for blank input" | "COMPARE(\"\",\">\",\"\")" | false | FieldType.STRING | ""
		"ExcelScript IRecordCondition COMPARE greter than for null input" | "COMPARE(input,\">\",input)" | false | FieldType.STRING | null
	}

}
