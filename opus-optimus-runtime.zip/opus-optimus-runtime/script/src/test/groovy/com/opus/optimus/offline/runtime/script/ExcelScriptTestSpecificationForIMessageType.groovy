package com.opus.optimus.offline.runtime.script

import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField

import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.beans.factory.annotation.Value
import org.springframework.data.mongodb.core.CollectionOptions
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource

import com.mongodb.BasicDBObjectBuilder
import com.mongodb.DBObject
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords
import com.opus.optimus.offline.configuration.ScriptTestConfiguration
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.script.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.script.util.Utility
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.DataSourceConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobInfoRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.JobResultRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.PublishedWorkflowConfigRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconAcitivitySummaryRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.ReconSummaryByTrnDateRepo
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.DataSourceConfigAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.JobInfoAuditRepository
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.audit.PublishedWorkflowConfigAuditRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.test.TestMessageFactory
import com.opusconsulting.pegasus.formula.excel.IMappingDataHolder
import com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException

import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

class ExcelScriptTestSpecificationForIMessageType extends AbstractScriptSpecification {

	@Autowired
	ScriptCreatorFactory scriptCreatorFactory;

	@Autowired
	TestMessageFactory messageFactory

	@Autowired
	@Qualifier("scriptUtility")
	Utility utility;

	def "ExcelScript IMessage RECORDTYPE formula exception"() {
		setup:
		def formulaText = "RECORDTsdYPE()"
		def fieldName = "processingCode"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(true)
				.type("excel.imessage-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "100000");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		IMessage message = messageFactory.createMessage(record);

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(message)

		then:
		thrown FormulaExecutionException
	}

	@Unroll
	def "#IMESSAGE"() {
		setup:
		def formulaText = formula
		def fieldName = "processingCode"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(conditional)
				.type("excel.imessage-script").build()

		List<RecordFieldConfig> recordFieldConfigs = new ArrayList<RecordFieldConfig>();
		recordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short)1)
				.name(fieldName)
				.type(FieldType.STRING)
				.build());

		utility.buildRecordMetaData(recordFieldConfigs, "data");
		Map<String, Object> testRecordFieldValues = new HashMap<>();
		testRecordFieldValues.put(fieldName, "100000");
		IRecord record = utility.buildRecord(recordFieldConfigs, testRecordFieldValues, "data");
		IMessage message = messageFactory.createMessage(record);

		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(message)

		then:
		valueProviderScript != null
		result == expectedOutput

		where:
		IMESSAGE | formula | conditional | expectedOutput
		"IMessage valid conditional Nonexecution" | "RECORDTYPE()" | false | "data"
		"IMessage valid conditional execution" | "EXACT(RECORDTYPE(),\"data\")" | true | true
	}

	def "ExcelScript IMessage RECORDTYPE formula Invalid execution"() {
		setup:
		def formulaText = "RECORDTYPE()"
		def fieldName = "processingCode"
		def excelScriptConfig = ExcelScriptConfig.builder()
				.formulaText(formulaText)
				.conditional(false)
				.type("excel.imessage-script").build()

		IMessage message = messageFactory.createMessage(null);
		def valueProviderScript = scriptCreatorFactory.createScript(excelScriptConfig)

		when:
		def result = false;
		if(valueProviderScript != null)
			result = valueProviderScript.execute(message)

		then:
		valueProviderScript != null
		result == ""
	}
}
