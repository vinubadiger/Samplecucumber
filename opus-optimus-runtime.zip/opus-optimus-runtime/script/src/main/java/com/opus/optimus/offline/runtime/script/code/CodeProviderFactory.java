package com.opus.optimus.offline.runtime.script.code;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.script.config.RecordType;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;

/**
 * A factory for creating CodeProvider objects.
 */
@Component
public class CodeProviderFactory implements ICodeProviderFactory {

	/** The code providers. */
	@Autowired
	private Map<String, ICodeProvider> codeProviders;
	
	@Override
	public ICodeProvider getProvider(RecordType recordType) {
		return codeProviders.get(recordType.getProviderName());
	}
}
