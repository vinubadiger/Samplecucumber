package com.opus.optimus.offline.runtime.script.excel;

import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.code.CodeProviderFactory;
import com.opus.optimus.offline.runtime.script.code.ICondition;
import com.opus.optimus.offline.runtime.script.code.IValueProvider;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opusconsulting.pegasus.formula.codegen.CodeMetaData;
import com.opusconsulting.pegasus.formula.codegen.FormulaCodeInfo;
import com.opusconsulting.pegasus.formula.codegen.FunctionMetaData;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;
import com.opusconsulting.pegasus.formula.codegen.ParamMetaData;
import com.opusconsulting.pegasus.formula.codegen.impl.FormulaCodeGenerator;
import com.opusconsulting.pegasus.formula.compiler.JavaCodeCompiler;

/**
 * The Class ExcelFormulaEvaluatorScript.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
@Component
public abstract class ExcelFormulaEvaluatorScript<T, R> implements IScript<T, R> {
	
	private static final Logger logger = LoggerFactory.getLogger(ExcelFormulaEvaluatorScript.class);
	
	/** The formula code generator. */
	@Autowired
	FormulaCodeGenerator formulaCodeGenerator;
	
	/** The code provider factory. */
	@Autowired
	CodeProviderFactory codeProviderFactory;
	
	/** The code compiler. */
	@Autowired
	JavaCodeCompiler codeCompiler;
	
	/** The excel script configuration. */
	ExcelScriptConfig excelScriptConfig;
	
	/** The formula code instance. */
	Object formulaCodeInstance;
	
	/**
	 * Instantiates a new excel formula evaluator script.
	 *
	 * @param config the configuration
	 */
	public ExcelFormulaEvaluatorScript(IScriptConfig config) {
		if(config != null && !ExcelScriptConfig.class.isAssignableFrom(config.getClass())) {
			throw new ClassCastException(); 
		}
		this.excelScriptConfig = (ExcelScriptConfig) config;
	}
	
	/**
	 * Initialize  the code executer
	 */
	@PostConstruct
	protected void init() {
		ICodeProvider codeProvider = codeProviderFactory.getProvider(excelScriptConfig.getRecordType());
		if(codeProvider == null) {
			logger.error("Erron in Excel Formula Evaluator script, In init method.");
			throw new UnsupportedOperationException();
		}
		try {
			CodeMetaData codeMetaData = new CodeMetaData();
			codeMetaData.setPackageName("com.opusconsulting.pegasus.formula");
			codeMetaData.addImport("static com.opusconsulting.pegasus.formula.excel.impl.ExcelFunctions.*");
			codeMetaData.addImport("static com.opus.optimus.offline.runtime.script.excel.AdditionalExcelFunctions.*");
			
			codeMetaData.addImport(codeProvider.getDataClassName());
			codeMetaData.addImport("java.util.Map");
			
			if(this.excelScriptConfig.isConditional()) {
				codeMetaData.addImport(ICondition.class.getName());
				codeMetaData.setImplementClasses(Arrays.asList(buildScriptClassName(ICondition.class, true, excelScriptConfig.getRecordType().getClassName())));
			} else {
				codeMetaData.addImport(IValueProvider.class.getName());
				codeMetaData.setImplementClasses(Arrays.asList(buildScriptClassName(IValueProvider.class, true, excelScriptConfig.getRecordType().getClassName())));
			}
			//build the function meta data for the java functions to be generated
			FunctionMetaData functionMetaData = this.excelScriptConfig.isConditional() ? buildConditionalFunctionMetaData()
					: buildValueProviderFunctionMetaData();
			codeMetaData.setCallFunctionMetaData(functionMetaData);
			//set the formula code generator info
			FormulaCodeInfo formulaCodeInfo = formulaCodeGenerator.create(excelScriptConfig.getFormulaText(), codeMetaData,
					codeProvider);
			

			Class<Object> conditionClass = (Class<Object>) codeCompiler.compile(formulaCodeInfo.getClassName(), formulaCodeInfo.getCode());

			if(conditionClass == null) {
				logger.debug("Erron in Excel Formula Evaluator script, \"conditionClass\" is null.");
				return;
			}
			this.formulaCodeInstance = conditionClass.newInstance();
		} catch(Exception exception) {
			logger.error("Erron in Excel Formula Evaluator script, Formula Text: {},  Error: {} , {}",excelScriptConfig.getFormulaText(), exception.getMessage() ,exception);
		}
		catch (Throwable error) {
			logger.error("Erron in Excel Formula Evaluator script, Error: {} , {}",error.getMessage() ,error);			
		}
	}

	/**
	 * Builds the script class name.
	 *
	 * @param scriptClassName - The script class name
	 * @param genericApplicable - The generic applicable
	 * @param dataClassName - The data class name
	 * @return the string
	 */
	private String buildScriptClassName(Class<?> scriptClassName, boolean genericApplicable, String dataClassName) {
		StringBuilder classNameBuilder = new StringBuilder();
		classNameBuilder.append(scriptClassName.getSimpleName());
		if(genericApplicable) {
			classNameBuilder.append("<");
			classNameBuilder.append(dataClassName);
			classNameBuilder.append(">");
		}
		return classNameBuilder.toString();
	}

	/**
	 * Builds the conditional function meta data.
	 *
	 * @return the function meta data
	 */
	protected FunctionMetaData buildConditionalFunctionMetaData() {
		FunctionMetaData functionMetaData = new FunctionMetaData();
		functionMetaData.setName("check");
		functionMetaData.setReturnType("boolean");
		functionMetaData.setParams(Arrays.asList(new ParamMetaData("request", excelScriptConfig.getRecordType().getClassName())));
		return functionMetaData;
	}
	
	/**
	 * Builds the value provider function meta data.
	 *
	 * @return the function meta data
	 */
	protected FunctionMetaData buildValueProviderFunctionMetaData() {
		FunctionMetaData functionMetaData = new FunctionMetaData();
		functionMetaData.setName("get");
		functionMetaData.setReturnType("T");
		functionMetaData.setParams(Arrays.asList(new ParamMetaData("request", excelScriptConfig.getRecordType().getClassName())));
		return functionMetaData;
	}

	/**
	 * Gets the formula code instance.
	 *
	 * @return the formula code instance
	 */
	protected Object getFormulaCodeInstance() {
		return formulaCodeInstance;
	}

	/**
	 * Gets the excel script configuration.
	 *
	 * @return the excel script config
	 */
	protected ExcelScriptConfig getExcelScriptConfig() {
		return excelScriptConfig;
	}
}
