package com.opus.optimus.offline.runtime.script.code;

import com.opus.optimus.offline.runtime.script.config.RecordType;
import com.opusconsulting.pegasus.formula.codegen.ICodeProvider;

/**
 * A factory for creating ICodeProvider objects.
 */
@FunctionalInterface
public interface ICodeProviderFactory {
	
	/**
	 * Gets the provider.
	 *
	 * @param providerType - The provider type
	 * @return the provider
	 */
	ICodeProvider getProvider(RecordType providerType);
}
