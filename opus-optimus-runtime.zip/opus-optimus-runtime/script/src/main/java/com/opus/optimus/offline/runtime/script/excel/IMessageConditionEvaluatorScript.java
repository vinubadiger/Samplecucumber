package com.opus.optimus.offline.runtime.script.excel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.script.code.ICondition;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.config.RecordType;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opusconsulting.pegasus.formula.exception.FormulaExceptionCodes;
import com.opusconsulting.pegasus.formula.exception.FormulaExecutionException;

/**
 * The Class IMessageConditionEvaluatorScript.
 */
@Component("excel.IMessageConditionEvaluatorScript")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class IMessageConditionEvaluatorScript extends ExcelFormulaEvaluatorScript<IMessage, Boolean> {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(IMessageConditionEvaluatorScript.class);

	/**
	 * Instantiates a new i message condition evaluator script.
	 *
	 * @param config the configuration
	 */
	public IMessageConditionEvaluatorScript(ExcelScriptConfig config) {
		super(config);
		config.setRecordType(RecordType.IMESSAGE);
	}

	@Override
	public Boolean execute(IMessage data) {
		if (getFormulaCodeInstance() == null) {
			logger.error("Error while compiling formula. Formula Text: {}", getExcelScriptConfig().getFormulaText());
			throw new FormulaExecutionException(FormulaExceptionCodes.FORMULA_COMPILATION_EXCEPTION,
					"Error while compiling formula. Formula Text: " + getExcelScriptConfig().getFormulaText(), null);
		}
		if (!ICondition.class.isAssignableFrom(getFormulaCodeInstance().getClass())) {
			return false;
		}
		return ((ICondition) getFormulaCodeInstance()).check(data);
	}

}
