package com.opus.optimus.offline.runtime.script.code;

/**
 * The Interface ICondition.
 *
 * @param <T> the generic type
 */
@FunctionalInterface
public interface ICondition<T> {
	
	/**
	 * Check.
	 *
	 * @param record - The record
	 * @return true, if successful
	 */
	boolean check(T record);
}
