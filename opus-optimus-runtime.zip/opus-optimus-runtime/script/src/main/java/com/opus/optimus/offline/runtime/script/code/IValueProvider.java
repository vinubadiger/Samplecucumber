package com.opus.optimus.offline.runtime.script.code;

/**
 * The Interface IValueProvider.
 *
 * @param <P> the generic type
 */
@FunctionalInterface
public interface IValueProvider<P> {
	
	/**
	 * Gets the.
	 *
	 * @param <T> the generic type
	 * @param record the record
	 * @return the t
	 */
	<T> T get(P record);
}
