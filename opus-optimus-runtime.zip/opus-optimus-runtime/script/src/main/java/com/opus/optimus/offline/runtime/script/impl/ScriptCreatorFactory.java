package com.opus.optimus.offline.runtime.script.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.api.IScriptCreator;

/**
 * A factory for creating ScriptCreator objects.
 */
@Component
public class ScriptCreatorFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(ScriptCreatorFactory.class);

    /** The script creators. */
    @Autowired(required = false)
    Map<String, IScriptCreator> scriptCreators;

    /**
     * Creates a new ScriptCreator object.
     *
     * @param config - The configuration of script
     * @return the i script
     */
    public IScript createScript(IScriptConfig config) {
    	
        IScriptCreator scriptCreator = scriptCreators.get(config.getType());
        if (scriptCreator == null) {
        	logger.error("No script creator registered for script type : {}" ,config.getType());
            throw new EngineException("No script creator registered for script type " + config.getType());
        }
        
        return scriptCreator.create(config);
    }

}
