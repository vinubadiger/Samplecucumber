package com.opus.optimus.offline.runtime.recon.statusupdate

import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.configuration.TestStatusUpdateConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.db.MongoDBReaderHelper
import com.opus.optimus.offline.runtime.exception.casehandler.ReconCaseTemplate
import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Ignore
import spock.lang.Specification

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestStatusUpdateConfiguration.class)
class ReconciliationStepWithDBReaderSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	MongoDBReaderHelper mongoDBReaderHelper

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	IMessageFactory messageFactory

	@SpringBean
	IJobInfoService jobService = Mock();

	@SpringBean
	ReconCaseTemplatesRepository reconcaseTemplatesRepo = Mock()

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	def "Reconciliation single rule test with json"() {
		setup:
		def mapper = mapperFactory.getMapper()
		//register the data source
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}
		
		MongoDataSource mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

		//set up embedded mongo
		def dbHostIP = mongoHost;
		def dbPort = mongoPort;

		//initialize data source factory
		mongoDataSource.init();
		dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);
		def mongoDataBase = mongoDataSource.getDatabase();

		def workflowConfigStream = getClass().getResourceAsStream("/MultiStepJson.json")
		def workflowConfig = mapper.readValue(workflowConfigStream, WorkflowConfig.class)

		def workflowExecutionConfig = new WorkflowExecutionConfig()
		//insert Amex sample records to mongo db
		loadSampleData("amexcoll", "/sampleTransactionData_amexcoll.txt", mongoDataBase)
		loadSampleData("paymentcoll", "/sampleTransactionData_paymentcoll.txt", mongoDataBase)


		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		jobService.findById(_ as String) >> { new JobInfo();}

		def statusTemplateMap = [
			ReconCaseTemplate.builder().
			activityName("test1").projectName("test1").
			templates("This is JUnit test template for NoMatch").
			recon_status("NoMatch").build()
		]
		reconcaseTemplatesRepo.findByProjectNameandActivityName(_ as String, _ as String) >> {
			return new ArrayList<String>(statusTemplateMap)
		}

		when:
		def result = localJobTaskExecutor.execute()
		def source1Emitter = localJobTaskExecutor.getInBoundQueue("Source-A").getEmitter()
		def source2Emitter = localJobTaskExecutor.getInBoundQueue("Source-B").getEmitter()

		source1Emitter.emit(messageFactory.createMessage(""))
		source2Emitter.emit(messageFactory.createMessage(""))

		source1Emitter.emit(messageFactory.createEndMessage())
		source2Emitter.emit(messageFactory.createEndMessage())

		def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

		then:
		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue("ReconStatusUpdateStepName").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)

		println receivedData
		receivedData.size() == 5
	}

	def loadSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			println("db object" + dbObject)
			collection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
	}
}
