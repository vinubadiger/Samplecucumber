package com.opus.optimus.offline.runtime.recon.statusupdate

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.context.ContextConfiguration
import org.springframework.web.client.RestTemplate

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus
import com.opus.optimus.offline.configuration.TestStatusUpdateConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference
import com.opus.optimus.offline.runtime.exception.logger.JobErrorSalesforceCaseLogger
import com.opus.optimus.offline.runtime.recon.statusupdate.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.recon.statusupdate.util.Utility
import com.opus.optimus.offline.runtime.step.reconciliation.IRecordMatcher
import com.opus.optimus.offline.runtime.step.reconciliation.MatchedResultType
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.JobInfoService
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.PublishedWorkflowConfigService
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.WorkflowConfigRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.MessageType
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder

import spock.lang.Specification

@ContextConfiguration(classes = TestStatusUpdateConfiguration.class)
class MatchWithToleranceAbsoluteVarianceSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	Utility utility;

	@Autowired
	JobErrorSalesforceCaseLogger errorSalesforceCaseLogger

	@Autowired
	JobInfoService jobInfoService

	@SpringBean(name = "restTemplate")
	RestTemplate restTemplate = Mock()

	@Autowired
	PublishedWorkflowConfigService publishedWorkflowConfigService

	def "Absolute variance generation in Recon status update step"() {
		setup:
		def activityName = "test1"
		def defaultErrorHandlerFlowName = "defaultInMemoryGlobalErrorWorkflow"
		def subStatus = ReconSubStatus.NoMatch
		def sourceACollection = "sourceA"
		def sourceBCollection = "sourceB"
		def templateCollection = "ReconCaseTemplate"
		def jobInfoCollection = "JobInfo"
		def publishedServicesCollection = "PublishedService"
		def dataSourceName = "sourceDataSource"
		def jobId = "reconErrorJob"
		def sourceAName = "src1"
		def sourceBName = "src2"

		def mapper = mapperFactory.getMapper()
		//register the data source
		def dataSourceJsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(dataSourceJsonStream, MongoDataSourceMeta.class)
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

		//set up embedded mongo
		def dbHostIP = mongoHost;
		def dbPort = mongoPort;

		//initialize data source factory
		mongoDataSource.init();
		dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);

		def mongo = new MongoClient(dbHostIP, dbPort);
		def mongoDatabase = mongo.getDatabase(mongoDbDataSourceMetaData.getDatabaseName());

		//insert sample records for source A
		loadSampleData(sourceACollection, "/sampleVarianceMatchSourceA.txt", mongoDatabase)

		//insert sample records for source B
		loadSampleData(sourceBCollection, "/sampleVarianceMatchSourceB.txt", mongoDatabase)

		//insert the templates
		loadSampleData(templateCollection, "/caseHandling/sampleCaseTemplate.txt", mongoDatabase)

		//insert sample job info
		jobId = loadAndGetIdOfSampleData(jobInfoCollection, "/caseHandling/sampleJobInfo.txt", mongoDatabase)

		//insert the published services
		def groupId = loadPublishedServices(publishedServicesCollection, "/caseHandling/samplePublishedService.txt", mongoDatabase)

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", new JobConfig(activityName, defaultErrorHandlerFlowName), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		//build the Recon Status to be emitted
		def reconciliationMatchResults = buildReconResultsWithMBTStatus(sourceAName, sourceBName, mongoDbDataSourceMetaData.databaseName, mongoDbDataSourceMetaData.getDataSourceName(), mongoDatabase, sourceACollection, sourceBCollection)

		//mock the case response
		def parentCaseId = "case1"
		mockSalesForceAuthentication()
		//map to store description per case reference id
		def caseDescriptions = [:]
		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(activityName, "ReconStatusUpdateStepName").getEmitter()
		reconciliationMatchResults.each { reconciliationMatchResult ->
			emitter.emit(messageFactory.createMessage(reconciliationMatchResult))
		}
		emitter.emit(messageFactory.createEndMessage())
		def jobResult = result.get()

		then:
		_ * restTemplate.postForEntity(_, _, SalesforceCaseResponse.class) >> { arguments ->
			def parentCaseRefId = arguments[1].getBody().records[0].referenceId
			caseDescriptions.put(parentCaseId, arguments[1].getBody().records[0].description)
			def successListSalesforceCaseDetails = []
			arguments[1].getBody().records[0].childcases.eachWithIndex { childCase, caseIndex ->
				def caseId = UUID.randomUUID().toString()
				//load all description in the map for assertion of configured tolerance value
				caseDescriptions.put(caseId, childCase.description)
				successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(caseId).caseNumber(String.valueOf(caseIndex)).referenceId(childCase.referenceId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())
			}
			successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(parentCaseId).caseNumber(String.valueOf(successListSalesforceCaseDetails.size())).referenceId(parentCaseRefId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())

			def successList = new ArrayList(successListSalesforceCaseDetails)

			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();

			return new ResponseEntity(salesForceResponse, HttpStatus.OK);
		}

		noExceptionThrown()
		//verify Source A Absolute Variance
		def sourceA_absVarianceAmt = calculateAbsoluteVarianceAmount(mongoDatabase, sourceACollection, activityName, caseDescriptions)
		assert sourceA_absVarianceAmt == 6.0
		//verify Source A Absolute Variance
		def sourceB_absVarianceAmt = calculateAbsoluteVarianceAmount(mongoDatabase, sourceBCollection, activityName, caseDescriptions)
		assert sourceB_absVarianceAmt == 6.0

		//verify Source A Variance
		def sourceA_VarianceAmt = calculateVarianceAmount(mongoDatabase, sourceACollection, activityName, caseDescriptions)
		assert sourceA_VarianceAmt == 2.0
		//verify Source B Variance
		def sourceB_VarianceAmt = calculateVarianceAmount(mongoDatabase, sourceBCollection, activityName, caseDescriptions)
		assert sourceB_VarianceAmt == 2.0

		cleanup:
		cleanupCollections(mongoDatabase, Arrays.asList(sourceACollection, sourceBCollection, templateCollection, jobInfoCollection, publishedServicesCollection))
	}

	def loadSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			collection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
	}

	def loadAndGetIdOfSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		def dbObject = Document.parse(sampleRecordLine)
		collection.insertOne(dbObject)
		return dbObject.get("_id").toHexString();
	}

	def buildAndRegisterSrcAFldConfig(def sourceName) {
		def sourceRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("transactionID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 2)
				.name("transactionAmount")
				.type(FieldType.DOUBLE)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 3)
				.name("recordReferenceID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 4)
				.name("transactionDate")
				.type(FieldType.DATETIME)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 5)
				.name("OID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 6)
				.name("reconControlFields")
				.type(FieldType.OBJECT)
				.build());
		utility.buildRecordMetaData(sourceRecordFieldConfigs, sourceName);
		return sourceRecordFieldConfigs;
	}

	def buildAndRegisterSrcBFldConfig(def sourceName) {
		def sourceRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("transID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 2)
				.name("transAmt")
				.type(FieldType.DOUBLE)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 3)
				.name("recordReferenceID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 4)
				.name("transDate")
				.type(FieldType.DATETIME)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 5)
				.name("OID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 6)
				.name("reconControlFields")
				.type(FieldType.OBJECT)
				.build());
		utility.buildRecordMetaData(sourceRecordFieldConfigs, sourceName);
		return sourceRecordFieldConfigs;
	}

	def loadRecordsForSource(def collectionName, def mongoDatabase, def srcFldConfigs, def sourceName, def sourceReference) {
		def recordList = new  ArrayList<>();
		def collection = mongoDatabase.getCollection(collectionName)
		def documents = collection.find()
		documents.each { document ->
			Set<String> keys = document.keySet();
			Map<String, Object> sourceFieldValues = new HashMap<>();
			keys.each { key ->
				if(key.equalsIgnoreCase("_id")) {
					sourceFieldValues.put("OID", document.get("_id").toHexString());
				} else {
					sourceFieldValues.put(key, document.get(key));
				}
			}
			println("Record map : " + sourceFieldValues)
			IRecord record = utility.buildRecord(srcFldConfigs, sourceFieldValues, sourceName)
			recordList.add(Arrays.asList(messageFactory.createMessage(MessageType.DATA, record, sourceReference)));
		}
		return recordList;
	}

	//This method implementation is based on assumption about the test data and test field configuration.Any change to test data will
	//impact this method implementation
	def buildReconResultsWithMBTStatus(def sourceAName, def sourceBName, def databaseName, def datasourceName, def mongoDatabase, def sourceACollection, def sourceBCollection) {
		def reconciliationMatchResults = []
		//register schema
		def srcAFldConfigs = buildAndRegisterSrcAFldConfig(sourceAName)
		def srcBFldConfigs = buildAndRegisterSrcBFldConfig(sourceBName)

		def sourceAReference = DBSourceReference.builder()
				.dataSourceName(datasourceName)
				.collectionName(sourceACollection)
				.schemaName(databaseName).build()


		def srcARecords = loadRecordsForSource(sourceACollection, mongoDatabase, srcAFldConfigs, sourceAName, sourceAReference)
		println("Source A records: " + srcARecords)

		def sourceBReference = DBSourceReference.builder()
				.dataSourceName(datasourceName)
				.collectionName(sourceBCollection)
				.schemaName(databaseName).build()
		def srcBRecords = loadRecordsForSource(sourceBCollection, mongoDatabase, srcBFldConfigs, sourceBName, sourceBReference)
		println("Source B records: " + srcBRecords)


		srcARecords.each { srcASelectedRecords ->
			def selectedRecords = new HashMap<>();
			//put source A records
			selectedRecords.put(sourceAName, srcASelectedRecords)
			def srcBSelectedRecords = findSourceBMatchingRecord(srcASelectedRecords, srcBRecords, "transactionID", "transID")
			//put source A records
			selectedRecords.put(sourceBName, srcBSelectedRecords)

			def actualVariance = calculateVariance(srcASelectedRecords, srcBSelectedRecords, "transactionAmount", "transAmt")
			def reconResult = new ReconciliationMatchResult(MatchedResultType.UNMATCHED, selectedRecords)
			reconResult.setSupportingData(new HashMap<>())
			reconResult.getSupportingData().put(IRecordMatcher.TOLERANCE_AMOUNT_VALUE, actualVariance)
			reconResult.getSupportingData().put(IRecordMatcher.CONFIGURED_TOLERANCE_VALUE, "5")
			reconciliationMatchResults.add(reconResult)
		}
		return reconciliationMatchResults
	}

	def findSourceBMatchingRecord(def srcARecords, def srcBRecords, def sourceAFieldName, def sourceBFieldName) {
		def srcARecord = srcARecords.get(0).getData()
		def srATranId = srcARecord.getValue(srcARecord.getFieldId(sourceAFieldName))
		//find the source B records equivalent of Source A record
		return srcBRecords.find { bRecords ->
			def srcBRecord = bRecords.get(0).getData()
			def srBTranId = srcBRecord.getValue(srcBRecord.getFieldId(sourceBFieldName))
			return srATranId.equalsIgnoreCase(srBTranId)
		}
	}

	def calculateVariance(def srcARecords, def srcBRecords, def sourceAFieldName, def sourceBFieldName) {
		def srcARecord = srcARecords.get(0).getData()
		def srcBRecord = srcBRecords.get(0).getData()
		def srAAmount = srcARecord.getValue(srcARecord.getFieldId(sourceAFieldName))
		def srBAmount = srcBRecord.getValue(srcBRecord.getFieldId(sourceBFieldName))
		return srBAmount - srAAmount;
	}

	def mockSalesForceAuthentication() {
		def accessToken = "abcd1234"

		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();

		restTemplate.postForEntity(_, _, SalesforceAuthenticateResponse.class) >> {
			new ResponseEntity(salesForceAuthResponse, HttpStatus.OK);
		}
	}

	def calculateAbsoluteVarianceAmount(def mongoDatabase, def sourceCollection, def activityName, def caseDescriptions) {
		caseDescriptions.each { entry ->
			println("Key: " + entry.getKey() + ", Value : " + entry.getValue())
		}
		MongoCollection<Document> sourceAMgCollection = mongoDatabase.getCollection(sourceCollection);
		Document searchSourceA = new Document();
		searchSourceA.append("reconControlFields."+activityName, new Document("\$exists", true));
		println("Document Filter Source : " + searchSourceA);
		FindIterable<Document> resultsSourceA = sourceAMgCollection.find(searchSourceA);
		println("Document Found -Source : " + resultsSourceA);
		resultsSourceA != null
		def absVarianceAmt = 0.0
		def varianceAmt = 0.0
		resultsSourceA.each { document ->
			Map<String, Object> reconControlField = document.get("reconControlFields")
			Map<String, Object> activityReconControlField = reconControlField.get(activityName)
			println("activityReconControlField = > " + activityReconControlField)
			absVarianceAmt = absVarianceAmt + activityReconControlField.get("absoluteTolerance")
		}
		println("Absolute Variance Amt -->  " +absVarianceAmt)
		return absVarianceAmt
	}

	def calculateVarianceAmount(def mongoDatabase, def sourceCollection, def activityName, def caseDescriptions) {
		caseDescriptions.each { entry ->
			println("Key: " + entry.getKey() + ", Value : " + entry.getValue())
		}
		MongoCollection<Document> sourceAMgCollection = mongoDatabase.getCollection(sourceCollection);
		Document searchSourceA = new Document();
		searchSourceA.append("reconControlFields."+activityName, new Document("\$exists", true));
		println("Document Filter Source : " + searchSourceA);
		FindIterable<Document> resultsSourceA = sourceAMgCollection.find(searchSourceA);
		println("Document Found -Source : " + resultsSourceA);
		resultsSourceA != null
		def absVarianceAmt = 0.0
		def varianceAmt = 0.0
		resultsSourceA.each { document ->
			Map<String, Object> reconControlField = document.get("reconControlFields")
			Map<String, Object> activityReconControlField = reconControlField.get(activityName)
			println("activityReconControlField = > " + activityReconControlField)
			varianceAmt =varianceAmt + activityReconControlField.get("tolerance")
		}
		println("VarianceAmt -- > "+varianceAmt)
		return varianceAmt
	}

	def loadPublishedServices(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		def groupId = ""
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			collection.insertOne(dbObject)
			if(!"000000000000000000000000".equals(dbObject.get("_id").toHexString())) {
				groupId = dbObject.get("_id").toHexString()
			}
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
		return groupId
	}

	def cleanupCollections(def mongoDatabase, def collectionList) {
		collectionList.each { collection ->
			mongoDatabase.getCollection(collection).drop();
		}
	}
}
