package com.opus.optimus.offline.runtime.recon.statusupdate

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus
import com.opus.optimus.offline.configuration.TestStatusUpdateConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.exception.logger.JobErrorSalesforceCaseLogger
import com.opus.optimus.offline.runtime.recon.statusupdate.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.recon.statusupdate.util.Utility
import com.opus.optimus.offline.runtime.step.reconciliation.IRecordMatcher
import com.opus.optimus.offline.runtime.step.reconciliation.MatchedResultType
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.JobInfoService
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.PublishedWorkflowConfigService
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.WorkflowConfigRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.MessageType
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder

import spock.lang.Specification

@ContextConfiguration(classes = TestStatusUpdateConfiguration.class)
class ReconciledNoMatchCaseSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Qualifier("statUpdateUtility")
	@Autowired
	Utility utility;

	@Autowired
	JobErrorSalesforceCaseLogger errorSalesforceCaseLogger

	@Autowired
	JobInfoService jobInfoService

	@SpringBean
	SalesforceCaseHelper salesforceCaseHelper = Mock()
	
	@Autowired
	PublishedWorkflowConfigService publishedWorkflowConfigService

	def "Reconciled No Match Record Handler Execution - Case closure"() {
		setup:
		def activityName = "test1"
		def defaultErrorHandlerFlowName = "defaultInMemoryGlobalErrorWorkflow"
		def subStatus = ReconSubStatus.NoMatch
		def sourceACollection = "sourceA"
		def sourceBCollection = "sourceB"
		def templateCollection = "ReconCaseTemplate"
		def jobInfoCollection = "JobInfo"
		def publishedServicesCollection = "PublishedService"
		def dataSourceName = "sourceDataSource"
		def jobId = "reconErrorJob"
		def sourceAName = "src1"
		def sourceBName = "src2"
		
		def mapper = mapperFactory.getMapper()
		//register the data source
		def dataSourceJsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(dataSourceJsonStream, MongoDataSourceMeta.class)
		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);

		//set up embedded mongo
		def dbHostIP = mongoHost;
		def dbPort = mongoPort;

		//initialize data source factory
		mongoDataSource.init();
		dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);

		def mongo = new MongoClient(dbHostIP, dbPort);
		def mongoDatabase = mongo.getDatabase(mongoDbDataSourceMetaData.getDatabaseName());

		//insert sample records for source A
		loadSampleData(sourceACollection, "/caseHandling/sampleReconNoMatchSrcARecords.txt", mongoDatabase)

		//insert sample records for source B
		loadSampleData(sourceBCollection, "/caseHandling/sampleReconNoMatchSrcBRecords.txt", mongoDatabase)

		//insert the templates
		loadSampleData(templateCollection, "/caseHandling/sampleCaseTemplate.txt", mongoDatabase)

		//insert sample job info
		jobId = loadAndGetIdOfSampleData(jobInfoCollection, "/caseHandling/sampleJobInfo.txt", mongoDatabase)

		//insert the published services
		def groupId = loadPublishedServices(publishedServicesCollection, "/caseHandling/samplePublishedService.txt", mongoDatabase)

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", new JobConfig(activityName, defaultErrorHandlerFlowName), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		//build the Recon Status to be emitted
		def reconciliationMatchResults = buildReconResultsWithMatchedStatus(sourceAName, sourceBName, mongoDbDataSourceMetaData.databaseName, mongoDbDataSourceMetaData.getDataSourceName(), mongoDatabase, sourceACollection, sourceBCollection)

		//mock the case response
		mockSalesForceAuthentication()
		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(activityName, "ReconStatusUpdateStepName").getEmitter()
		reconciliationMatchResults.each { reconciliationMatchResult ->
			emitter.emit(messageFactory.createMessage(reconciliationMatchResult))
		}
		emitter.emit(messageFactory.createEndMessage())
		def jobResult = result.get()

		then:
		_ * salesforceCaseHelper.bulkUpdate(_, _) >> {arguments ->
			def successListSalesforceCaseDetails = []
			println("arguments = > " + arguments[1])
			arguments[0].records.eachWithIndex { childCase, caseIndex ->
				def caseId = childCase.caseId
				def referenceId = childCase.referenceId
				successListSalesforceCaseDetails.add(SalesforceCaseDetails.builder().caseId(caseId).referenceId(referenceId).caseNumber(String.valueOf(caseIndex)).caseDetailUrl("https://salesforce.com/test/Case/1/view").build())
			}

			def successList = new ArrayList(successListSalesforceCaseDetails)

			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();

			return salesForceResponse;
		}

		noExceptionThrown()
		//verify Source A records
		verifySourceRecordsForCaseInfo(mongoDatabase, sourceACollection, activityName)
		//verify Source B records
		verifySourceRecordsForCaseInfo(mongoDatabase, sourceBCollection, activityName)
		cleanup:
		cleanupCollections(mongoDatabase, Arrays.asList(sourceACollection, sourceBCollection, templateCollection, jobInfoCollection, publishedServicesCollection))
	}

	def loadSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			collection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
	}

	def loadAndGetIdOfSampleData(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		def dbObject = Document.parse(sampleRecordLine)
		collection.insertOne(dbObject)
		return dbObject.get("_id").toHexString();
	}
	
	def buildAndRegisterSrcAFldConfig(def sourceName) {
		def sourceRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("transactionID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 2)
				.name("transactionAmount")
				.type(FieldType.DOUBLE)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 3)
				.name("recordReferenceID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 4)
				.name("transactionDate")
				.type(FieldType.DATETIME)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 5)
				.name("OID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 6)
				.name("reconControlFields")
				.type(FieldType.OBJECT)
				.build());
		utility.buildRecordMetaData(sourceRecordFieldConfigs, sourceName);
		return sourceRecordFieldConfigs;
	}

	def buildAndRegisterSrcBFldConfig(def sourceName) {
		def sourceRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("transID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 2)
				.name("transAmt")
				.type(FieldType.DOUBLE)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 3)
				.name("recordReferenceID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 4)
				.name("transDate")
				.type(FieldType.DATETIME)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 5)
				.name("OID")
				.type(FieldType.STRING)
				.build());
		sourceRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 6)
				.name("reconControlFields")
				.type(FieldType.OBJECT)
				.build());
		utility.buildRecordMetaData(sourceRecordFieldConfigs, sourceName);
		return sourceRecordFieldConfigs;
	}

	def loadRecordsForSource(def collectionName, def mongoDatabase, def srcFldConfigs, def sourceName, def sourceReference) {
		def recordList = new  ArrayList<>();
		def collection = mongoDatabase.getCollection(collectionName)
		def documents = collection.find()
		documents.each { document ->
			Set<String> keys = document.keySet();
			Map<String, Object> sourceFieldValues = new HashMap<>();
			keys.each { key ->
				if(key.equalsIgnoreCase("_id")) {
					sourceFieldValues.put("OID", document.get("_id").toHexString());
				} else {
					sourceFieldValues.put(key, document.get(key));
				}
			}
			println("Record map : " + sourceFieldValues)
			IRecord record = utility.buildRecord(srcFldConfigs, sourceFieldValues, sourceName)
			recordList.add(Arrays.asList(messageFactory.createMessage(MessageType.DATA, record, sourceReference)));
		}
		return recordList;
	}

	//This method implementation is based on assumption about the test data and test field configuration.Any change to test data will
	//impact this method implementation
	def buildReconResultsWithMatchedStatus(def sourceAName, def sourceBName, def databaseName, def datasourceName, def mongoDatabase, def sourceACollection, def sourceBCollection) {
		def reconciliationMatchResults = []
		//register schema
		def srcAFldConfigs = buildAndRegisterSrcAFldConfig(sourceAName)
		def srcBFldConfigs = buildAndRegisterSrcBFldConfig(sourceBName)
		
		def sourceAReference = DBSourceReference.builder()
				.dataSourceName(datasourceName)
				.collectionName(sourceACollection)
				.schemaName(databaseName).build()

		
		def srcARecords = loadRecordsForSource(sourceACollection, mongoDatabase, srcAFldConfigs, sourceAName, sourceAReference)
		println("Source A records: " + srcARecords)

		def sourceBReference = DBSourceReference.builder()
				.dataSourceName(datasourceName)
				.collectionName(sourceBCollection)
				.schemaName(databaseName).build()
		def srcBRecords = loadRecordsForSource(sourceBCollection, mongoDatabase, srcBFldConfigs, sourceBName, sourceBReference)
		println("Source B records: " + srcBRecords)

		
		srcARecords.each { srcASelectedRecords ->
			def selectedRecords = new HashMap<>();
			//put source A records
			selectedRecords.put(sourceAName, srcASelectedRecords)
			def srcBSelectedRecords = findSourceBMatchingRecord(srcASelectedRecords, srcBRecords, "transactionID", "transID")
			//put source A records
			selectedRecords.put(sourceBName, srcBSelectedRecords)
			
			def actualVariance = 0.0d
			def reconResult = new ReconciliationMatchResult(MatchedResultType.MATCHED, selectedRecords)
			reconResult.setSupportingData(new HashMap<>())
			reconResult.getSupportingData().put(IRecordMatcher.TOLERANCE_AMOUNT_VALUE, actualVariance)
			//reconResult.getSupportingData().put(IRecordMatcher.CONFIGURED_TOLERANCE_VALUE, "0")
			reconciliationMatchResults.add(reconResult)
		}
		return reconciliationMatchResults
	}
	
	def findSourceBMatchingRecord(def srcARecords, def srcBRecords, def sourceAFieldName, def sourceBFieldName) {
		def srcARecord = srcARecords.get(0).getData()
		def srATranId = srcARecord.getValue(srcARecord.getFieldId(sourceAFieldName))
		//find the source B records equivalent of Source A record
		return srcBRecords.find { bRecords ->
			def srcBRecord = bRecords.get(0).getData()
			def srBTranId = srcBRecord.getValue(srcBRecord.getFieldId(sourceBFieldName))
			return srATranId.equalsIgnoreCase(srBTranId)
		}
	}

	def mockSalesForceAuthentication() {
		def accessToken = "abcd1234"
		
		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();

		salesforceCaseHelper.authenticate() >> {
			return salesForceAuthResponse 
		}
	}
	
	def verifySourceRecordsForCaseInfo(def mongoDatabase, def sourceCollection, def activityName) {
		MongoCollection<Document> sourceAMgCollection = mongoDatabase.getCollection(sourceCollection);
		Document searchSourceA = new Document();
		searchSourceA.append("reconControlFields."+activityName, new Document("\$exists", true));
		println("Document Filter Source A: " + searchSourceA);
		FindIterable<Document> resultsSourceA = sourceAMgCollection.find(searchSourceA);
		println("Document Found -Source A: " + resultsSourceA);
		resultsSourceA != null
		resultsSourceA.each { document ->
			Map<String, Object> reconControlField = document.get("reconControlFields")
			Map<String, Object> activityReconControlField = reconControlField.get(activityName)
			Map<String, Object> caseInfo = activityReconControlField.get("caseInfo")
			assert caseInfo != null
			assert caseInfo.get("caseID") != null
			assert caseInfo.get("status").toString() == CaseStatus.CLOSED.toString()
		}
	}
	
	def loadPublishedServices(def collectionName, def dataFileLocation, def mongoDatabase) {
		def collection = mongoDatabase.getCollection(collectionName)
		def sampleDataJsonStream = getClass().getResourceAsStream(dataFileLocation)
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		def groupId = ""
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			collection.insertOne(dbObject)
			if(!"000000000000000000000000".equals(dbObject.get("_id").toHexString())) {
				groupId = dbObject.get("_id").toHexString()
			}
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}
		return groupId
	}
	
	def cleanupCollections(def mongoDatabase, def collectionList) {
		collectionList.each { collection -> 
			mongoDatabase.getCollection(collection).drop();
		}
	}
}
