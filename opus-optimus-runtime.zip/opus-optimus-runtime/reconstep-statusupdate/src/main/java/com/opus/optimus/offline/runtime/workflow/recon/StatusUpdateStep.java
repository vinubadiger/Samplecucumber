package com.opus.optimus.offline.runtime.workflow.recon;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongodb.bulk.BulkWriteResult;
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.recon.ReconStatusUpdateConfig;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconControlInfo;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.config.recon.subtypes.SummaryField;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.ErrorHandlerConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.common.api.record.IFieldSchema;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.ISchema;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordFactory;
import com.opus.optimus.offline.runtime.common.reader.MongoDBReaderStep;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.exception.casehandler.ReconCaseTemplateSevice;
import com.opus.optimus.offline.runtime.exception.logger.JobErrorSalesforceCaseClosure;
import com.opus.optimus.offline.runtime.exception.logger.JobErrorSalesforceCaseLogger;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.step.reconciliation.IRecordMatcher;
import com.opus.optimus.offline.runtime.step.reconciliation.MatchedResultType;
import com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceSummary;
import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;
import com.opus.optimus.offline.runtime.workflow.recon.exception.ExceptionErrorCodes;

/**
 * This class is used to update the job reconciliation status after the run of reconciliation complete.
 */
@Component (StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE)
@Scope ("prototype")
public class StatusUpdateStep extends MapStep<ReconStatusUpdateConfig> implements IJobTaskInfoAware {

	private static final String PROC_DATE_ERROR_MSG = "Existing value of processing date in recon control field is not of type date. Actual Type: {}, Activity Name: {}, Sub Status: {}";

	private static final int MAX_BATCH_COMMIT_SIZE = 1024;

	private static final Logger logger = LoggerFactory.getLogger(StatusUpdateStep.class);

	private static final String RECONCTRLFIELDNAME = "reconControlFields";
	
	//constant for recon control info fields
	private static final String RECONCTRLFIELDNAME_PROCESSINGDATE = "processingDate";
	private static final String RECONCTRLFIELDNAME_SUBSTATUS = "subStatus";
	private static final String RECONCTRLFIELDNAME_CASEID = "caseID";
	private static final String RECONCTRLFIELDNAME_CASESTATUS = "status";
	private static final String RECONCTRLFIELDNAME_CASEINFO = "caseInfo";
	
	private static final String TRANSACTION_DATE_NOT_AVAILABLE = "Transaction date is not avalibale for transaction.";

	@Autowired
	private DataSourceFactory dataSourceFactory;

	@Autowired
	RecordFactory recordFactory;

	@Autowired
	IJobInfoService jobInfoService;

	@Autowired
	ReconCaseTemplateSevice reconCaseTemplateService;
	
	/** The error salesforce case logger. */
	@Autowired
	JobErrorSalesforceCaseLogger errorSalesforceCaseLogger;
	
	@Autowired
	JobErrorSalesforceCaseClosure errorSalesforceCaseClosure;

	JobInfo jobInfo = null;

	Map<String, SourceConfig> sourceConfigMap = new HashMap<>();

	Map<String, Integer> summaryFieldInfo = new HashMap<>();

	Map<String, Integer> txnDateFieldInfo = new HashMap<>();

	Map<String, String> sourceCounterPart = new HashMap<>();

	IJobTaskInfo jobTaskInfo;
	
	public class SourceConfig {
		BulkOperations bulkOps;

		int currBulkCommandSize = 0;

		int summaryfieldID;

		int trnsDateFieldID;

		MongoTemplate mongoTemplate;

		public SourceConfig(MongoTemplate mongoTemplate) {
			this.mongoTemplate = mongoTemplate;
		}

		/**
		 * This method is used for adding update command.
		 * 
		 * @param query
		 * @param update
		 */
		void addUpdateCommand(Query query, Update update) {
			bulkOps.updateOne(query, update);
			currBulkCommandSize++;
		}

		/**
		 * This method is used for commit operation.
		 * 
		 * @param force
		 */
		boolean commit(boolean force) {
			if ((force && currBulkCommandSize > 0) || (currBulkCommandSize >= MAX_BATCH_COMMIT_SIZE)){
				logger.debug("Commiting the status update. Force: {}, Bulk Command Size: {}", force, currBulkCommandSize);
				final BulkWriteResult result = bulkOps.execute();
				logger.debug("Commit successful. Record count: {}", result.getMatchedCount());
				currBulkCommandSize = 0;
				return true;
			}
			return false;
		}

		protected MongoTemplate getMongoTemplate() {
			return mongoTemplate;
		}

		@Override
		public String toString() {
			return "SourceConfig [bulkOps=" + bulkOps + ", currBulkCommandSize=" + currBulkCommandSize + ", summaryfieldID=" + summaryfieldID + "]";
		}
	}

	public StatusUpdateStep(ReconStatusUpdateConfig config) {
		super(config);
		this.config = config;
	}

	@PostConstruct
	public void init() {
		try{
			sourceCounterPart.put(config.getSourceA().getSourceName(), config.getSourceB().getSourceName());
			sourceCounterPart.put(config.getSourceB().getSourceName(), config.getSourceA().getSourceName());

			buildSummaryInfo(config.getSourceA());
		} catch (Exception exception){
			logger.error("Error while initialization of the Summary Info for Source : {}", config.getSourceA().getSourceName());
		}
		try{
			buildSummaryInfo(config.getSourceB());
		} catch (Exception exception){
			logger.error("Error while initialization of the Summary Info for Source : {}", config.getSourceB().getSourceName());
		}
		logger.info("Summary Info Built: {}", summaryFieldInfo);
	}

	/**
	 * This method is used to build the summary information.
	 * 
	 * @param summaryField
	 */
	private void buildSummaryInfo(SummaryField summaryField) {
		ISchema schema = recordFactory.getSchema(summaryField.getSourceName());
		if (schema == null) return;
		int index = 0;
		for (IFieldSchema fieldSchema : schema.getFields()){
			if (fieldSchema.getName().equalsIgnoreCase(summaryField.getFieldName())){
				summaryFieldInfo.put(summaryField.getSourceName(), index);
			} else if (fieldSchema.getName().equalsIgnoreCase(summaryField.getTxnDateFieldName())){
				txnDateFieldInfo.put(summaryField.getSourceName(), index);
			}
			index++;
		}
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}

	@Override
	protected <I extends Serializable, R extends Serializable> R doProcess(I data) throws RecordProcessingException {
		try{
			if (summaryFieldInfo.get(config.getSourceA().getSourceName()) == null || summaryFieldInfo.get(config.getSourceB().getSourceName()) == null){
				logger.debug("Summary info is not initialized. Initializing summary info...");
				init();
			}

			if (data instanceof ReconciliationMatchResult){
				ReconciliationMatchResult<IMessage> reconResult = (ReconciliationMatchResult<IMessage>) data;

				setupBulkOps(reconResult);
				switch (reconResult.getType()) {
				case PERFECT:
				case MATCHED:{
					updateReconciledRecords(reconResult);
					break;
				}
				case NO_DATA_IN_SOURCE:{
					updateUnReconciledRecords(reconResult);
					break;
				}
				case UNMATCHED:{
					updateUnReconciledRecords(reconResult);
					break;
				}
				case UNEXPECTED_MULTIPLE_RECORDS:{
					updateUnReconciledRecords(reconResult);
					break;
				}
				default:{
					logger.debug("In the default case...");
					break;
				}
				}
			} else{
				logger.error("The data received in incorrect format. Received: {}, Expected: com.opus.optimus.offline.runtime.step.reconciliation.ReconciliationMatchResult", (data == null ? "No info available." : data.getClass().getName()));
			}
		} catch (RecordProcessingException recordProcessingException){
			throw recordProcessingException;
		} catch (Exception e){
			logger.error("System error while processing the record for Status update.", e);
			ErrorDetails errorDetails = ErrorDetails.builder()
					.additionalData(buildGenExceptionAdditionalData(ExceptionErrorCodes.GENERIC_RECON_EXCEPTION))
					.userDetails("System Exception while update. Error message: " + e.getMessage()).errorDetail(e)
					.severity(Severity.FATAL).build();
			throw new RecordProcessingException(ExceptionErrorCodes.GENERIC_RECON_EXCEPTION, errorDetails);
		}
		return (R) data;
	}

	@Override
	public IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter) {
		logger.debug("{} Instance end. Performing cleanup.", this.getClass().getSimpleName());
		sourceConfigMap.forEach((sourceName, sourceConfig) -> sourceConfig.commit(true));
		sourceConfigMap.clear();
		return super.onInstanceEnd(forceEnd, emitter);
	}

	@Override
	public void onStepEnd(boolean forceEnd, IEmitter emitter) {
		logger.info("{} Step end.", this.getClass().getSimpleName());
		try {
			logger.debug("Performing NoMatch All count case creation. ");
			if(jobInfo == null) {
				jobInfo = jobInfoService.findById(jobTaskInfo.getJobId());
			}
			if(jobInfo == null) {
				logger.error("No JobInfo available in the database with Id: {}. Cannot submit the case for All No match scenario.", jobTaskInfo.getJobId());
			} else {
				final ErrorDetails errorDetails = buildErrorDetails(ReconSubStatus.NoMatch, null, null, null);
				errorSalesforceCaseLogger.postCaseForAllNoMatch(jobInfo, config.getSourceA().getSourceName(), config.getSourceB().getSourceName(), errorDetails);
				//flush cases for close case
				errorSalesforceCaseClosure.flushCases(jobInfo);
			}
		} catch(Exception e) {
			logger.error("Error while processing onStep End work of Status update step.", e);
		}
		super.onStepEnd(forceEnd, emitter);
	}

	/**
	 * This method is used to set up the bulk operations.
	 * 
	 * @param reconResult
	 * @throws RecordProcessingException
	 */
	void setupBulkOps(ReconciliationMatchResult<IMessage> reconResult) throws RecordProcessingException {
		if (sourceConfigMap.size() >= 2){
			return;
		}

		for (Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords().entrySet()){
			String sourceName = entry.getKey();
			List<IMessage> selectedMessages = entry.getValue();
			if (!sourceConfigMap.containsKey(sourceName) && selectedMessages != null && !selectedMessages.isEmpty()){
				ISourceReference srcRef = selectedMessages.get(0).getSourceReference();
				loadSourceConfigs(sourceName, srcRef);
			}
		}
	}

	private void loadSourceConfigs(String sourceName, ISourceReference sourceReference) throws RecordProcessingException {
		DBSourceReference srcDebRef = (DBSourceReference) sourceReference;
		final SourceConfig sourceConfig = buildSourceConfig(sourceName, srcDebRef.getDataSourceName(), srcDebRef.getSchemaName(), srcDebRef.getCollectionName());
		sourceConfigMap.put(sourceName, sourceConfig);
		logger.debug("Source Config Map: {}", sourceConfigMap);
	}

	/**
	 * Build the source config object as per the provided information and BulkOperation
	 * 
	 * @param sourceName
	 * @param dataSourceName
	 * @param databaseName
	 * @param collectionName
	 * @return
	 * @throws RecordProcessingException
	 */
	private SourceConfig buildSourceConfig(String sourceName, String dataSourceName, String databaseName, String collectionName) throws RecordProcessingException {
		try{
			IDataSource dataSource = dataSourceFactory.getDataSource(dataSourceName);
			if (!MongoDataSource.class.isAssignableFrom(dataSource.getClass())){
				// build error message
				final StringBuilder errorMessage = new StringBuilder();
				errorMessage.append("Invalid Data source available. Actual: ");
				errorMessage.append(dataSource.getClass().getName());
				errorMessage.append(", Expected: ");
				errorMessage.append(MongoDataSource.class.getName());
				if (logger.isErrorEnabled()) logger.error(errorMessage.toString());
				final ErrorDetails errorDetails = ErrorDetails.builder()
						.additionalData(buildGenExceptionAdditionalData(ExceptionErrorCodes.GENERIC_RECON_EXCEPTION))
						.userDetails(errorMessage.toString()).severity(Severity.FATAL).build();
				throw new RecordProcessingException(ExceptionErrorCodes.GENERIC_RECON_EXCEPTION, errorDetails);
			}
			logger.debug("Building Source Config after commit execution. Source Name: {}, Data Source name: {}, Database Name: {}, Collection Name: {}", sourceName, dataSourceName, databaseName, collectionName);

			SourceConfig sourceConfig = sourceConfigMap.get(sourceName);
			if (sourceConfig == null){
				MongoTemplate mongoTemplate = new MongoTemplate(((MongoDataSource) dataSource).getMongoClient(), databaseName);
				sourceConfig = new SourceConfig(mongoTemplate);
				sourceConfig.summaryfieldID = summaryFieldInfo.get(sourceName);
				sourceConfig.trnsDateFieldID = txnDateFieldInfo.get(sourceName) != null
						? txnDateFieldInfo.get(sourceName)
						: -1;
			}
			resetBulkOperation(collectionName, sourceConfig);
			return sourceConfig;
		} catch (NoSuchDataSourceAvailableException dsNotAvailableException){
			logger.error(dsNotAvailableException.getMessage(), dsNotAvailableException);
			ErrorDetails errorDetails = ErrorDetails.builder()
					.additionalData(buildGenExceptionAdditionalData(ExceptionErrorCodes.GENERIC_RECON_EXCEPTION))
					.userDetails("Invalid datasource - " + dataSourceName)
					.errorDetail(dsNotAvailableException.getMessage()).severity(Severity.FATAL).build();
			throw new RecordProcessingException(ExceptionErrorCodes.GENERIC_RECON_EXCEPTION, errorDetails);
		}
	}

	private void resetBulkOperation(String collectionName, SourceConfig sourceConfig) {
		sourceConfig.bulkOps = null;
		BulkOperations bulkOps = sourceConfig.getMongoTemplate().bulkOps(BulkMode.UNORDERED, HashMap.class, collectionName);
		sourceConfig.bulkOps = bulkOps;
	}

	/**
	 * This method is used to update the records which are reconciled
	 * 
	 * @param reconResult
	 * @throws RecordProcessingException
	 */
	void updateReconciledRecords(ReconciliationMatchResult<IMessage> reconResult) throws RecordProcessingException {
		if (jobInfo == null){
			logger.debug("Setting up the JobInfo for job id : {}", jobTaskInfo.getJobId());
			jobInfo = jobInfoService.findById(jobTaskInfo.getJobId());
		}
		// Unique reference ID for source record - related reference
		final String referenceUUID = UUID.randomUUID().toString();
		//reference to list of case ids to be closes
		final Set<String> closeCaseIds = new HashSet<>();
		//get the status
		ReconSubStatus subStatus = getReconSubStatus(reconResult.getType());
		// reference to Map for error details to log the reconciliation business exception scenario
		final List<UnReconcileRecords> reconciledRecordInfoList = new ArrayList<>();
		for (Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords ().entrySet ()) {
			String sourceName = entry.getKey ();
			List<IMessage> selectedMessages = entry.getValue ();
			SourceConfig sourceConfig = sourceConfigMap.get (sourceName);

			if (selectedMessages.isEmpty ()) {
				continue;
			}
			// build the unreconciled record info for exception case handling
			final UnReconcileRecords unReconcileRecords = buildUnReconciledRecordsData (sourceName);

			for (IMessage iMessage : selectedMessages) {
				IRecord record = (IRecord) iMessage.getData ();
				String oID = record.getValue (record.getFieldId (MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
				double dblVal = record.getValue (sourceConfig.summaryfieldID);

				Map<String, Object> reconControlField = getReconControlField (record);

				double toleranceAmt = (reconResult.getType () == MatchedResultType.PERFECT ? 0.0 : getToleranceAmount (reconResult));
				ReconControlInfo reconControlInfo = ReconControlInfo.builder ().activityName (config.getActivityName ())
						.amount (dblVal).tolerance (toleranceAmt).absoluteTolerance (getAbsoluteValue (toleranceAmt)).jobId (jobTaskInfo.getJobId ())
						.ruleId (reconResult.getRuleId ()).status (ReconStatus.RECONCILED).subStatus (subStatus)
						.relatedRecordsRefId (referenceUUID).build ();

				final Date newDate = calculateProcessingDate (reconControlField, subStatus);
				reconControlInfo.setProcessingDate (newDate);

				Date transactionDate = record.getValue (sourceConfig.trnsDateFieldID);
				if (transactionDate == null) {
					logger.debug (TRANSACTION_DATE_NOT_AVAILABLE);
				}
				reconControlInfo.setTransactionDate (transactionDate);

				//Need to close the case if any OPEN with this record
				Object existingCaseInfo = fetchFromReconControlInfo (reconControlField, config.getActivityName (), RECONCTRLFIELDNAME_CASEINFO);
				if (existingCaseInfo != null) {
					//get the case Id from it
					final CaseInfo caseInfo = CaseInfo.builder ()
							.caseID (((Document) existingCaseInfo).getString (RECONCTRLFIELDNAME_CASEID))
							.status (CaseStatus
									.valueOf (((Document) existingCaseInfo).getString (RECONCTRLFIELDNAME_CASESTATUS)))
							.build ();
					//set the case info for new recon info if there is any existing case info
					reconControlInfo.setCaseInfo (caseInfo);

					// load the oID in the list of exception info records
					loadPrimaryIdAndOtherInfo (unReconcileRecords, oID, iMessage);
					//set the case id which is getting closed
					unReconcileRecords.setCaseId (caseInfo.getCaseID ());
					reconciledRecordInfoList.add (unReconcileRecords);
					//collect the case ids to be closed
					closeCaseIds.add (caseInfo.getCaseID ());
				}

				reconControlField.put (config.getActivityName (), reconControlInfo);
				Query query = Query.query (new Criteria ("_id").is (oID));
				sourceConfig.addUpdateCommand (query, Update.update (RECONCTRLFIELDNAME, reconControlField));


				boolean commitExecuted = sourceConfig.commit (false);
				if (commitExecuted) {
					loadSourceConfigs (sourceName, iMessage.getSourceReference ());
				}
			}
			
		}
		logger.debug("Calling ErrorCaseClosure to close the cases..");
		errorSalesforceCaseClosure.closeCase(closeCaseIds, jobInfo, reconciledRecordInfoList);
	}

	private double getToleranceAmount(ReconciliationMatchResult<IMessage> reconResult) {
		return (reconResult == null || reconResult.getSupportingData() == null
				|| reconResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) == null) ? 0.0
						: (Double) reconResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE);
	}

	private String getConfiguredTolerance(ReconciliationMatchResult<IMessage> reconResult) {
		return (reconResult == null || reconResult.getSupportingData() == null
				|| reconResult.getSupportingData().get(IRecordMatcher.CONFIGURED_TOLERANCE_VALUE) == null) ? StringUtils.EMPTY
						: (String) reconResult.getSupportingData().get(IRecordMatcher.CONFIGURED_TOLERANCE_VALUE);
	}
	
	/**
	 * This method is used to get the reconciliation subStatus.
	 * 
	 * @param type
	 * @return ReconSubStatus
	 */
	ReconSubStatus getReconSubStatus(MatchedResultType type) {
		switch (type) {
		case PERFECT:
			return ReconSubStatus.Exact;
		case MATCHED:
			return ReconSubStatus.MatchWithinTolerance;
		case NO_DATA_IN_SOURCE:
			return ReconSubStatus.NoMatch;
		case UNEXPECTED_MULTIPLE_RECORDS:
			return ReconSubStatus.MultipleMatches;
		case UNMATCHED:
			return ReconSubStatus.MatchBeyondTolerance;
		default:
			return ReconSubStatus.NoMatch;
		}
	}

	static String getOID(IMessage msg) {
		IRecord record = (IRecord) msg.getData();
		return record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
	}

	/**
	 * This method is used to update the records which are not reconciled
	 * 
	 * @param reconResult
	 * @throws RecordProcessingException
	 */
	void updateUnReconciledRecords(ReconciliationMatchResult<IMessage> reconResult) throws RecordProcessingException {
		ReconSubStatus subStatus = getReconSubStatus(reconResult.getType());
		// case 1: unreconciled (no corresponding records)
		// case 3: multiple records
		if (subStatus == ReconSubStatus.NoMatch || subStatus == ReconSubStatus.MultipleMatches){
			handleUnMatchAndMultiMatch(reconResult, subStatus);
		}
		// case 2: matched beyond tolerance (Create a case)
		else if (subStatus == ReconSubStatus.MatchBeyondTolerance){
			handleMatchBeyondTolerance(reconResult, subStatus);
		}
	}

	private void handleMatchBeyondTolerance(ReconciliationMatchResult<IMessage> reconResult, ReconSubStatus subStatus) throws RecordProcessingException {
		// Unique reference ID for source record - related reference
		final String referenceUUID = UUID.randomUUID().toString();
		// reference to Map for error details to log the reconciliation business exception scenario
		final List<UnReconcileRecords> errorRecordInfoList = new ArrayList<>();
		// get the tolerance value from the recon result
		double toleranceAmt = getToleranceAmount(reconResult);
		// stamp with processing date
		for (Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords().entrySet()){
			String sourceName = entry.getKey();
			logger.debug("Processing for status {} for the records of Source {}, Available Source config Map: {}", subStatus, sourceName, sourceConfigMap);
			List<IMessage> selectedMessages = entry.getValue();
			SourceConfig sourceConfig = sourceConfigMap.get(sourceName);

			final UnReconcileRecords unReconcileRecords = buildUnReconciledRecordsData(sourceName);

			IMessage msg = selectedMessages.get(0); // for One to One recon only one record would be available
			IRecord record = (IRecord) msg.getData();
			String oID = record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
			double dblVal = record.getValue(sourceConfig.summaryfieldID);

			Map<String, Object> reconControlField = getReconControlField(record);

			ReconControlInfo reconControlInfo = ReconControlInfo.builder().activityName(config.getActivityName())
					.amount(dblVal).tolerance(toleranceAmt).absoluteTolerance(getAbsoluteValue(toleranceAmt))
					.jobId(jobTaskInfo.getJobId()).ruleId(reconResult.getRuleId()).status(ReconStatus.UNRECONCILED)
					.subStatus(subStatus).relatedRecordsRefId(referenceUUID).build();
			final Date newDate = calculateProcessingDate(reconControlField, subStatus);
			reconControlInfo.setProcessingDate(newDate);

			Date transactionDate = record.getValue(sourceConfig.trnsDateFieldID);
			if(transactionDate ==  null) {
				logger.debug(TRANSACTION_DATE_NOT_AVAILABLE);
			}
			reconControlInfo.setTransactionDate(transactionDate);
			
			reconControlField.put(config.getActivityName(), reconControlInfo);
			Query query = Query.query(new Criteria("_id").is(oID));
			sourceConfig.addUpdateCommand(query, Update.update(RECONCTRLFIELDNAME, reconControlField));
			boolean commitExecuted = sourceConfig.commit(false);
			if (commitExecuted){
				logger.debug("Commit executed, Loading source config for the Source Name: {}", sourceName);
				loadSourceConfigs(sourceName, msg.getSourceReference());
			}
			// load the oID in the list of exception info records
			loadPrimaryIdAndOtherInfo(unReconcileRecords, oID, msg);
			errorRecordInfoList.add(unReconcileRecords);
		}
		
		// throw exception with Error details for the case and business exception handling
		logger.debug("Calling Build & Throw Recon Exception routine..");
		buildAndThrowReconException(subStatus, errorRecordInfoList, reconResult, referenceUUID);
	}

	private UnReconcileRecords buildUnReconciledRecordsData(String sourceName) {
		// prepare the exception source info
		// build the unreconciled record info for exception case handling
		final List<String> oIDs = new ArrayList<>();
		return UnReconcileRecords.builder().sourceName(sourceName).oIDs(oIDs).build();
	}

	private void loadPrimaryIdAndOtherInfo(final UnReconcileRecords unReconcileRecords, String oID, IMessage msg) {
		// load the oID in the list of exception info records
		unReconcileRecords.getOIDs().add(oID);
		unReconcileRecords.setCollectionName(((DBSourceReference) msg.getSourceReference()).getCollectionName());
		unReconcileRecords.setDataSourceName(((DBSourceReference) msg.getSourceReference()).getDataSourceName());
	}

	private void handleUnMatchAndMultiMatch(ReconciliationMatchResult<IMessage> reconResult, ReconSubStatus subStatus) throws RecordProcessingException {
		// Unique reference ID for source record - related reference
		final String referenceUUID = UUID.randomUUID().toString();

		// reference to Map for error details to log the reconciliation business exception scenario
		final List<UnReconcileRecords> errorRecordInfoList = new ArrayList<>();
		
		//flag to note create case
		boolean createCase = false;
		
		// stamp with processing date
		// each source could have different number of records
		// for multipleMatches
		// Following loop has written in traditional way as we need to throw a checked exception - RecordProcessingException
		for (Map.Entry<String, List<IMessage>> entry : reconResult.getSelectedRecords().entrySet()){
			String sourceName = entry.getKey();
			logger.debug("Processing for status {} for the records of Source {}, Available Source config Map: {}", subStatus, sourceName, sourceConfigMap);
			List<IMessage> selectedMessages = entry.getValue();
			SourceConfig sourceConfig = sourceConfigMap.get(sourceName);

			if (selectedMessages != null && !selectedMessages.isEmpty()){
				// prepare the exception source info
				// build the unreconciled record info for exception case handling
				final UnReconcileRecords unReconcileRecords = buildUnReconciledRecordsData(sourceName);
				for (IMessage msg : selectedMessages){
					IRecord record = (IRecord) msg.getData();
					String oID = record.getValue(record.getFieldId(MongoDBReaderStep.MONGO_OBJECT_ID_RECORD_FIELD_NAME));
					double dblVal = record.getValue(sourceConfig.summaryfieldID);
					Date transactionDate = record.getValue(sourceConfig.trnsDateFieldID);
					if(transactionDate ==  null) {
						logger.debug(TRANSACTION_DATE_NOT_AVAILABLE);
					}
					
					Map<String, Object> reconControlField = getReconControlField(record);
					//calculate processing date
					final Date newDate = calculateProcessingDate(reconControlField, subStatus);
					//build recon control info
					final ReconControlInfo reconControlInfo = ReconControlInfo.builder()
							.activityName(config.getActivityName()).amount(dblVal).tolerance(0.0).absoluteTolerance(0.0)
							.jobId(jobTaskInfo.getJobId()).ruleId(reconResult.getRuleId())
							.status(ReconStatus.UNRECONCILED).subStatus(subStatus).relatedRecordsRefId(referenceUUID)
							.processingDate(newDate).transactionDate(transactionDate).build();
					//If there is no change in the status, no need to update. But if no change in status
					//and marked aged then need to update
					boolean recordAgedFlag = markRecordIfAged(subStatus, newDate, reconControlInfo);
					boolean statusChangeFlag = checkForChangeInSubStatus(reconControlField, config.getActivityName(), subStatus);
					if(recordAgedFlag || statusChangeFlag) {
						logger.debug("The record is either marked as Aged or there is change in the existing status.");
						reconControlField.put(config.getActivityName(), reconControlInfo);	
						Query query = Query.query(new Criteria("_id").is(oID));
						sourceConfig.addUpdateCommand(query, Update.update(RECONCTRLFIELDNAME, reconControlField));
						boolean commitExecuted = sourceConfig.commit(false);
						if (commitExecuted){
							logger.debug("Commit executed, Loading source config for the Source Name: {}", sourceName);
							loadSourceConfigs(sourceName, msg.getSourceReference());
						}	
					}
					/**
					 * In case of NoMatch, Application will wait till x configured days for case creation for NoMatch records. 
					 * The x days configuration will be different per activity. Application will create a sub case for every 
					 * reconciliation with NoMatch record count. This is the count of NoMatch records which are fresh records.Application 
					 * will keep creating the sub case with refreshed count of an activity for a particular processing date 
					 * under the original parent case. Application will create the sub cases under the original parent case 
					 * for all NoMatch records as of reconciliation date passed configured threshold days. 
					 * Optional, application will close the case with AllNoMatchCount
					 * Application will close the sub cases once the record got reconciled.
					 */
					if(ReconSubStatus.NoMatch.equals(subStatus) && !recordAgedFlag) {
						boolean isNewlyIngestedRecord = checkIfRecordNewlyIngested(record);
						if(!isNewlyIngestedRecord && isCaseCreateThresholdReached(newDate)) {
							createCase = true;
							// load the oID in the list of exception info records
							loadPrimaryIdAndOtherInfo(unReconcileRecords, oID, msg);
						} else {
							UnReconcileRecords nonMatchUnReconcileRecords = errorSalesforceCaseLogger
									.getNoMatchSourceRecord(newDate, sourceName);
							if(nonMatchUnReconcileRecords == null) {
								// build the unreconciled record info for exception case handling for All No match records
								nonMatchUnReconcileRecords = buildUnReconciledRecordsData(sourceName);
								// load the oID in the list of exception info records
								loadPrimaryIdAndOtherInfo(nonMatchUnReconcileRecords, oID, msg);
								errorSalesforceCaseLogger.pushToNoMatchCountBucket(newDate, sourceName, nonMatchUnReconcileRecords);
							} else {
								// load the oID in the list of exception info records
								loadPrimaryIdAndOtherInfo(nonMatchUnReconcileRecords, oID, msg);
							}
						}
					} else if(ReconSubStatus.MultipleMatches.equals(subStatus)) {
						createCase = true;
						//MutiplMatches scenario - load the oID in the list of exception info records
						loadPrimaryIdAndOtherInfo(unReconcileRecords, oID, msg);	
					}
				}
				errorRecordInfoList.add(unReconcileRecords);
			}
			
		}
		logger.debug("Case create flag: {}", createCase);
		if(createCase) {
			// throw exception with Error details for the case and business exception handling
			logger.debug("Calling Build & Throw Recon Exception routine..");
			buildAndThrowReconException(subStatus, errorRecordInfoList, reconResult, referenceUUID);
		} 
	}

	/**
	 * This method is used to commit the bulk operations if it is full.
	 * 
	 * @param bulkOps
	 */
	void commitIfFull(BulkOperations bulkOps) {
		bulkOps.execute();
	}

	private Date calculateProcessingDate(Map<String, Object> reconControlField, ReconSubStatus subStatus) {
		Date newDate = null;
		//get the processing date if any from recon control info
		Object existingProcessingDate = fetchFromReconControlInfo(reconControlField, config.getActivityName(), RECONCTRLFIELDNAME_PROCESSINGDATE);
		if(existingProcessingDate == null) {
			newDate = java.util.Date.from(java.time.LocalDate.now().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		} else {
			try{
				newDate = (Date) existingProcessingDate;
			} catch (ClassCastException classCastException){
				logger.error(PROC_DATE_ERROR_MSG, existingProcessingDate.getClass(), config.getActivityName(), subStatus);
				newDate = java.util.Date.from(java.time.LocalDate.now().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			}	
		}
		return newDate;
	}

	private boolean markRecordIfAged(ReconSubStatus subStatus, Date newDate, ReconControlInfo reconControlInfo) {
		// perform ageing only if unReconciledBacklog is enabled
		if (config.isUnreconciledBacklog() && subStatus == ReconSubStatus.NoMatch
				&& isProcessingDatePassThreshold(newDate, config.getTimeLegInterval())) {
			reconControlInfo.setSubStatus(ReconSubStatus.Aged);
			return true;
		}
		return false;
	}

	private Map<String, Object> getReconControlField(IRecord record) {
		final Map<String, Object> reconControlField = record.getValue(record.getFieldId(RECONCTRLFIELDNAME));
		return reconControlField == null ? new HashMap<>() : reconControlField;
	}

	private void buildAndThrowReconException(ReconSubStatus subStatus, final List<UnReconcileRecords> errorRecordInfoList, ReconciliationMatchResult<
					IMessage> reconResult, String referenceUUID) throws RecordProcessingException {
		throw new RecordProcessingException("", buildErrorDetails(subStatus, errorRecordInfoList, reconResult, referenceUUID));
	}

	private ErrorDetails buildErrorDetails(ReconSubStatus subStatus, final List<UnReconcileRecords> errorRecordInfoList,
			ReconciliationMatchResult<IMessage> reconResult, String referenceUUID) {
		final Map<String, Object> exceptionSupportingData = new HashMap<>(1);
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_UNIQUE_REC_IDS_KEY, errorRecordInfoList);
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY, config.getActivityName());
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_RECON_STATUS_KEY, subStatus);
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_RECON_TOLERANCE_KEY, getToleranceAmount(reconResult));
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_RECON_CONF_TOLERANCE_KEY, getConfiguredTolerance(reconResult));
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_RECON_UUID_KEY, referenceUUID);
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY,
				(config != null ? config.getSourceA().getSourceName()
						: StringUtils.EMPTY));
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY,
				(config != null ? config.getSourceB().getSourceName()
						: StringUtils.EMPTY));
		return ErrorDetails.builder().additionalData(exceptionSupportingData).severity(Severity.ERROR)
				.userDetails("Reconcile result - " + subStatus.name()).build();
	}

	private boolean checkIfRecordNewlyIngested(IRecord record) {
		final Map<String, Object> reconControlField = record.getValue(record.getFieldId(RECONCTRLFIELDNAME));
		return reconControlField == null || reconControlField.get(config.getActivityName()) == null; 
	}
	
	/**
	 * Check if the processing date reached to threshold for creating the sub cases for each NoMatch results
	 * @param processingDate
	 * @return
	 */
	private boolean isCaseCreateThresholdReached(Date processingDate) {
		return isProcessingDatePassThreshold(processingDate, config.getCaseCreationThreshold());
	}
	
	private boolean isProcessingDatePassThreshold(Date processingDate, int threshold) {
		//convert java.util.Date to java.time.LocalDateTime
		LocalDateTime localProcDateTime = processingDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		//add the threshold to processing date
		localProcDateTime = localProcDateTime.plusDays(threshold);
		//get the java.util.date from calculated processing date + threshold
		Date thresholdProcessingDate = Date.from(localProcDateTime.atZone(ZoneId.systemDefault()).toInstant());
		// current date
		final Date currDate = Date.from(java.time.LocalDate.now().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		return currDate.after(thresholdProcessingDate) || currDate.equals(thresholdProcessingDate);
	}
	
	private Object fetchFromReconControlInfo(final Map<String, Object> reconControlField, final String activityName,
			final String fieldName) {
		Object reconCntrlActivityDBValue = reconControlField.get(activityName);
		if (reconCntrlActivityDBValue != null
				&& Document.class.isAssignableFrom(reconCntrlActivityDBValue.getClass())) {
			if (RECONCTRLFIELDNAME_PROCESSINGDATE.equalsIgnoreCase(fieldName)) {
				return ((Document) reconCntrlActivityDBValue).getDate(fieldName);
			} else if (RECONCTRLFIELDNAME_SUBSTATUS.equalsIgnoreCase(fieldName)
					|| RECONCTRLFIELDNAME_CASEINFO.equalsIgnoreCase(fieldName)) {
				return ((Document) reconCntrlActivityDBValue).get(fieldName);
			} else if (RECONCTRLFIELDNAME_CASEID.equalsIgnoreCase(fieldName)) {
				final Object caseInfoDoc = ((Document) reconCntrlActivityDBValue).get(RECONCTRLFIELDNAME_CASEINFO);
				if (caseInfoDoc != null && Document.class.isAssignableFrom(caseInfoDoc.getClass())) {
					return ((Document) caseInfoDoc).getString(fieldName);
				} else {
					logger.error("No data available for the field: {} from recon control info of activity: {}",
							RECONCTRLFIELDNAME_CASEINFO, activityName);
					return null;
				}
			} else {
				logger.error("No data available for the field: {} from recon control info of activity: {}", fieldName,
						activityName);
				return null;
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug(
						"Error while fetching the field: {} value from recon control info for activity: {}. It must be a newly ingested record.",
						fieldName, activityName);
			}
			return null;
		}
	}
	
	private boolean checkForChangeInSubStatus(Map<String, Object> reconControlField, String activityName,
			ReconSubStatus subStatus) {
		//get the existing substatus if any from recon control info
		Object existingSubStatusValue = fetchFromReconControlInfo(reconControlField, activityName, RECONCTRLFIELDNAME_SUBSTATUS);
		if(existingSubStatusValue == null) {
			return true;
		} else {
			try {
				final String existingSubStatusStr = (String)existingSubStatusValue;
				final ReconSubStatus existingSubStatus = ReconSubStatus.valueOf(existingSubStatusStr);
				return !subStatus.equals(existingSubStatus);
			} catch(ClassCastException castException) {
				logger.error("Existing value of Sub Status in recon control field is not of type String. Actual Type: {}, Activity Name: {}, Sub Status: {}", existingSubStatusValue.getClass(), config.getActivityName(), subStatus);
				return true;
			}
		}
	}
	
	private double getAbsoluteValue(double exactValue) {
		return Math.abs(exactValue);
	}
	
	/**
	 *
	 * @param errorCode
	 * @return
	 */
	private Map<String, Object> buildGenExceptionAdditionalData(String errorCode) {
		final Map<String, Object> exceptionSupportingData = new HashMap<>(1);
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_ERROR_CODE_KEY, errorCode);
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY, config.getActivityName());
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY,
				(config != null ? config.getSourceA().getSourceName()
						: StringUtils.EMPTY));
		exceptionSupportingData.put(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY,
				(config != null ? config.getSourceB().getSourceName()
						: StringUtils.EMPTY));
		return exceptionSupportingData;
	}
}
