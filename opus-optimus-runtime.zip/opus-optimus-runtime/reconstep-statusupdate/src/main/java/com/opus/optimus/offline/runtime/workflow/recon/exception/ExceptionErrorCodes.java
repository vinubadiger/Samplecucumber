package com.opus.optimus.offline.runtime.workflow.recon.exception;

public class ExceptionErrorCodes {
	private ExceptionErrorCodes() {}
	
	public static final String GENERIC_RECON_EXCEPTION = "RCN-GEN-001";
}
