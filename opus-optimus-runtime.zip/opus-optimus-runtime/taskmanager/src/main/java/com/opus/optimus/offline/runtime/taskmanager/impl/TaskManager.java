package com.opus.optimus.offline.runtime.taskmanager.impl;

import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobResultService;
import com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManager;
import com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager;
import com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobIdException;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobResult;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;
import com.opus.optimus.offline.runtime.taskmanager.mongo.datasource.DataSourceOperation;
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus;
import com.opus.optimus.offline.runtime.workflow.api.event.IJobEventManager;
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper;

/**
 * This class is used for managing the all the task which are related to job that is create, run ,cancel job and fetching the job information and job
 * result.
 */
@Component
public class TaskManager implements ITaskManager, ITaskManagerAdmin, IRawTaskManagerListener {

	/** The logger. */
	private static Logger logger = LoggerFactory.getLogger(TaskManager.class);

	/** The raw task manager. */
	@Autowired
	IRawTaskManager rawTaskManager;

	/** The job info service. */
	@Autowired
	IJobInfoService jobInfoService;

	/** The job result service. */
	@Autowired
	IJobResultService jobResultService;

	/** The job event manager. */
	@Autowired (required = false)
	IJobEventManager jobEventManager;

	/** The job event emitter helper. */
	JobEventEmitterHelper jobEventEmitterHelper;

	@Autowired
	private JobErrorDetailsRepository jobErrorDetailsService;
	
	/**
	 * This is required as TaskManager performs few updates once Job completes
	 */

	private static final String ERROR_TYPE = "FATAL";

	
	/**
	 * Inits the.
	 */
	@PostConstruct
	void init() {
		if (this.jobEventManager != null){
			this.jobEventEmitterHelper = new JobEventEmitterHelper(this.jobEventManager.getEmitter());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin#start()
	 */
	@Override
	public void start() {
		this.rawTaskManager.addListener(this);
		this.rawTaskManager.start();
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManagerAdmin#stop()
	 */
	@Override
	public void stop() {
		this.rawTaskManager.stop();
		this.rawTaskManager.removeListener(this);
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager#createJob(java.lang.String, java.util.List)
	 */
	@Override
	public String createJob(String name, List<JobTask> jobTasks) {
		try{
			String jobId = this.rawTaskManager.generateJobId();
			JobInfo jobInfo = JobInfo.builder().id(jobId).name(name).jobTasks(jobTasks).status(JobStatus.CREATED).createdTime(new Date()).build();
			this.jobInfoService.save(jobInfo);
			return jobId;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager#runJob(java.lang.String)
	 */
	@Override
	public CompletableFuture<JobResult> runJob(String jobId) throws InvalidJobIdException, InvalidJobStatusException {
		logger.debug("Starting Run Job for JobID {}", jobId);
		JobInfo jobInfo = this.jobInfoService.updateStatusAndGet(jobId, JobStatus.WAITING_TO_START);
		if (jobInfo == null){
			throw new InvalidJobIdException(jobId);
		}
		try{
			logger.debug("Submitting Job with JobID {}", jobId);
			CompletableFuture<Void> result = this.rawTaskManager.submitJob(jobId, jobInfo.getJobTasks());
			return result.thenApply(v -> this.jobResultService.findById(jobId));
		} catch (Exception e){
			throw new EngineException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager#cancelJob(java.lang.String)
	 */
	@Override
	public void cancelJob(String jobId) throws InvalidJobIdException, InvalidJobStatusException {
		JobInfo jobInfo = this.jobInfoService.updateStatusAndGet(jobId, JobStatus.CANCEL_IN_PROGRESS);
		if (jobInfo == null){
			throw new InvalidJobIdException(jobId);
		}
		this.rawTaskManager.cancelJob(jobId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager#getJobInfo(java.lang.String)
	 */
	@Override
	public JobInfo getJobInfo(String jobId) throws InvalidJobIdException {
		JobInfo jobInfo = this.jobInfoService.findById(jobId);
		if (jobInfo == null){
			throw new InvalidJobIdException(jobId);
		}
		return jobInfo;
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager#getJobInfos(com.opus.optimus.offline.runtime.taskmanager.model.JobStatus)
	 */
	@Override
	public List<JobInfo> getJobInfos(JobStatus jobStatus) {
		return this.jobInfoService.findByStatus(jobStatus);
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.ITaskManager#getJobResult(java.lang.String)
	 */
	@Override
	public JobResult getJobResult(String jobId) throws InvalidJobIdException {
		JobResult jobResult = this.jobResultService.findById(jobId);
		if (jobResult == null){
			throw new InvalidJobIdException(jobId);
		}

		return jobResult;
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener#onTaskStart(java.lang.String, java.lang.String)
	 */
	@Override
	public void onTaskStart(String jobId, String taskId) {
		logger.info("Task started with JobId {} & TaskId {}", jobId, taskId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener#onTaskComplete(java.lang.String, java.lang.String)
	 */
	@Override
	public void onTaskComplete(String jobId, String taskId) {
		logger.info("Task completed with JobId {} & TaskId {}", jobId, taskId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener#onJobStart(java.lang.String)
	 */
	@Override
	public void onJobStart(String jobId) {
		this.jobInfoService.updateStatus(jobId, JobStatus.STARTED);
		if (this.jobEventEmitterHelper != null){
			this.jobEventEmitterHelper.startJob(jobId);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.opus.optimus.offline.runtime.taskmanager.api.IRawTaskManagerListener#onJobComplete(java.lang.String)
	 */
	@Override
	public void onJobComplete(String jobId) {
		try{
			logger.debug("Starting OnJobComplete post processings for JobId - {}", jobId);
			final JobResult jobResult = getJobResult(jobId);

			boolean isJobAborted = jobResult.getTaskResults().stream().anyMatch(taskResult -> {
				return taskResult.getStepExecutorResults().stream().anyMatch(executorResult -> {
					return executorResult.getInstanceStats().anySatisfy(instanceStat -> OperationStatus.ABORTED.equals(instanceStat.getStatus()));
				});
			});
			final List<JobErrorDetails>  jobErrorDetails = jobErrorDetailsService.findByjobIdAnderrorType(jobId, ERROR_TYPE);
			boolean isFatalErrorFound = (jobErrorDetails != null && !(jobErrorDetails.isEmpty()));
			if (isJobAborted || isFatalErrorFound){
				jobInfoService.rollbackJobData(jobId);
				logger.debug("JobAborted status found in JobTaskResults : {}, FATAL error found in JobErrorDetails - {}", isJobAborted, isFatalErrorFound);
				updateJobInfoStatus(jobId, JobStatus.COMPLETED_FAILED);
			} else {
				updateJobInfoStatus(jobId, JobStatus.COMPLETED_SUCCESS);
			}
			this.rawTaskManager.cleanZookeeperId(jobId);
		} catch (InvalidJobIdException invalidjobIdException){
			logger.error(invalidjobIdException.getMessage(), invalidjobIdException);
			logger.debug("Job failed due to error occured while updating the status. Marking it as COMPLETED_FAILED");
			updateJobInfoStatus(jobId, JobStatus.COMPLETED_FAILED);
		} catch (Exception e){
			logger.error(e.getMessage(), e);
			logger.debug("Job failed due to error occured while updating the status. Marking it as COMPLETED_FAILED");
			updateJobInfoStatus(jobId, JobStatus.COMPLETED_FAILED);
		}
	}

	/**
	 * Update job info status.
	 *
	 * @param jobId the job id
	 * @param jobStatus the job status
	 */
	private void updateJobInfoStatus(String jobId, JobStatus jobStatus) {
		jobInfoService.updateStatus(jobId, jobStatus);
		if (jobEventEmitterHelper != null){
			jobEventEmitterHelper.endJob(jobId, jobStatus.name());
		}
	}
}
