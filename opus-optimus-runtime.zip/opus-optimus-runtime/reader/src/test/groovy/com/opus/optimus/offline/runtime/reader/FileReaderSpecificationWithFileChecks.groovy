package com.opus.optimus.offline.runtime.reader

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.DelimitedFieldConfig
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig
import com.opus.optimus.offline.config.fieldextractor.impl.DelimitedFieldExtractorConfig
import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.common.reader.TextFileReaderHelper;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import groovy.xml.StreamingDOMBuilder

import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.attribute.FileAttribute
import java.nio.file.attribute.PosixFilePermission
import java.nio.file.attribute.PosixFilePermissions

import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class FileReaderSpecificationWithFileChecks extends Specification {

	@Autowired
	TextFileReaderHelper fileReader;

	@Autowired
	MapperFactory mapperFactory

	def "CSV reader execution for blank file "() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 2;


		def fileReaderConfig = new TextFileReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/DelimitedConfigJSON_Blank_Sections.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		fileReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testFile_Blank.csv";

		fileReader.init(inputFileLocation , fileReaderConfig, "hey");

		def noOfColumnsRead = 0;
		def columnTypesMatch = true;
		def columnTypes = ["String", "Long"];

		when:
		println("CSV reader execution")
		fileReader.processFile(null, new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						print("data row:	");
						noOfColumnsRead = record.schema.fields.size();
						for  (int i =0; i < noOfColumnsRead ; i++) {
							String type = record.getValue(i).getClass().getSimpleName();
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		thrown ReaderException
	}
	
	@Ignore
	def "CSV reader execution for authorized file "() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 2;


		def fileReaderConfig = new TextFileReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/DelimitedConfigJSON_Blank_Sections.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		fileReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testFile_Lock.csv";
		def file = new File(inputFileLocation)
		println("Input file location ======> " + new File(inputFileLocation).getAbsolutePath())
		
		String osName =System.getProperty("os.name").toLowerCase();
		
		if(osName.contains("win")) {
			Runtime.getRuntime().exec("icacls " + file.getAbsolutePath() +" /deny %username%:(F)").waitFor();
			Runtime.getRuntime().exec("icacls " + file.getAbsolutePath() +" /deny Administrators:(F)").waitFor();
			Runtime.getRuntime().exec("icacls " + file.getAbsolutePath() +" /deny SYSTEM:(F)").waitFor();
		}
		if(osName.contains("nix") || osName.contains("nux") || osName.contains("aix")){
			Runtime.getRuntime().exec("chmod 600 ./src/test/resources/testFile_Lock.csv");
		}
		

		fileReader.init(inputFileLocation , fileReaderConfig, "hey");

		def noOfColumnsRead = 0;
		def columnTypesMatch = true;
		def columnTypes = ["String", "Long"];

		when:
		println("CSV reader execution")
		fileReader.processFile(null, new IRecordReaderEventHandlerAdapter() {
			public void onData(IRecord record,ISourceReference sourceReference) {}
		});

		then:
		thrown ReaderException
		if(osName.contains("win"))  {
			Runtime.getRuntime().exec("icacls ./src/test/resources/testFile_Lock.csv /grant %usename%:(F)");
			Runtime.getRuntime().exec("icacls ./src/test/resources/testFile_Lock.csv /grant Administrators:(F)");
			Runtime.getRuntime().exec("icacls ./src/test/resources/testFile_Lock.csv /grant SYSTEM:(F)");
		}
		if(osName.contains("nix") || osName.contains("nux") || osName.contains("aix")){
			Runtime.getRuntime().exec("chmod 777 ./src/test/resources/testFile_Lock.csv");
		}
	}
}
