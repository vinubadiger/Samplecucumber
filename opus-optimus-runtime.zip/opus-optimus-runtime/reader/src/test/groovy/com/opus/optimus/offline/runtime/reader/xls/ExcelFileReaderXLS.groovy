package com.opus.optimus.offline.runtime.reader.xls

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.reader.ExcelReaderConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.ExcelReaderHelper
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ExcelFileReaderXLS extends Specification {

	@Autowired
	ExcelReaderHelper excelReader;
	
	@Autowired
	MapperFactory mapperFactory

	def "Excel reader execution"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 7;
			def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLS1.xls";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter(){
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data row");
						int maxIndex = record.schema.fields.size();
						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows > 8
	}
}
