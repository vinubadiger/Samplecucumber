package com.opus.optimus.offline.runtime.reader.xls

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.ExcelFieldConfig
import com.opus.optimus.offline.config.reader.ExcelReaderConfig
import com.opus.optimus.offline.config.record.impl.ExcelRecordExtractorConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.ExcelReaderHelper
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ExcelFileStructureCheckXLS extends Specification {

	@Autowired
	ExcelReaderHelper excelReader;

	@Autowired
	MapperFactory mapperFactory


	def "Excel XLSX No of row iterated"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 7;

		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLS1.xls";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		println("--------TEST 1--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data row");
						int maxIndex = record.schema.fields.size();
						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows == 10
	}

	//	TEST 2
	def "Excel XLSX No of row skip check"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 7;
		def nullFlag = false;
		def nullCounter =0;

		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/ExcelWithRowExcepion.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLS2.xls";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		println("--------TEST 2--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data rows");
						int maxIndex = record.schema.fields.size();
						//						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							if((record.getValue(i)).toString().trim().length() <= 0) {
								nullCounter ++;
								print("row no#::"+noOfRows+"    field no#"+i);
							}
							if(nullCounter == maxIndex){
								nullFlag = true;
							}
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		nullFlag == false;
	}


	//	TEST 3
	def "Excel XLSX No of sheet iterate check"() {
		setup:
		def noOfRows = 0;
		def recordsInSheet = 13;
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/ExcelWithRowExcepion.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLS2.xls";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		println("--------TEST 3--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data rows");
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		recordsInSheet < noOfRows;
	}
	
	
	//	TEST 4
	def "Excel XLSX No of sheet iterate check test"() {
		setup:
		def noOfRows = 0;
		def recordsInSheet = 48;
		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel2.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/samson_shortdata_01.xlsx";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		println("--------TEST 4--------");
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data rows");
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		println("Total no of row parse --->"+noOfRows)
		recordsInSheet == noOfRows;
	}
	


}
