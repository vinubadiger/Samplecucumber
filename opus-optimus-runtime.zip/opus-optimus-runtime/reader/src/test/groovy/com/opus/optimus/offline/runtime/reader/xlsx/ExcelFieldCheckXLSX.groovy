package com.opus.optimus.offline.runtime.reader.xlsx

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.config.reader.ExcelReaderConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.ExcelReaderHelper
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ExcelFieldCheckXLSX extends Specification {

	@Autowired
	ExcelReaderHelper excelReader;

	@Autowired
	MapperFactory mapperFactory

	//check if it iterating through all coulumns(fields)
	def "Check for All field (All column iteration)"() {
		setup:
		def noOfRowsInFile = 8;
		def columnCount = 0;
		def totalColumns = 7;
		def columnMissmatch = 0

		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLSX1.xlsx";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							columnCount++;
							print(record.getValue(i));
							print("-");
						}
						if(columnCount != totalColumns) {
							columnMissmatch++;
						}
						columnCount = 0;
						println("");
					}
				});

		then:
		columnMissmatch == 0
	}

	//check data type of fields are correct as per given input type
	def "Data type of fields"() {
		setup:
		def noOfRowsInFile = 8;


		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLSX1.xlsx";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		def columnMissmatch = false;
		def columnDataType = [
			"Date",
			"String",
			"String",
			"String",
			"String",
			"String",
			"String"
		];

		when:
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							String type = record.getValue(i).getClass().getSimpleName();
							if(!type.equals(columnDataType.get(i))) {
								columnMissmatch = true;
							}
							print(record.getValue(i));
							print("-");
						}
						println("");
					}
				});

		then:
		columnMissmatch == false
	}

	//check, is it iterating through all rows
	def "Check for all rows iteartion"() {
		setup:
		def noOfRowsInFile = 10;
		def noOfRows = 0;

		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLSX1.xlsx";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						int maxIndex = record.schema.fields.size();
						for  (int i =0; i < maxIndex ; i++) {
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows == noOfRowsInFile
	}
}
