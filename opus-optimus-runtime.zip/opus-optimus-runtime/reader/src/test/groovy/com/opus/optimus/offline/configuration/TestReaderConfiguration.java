package com.opus.optimus.offline.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.opus.optimus.offline.config.exception.EngineException;

import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.IMongodConfig;
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;
import de.flapdoodle.embed.process.runtime.Network;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@TestConfiguration
@ComponentScan(basePackages = {"com.opus.optimus.offline", "com.opusconsulting.pegasus.formula"})
@EnableMongoRepositories ({"com.opus.optimus.offline.runtime.common.reader.repository" ,"com.opus.optimus.offline.runtime.common.writer.repository"})
public class TestReaderConfiguration {

	private static final String MONGO_HOST_IP = "localhost";
	private int port = 0;
	private MongodExecutable mongodExecutable;
	private MongodProcess mongod;
	private static final Logger logger = LoggerFactory.getLogger(TestReaderConfiguration.class);
	
    @Bean
    public ExecutorService createExecutorService() {
        return Executors.newCachedThreadPool();
    }
    
    @Bean
    public MongoClient mongo() {
        return new MongoClient("localhost");
    }
 
    @Bean
    public MongoTemplate mongoTemplate() throws EngineException {
        return new MongoTemplate(mongo(), "test");
    } 
    
    @Bean
    public String mongoHost() {
    	return MONGO_HOST_IP;
    }
    
    @Bean
    public Integer mongoPort() {
    	try {
			this.port = Network.getFreeServerPort();
		} catch (IOException e) {
			logger.error("Error finding the free port for embedded mongo. Default to 27018");
			this.port = 27018;
		}
    	return this.port;
    }
    
    @PostConstruct
    public void startEmbeddedMongo() throws IOException {
    	if(this.port == 0) this.port = mongoPort();
    	logger.info("Starting embedded mongo process on {}:{}", mongoHost(), this.port);
    	MongodStarter starter = MongodStarter.getDefaultInstance();
		try {
	    	IMongodConfig mongodConfig = new MongodConfigBuilder()
					.version(Version.Main.V3_5)
					.net(new Net(MONGO_HOST_IP, this.port, Network.localhostIsIPv6()))
					.build();
			this.mongodExecutable = starter.prepare(mongodConfig);
			this.mongod = mongodExecutable.start();
		} catch (IOException e) {
			logger.error("Error while stating the mongo server. Host: {}, Port: {} Error Message: {}", MONGO_HOST_IP,
					this.port, e.getMessage(), e);
			throw e;
		}
    }
    
    @PreDestroy
    public void stopEnbeddedMongo() {
    	if(this.mongod != null) {
    		this.mongod.stopInternal();
    	}
    	if(this.mongodExecutable != null) {
    		this.mongodExecutable.stop();
    	}
    }

}
