package com.opus.optimus.offline.runtime.reader;

import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

public class IRecordReaderEventHandlerAdapter implements IReaderEventHandler<IRecord> {

	@Override
	public void onData(IRecord record, ISourceReference sourceReference) {
		// This will used while sending successful data to next step
	}

	@Override
	public void onDataError(Throwable cause, ISourceReference sourceReference) {
		// This will used while sending unsuccessful data to global error step 
	}

}
