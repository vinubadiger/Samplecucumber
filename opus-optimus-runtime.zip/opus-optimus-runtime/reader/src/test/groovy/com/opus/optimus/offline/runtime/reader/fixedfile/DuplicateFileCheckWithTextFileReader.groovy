
package com.opus.optimus.offline.runtime.reader.fixedfile

import static org.junit.Assert.*

import org.json.JSONObject
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.TextFileReaderHelper
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException
import com.opus.optimus.offline.runtime.common.reader.repository.FileReaderChecksumRepository
import com.opus.optimus.offline.runtime.common.reader.util.CalculateFileChecksum

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class DuplicateFileCheckWithTextFileReader extends Specification {

	@Autowired
	TextFileReaderHelper fileReader;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	CalculateFileChecksum calculateFileChecksum;

	@Autowired
	FileReaderChecksumRepository fileReaderChecksumRepository;



	def "Duplicate File Check"() {
		setup:
		def noOfRows = 0;

		def fileReaderConfig = new TextFileReaderConfig();
		def object ;
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/checksum.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		fileReaderConfig = object.stepConfig;

		when:
		String inputFileLocation = "./src/test/resources/testFile.txt";

		fileReader.init(inputFileLocation , fileReaderConfig,"123");

		then:
		true
	}
}
