package com.opus.optimus.offline.runtime.reader.db;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang.StringUtils;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

/**
 * Creates a Mock of a ResultSet
 */
public class ResultSetMocker {

    private Map<String, Integer> columnNames = new HashMap<> ();

    private Object[][] result;

    public ResultSetMocker(String filename) throws IOException {
        loadData (filename);
    }

    private void loadData(String filename) throws IOException {
        List<Object[]> toRet = new ArrayList<> ();

        int numberOfParts = 0;
        String path = filename;
        URL resourceUrl = getClass ().getResource (path);
        File file = null;
        try {
            file = new File (resourceUrl.toURI ());
        } catch (URISyntaxException e) {
            e.printStackTrace ();
        }
        LineIterator it = FileUtils.lineIterator (file, "ISO8859-1");
        try {
            String names = it.nextLine ();
            String[] name = names.split (";");
            for (int i = 0; i < name.length; i++) {
                columnNames.put (name[i], i + 1);
            }

            while (it.hasNext ()) {
                String line = it.nextLine ();

                String[] parts = line.split (";");
                numberOfParts = parts.length;
                Object[] result = new Object[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    if (parts[i].equals ("(null)"))
                        result[i] = null;
                    else if (StringUtils.isNumeric (parts[i])) {
                        try {
                            result[i] = Integer.parseInt (parts[i]);
                        } catch (Exception e) {

                        }
                        result[i] = parts[i];
                    } else
                        result[i] = parts[i];
                }

                toRet.add (result);
            }
        } finally {
            it.close ();
        }

        result = toRet.toArray (new Object[toRet.size ()][numberOfParts]);
    }

    public ResultSet getResultSet() throws SQLException, IOException {
        ResultSet resultSet = mock (ResultSet.class);

        final AtomicInteger idx = new AtomicInteger (0);
        final MockRow row = new MockRow (columnNames);

        doAnswer (new Answer<Boolean> () {
            @Override
            public Boolean answer(InvocationOnMock invocation) throws Throwable {
                int index = idx.getAndIncrement ();
                if (result.length > index) {
                    row.setCurrentRowData (result[index]);
                    return true;
                } else
                    return false;
            }
        }).when (resultSet).next ();

        doAnswer (new Answer<String> () {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments ();
                int idx = (Integer) args[0];
                return row.getString (idx);
            }
        }).when (resultSet).getString (anyInt ());

        doAnswer (new Answer<String> () {
            @Override
            public String answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments ();
                String name = (String) args[0];
                return row.getString (name);
            }
        }).when (resultSet).getString (anyString ());

        doAnswer (new Answer<Object> () {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments ();
                String name = (String) args[0];
                return row.getObject (name);
            }
        }).when (resultSet).getObject (anyString ());

        doAnswer (new Answer<Integer> () {
            @Override
            public Integer answer(InvocationOnMock invocation) throws Throwable {
                Object[] args = invocation.getArguments ();
                String name = (String) args[0];
                return row.getInt (name);
            }
        }).when (resultSet).getInt (anyString ());

        return resultSet;
    }

    static class MockRow {
        Object[] rowData;
        private Map<String, Integer> columnNames;

        public MockRow(Map<String, Integer> columnNames) {

            this.columnNames = columnNames;
        }

        public void setCurrentRowData(Object[] rowData) {
            this.rowData = rowData;
        }

        public String getString(int idx) {
            return (String) rowData[idx - 1];
        }

        public String getString(String name) {
            return (String) rowData[columnNames.get (name) - 1];
        }

        public Object getObject(String name) {
            return rowData[columnNames.get (name) - 1];
        }

        public Integer getInt(String name) {
            return (Integer) rowData[columnNames.get (name) - 1];
        }
    }
}