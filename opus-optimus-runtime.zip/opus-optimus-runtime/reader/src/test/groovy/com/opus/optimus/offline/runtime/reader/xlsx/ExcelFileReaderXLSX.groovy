package com.opus.optimus.offline.runtime.reader.xlsx

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.ExcelFieldConfig
import com.opus.optimus.offline.config.reader.ExcelReaderConfig
import com.opus.optimus.offline.config.record.impl.ExcelRecordExtractorConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.ExcelReaderHelper
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.reader.IRecordReaderEventHandlerAdapter
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class ExcelFileReaderXLSX extends Specification {

	@Autowired
	ExcelReaderHelper excelReader;

	@Autowired
	MapperFactory mapperFactory

	def "Excel reader execution"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 7;
		/*
		 List<IFieldConfig> fieldConfigs = new ArrayList<IFieldConfig>();
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 1).name("Column1").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 2).name("Column2").type(FieldType.STRING)
		 .maxSize(12).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 3).name("Column3").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 4).name("Column4").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 5).name("Column5").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 6).name("Column6").type(FieldType.STRING)
		 .maxSize(24).build());
		 fieldConfigs.add(ExcelFieldConfig.builder().fieldIndex((short) 7).name("Column7").type(FieldType.STRING)
		 .maxSize(24).build());
		 ExcelRecordExtractorConfig recordExtractorConfig = ExcelRecordExtractorConfig.builder()
		 .sectionName("Data").fieldConfigs(fieldConfigs).build();
		 Map<String, ExcelRecordExtractorConfig> recordExtractorMap = new HashMap<String, ExcelRecordExtractorConfig>();
		 recordExtractorMap.put("Data", recordExtractorConfig);
		 ExcelReaderConfig excelReaderConfig = new ExcelReaderConfig();
		 excelReaderConfig.setCharEncoding("USASCII"); // UTF8
		 excelReaderConfig.setTopRowsToSkip(3);
		 excelReaderConfig.setProcessAllSheets(true);
		 excelReaderConfig.setNoOfHeaderRecs(1);
		 excelReaderConfig.setRecordExtractorConfig(recordExtractorMap);
		 */

		def excelReaderConfig = new ExcelReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/Excel.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		excelReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testXLSX1.xlsx";

		excelReader.init(inputFileLocation , excelReaderConfig,null);

		when:
		excelReader.processFile(null,new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						println("data row");
						int maxIndex = record.schema.fields.size();
						println("max Index::"+maxIndex);
						for  (int i =0; i < maxIndex ; i++) {

							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows > 8
	}
}
