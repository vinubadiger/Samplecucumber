package com.opus.optimus.offline.runtime.reader.db

import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.datasource.OracleDataSource
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.db.OracleDBReaderHelper
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Ignore
import spock.lang.Specification

@Ignore
@ContextConfiguration(classes = TestReaderConfiguration.class)
class OracleDBReaderSpecification extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    OracleDBReaderHelper oracleDBReaderHelper

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    DataSourceFactory dataSourceFactory;

    @Autowired
    IMessageFactory messageFactory

	//TODO Fix later Need to be added IN memory Database..
    @Ignore
    def "Oracle DB reader execution - Successful"() {
        setup:

        def mapper = mapperFactory.getMapper()
        //register the data source
        def jsonStream = getClass().getResourceAsStream("/json/OracleDBDataSourceMetaData.json")
        def oracleDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

        OracleDataSource oracleDataSource = new OracleDataSource(oracleDbDataSourceMetaData);

        //initialize data source factory
        oracleDataSource.init();
        dataSourceFactory.register(oracleDbDataSourceMetaData.getDataSourceName(), oracleDataSource);

        //    com.opus.optimus.offline.runtime.reader.db.ResultSetMocker resultSetMocker = new ResultSetMocker("/dbReader.txt");
        //    resultSetMocker.getResultSet();

        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/json/OracleDBReaderConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getStepConfig()]

        def jobId = "oracleDBReaderJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))


        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getStepConfig().getStepName()).get(0).getReceiver()

        emitter.emit(messageFactory.createMessage("START"))
        emitter.emit(messageFactory.createEndMessage())

        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 3

    }


}
