package com.opus.optimus.offline.runtime.reader

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.fasterxml.jackson.databind.ObjectMapper
import com.opus.optimus.offline.config.field.IFieldConfig
import com.opus.optimus.offline.config.field.impl.DelimitedFieldConfig
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig
import com.opus.optimus.offline.config.fieldextractor.impl.DelimitedFieldExtractorConfig
import com.opus.optimus.offline.config.reader.TextFileReaderConfig
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig
import com.opus.optimus.offline.configuration.TestReaderConfiguration
import com.opus.optimus.offline.configuration.TestWorkflowConfig
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler
import com.opus.optimus.offline.runtime.common.reader.TextFileReaderHelper;
import com.opus.optimus.offline.runtime.workflow.api.IMessage
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference

import spock.lang.Shared
import spock.lang.Specification

@ContextConfiguration(classes = TestReaderConfiguration.class)
class FileReaderSpecificationWithSectiondata extends Specification {

	@Autowired
	TextFileReaderHelper fileReader;

	@Autowired
	MapperFactory mapperFactory

	def "CSV reader execution"() {
		setup:
		def noOfRowsInFile = 8;
		def noOfRows = 0;
		def noOfColumns = 2;


		def fileReaderConfig = new TextFileReaderConfig();
		def object ;

		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/json/DelimitedConfigJSON_Sections.json")
		object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		fileReaderConfig = object.stepConfig;

		String inputFileLocation = "./src/test/resources/testFile_Section.csv";

		fileReader.init(inputFileLocation, fileReaderConfig,null);

		def noOfColumnsRead = 0;
		def columnTypesMatch = true;
		def columnTypes = ["String", "Long"];

		when:
		println("CSV reader execution")
		fileReader.processFile(null, new IRecordReaderEventHandlerAdapter() {
					public void onData(IRecord record,ISourceReference sourceReference) {
						print("data row:	");
						noOfColumnsRead = record.schema.fields.size();
						for  (int i =0; i < noOfColumnsRead ; i++) {
							String type = record.getValue(i).getClass().getSimpleName();
							print(record.getValue(i));
							print("-");
						}
						println("");
						noOfRows++;
					}
				});

		then:
		noOfRows == 10
	}
}
