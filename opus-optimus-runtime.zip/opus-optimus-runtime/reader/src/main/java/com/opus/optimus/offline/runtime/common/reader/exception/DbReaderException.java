package com.opus.optimus.offline.runtime.common.reader.exception;

public class DbReaderException extends ReaderException {
	private static final long serialVersionUID = 1L;

	private final String errorCode ;

	public DbReaderException() {
		this.errorCode = ExceptionCodes.DB_GENERAL_EXCEPTION;
	}

	public DbReaderException(Throwable cause) {
		super(cause);
		this.errorCode = ExceptionCodes.DB_GENERAL_EXCEPTION;
	}
	
	
	public DbReaderException(String errorCode, Throwable cause)	{
		super(cause);
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return this.errorCode;
	}	
}
