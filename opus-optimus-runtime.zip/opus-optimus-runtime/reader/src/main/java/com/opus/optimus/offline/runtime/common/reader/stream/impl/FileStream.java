package com.opus.optimus.offline.runtime.common.reader.stream.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.poi.EmptyFileException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.config.reader.TextFileReaderConfig;
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig;
import com.opus.optimus.offline.config.record.impl.FixedRecordExtractorConfig;
import com.opus.optimus.offline.runtime.common.reader.exception.EOFException;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.stream.IStream;

/**
 * The Class FileStream for creating file reading streams.
 * 
 * 
 * @author Ram
 * @author Manjusha.Dhamdhere
 * @author Yashkumar.Thakur
 */
public class FileStream implements IStream {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(FileStream.class);

	/** The unspecified reader. */
	public static final short UNSPECIFIED_READER = 0;

	/** The delimited reader. */
	public static final short DELIMITED_READER = 1;

	/** The fixedlength reader. */
	public static final short FIXEDLENGTH_READER = 2;

	/** The reader. */
	private Reader reader;

	/** The record separator. */
	private String recordSeparator;

	/** The record size. */
	private int recordSize;

	/**
	 * The delimited data reader ,applicable only if recordSeparator is based on
	 * delimiter
	 */
	private DataReader delimitedDataReader;

	@Override
	public void release() throws ReaderException {
		if (delimitedDataReader != null) {
			delimitedDataReader.close();
		}
		try {
			if (reader != null) {
				reader.close();
			}
		} catch (IOException e) {
			logger.error("Error while releasing stream: {}", e);
			throw new ReaderException(e);
		}
	}

	@Override
	public InputStream getUnderlyingStream() {
		throw new EngineException("FileStream does not implement getUnderlyingStream()");
	}

	/**
	 * Initialize the stream creation process
	 *
	 * @param fileName
	 *            - The input file name
	 * @param encodingType
	 *            - The encoding type
	 * @param readerConfig
	 *            - The reader configuration
	 * @throws ReaderException
	 *             the reader exception
	 */
	public void init(String fileName, String encodingType, TextFileReaderConfig readerConfig) throws ReaderException {
		try {
			logger.debug("File name: {}", fileName);
			fileChecks(fileName);
			RandomAccessFile randomAccessFile;

			this.reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), encodingType));

			if (readerConfig.getRecordExtractorConfig() instanceof DelimitedRecordExtractorConfig) {
				this.recordSeparator = ((DelimitedRecordExtractorConfig) readerConfig.getRecordExtractorConfig())
						.getRecordSeperator();
				if (isNewLineCharacter(this.recordSeparator)) {
					this.delimitedDataReader = new NewLineReader((BufferedReader) reader);
				} else {
					this.delimitedDataReader = new DelimitedLineReader((BufferedReader) reader, this.recordSeparator);
				}
			} else {
				this.recordSize = ((FixedRecordExtractorConfig) readerConfig.getRecordExtractorConfig())
						.getRecordLength();
				randomAccessFile = new RandomAccessFile(fileName, "r");
				this.delimitedDataReader = new FixedLineReader(randomAccessFile, this.recordSize);
			}
		} catch (AccessDeniedException exp) {
			logger.error("Access denied while reading file :{} , {}", fileName, exp);
			throw new ReaderException(ExceptionCodes.READER_FILE_ACCESS_DENIED_EXCEPTION, exp);
		} catch (FileNotFoundException exp) {
			logger.error("File not found ! {} ,{}", fileName, exp);
			throw new ReaderException(ExceptionCodes.READER_FILE_NOT_FOUND_EXCEPTION, exp);
		} catch (EmptyFileException exp) {
			logger.error("Given file is empty :{} , {}", fileName, exp);
			throw new ReaderException(ExceptionCodes.READER_FILE_EMPTY, exp);
		} catch (IOException exp) {
			logger.error("Error while processing file : {}, {}", fileName, exp);
			throw new ReaderException(ExceptionCodes.INVALID_FILE_FORMAT_EXCEPTION, exp);
		}

	}

	private void fileChecks(String fileName) throws AccessDeniedException {
		File file = new File(fileName);
		if (file.length() == 0)
			throw new EmptyFileException();
	}

	/**
	 * Checks if is new line character.
	 *
	 * @param recordSeparator
	 *            - The record separator
	 * @return true, if is new line character
	 */
	private boolean isNewLineCharacter(String recordSeparator) {
		if (recordSeparator.matches("\\\\n")) { // if UI saves the new line character escaping the backslash
			// as Mongo DB return the record separator character without escaping the
			// backslash, we need tell JRE to escape when compare.
			return StringEscapeUtils.unescapeJava(recordSeparator).equals("\n");
		}
		return "\n".equals(recordSeparator);
	}

	/**
	 * Gets the record.
	 *
	 * @return the record
	 * @throws ReaderException
	 *             the reader exception
	 */
	// Get one Record at a time
	public String getRecord() throws ReaderException {
		if (delimitedDataReader == null) {
			throw new ReaderException();
		}
		return delimitedDataReader.getRecord();
	}

	/**
	 * Gets the record.
	 *
	 * @param recordSize
	 *            - The record size for fixed reader
	 * @return the record
	 * @throws ReaderException
	 *             the reader exception
	 */
	public String getRecord(short recordSize) throws ReaderException {
		if (delimitedDataReader == null) {
			throw new ReaderException();
		}
		return delimitedDataReader.getRecord();
	}

	/**
	 * The Interface DataReader.
	 */
	// Reader Interface
	private static interface DataReader {

		/**
		 * Gets the record.
		 *
		 * @return the record
		 * @throws EOFException
		 *             the EOF exception
		 */
		public abstract String getRecord() throws EOFException;

		/**
		 * Close.
		 *
		 * @throws ReaderException
		 *             the reader exception
		 */
		public abstract void close() throws ReaderException;
	}

	/**
	 * The Class NewLineReader.
	 */
	private class NewLineReader implements DataReader {

		/** The reader. */
		BufferedReader reader;

		/**
		 * Instantiates a new new line reader.
		 *
		 * @param reader
		 *            the reader
		 */
		public NewLineReader(BufferedReader reader) {
			this.reader = reader;
		}

		@Override
		public String getRecord() throws EOFException {
			try {
				String line = this.reader.readLine();
				if (line == null) {
					// buffered reader returns null on end of stream.
					throw new EOFException();
				}
				return line;
			} catch (IOException exp) {
				throw new EOFException(exp);
			}
		}

		@Override
		public void close() throws ReaderException {
			try {
				this.reader.close();
			} catch (IOException e) {
				logger.error("Error while releasing channel : {}", e);
				throw new ReaderException(ExceptionCodes.READER_RELEASE_EXCEPTION, e);
			}
		}

	}

	/**
	 * The Class DelimitedLineReader.
	 */
	private class DelimitedLineReader implements DataReader {

		/** The scanner for reading file */
		private Scanner scanner = null;

		/**
		 * Instantiates a new delimited line reader.
		 *
		 * @param inputStreamReader
		 *            the input stream reader
		 * @param recordSeparator
		 *            the record separator
		 */
		public DelimitedLineReader(Reader inputStreamReader, String recordSeparator) {
			this.scanner = new Scanner(inputStreamReader).useDelimiter(Pattern.quote(recordSeparator));
		}

		@Override
		public String getRecord() throws EOFException {
			if (this.scanner.hasNext()) {
				return this.scanner.next();
			}
			throw new EOFException();
		}

		@Override
		public void close() throws ReaderException {
			this.scanner.close();
		}
	}

	/**
	 * The Class FixedLineReader.
	 */
	private class FixedLineReader implements DataReader {

		/** The in channel. */
		private FileChannel inChannel;

		/** The byte buffer. */
		private ByteBuffer byteBuffer;

		/** The doublebyte. */
		final Charset doublebyte = StandardCharsets.US_ASCII;

		/**
		 * Instantiates a new fixed line reader.
		 *
		 * @param randomAccessFile
		 *            the random access file
		 * @param recordSize
		 *            the record size
		 */
		public FixedLineReader(RandomAccessFile randomAccessFile, int recordSize) {
			this.inChannel = randomAccessFile.getChannel();
			this.byteBuffer = ByteBuffer.allocate(recordSize);
		}

		@Override
		public String getRecord() throws EOFException {
			try {
				if (this.inChannel.read(this.byteBuffer) > 2) {
					byteBuffer.rewind();
					String temp = doublebyte.decode(byteBuffer).toString();
					byteBuffer.flip();
					byteBuffer.clear();
					return temp;
				}
			} catch (IOException e) {
				logger.error("Error While readind record in fixed file : {} , {}", e.getMessage(), e);
				throw new EOFException();
			}
			throw new EOFException();
		}

		@Override
		public void close() throws ReaderException {
			try {
				this.inChannel.close();
			} catch (IOException e) {
				logger.error("Error while releasing channel :{}", e);
				throw new ReaderException(ExceptionCodes.READER_RELEASE_EXCEPTION, e);
			}
			this.byteBuffer.clear();
		}
	}
}
