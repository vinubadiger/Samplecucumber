package com.opus.optimus.offline.runtime.common.reader.record.impl;

import java.util.Iterator;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.config.reader.ExcelReaderConfig;
import com.opus.optimus.offline.config.record.impl.ExcelRecordExtractorConfig;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.field.formatter.ExcelFieldFormatterImpl;
import com.opus.optimus.offline.runtime.common.reader.field.formatter.FieldFormatterImpl;
import com.opus.optimus.offline.runtime.common.reader.util.SchemaBuilder;

import lombok.Getter;

/**
 * The Class ExcelRecordExtractor for extraction excel cells.
 * 
 * @author Yashkumar.Thakur
 *
 */
public class ExcelRecordExtractor {

	private static final Logger logger = LoggerFactory.getLogger(ExcelRecordExtractor.class);

	/**
	 * Gets the schema.
	 *
	 * @return the schema
	 */
	@Getter
	private Schema schema;

	/** The record factory. */
	private IRecordFactory recordFactory;

	/** The hash map for section name field extractor configuration. */
	private Map<String, ExcelRecordExtractorConfig> sectionNameVsfieldExtractorConfig;

	/** The reader configuration object . */
	private ExcelReaderConfig readerConfig;

	/** The default section name (Pick last section name default) */
	private String defaultSectionName;

	/**
	 * Initialize the field configuration.
	 *
	 * @param readerConfig -
	 *            The reader configuration
	 * 
	 */
	public void init(ExcelReaderConfig readerConfig) {
		this.readerConfig = readerConfig;

		// Get all section configuration
		sectionNameVsfieldExtractorConfig = readerConfig.getRecordExtractorConfig();
		sectionNameVsfieldExtractorConfig.forEach((pSectionName, pFieldExtractorConfig) -> {
			schema = SchemaBuilder.buildSchema(pFieldExtractorConfig.getSectionName(),
					pFieldExtractorConfig.getFieldConfigs());
			recordFactory.registerSchema(schema);
			// picks last section
			defaultSectionName = pSectionName;
		});
	}

	/**
	 * For proceeding Excel sheets.
	 *
	 * @param context -
	 *            The context
	 * @param workbook -
	 *            The workbook Object for access excel file
	 * @param eventHandler -
	 *            The event handler
	 * @throws ReaderException -
	 *             The reader exception
	 */
	public void process(Object context, Workbook workbook, IReaderEventHandler eventHandler) throws ReaderException {

		if (readerConfig.isProcessAllSheets()) {

			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				logger.debug("Current Sheet : {} , Sheet Name: {}", i, workbook.getSheetName(i));
				Sheet sheet = workbook.getSheetAt(i);
				Iterator<Row> rowIterator = sheet.rowIterator();
				skipRowsIfRequired(rowIterator);
				skipColumnIndexRows(rowIterator);
				doProcessData(rowIterator, eventHandler);
			}
		} else {
			// TODO logic to process specific sheets
		}
	}

	/**
	 * Create record according to given schema.
	 *
	 * @param rowIterator -
	 *            The row iterator, to iterate all rows 
	 * @param handler -
	 *            The handler
	 * @throws ReaderException -
	 *             the reader exception
	 */
	private void doProcessData(Iterator<Row> rowIterator, IReaderEventHandler handler) throws ReaderException {
		try {
			while (rowIterator.hasNext()) {
				// TODO find the section by execution formula
				ExcelRecordExtractorConfig config = sectionNameVsfieldExtractorConfig.get(defaultSectionName);

				IRecord record = recordFactory.createRecord(defaultSectionName);
				Row row = rowIterator.next();

				for (IFieldConfig fieldConfig : config.getFieldConfigs()) {

					int fldIndex = fieldConfig.getFieldIndex() - 1;
					record.setValue(fldIndex,
							FieldFormatterImpl.populateField(fieldConfig, ExcelFieldFormatterImpl
									.getCellValue(row.getCell(fldIndex), fieldConfig).toString()));
				}
				handler.onData(record, null);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error while iterating excel file: {} , {}", e.getMessage() ,e );
			throw new ReaderException();

		}

	}

	/**
	 * Skip rows if required.
	 *
	 * @param rowIterator
	 *            the row iterator
	 */
	private void skipRowsIfRequired(Iterator<Row> rowIterator) {
		skipRows(rowIterator, readerConfig.getTopRowsToSkip());
	}

	/**
	 * Skip rows.
	 *
	 * @param rowIterator
	 *            the row iterator
	 * @param noOfRowsToSkip
	 *            the no of rows to skip
	 */
	private void skipRows(Iterator<Row> rowIterator, int noOfRowsToSkip) {
		if (noOfRowsToSkip <= 0) {
			return;
		}

		int skippedCount = 0;
		while (rowIterator.hasNext() && skippedCount < noOfRowsToSkip) {
			skippedCount++;
			rowIterator.next();
		}
	}

	/**
	 * Skip column index rows.
	 *
	 * @param rowIterator -
	 *            The row iterator
	 */
	private void skipColumnIndexRows(Iterator<Row> rowIterator) {
		if (readerConfig.getNoOfHeaderRecs() <= 0) {
			return;
		}

		int rowsToSkip = readerConfig.getNoOfHeaderRecs();
		if (rowsToSkip > 0) {
			skipRows(rowIterator, rowsToSkip);
		}
	}

	/**
	 * Sets the record factory.
	 *
	 * @param recordFactory -
	 *            The new record factory
	 */
	public void setRecordFactory(IRecordFactory recordFactory) {
		this.recordFactory = recordFactory;
	}
}
