
package com.opus.optimus.offline.runtime.common.reader.stream.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.monitorjbl.xlsx.StreamingReader;
import com.opus.optimus.offline.config.reader.ExcelReaderConfig;
import com.opus.optimus.offline.runtime.common.reader.exception.EOFException;
import com.opus.optimus.offline.runtime.common.reader.exception.InvalidFileFormatException;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.stream.IStream;
/**
 * The Class ExcelStream for stream excel file for reading.
 * 
 * @author Yashkumar.Thakur
 *
 */
public class ExcelStream implements IStream {
	
	private static final Logger logger = LoggerFactory.getLogger(ExcelStream.class);

	/** The reader filename. */
	public static final String READER_FILENAME = "reader.fileName";

	/** The input stream. */
	private InputStream inputStream;

	/** The workbook. */
	private Workbook workbook;

	@Override
	public void release() {
		try {
			this.workbook.close();
			inputStream.close();
		} catch (IOException e) {
			logger.error("Error while realesing input file stream : {}", e.getMessage() + e);
		}
	}

	/**
	 * Inits the.
	 *
	 * @param inputFileLocation -
	 *            The input file location
	 * @param encodingType -
	 *            The encoding type
	 * @param readerConfig -
	 *            The reader configuration
	 * @throws ReaderException -
	 *             The reader exception
	 * @throws EncryptedDocumentException -
	 *             The encrypted document exception
	 * @throws IOException -
	 *             Signals that an I/O exception has occurred.
	 * @throws InvalidFileFormatException
	 *             the invalid file format exception
	 */
	public void init(String inputFileLocation, String encodingType, ExcelReaderConfig readerConfig)
			throws ReaderException, EncryptedDocumentException, IOException, InvalidFileFormatException {
		// TODO Check throws for EncryptedDocumentException
		try {
			logger.debug("filename : {}", inputFileLocation);
			
			inputStream = new FileInputStream(new File(inputFileLocation));
			if (inputFileLocation.endsWith(".xls")) {
				this.workbook = WorkbookFactory.create(inputStream);
			} else if (inputFileLocation.endsWith(".xlsx")) {
				this.workbook = StreamingReader.builder().rowCacheSize(1000).bufferSize(4096 * 1).open(inputStream);
			} else {
				throw new InvalidFileFormatException();
			}

		} catch (FileNotFoundException e) {
			logger.error("File not found {} Error: {} , {}",inputFileLocation,e.getMessage(), e);
			throw new EOFException();
		}catch (Exception e) {
			logger.error("Error in excel stream : {} , {}",e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Gets the workbook.
	 *
	 * @return the workbook
	 */
	public Workbook getWorkbook() {
		return this.workbook;
	}
	
	@Override
	public InputStream getUnderlyingStream() {
		return inputStream;
	}
}
