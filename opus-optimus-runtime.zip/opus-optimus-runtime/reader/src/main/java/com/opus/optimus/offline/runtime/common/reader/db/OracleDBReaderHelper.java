package com.opus.optimus.offline.runtime.common.reader.db;

import com.opus.optimus.offline.config.datasource.OracleDataSource;
import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.config.field.impl.DBFieldConfig;
import com.opus.optimus.offline.config.reader.DBReaderConfig;
import com.opus.optimus.offline.config.recon.subtypes.AndClause;
import com.opus.optimus.offline.config.recon.subtypes.Operator;
import com.opus.optimus.offline.config.recon.subtypes.OrClause;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.reader.IReaderEventHandler;
import com.opus.optimus.offline.runtime.common.reader.OracleDBReaderStep;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.opus.optimus.offline.constants.ReaderConstants.AND;
import static com.opus.optimus.offline.constants.ReaderConstants.DATA;
import static com.opus.optimus.offline.constants.ReaderConstants.FROM;
import static com.opus.optimus.offline.constants.ReaderConstants.OR;
import static com.opus.optimus.offline.constants.ReaderConstants.SCRIPT_MAP_LSH_FIELD_KEY;
import static com.opus.optimus.offline.constants.ReaderConstants.SCRIPT_MAP_RSH_FIELD_KEY;
import static com.opus.optimus.offline.constants.ReaderConstants.SELECT;
import static com.opus.optimus.offline.constants.ReaderConstants.SPACE;
import static com.opus.optimus.offline.constants.ReaderConstants.WHERE;

/**
 * The Class OracleDBReaderHelper.
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class OracleDBReaderHelper {

    /**
     * The Constant logger.
     */
    private static final Logger logger = LoggerFactory.getLogger (OracleDBReaderHelper.class);
    /**
     * The record factory.
     */
    @Autowired
    IRecordFactory recordFactory;
    /**
     * The script creator factory.
     */
    @Autowired
    ScriptCreatorFactory scriptCreatorFactory;
    /**
     * The data source factory.
     */
    @Autowired
    private DataSourceFactory dataSourceFactory;
    /**
     * The config.
     */
    private DBReaderConfig config;

    /**
     * The field value script map.
     */
    private Map<String, IScript<?, ?>> fieldValueScriptMap = new HashMap<> ();

    /**
     * The JDBC template.
     */
    private JdbcTemplate jdbcTemplate;

    /**
     * Initialize step.
     *
     * @param config - The Database reader configuration
     * @throws ReaderException                    the reader exception
     * @throws NoSuchDataSourceAvailableException the no such data source available exception
     */
    public void init(final DBReaderConfig config) throws ReaderException, NoSuchDataSourceAvailableException {
        this.config = config;
        final IDataSource dataSource = dataSourceFactory.getDataSource (this.config.getDataSourceName ());
        if (OracleDataSource.class.isAssignableFrom (dataSource.getClass ())) {
            final OracleDataSource oracleDataSource = (OracleDataSource) dataSource;
            // build the template
            this.jdbcTemplate = new JdbcTemplate (oracleDataSource.getDataSource ());
        } else {
            throw new NoSuchDataSourceAvailableException ("Incorrect datasource identified. Please check configuration.");
        }
        buildScript (config);
    }

    /**
     * Process.
     *
     * @param stepInstance the step instance
     * @param eventHandler - The DB reader event handler
     */
    public void process(OracleDBReaderStep stepInstance, final IReaderEventHandler<IRecord> eventHandler) {
        try {
            String sqlScript = buildQuery ();
            ISourceReference sourceReference = DBSourceReference.builder ().rawRecordData (sqlScript).dataSourceName (config.getDataSourceName ()).build ();

            RowCallbackHandler callbackHandler = resultSet -> {
                if (stepInstance != null && stepInstance.doStop ()) {
                    logger.info ("Job aborted due to some FATAL error. Please check the error details.");
                    throw new EngineException ("Job aborted due to some FATAL error. Please check the error details.");
                }
                try {
                    do {
                        try {
                            IRecord record = createIRecord (resultSet);
                            eventHandler.onData (record, sourceReference);
                        } catch (Exception e) {
                            eventHandler.onDataError (e, sourceReference);
                        }
                    } while (resultSet.next ());
                } catch (SQLException e) {
                    logger.error ("Error occured while initializing Oracle DB Connection.", e);
                    throw new EngineException (ExceptionCodes.DB_GENERAL_EXCEPTION, e);
                } catch (InvalidResultSetAccessException e) {
                    logger.error ("Error occured while InvalidResultSetAccessException Oracle DB Connection.", e);
                    throw new EngineException (ExceptionCodes.DB_GENERAL_EXCEPTION, e);
                } catch (DataAccessException e) {
                    logger.error ("Error occured while DataAccessException Oracle DB Connection.", e);
                    throw new EngineException (ExceptionCodes.DB_GENERAL_EXCEPTION, e);
                } catch (Exception e) {
                    throw new EngineException (ExceptionCodes.DB_GENERAL_EXCEPTION, e);
                }
            };

            jdbcTemplate.query (sqlScript, callbackHandler);
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }
    }

    /**
     * Creates the I record.
     *
     * @param rs the rs
     * @return the i record
     */
    private IRecord createIRecord(ResultSet rs) {
        try {
            IRecord record = recordFactory.createRecord (config.getSection () == null ? DATA : config.getSection ());
            config.getFieldSelected ().forEach (selectField -> {
                try {
                    record.setValue (record.getFieldId (selectField.getName ()), rs.getString (selectField.getName ()));
                } catch (SQLException e) {
                    logger.error (e.getMessage (), e);
                }
            });

            return record;
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }
    }

    /**
     * Builds the query.
     *
     * @return the string
     */
    private String buildQuery() {
        try {
            StringBuilder qureyBuilder = new StringBuilder ();
            qureyBuilder.append (SELECT);
            qureyBuilder.append (SPACE);
            qureyBuilder.append (config.getFieldSelected ().stream ().map (DBFieldConfig::getName).collect (Collectors.joining (",")));
            qureyBuilder.append (SPACE);
            qureyBuilder.append (FROM);
            qureyBuilder.append (SPACE);
            qureyBuilder.append (config.getCollectionName ());
            if (config.getSelectionCriteria () != null && config.getSelectionCriteria ().getOrClauseSections () != null
                    && !config.getSelectionCriteria ().getOrClauseSections ().isEmpty ()) {
                qureyBuilder.append (buildCriteriaQuery ());
            }
            logger.debug ("ORACLE QUERY TO BE EXECUTED - {}", qureyBuilder);
            return qureyBuilder.toString ();
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }

    }

    /**
     * Builds the criteria query.
     *
     * @return the string
     */
    private String buildCriteriaQuery() {
        try {
            StringBuilder orCriteriaStatement = new StringBuilder (SPACE).append (WHERE).append (SPACE);
            String orCriterias = IntStream.range (0, config.getSelectionCriteria ().getOrClauseSections ().size ()).mapToObj (orClauseIndex -> {
                OrClause orClause = config.getSelectionCriteria ().getOrClauseSections ().get (orClauseIndex);
                return IntStream.range (0, orClause.getAndClauses ().size ()).mapToObj (andClauseIndex ->
                        buildLhsAndOperatorAndRhsField (orClauseIndex, andClauseIndex, orClause.getAndClauses ().get (andClauseIndex),
                                config.getSection ())).collect (Collectors.joining (AND + SPACE));
            }).collect (Collectors.joining (SPACE + OR + SPACE));
            logger.debug ("SelectQuery.orCriterias= {}", orCriterias);
            orCriteriaStatement.append (orCriterias);
            logger.debug ("SQL Condiiontal criteria - {}", orCriteriaStatement);
            return orCriteriaStatement.toString ();
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            logger.error ("Error while build Criteria Query", e);
            throw new EngineException (e);
        }
    }

    /**
     * Builds the lhs and operator and rhs field.
     *
     * @param orClauseIndex  the or clause index
     * @param andClauseIndex the and clause index
     * @param andClause      the and clause
     * @param section        the section
     * @return the string
     */
    // Building Selection Criteria
    private String buildLhsAndOperatorAndRhsField(int orClauseIndex, int andClauseIndex, AndClause andClause, String section) {
        try {// lhs
            final IScript<?, ?> lhsFieldScript = fieldValueScriptMap.get (buildScriptKey (orClauseIndex, andClauseIndex, SCRIPT_MAP_LSH_FIELD_KEY, section, andClause.getOperator ()));
            final Object lhsField = lhsFieldScript.execute (null);

            // rhs
            final IScript<?, ?> rhsFieldScript = fieldValueScriptMap.get (buildScriptKey (orClauseIndex, andClauseIndex, SCRIPT_MAP_RSH_FIELD_KEY, section, andClause.getOperator ()));
            final Object rhsField = rhsFieldScript.execute (null);

            return lhsField + getOperatorAndRhsField (andClause, rhsField) + SPACE;
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }
    }

    /**
     * Gets the operator and rhs field.
     *
     * @param andClause the and clause
     * @param _rhsField  the rhs field
     * @return the operator and rhs field
     */
    private String getOperatorAndRhsField(AndClause andClause, Object _rhsField) {
        try {
            String rhsField = convertObjectToString (_rhsField); //  Date object is converted into String. Default toString()
            switch (andClause.getOperator ().getOperatorLiteral ()) {
                case EQUAL:
                    return rhsField.contains ("(") ? "= " + rhsField : "= \'" + rhsField + "\'";
                case GT:
                    return "> \'" + rhsField + "\'";
                case GTE:
                    return ">= \'" + rhsField + "\'";
                case IN:
                    return " IN (\'" + Arrays.stream (rhsField.split (",")).collect (Collectors.joining ("', '")) + "\')";
                case LT:
                    return "< \'" + rhsField + "\'";
                case LTE:
                    return "<= \'" + rhsField + "\'";
                case NOTEQUAL:
                    return "!= \'" + rhsField + "\'";
                case NOTIN:
                	return " NOT IN (\'" + Arrays.stream (rhsField.split (",")).collect (Collectors.joining ("', '")) + "\')";
                default:
                    break;
            }
            return null;
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }
    }

    private String convertObjectToString(Object rhsField) {
        if (rhsField instanceof Date) {
            SimpleDateFormat formatter = new SimpleDateFormat ("dd-MMM-yyyy");
            return formatter.format (rhsField);
        } else {
            return rhsField.toString ();
        }
    }

    /**
     * Builds the script.
     *
     * @param config the config
     */
    private void buildScript(DBReaderConfig config) {
        try {
            if (config.getSelectionCriteria () != null && config.getSelectionCriteria ().getOrClauseSections () != null) {
                IntStream.range (0, config.getSelectionCriteria ().getOrClauseSections ().size ()).forEach (orClauseIndex -> {
                    List<AndClause> andClauses = config.getSelectionCriteria ().getOrClauseSections ().get (orClauseIndex).getAndClauses ();
                    IntStream.range (0, andClauses.size ()).forEach (andClauseIndex -> {
                        AndClause andClause = andClauses.get (andClauseIndex);
                        IScript<?, ?> lhsFieldScript = scriptCreatorFactory.createScript (andClause.getLhsField ().getFormulaConfig ());
                        IScript<?, ?> rhsFieldScript = scriptCreatorFactory.createScript (andClause.getRhsField ().getFormulaConfig ());
                        fieldValueScriptMap.put (buildScriptKey (orClauseIndex, andClauseIndex, SCRIPT_MAP_LSH_FIELD_KEY, config.getSection (), andClause.getOperator ()), lhsFieldScript);
                        fieldValueScriptMap.put (buildScriptKey (orClauseIndex, andClauseIndex, SCRIPT_MAP_RSH_FIELD_KEY, config.getSection (), andClause.getOperator ()), rhsFieldScript);
                    });
                });
            } else {
                logger.info ("No Selection Criteria in step configuration {}", config.getSelectionCriteria ());
            }
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }
    }

    /**
     * Builds the script key.
     *
     * @param parentIndex     the parent index
     * @param subIndex        the sub index
     * @param helperCharecter the helper charecter
     * @param section         the section
     * @param operator        the operator
     * @return the string
     */
    private String buildScriptKey(int parentIndex, int subIndex, String helperCharecter, String section, Operator operator) {
        try {
            StringBuilder fieldScriptMapKeyBuilder = new StringBuilder ();
            fieldScriptMapKeyBuilder.append (parentIndex);
            fieldScriptMapKeyBuilder.append ("_");
            fieldScriptMapKeyBuilder.append (subIndex);
            fieldScriptMapKeyBuilder.append ("_");
            fieldScriptMapKeyBuilder.append (helperCharecter);
            fieldScriptMapKeyBuilder.append ("_");
            section = section == null || section.isEmpty () ? DATA : section;
            fieldScriptMapKeyBuilder.append (section);
            fieldScriptMapKeyBuilder.append ("_");
            fieldScriptMapKeyBuilder.append (operator.getOperatorLiteral ());
            return fieldScriptMapKeyBuilder.toString ();
        } catch (EngineException e) {
            throw e;
        } catch (Exception e) {
            throw new EngineException (e);
        }
    }
}
