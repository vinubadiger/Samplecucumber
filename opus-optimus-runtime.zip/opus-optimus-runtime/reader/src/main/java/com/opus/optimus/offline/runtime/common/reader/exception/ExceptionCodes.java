package com.opus.optimus.offline.runtime.common.reader.exception;

import java.util.HashMap;
import java.util.Map;

public class ExceptionCodes {

	public static final Map<String, String> CASE_REASON_CODE = new HashMap<>();

	// General Exception
	public static final String READER_GENERAL_EXCEPTION = "RDR-GEN-001";
	public static final String READER_FILE_NOT_FOUND_EXCEPTION = "RDR-GEN-005";
	public static final String READER_DUPLICATE_FILE_EXCEPTION = "RDR-GEN-006";
	public static final String READER_RELEASE_EXCEPTION = "RDR-GEN-007";
	public static final String READER_FILE_EMPTY = "RDR-GEN-008";
	public static final String READER_FILE_ACCESS_DENIED_EXCEPTION = "RDR-GEN-009";

	// Data Exception
	public static final String READER_EOF_EXCEPTION = "RDR-DAT-001";
	public static final String FIELD_FORMAT_EXCEPTION = "RDR-DAT-002";
	public static final String INVALID_FILE_FORMAT_EXCEPTION = "RDR-DAT-003";
	public static final String MISSING_FIELDS = "RDR-DAT-004";

	// System Exception
	public static final String SYSTEM_GENERAL_EXCEPTION = "SYS-GEN-001";
	public static final String DB_GENERAL_EXCEPTION = "DB-GEN-001";
	public static final String DATASOURCE_INIT_EXCEPTION = "DS-INIT-001";
	public static final String DATASOURCE_NOSUCH_EXCEPTION = "DS-NOSUCH-001";

	// Default
	public static final String DEFAULT = "DEFAULT";

	private ExceptionCodes() {
	}

	static{
		CASE_REASON_CODE.put(READER_GENERAL_EXCEPTION, "General Exception occured during Reader Execution !");
		CASE_REASON_CODE.put(READER_FILE_NOT_FOUND_EXCEPTION, "File not found !");
		CASE_REASON_CODE.put(READER_DUPLICATE_FILE_EXCEPTION, "Duplicate file found !");
		CASE_REASON_CODE.put(READER_RELEASE_EXCEPTION, "Exception while File stream release!");
		CASE_REASON_CODE.put(READER_FILE_EMPTY, "Empty File !");
		CASE_REASON_CODE.put(READER_FILE_ACCESS_DENIED_EXCEPTION, "File Access denied !");
		CASE_REASON_CODE.put(READER_EOF_EXCEPTION, "File end !");
		CASE_REASON_CODE.put(FIELD_FORMAT_EXCEPTION, "Field formate Error !");
		CASE_REASON_CODE.put(INVALID_FILE_FORMAT_EXCEPTION, "Invalid field formate !");
		CASE_REASON_CODE.put(MISSING_FIELDS, "Missing fields from record !");
		CASE_REASON_CODE.put(SYSTEM_GENERAL_EXCEPTION, "System general exception !");
		CASE_REASON_CODE.put(DB_GENERAL_EXCEPTION, "DB Connectivity Error");
		CASE_REASON_CODE.put(DATASOURCE_INIT_EXCEPTION, "DB Connectivity Error, Please check DB configuration");
		CASE_REASON_CODE.put(DATASOURCE_NOSUCH_EXCEPTION, "DB Connectivity Error, No such data source available");
		CASE_REASON_CODE.put(DEFAULT, "Default Exception. This is not properly handled in Engine. Please contact developer !");
	}

}
