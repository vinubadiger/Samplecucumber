package com.opus.optimus.offline.runtime.common.reader.config;

/**
 * The Enum ReaderSourceType.
 */
public enum ReaderSourceType {
	
	/** The textfile. */
	TEXTFILE,
	
	/** The db. */
	DB,
	
	/** The xls. */
	XLS,
	
	/** The pdf. */
	PDF,
	
	/** The binary. */
	BINARY
}
