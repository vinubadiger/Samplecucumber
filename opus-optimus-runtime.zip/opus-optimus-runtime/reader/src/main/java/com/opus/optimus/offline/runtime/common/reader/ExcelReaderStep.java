package com.opus.optimus.offline.runtime.common.reader;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.reader.ExcelReaderConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * The Class ExcelReaderStep.
 *
 * @author Yashkumar.Thakur
 */

@Component(StepTypeConstants.EXCEL_READER_STEPTYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ExcelReaderStep extends AbstractStep<ExcelReaderConfig> implements IJobTaskInfoAware {
	
	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(ExcelReaderStep.class);

	/** The file reader. */
	@Autowired
	ExcelReaderHelper fileReader;

	/** The message factory. */
	@Autowired
	IMessageFactory messageFactory;
	
	IJobTaskInfo jobTaskInfo;

	/**
	 * Instantiates a new excel reader step.
	 *
	 * @param config the configuration
	 */
	public ExcelReaderStep(ExcelReaderConfig config) {
		super(config);
	}
	
	/**
	 * Do stop of force stop if any intermediate step fail.
	 *
	 * @return true, if successful
	 */
	public boolean doStop() {
		return forceStop.get();
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		try {
			fileReader.init((String) data.getData(), config,jobTaskInfo.getJobId());
			fileReader.processFile(this,new IReaderEventHandler<IRecord>() {
				@Override
				public void onData(IRecord record, ISourceReference sourceReference) {
					Serializable result = null;
					MessageType messageType = MessageType.DATA;
					try {
						result = record;
					} catch (Exception e) {
						logger.error("Error while setting record : {} , {}",e.getMessage() , e);
						messageType = MessageType.ERROR;
						result = e.getMessage();
					}

					if (result != null) {
						emitter.emit(messageFactory.createMessage(messageType, result,
								(sourceReference == null) ? data.getSourceReference() : sourceReference));
					}
				}

				@Override
				public void onDataError(Throwable cause, ISourceReference sourceReference) {
					ErrorDetails errorDetails = ErrorDetails.builder().userDetails(cause.getMessage())
							.errorDetail(cause).severity(Severity.ERROR).build();
					emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, sourceReference));
				}
			});

		} catch (ReaderException readerException) {
			logger.error("Error while ExcelFileReader Step execution.", readerException);
			final FileSourceReference fileSourceReference = FileSourceReference.builder()
					.fileName((String) data.getData()).build();
			final ErrorDetails errorDetails = ErrorDetails.builder().userDetails(readerException.getMessage())
					.errorDetail(readerException).severity(Severity.FATAL).build();
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, fileSourceReference));
		} catch (Exception exception) {
			logger.error("System Error occured.", exception);
			final FileSourceReference fileSourceReference = FileSourceReference.builder()
					.fileName((String) data.getData()).build();
			final ErrorDetails errorDetails = ErrorDetails.builder().userDetails(exception.getMessage())
					.errorDetail(exception).severity(Severity.FATAL).build();
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, fileSourceReference));
		}
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
		
	}
}
