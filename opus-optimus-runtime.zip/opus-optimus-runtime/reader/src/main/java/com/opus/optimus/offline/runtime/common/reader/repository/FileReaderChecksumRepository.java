package com.opus.optimus.offline.runtime.common.reader.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;

@Repository
public interface FileReaderChecksumRepository extends MongoRepository<JobInfo, String> {
	@Query("{ 'sourceInfo.fileChecksum' : ?0 }")
	JobInfo findByfileChecksum(String fileChecksum);
	
	@Query("{ '_id' : ?0 }")
	JobInfo findByjobId(String jobId);
}
