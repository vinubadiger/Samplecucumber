package com.opus.optimus.offline.runtime.common.reader.exception;

public class EOFException extends ReaderException {
	private static final long serialVersionUID = 1L;

	private final String errorCode ;

	public EOFException() {
		this.errorCode = ExceptionCodes.READER_EOF_EXCEPTION;
	}

	public EOFException(Throwable cause) {
		super(cause);
		this.errorCode = ExceptionCodes.READER_EOF_EXCEPTION;
	}
	
	@Override
	public String getErrorCode() {
		return this.errorCode;
	}	
}
