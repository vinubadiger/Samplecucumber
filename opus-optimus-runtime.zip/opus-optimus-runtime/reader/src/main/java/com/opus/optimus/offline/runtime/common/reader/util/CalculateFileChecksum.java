package com.opus.optimus.offline.runtime.common.reader.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.repository.FileReaderChecksumRepository;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.SourceInfo;

@Component
public class CalculateFileChecksum {
	private static final Logger logger = LoggerFactory.getLogger(CalculateFileChecksum.class);

	@Autowired
	FileReaderChecksumRepository fileReaderChecksumRepository;

	public String isFileChecksumRequired(String inputFileLocation, String jobId) throws ReaderException {
		logger.debug("Command received for calculating file checksum");
		String fileChecksum = null;
		try{
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			fileChecksum = checkSum(inputFileLocation, md);
			logger.debug("Generated file checksum {} ", fileChecksum);
			JobInfo jobInfo = fileReaderChecksumRepository.findByfileChecksum(fileChecksum);
			if (jobInfo == null){
				jobInfo = fileReaderChecksumRepository.findByjobId(jobId);
				SourceInfo sourceInfo = Optional.ofNullable(jobInfo.getSourceInfo()).orElse(new SourceInfo());
				sourceInfo.setFileChecksum(fileChecksum);
				jobInfo.setSourceInfo(sourceInfo);
				fileReaderChecksumRepository.save(jobInfo);
			} else{
				String checksum = jobInfo.getSourceInfo().getFileChecksum();
				if (fileChecksum.equals(checksum)){
					logger.error("Duplicate File Found");
					throw new ReaderException(ExceptionCodes.READER_DUPLICATE_FILE_EXCEPTION, "Duplicate File Found at " + inputFileLocation);
				}
			}

		} catch (ReaderException e){
			throw e;
		} catch (FileNotFoundException e){
			logger.error("File not found while calculating file checksum : {}", e);
			throw new ReaderException(ExceptionCodes.READER_FILE_NOT_FOUND_EXCEPTION, "File not found while calculating file checksum - " + inputFileLocation);
		} catch (IOException e){
			logger.error("Problem while reading file for Filechecksum {}", e);
			throw new ReaderException("Problem while reading file for Filechecksum: {}", e);
		} catch (Exception e){
			logger.error("Error while calculating cheksum of file :{}", e);
			throw new ReaderException("Error Ouccured while calculating File Checksum", e);
		}
		return fileChecksum;
	}

	private String checkSum(String filePath, MessageDigest md) throws IOException {

		// file hashing with DigestInputStream
		try (DigestInputStream dis = new DigestInputStream(new FileInputStream(filePath), md)){
			while (dis.read() != -1); // empty loop to clear the data
			md = dis.getMessageDigest();

			// bytes to hex
			StringBuilder result = new StringBuilder();
			for (byte b : md.digest()){
				result.append(String.format("%02x", b));
			}
			return result.toString();
		}
	}

}
