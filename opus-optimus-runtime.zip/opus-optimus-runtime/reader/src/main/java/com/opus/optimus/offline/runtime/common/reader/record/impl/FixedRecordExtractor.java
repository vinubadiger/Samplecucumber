package com.opus.optimus.offline.runtime.common.reader.record.impl;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.config.record.impl.FixedRecordExtractorConfig;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.record.IRecordExtractor;
import com.opus.optimus.offline.runtime.common.reader.stream.IStream;
import com.opus.optimus.offline.runtime.common.reader.stream.impl.FileStream;

/**
 * The Class FixedRecordExtractor.
 *
 * @author Ram
 */

public class FixedRecordExtractor implements IRecordExtractor<String> {

	/** The configuration  */
	private FixedRecordExtractorConfig config;

	@Override
	public void init(IBaseConfig config) {
		this.config = (FixedRecordExtractorConfig) config;
	}

	@Override
	public String getRecord(Object context, IStream stream) throws ReaderException {
		return ((FileStream) stream).getRecord(config.getRecordLength());
	}

}
