package com.opus.optimus.offline.runtime.common.reader.config;

import java.io.Serializable;

import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

import lombok.Builder;
import lombok.Data;

/**
 * The Class DBSourceReference.
 *
 * @author Anup.Warke
 */

@Builder
@Data
public class DBSourceReference implements ISourceReference {

	/** The Constant SOURCE_REFERENCE_TYPE. */
	private static final String SOURCE_REFERENCE_TYPE = "DBSourceReference";

	/** The row index. */
	private int rowIndex;

	/** The raw record data. */
	private Serializable rawRecordData;

	/** The data source name. */
	private String dataSourceName;

	/** The schema name. */
	private String schemaName;

	/** The collection name. */
	private String collectionName;

	@Override
	public String getType() {
		return SOURCE_REFERENCE_TYPE;
	}

}
