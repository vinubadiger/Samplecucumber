package com.opus.optimus.offline.runtime.common.reader;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.config.fieldextractor.impl.DelimitedFieldExtractorConfig;
import com.opus.optimus.offline.config.fieldextractor.impl.FixedFieldExtractorConfig;
import com.opus.optimus.offline.runtime.common.reader.field.IFieldExtractor;
import com.opus.optimus.offline.runtime.common.reader.field.impl.DelimitedFieldExtractor;
import com.opus.optimus.offline.runtime.common.reader.field.impl.FixedFieldExtractor;

/**
 * A factory for creating FieldExtractor objects.
 *
 * @author Ram
 */

public class FieldExtractorFactory {
	
	/**
	 * Instantiates a new field extractor factory.
	 */
	private FieldExtractorFactory() {}
	
	/**
	 * Factory giver the extractor.
	 *
	 * @param config the configuration
	 * @return the extractor
	 */
	@SuppressWarnings("rawtypes")
	public static IFieldExtractor getExtractor(IBaseConfig config) {		
		if (config instanceof DelimitedFieldExtractorConfig) {
			return new DelimitedFieldExtractor();
		} else if(config instanceof FixedFieldExtractorConfig) {
			return new FixedFieldExtractor();
		}
		
		return null;
	}
}
