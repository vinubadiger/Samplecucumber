package com.opus.optimus.offline.runtime.common.reader.stream;

import java.io.InputStream;

import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;

/**
 * The Interface IStream.
 */
public interface IStream {
	  
  	/**
  	 * Gets the underlying stream.
  	 *
  	 * @return the underlying stream
  	 */
  	public abstract InputStream getUnderlyingStream() ;
	  
  	/**
  	 * Release.
  	 *
  	 * @throws ReaderException the reader exception
  	 */
  	public abstract void release() throws ReaderException;
}
