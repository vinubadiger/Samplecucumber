package com.opus.optimus.offline.runtime.common.reader.record;

import com.opus.optimus.offline.config.IBaseConfig;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.stream.IStream;

/**
 * The Interface IRecordExtractor.
 *
 * @author Ram
 * @param <T> the generic type
 */
public interface IRecordExtractor<T> {

	  /**
  	 * Gets the record.
  	 *
  	 * @param context the context
  	 * @param stream the stream
  	 * @return the record
  	 * @throws ReaderException the reader exception
  	 */
  	public abstract T getRecord(Object context, IStream stream)
			    throws ReaderException;
	
	  /**
  	 * Initialize the.
  	 *
  	 * @param config the configuration
  	 */
  	public abstract void init(IBaseConfig config);
}
