package com.opus.optimus.offline.runtime.common.reader.exception;

public class ReaderException extends Exception {
	private static final long serialVersionUID = 1L;

	private final String errorCode ;

	public ReaderException() {
		this.errorCode = ExceptionCodes.READER_GENERAL_EXCEPTION;
	}

	public ReaderException(Throwable cause) {
		super(cause);
		this.errorCode = ExceptionCodes.READER_GENERAL_EXCEPTION;
	}
	
	public ReaderException(String errorCode, String reason)	{
		super(reason);
		this.errorCode = errorCode;
	}
	
	public ReaderException(String errorCode, Throwable cause)	{
		super(cause);
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return this.errorCode;
	}	
}
