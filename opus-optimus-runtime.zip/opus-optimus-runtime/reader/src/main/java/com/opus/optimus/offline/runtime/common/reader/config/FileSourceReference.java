/*
 * 
 */
package com.opus.optimus.offline.runtime.common.reader.config;

import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * Instantiates a new file source reference, used for error looging.
 * 
 * @author Yashkumar.Thakur
 *
 */

/**
 *
 *
 * @param fileName -
 *            The file name
 * @param rowIndex -
 *            The row index
 * @param rawRecordData -
 *            The raw record data
 */
@AllArgsConstructor
@Builder
@Data
public class FileSourceReference implements ISourceReference {

	/** The Constant FILE_SOURCE_REFECN. */
	private static final String FILE_SOURCE_REFECN = "FileSourceReference";

	/** The file name. */
	private String fileName;

	/** The row index. */
	private int rowIndex;

	/** The raw record data. */
	private String rawRecordData;

	@Override
	public String getType() {
		return FILE_SOURCE_REFECN;
	}

}
