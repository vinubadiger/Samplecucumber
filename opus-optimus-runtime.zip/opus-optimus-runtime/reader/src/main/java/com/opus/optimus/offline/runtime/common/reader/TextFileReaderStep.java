package com.opus.optimus.offline.runtime.common.reader;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.constants.Constants;
import com.opus.optimus.offline.config.reader.TextFileReaderConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * The Class TextFileReader Step for reading delimited and fixed files.
 * 
 * @author Yashkumar.Thakur
 */
@Component (StepTypeConstants.FILE_READER_STEPTYPE)
@Scope (value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TextFileReaderStep extends AbstractStep<TextFileReaderConfig> implements IJobTaskInfoAware {

	/** The Constant for logger slf4j, to log info, warning, error and debug. */
	private static final Logger logger = LoggerFactory.getLogger(TextFileReaderStep.class);

	/** The file reader helper. for injection facilities */
	@Autowired
	TextFileReaderHelper fileReaderHelper;

	/** The message factory for message creation using Message Type Enum. */
	@Autowired
	IMessageFactory messageFactory;

	IJobTaskInfo jobTaskInfo;

	/**
	 * Instantiates a new text file reader step.
	 *
	 * @param config - The reader configuration
	 */
	public TextFileReaderStep(TextFileReaderConfig config) {
		super(config);
	}

	/**
	 * Do stop of force stop if any intermediate step fail.
	 *
	 * @return true, if successful
	 */
	public boolean doStop() {
		return forceStop.get();
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		try{
			fileReaderHelper.init((String) data.getData(), config, jobTaskInfo.getJobId());
			fileReaderHelper.processFile(this, new IReaderEventHandler<IRecord>() {

				@Override
				public void onData(IRecord record, ISourceReference sourceReference) {
					// Due to performance issue, commented for now
					// logger.debug("Record parsed :{} " + record)

					emitter.emit(messageFactory.createMessage(MessageType.DATA, record, sourceReference));
				}

				@Override
				public void onDataError(Throwable cause, ISourceReference sourceReference) {
					ErrorDetails errorDetails = ErrorDetails.builder().userDetails(cause.getMessage())
							.errorDetail(cause).severity(Severity.ERROR).build();
					emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, sourceReference));
				}

			});

		} catch (ReaderException readerException){
			logger.error("Error while TextFileReader Step execution :{} , {}", readerException.getMessage(), readerException);
			final FileSourceReference fileSourceReference = FileSourceReference.builder().fileName((String) data.getData()).build();
			final Map<String, Object> errorSupportingData = new HashMap<>();
			final ErrorDetails errorDetails = ErrorDetails.builder().userDetails(readerException.getMessage()).errorDetail(readerException).severity(Severity.FATAL).additionalData(errorSupportingData).build();
			errorDetails.getAdditionalData().put(Constants.ERROR_CODE, readerException.getErrorCode());
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, fileSourceReference));
		} catch (Exception exception){
			logger.error("System Error occured : {}", exception);
			final FileSourceReference fileSourceReference = FileSourceReference.builder().fileName((String) data.getData()).build();
			final ErrorDetails errorDetails = ErrorDetails.builder().userDetails(exception.getMessage()).errorDetail(exception).severity(Severity.FATAL).build();
			emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, fileSourceReference));
		}
	}

	@Override
	public void onStepEnd(boolean forceEnd, IEmitter emitter) {
		logger.info("On End");
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}
}
