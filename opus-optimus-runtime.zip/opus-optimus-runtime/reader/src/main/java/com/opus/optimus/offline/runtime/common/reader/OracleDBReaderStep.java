package com.opus.optimus.offline.runtime.common.reader;


import com.opus.optimus.offline.config.reader.DBReaderConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.IRecordFactory;
import com.opus.optimus.offline.runtime.common.api.record.impl.Schema;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.db.OracleDBReaderHelper;
import com.opus.optimus.offline.runtime.common.reader.exception.DbReaderException;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.reader.util.SchemaBuilder;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

import static com.opus.optimus.offline.constants.ReaderConstants.DATA;

/**
 * The Class OracleDBReaderStep.
 */

@Component(StepTypeConstants.DBREADER_STEP_TYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class OracleDBReaderStep extends AbstractStep<DBReaderConfig> {

    /**
     * The Constant logger.
     */
    static final Logger logger = LoggerFactory.getLogger (OracleDBReaderStep.class);

    /**
     * The message factory.
     */
    @Autowired
    IMessageFactory messageFactory;
    /**
     * The record factory.
     */
    @Autowired
    IRecordFactory recordFactory;
    /**
     * The Oracle DB reader helper.
     */
    @Autowired
    private OracleDBReaderHelper oracleDBReaderHelper;

    /**
     * Instantiates a new Oracle DB reader step.
     *
     * @param config the configuration
     */
    public OracleDBReaderStep(DBReaderConfig config) {
        super (config);
    }

    /**
     * Initialize the helper.
     *
     * @throws ReaderException the reader exception
     */
    public boolean doStop() {
        return forceStop.get ();
    }

    @PostConstruct
    public void initHelper() throws ReaderException {

        final Schema schema = SchemaBuilder.buildDBReaderSchema (config.getSection () == null ? DATA : config.getSection (), this.config.getFieldConfigs ());
        recordFactory.registerSchema (schema);
        try {
            oracleDBReaderHelper.init (this.config);
        } catch (NoSuchDataSourceAvailableException e) {
            logger.error ("Error occured while initializing Oracle DB Connection.", e);
            throw new DbReaderException (ExceptionCodes.DB_GENERAL_EXCEPTION, e);
        }
    }

    @Override
    public void process(IMessage data, IEmitter emitter) {
        try {
            oracleDBReaderHelper.process (this, new IReaderEventHandler<IRecord> () {
                @Override
                public void onDataError(Throwable cause, ISourceReference sourceReference) {
                    ErrorDetails errorDetails = ErrorDetails.builder ().userDetails (cause.getMessage ()).errorDetail (cause).severity (Severity.ERROR).build ();
                    emitter.emit (messageFactory.createMessage (MessageType.ERROR, errorDetails, sourceReference));
                }

                @Override
                public void onData(IRecord record, ISourceReference sourceReference) {
                    logger.info ("Record parsed : " + record);
                    emitter.emit (messageFactory.createMessage (MessageType.DATA, record, sourceReference));
                }
            });
        } catch (Exception exception) {
            logger.error ("System Error occured : {}", exception);
            //prepare DB Source reference
            ISourceReference sourceReference = DBSourceReference.builder ().rawRecordData (this.config.getCollectionName ()) //Table Name
                    .dataSourceName (config.getDataSourceName ()).build ();
            final ErrorDetails errorDetails = ErrorDetails.builder ().userDetails (exception.getMessage ()).errorDetail (exception).severity (Severity.FATAL).build ();
            emitter.emit (messageFactory.createMessage (MessageType.ERROR, errorDetails, sourceReference));
        }

    }


}
