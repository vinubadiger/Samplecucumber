package com.opus.optimus.offline.runtime.exception.test

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.context.ContextConfiguration
import org.springframework.web.client.RestTemplate

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.exception.ErrorHandlerConstants
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails
import com.opus.optimus.offline.runtime.workflow.exception.Severity
import com.opus.optimus.offline.runtime.workflow.test.TestWorkflowConfig

import spock.lang.Ignore
import spock.lang.Specification

@Ignore
@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class ReconErrorHandlerSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory;
	
	@Autowired
	MapperFactory mapperFactory
	
	@Autowired
	String mongoHost;
	
	@Autowired
	Integer mongoPort;
	
	@Autowired
	DataSourceFactory dataSourceFactory;

	@SpringBean(name = "restTemplate")
	RestTemplate restTemplate = Mock()
	
	@SpringBean
	SalesforceCaseHelper salesforceCaseHelper = Mock()

	def "Recon Error Handler Step Execution - One Job - MultiMatch"() {
		setup:
			def activityName = "TestReconError"
			def subStatus = ReconSubStatus.MultipleMatches
			def sourceACollection = "sourceA"
			def sourceBCollection = "sourceB"
			def templateCollection = "ReconCaseTemplate"
			def dataSourceName = "sourceDataSource"
			def jobId = "reconErrorJob"
			def caseDesciption = ""
			
			def mapper = mapperFactory.getMapper()
			//register the data source
			def dataSourceJsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
			def mongoDbDataSourceMetaData = mapper.readValue(dataSourceJsonStream, MongoDataSourceMeta.class)
			//change the dynamic port with meta data.
			mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
				addressMeta.setPort(mongoPort)
			}
			
			def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
	
			//set up embedded mongo
			def dbHostIP = mongoHost;
			def dbPort = mongoPort;
	
			//initialize data source factory
			mongoDataSource.init();
			dataSourceFactory.register(mongoDbDataSourceMetaData.getDataSourceName(), mongoDataSource);
	
			def mongo = new MongoClient(dbHostIP, dbPort);
			def mongoDataBase = mongo.getDatabase(mongoDbDataSourceMetaData.getDatabaseName());
		
			//prepare error details of source A
			def errorRecordInfoList = new ArrayList<>();
			def sourceA_oIDs = new ArrayList<>();
			def srcA_unReconcileRecords = UnReconcileRecords.builder().sourceName(sourceACollection).oIDs(sourceA_oIDs)
					.collectionName(sourceACollection).dataSourceName(dataSourceName).build();
			//insert sample records for source A
			def mongoCollectionA = mongoDataBase.getCollection(sourceACollection)
			def sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleSourceARecords.txt")
			def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
			def sampleRecordLine = sampleRecordBufferedReader.readLine();
			while (sampleRecordLine != null) {
				def dbObject = Document.parse(sampleRecordLine)
				println("db object" + dbObject)
				mongoCollectionA.insertOne(dbObject)
				sourceA_oIDs.add(dbObject.get("_id").toHexString())
				sampleRecordLine = sampleRecordBufferedReader.readLine();
			}
			errorRecordInfoList.add(srcA_unReconcileRecords)
			
			def sourceB_oIDs = new ArrayList<>();
			def srcB_unReconcileRecords = UnReconcileRecords.builder().sourceName(sourceBCollection).oIDs(sourceB_oIDs)
					.collectionName(sourceBCollection).dataSourceName(dataSourceName).build();
			//insert sample records for source B
			def mongoCollectionB = mongoDataBase.getCollection(sourceBCollection)
			sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleSourceBRecords.txt")
			sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
			sampleRecordLine = sampleRecordBufferedReader.readLine();
			while (sampleRecordLine != null) {
				def dbObject = Document.parse(sampleRecordLine)
				println("db object" + dbObject)
				mongoCollectionB.insertOne(dbObject)
				sourceB_oIDs.add(dbObject.get("_id").toHexString())
				sampleRecordLine = sampleRecordBufferedReader.readLine();
			}
			errorRecordInfoList.add(srcB_unReconcileRecords)
			
			//insert the templates
			def mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
			sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleCaseTemplate.txt")
			sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
			sampleRecordLine = sampleRecordBufferedReader.readLine();
			while (sampleRecordLine != null) {
				println("template sample to be inserted : " + sampleRecordLine)
				def dbObject = Document.parse(sampleRecordLine)
				println("template db object" + dbObject)
				mongoTemplateCollection.insertOne(dbObject)
				sampleRecordLine = sampleRecordBufferedReader.readLine();
			}
			
			//insert sample job info
			def jobInfoCollection = mongoDataBase.getCollection("JobInfo")
			sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfo.txt")
			sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
			sampleRecordLine = sampleRecordBufferedReader.readLine();
			while (sampleRecordLine != null) {
				def dbObject = Document.parse(sampleRecordLine)
				println("db object" + dbObject)
				jobInfoCollection.insertOne(dbObject)
				jobId = dbObject.get("_id").toHexString();
				sampleRecordLine = sampleRecordBufferedReader.readLine();
			}
			
			//Build the DefaultErrorHandlerWorkflowConfig
			def jsonStream = getClass().getResourceAsStream("/ReconHandlerWorkflowConfig.json")
			println("Recon Error handler config Json Stream: " + jsonStream)
			def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
			def reconErrorHandlerWorkflowrConfig = object.stepConfig;
			println("Recon Error handler config: " + reconErrorHandlerWorkflowrConfig)
			
			def workflowConfig = new WorkflowConfig()
			workflowConfig.stepConfigs = [reconErrorHandlerWorkflowrConfig]
			
			
			def userDetailsMessage = "Test recon error message raised."
			
			def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
			localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
			localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
			
			//build the Error Details to be emitted
			//build the supporting data
			def supportingData = new HashMap();
			supportingData.put(ErrorHandlerConstants.ERR_UNIQUE_REC_IDS_KEY, errorRecordInfoList);
			supportingData.put(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY, activityName);
			supportingData.put(ErrorHandlerConstants.ERR_RECON_STATUS_KEY, subStatus);
			supportingData.put(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY, sourceACollection);
			supportingData.put(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY, sourceBCollection);
			
			def errorDetails = ErrorDetails.builder()
									.userDetails(userDetailsMessage)
									.severity(Severity.ERROR)
									.additionalData(supportingData)
									.build();
			//mock the case response
			def caseId = "case1"
			def accessToken = "abcd1234"
			
			def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();
			salesforceCaseHelper.authenticate() >> {
				return salesForceAuthResponse 
			}
		when:
			def result = localJobTaskExecutor.execute()
			def emitter = localJobTaskExecutor.getInBoundQueue("defaultGlobalErrorHandler").getEmitter()
			emitter.emit(messageFactory.createMessage(errorDetails))
			emitter.emit(messageFactory.createEndMessage())
			def jobResult = result.get()
		then:
			_ * restTemplate.postForEntity(_, _, SalesforceCaseResponse.class) >> { arguments ->
				def referenceId1 = arguments[1].getBody().records[0].childcases[0].referenceId
				caseDesciption = arguments[1].getBody().records[0].childcases[0].description
				def successListSalesforceCaseDetails = [
					SalesforceCaseDetails.builder().caseId(caseId).caseNumber("1").referenceId(referenceId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				]
			
				def successList = new ArrayList(successListSalesforceCaseDetails)
				
				def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
				
				return new ResponseEntity(salesForceResponse, HttpStatus.OK);
			}
			noExceptionThrown()
			//verify Source A records
			MongoCollection<Document> sourceAMgCollection = mongoDataBase.getCollection(sourceACollection);
			Document searchSourceA = new Document();
			searchSourceA.append("reconControlFields."+activityName, new Document("\$exists", true));
			println("Document Filter Source A: " + searchSourceA);
			FindIterable<Document> resultsSourceA = sourceAMgCollection.find(searchSourceA);
			println("Document Found -Source A: " + resultsSourceA);
			resultsSourceA != null
			resultsSourceA.each { document ->
				Map<String, Object> reconControlField = document.get("reconControlFields")
				Map<String, Object> activityReconControlField = reconControlField.get(activityName)
				Map<String, Object> caseInfo = activityReconControlField.get("caseInfo")
				assert caseInfo != null
				assert caseInfo.get("caseID") != null
				assert caseInfo.get("status").toString() == CaseStatus.OPEN.toString()
			}
			//verify Source B records
			MongoCollection<Document> sourceBMgCollection = mongoDataBase.getCollection(sourceBCollection);
			Document searchSourceB = new Document();
			searchSourceB.append("reconControlFields."+activityName, new Document("\$exists", true));
			println("Document Filter Source B: " + searchSourceB);
			FindIterable<Document> resultsSourceB = sourceBMgCollection.find(searchSourceB);
			println("Document Found -Source B: " + resultsSourceB);
			resultsSourceB != null
			resultsSourceB.each { document ->
				Map<String, Object> reconControlField = document.get("reconControlFields")
				Map<String, Object> activityReconControlField = reconControlField.get(activityName)
				Map<String, Object> caseInfo = activityReconControlField.get("caseInfo")
				assert caseInfo != null
				assert caseInfo.get("caseID") != null
				assert caseInfo.get("status").toString() == CaseStatus.OPEN.toString()
			}
			caseDesciption != ""
			caseDesciption.startsWith("The record failed with status  " + subStatus)
	}
}
