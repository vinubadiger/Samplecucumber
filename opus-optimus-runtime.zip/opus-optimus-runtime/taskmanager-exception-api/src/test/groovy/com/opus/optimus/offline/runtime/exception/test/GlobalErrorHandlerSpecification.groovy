package com.opus.optimus.offline.runtime.exception.test

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

import org.bson.Document
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails
import com.opus.optimus.offline.runtime.workflow.exception.Severity
import com.opus.optimus.offline.runtime.workflow.test.TestWorkflowConfig

import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import spock.lang.Ignore
import spock.lang.Specification

@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class GlobalErrorHandlerSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory;
	
	@Autowired
	MapperFactory mapperFactory
	
	@Autowired
	String mongoHost;
	
	@Autowired
	Integer mongoPort;

	def "Default Global Error Handler Step Execution - Severity Error"() {
		setup:
			//set up embedded mongo
			def dbHostIP = mongoHost;
			def dbPort = mongoPort;
			def databaseName = "local";
			def collectionName = "JobErrorDetails";
			
			def mongo = new MongoClient(dbHostIP, dbPort);
			def mongoDataBase = mongo.getDatabase(databaseName);
			
			//Build the DefaultErrorHandlerWorkflowConfig
			def mapper = mapperFactory.getMapper()
			def jsonStream = getClass().getResourceAsStream("/GlobalErrorHandlerWorkflowConfig.json")
			println("Global Error handler config Json Stream: " + jsonStream)
			def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
			def globalErrorHandlerWorkflowrConfig = object.stepConfig;
			println("Global Error handler config: " + globalErrorHandlerWorkflowrConfig)
			
			def workflowConfig = new WorkflowConfig()
			workflowConfig.stepConfigs = [globalErrorHandlerWorkflowrConfig]
			
			def jobId = ""
			def userDetailsMessage = "Test error message raised."
			
			//insert sample job info
			def jobInfoCollection = mongoDataBase.getCollection("JobInfo")
			def sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfo.txt")
			def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
			def sampleRecordLine = sampleRecordBufferedReader.readLine();
			while (sampleRecordLine != null) {
				def dbObject = Document.parse(sampleRecordLine)
				println("db object" + dbObject)
				jobInfoCollection.insertOne(dbObject)
				jobId = dbObject.get("_id").toHexString();
				sampleRecordLine = sampleRecordBufferedReader.readLine();
			}
			
			def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
			localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
			localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
			
			//build the Error Details to be emitted
			def errorDetails = ErrorDetails.builder()
									.userDetails(userDetailsMessage)
									.severity(Severity.ERROR)
									.errorDetail(new TestException("Test error occured. Global error handling working as expected."))
									.build();
		when:
			def result = localJobTaskExecutor.execute()
			def emitter = localJobTaskExecutor.getInBoundQueue("defaultGlobalErrorHandler").getEmitter()
			emitter.emit(messageFactory.createMessage(errorDetails))
			emitter.emit(messageFactory.createEndMessage())
			def jobResult = result.get(500, TimeUnit.SECONDS)
			Thread.sleep(2000)
		then:
			noExceptionThrown()
			MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
			Document searchDocument = new Document();
			searchDocument.append("jobId", jobId);
			println("Document Filter: " + searchDocument);
			Document searchResult = resultCollection.find(searchDocument).first();
			println("Document Found -For Error Details: " + searchResult);
			searchResult != null
			println("Error record updated in Mongo DB: Job Id: " + searchResult.getString("jobId"))
			searchResult.getString("errorMessage").contains(userDetailsMessage)
			Severity.ERROR.name().equalsIgnoreCase(searchResult.getString("errorType"))
		cleanup:
			mongo.close();
	}
	
	def "Default Global Error Handler Step Execution - Severity Fatal"() {
		setup:
			//set up embedded mongo
			def dbHostIP = mongoHost
			def dbPort = mongoPort
			def databaseName = "local";
			def collectionName = "JobErrorDetails";
			def jobResultCollectionName = "JobResult"
			
			def mongo = new MongoClient(dbHostIP, dbPort);
			def mongoDataBase = mongo.getDatabase(databaseName);
			
			//Build the DefaultErrorHandlerWorkflowConfig
			def mapper = mapperFactory.getMapper()
			def jsonStream = getClass().getResourceAsStream("/GlobalErrorHandlerWorkflowConfig.json")
			println("Global Error handler config Json Stream: " + jsonStream)
			def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
			def globalErrorHandlerWorkflowrConfig = object.stepConfig;
			println("Global Error handler config: " + globalErrorHandlerWorkflowrConfig)
			
			def workflowConfig = new WorkflowConfig()
			workflowConfig.stepConfigs = [globalErrorHandlerWorkflowrConfig]
			
			def jobId = ""
			def userDetailsMessage = "Test error message raised."
			
			//insert sample job info
			def jobInfoCollection = mongoDataBase.getCollection("JobInfo")
			def sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfo.txt")
			def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
			def sampleRecordLine = sampleRecordBufferedReader.readLine();
			while (sampleRecordLine != null) {
				def dbObject = Document.parse(sampleRecordLine)
				println("db object" + dbObject)
				jobInfoCollection.insertOne(dbObject)
				jobId = dbObject.get("_id").toHexString();
				sampleRecordLine = sampleRecordBufferedReader.readLine();
			}
			
			def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
			localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
			localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
			
			//build the Error Details to be emitted
			def errorDetails = ErrorDetails.builder()
									.userDetails(userDetailsMessage)
									.severity(Severity.FATAL)
									.errorDetail(new TestException("Test error occured. Global error handling working as expected."))
									.build();
		when:
			def result = localJobTaskExecutor.execute()
			def emitter = localJobTaskExecutor.getInBoundQueue("defaultGlobalErrorHandler").getEmitter()
			emitter.emit(messageFactory.createMessage(errorDetails))
			emitter.emit(messageFactory.createEndMessage())
			def jobResult = result.get(500, TimeUnit.SECONDS)
			Thread.sleep(2000)
		then:
			noExceptionThrown()
			MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
			Document searchDocument = new Document();
			searchDocument.append("jobId", jobId);
			println("Document Filter: " + searchDocument);
			Document searchResult = resultCollection.find(searchDocument).first();
			println("Document Found for error details log: " + searchResult);
			searchResult != null
			println("Error record updated in Mongo DB: Job Id: " + searchResult.getString("jobId"))
			searchResult.getString("errorMessage").contains(userDetailsMessage)
			Severity.FATAL.name().equalsIgnoreCase(searchResult.getString("errorType"))
			
			//fetch the Task Result for the job jobResultCollectionName
			jobResult != null
			def isAborted = false
			for(def stepExecutorResult : jobResult.stepExecutorResults) {
				println("Status : " + stepExecutorResult)
				def instanceStatsKeySet = stepExecutorResult.instanceStats.keySet()
				def instanceStatsKeyIterator = instanceStatsKeySet.iterator()
				while(instanceStatsKeyIterator.hasNext()) {
					def instanceStat = stepExecutorResult.instanceStats.get(instanceStatsKeyIterator.next())
					if(instanceStat != null) {
						if(OperationStatus.ABORTED.equals(instanceStat.status)) {
							isAborted = true
						}
					}
				}
			}

			isAborted == true
			
		cleanup:
			mongo.close();
	}
}
