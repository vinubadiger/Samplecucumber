package com.opus.optimus.offline.runtime.exception.test

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.exception.ErrorHandlerConstants
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.MessageType
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails
import com.opus.optimus.offline.runtime.workflow.exception.Severity
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import com.opus.optimus.offline.runtime.workflow.test.TestWorkflowConfig

import spock.lang.Specification

@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class SalesForceCaseCreationStepSpecification extends Specification {
	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	@SpringBean
	SalesforceCaseHelper salesforceCaseHelper = Mock()
	
	def "Sales force case creation Step Execution - RECON - FATAL"() {
		setup:
		//set up embedded mongo
		def dbHostIP = mongoHost
		def dbPort = mongoPort
		def databaseName = "local";
		def collectionName = "JobErrorDetails";
		def templateCollection = "ReconCaseTemplate"
		def jobResultCollectionName = "JobResult"
		def jobInfoCollectionName = "JobInfo"
		def jobId = "errorJob3"
		def activityName = "jUnitTestActivity"
		def sourceACollection = "sourceA"
		def sourceBCollection = "sourceB"

		def mongo = new MongoClient(dbHostIP, dbPort);
		def mongoDataBase = mongo.getDatabase(databaseName);

		//insert sample job info
		def jobInfoCollection = mongoDataBase.getCollection(jobInfoCollectionName)
		def sampleJobInfoJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfo.txt")
		def sampleJobInfoBufferedReader = new BufferedReader(new InputStreamReader(sampleJobInfoJsonStream));
		def sampleRecordLine = sampleJobInfoBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			println("db object" + dbObject)
			jobInfoCollection.insertOne(dbObject)
			jobId = dbObject.get("_id").toHexString()
			sampleRecordLine = sampleJobInfoBufferedReader.readLine();
		}

		//insert the templates
		def mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		def sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleCaseTemplate.txt")
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			println("template sample to be inserted : " + sampleRecordLine)
			def dbObject = Document.parse(sampleRecordLine)
			println("template db object" + dbObject)
			mongoTemplateCollection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}

		//Build the SalesForceStepWorkflowConfig
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/SalesForceStepWorkflowConfig.json")
		println("Sales force step config Json Stream: " + jsonStream)
		def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		def salesForceStepWorkflowrConfig = object.stepConfig;
		println("Sales force step config: " + salesForceStepWorkflowrConfig)

		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [
			salesForceStepWorkflowrConfig
		]

		def userDetailsMessage = "Test error message raised for sales force step test."

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		//build the Error Details to be emitted
		//build the supporting data
		def supportingData = new HashMap();
		supportingData.put(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY, activityName);
		supportingData.put(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY, sourceACollection);
		supportingData.put(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY, sourceBCollection);

		def errorDetails = ErrorDetails.builder()
				.userDetails(userDetailsMessage)
				.severity(Severity.FATAL)
				.additionalData(supportingData)
				.errorDetail(new TestException("Test error occured. Test sales force step."))
				.build();

		//mock the case response
		def caseId = "case2"
		def childCaseId = "case3"
		def accessToken = "abcd12345"

		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();

		salesforceCaseHelper.authenticate() >> {
			salesForceAuthResponse;
		}
		def caseDesciption = ""
		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("salesForceCase").getEmitter()
		emitter.emit(messageFactory.createMessage(errorDetails))
		emitter.emit(messageFactory.createEndMessage())
		def jobResult = result.get()
		then:
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			def referenceId1 = arguments[0].records[0].referenceId
			def childCaseRefId = arguments[0].records[0].childcases[0].referenceId
			caseDesciption = arguments[0].records[0].childcases[0].description
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId(caseId).caseNumber("1").referenceId(referenceId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId(childCaseId).caseNumber("2").referenceId(childCaseRefId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build()
			]

			def successList = new ArrayList(successListSalesforceCaseDetails)

			return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}
		noExceptionThrown()
		def receiver = localJobTaskExecutor.getOutBoundQueue("salesForceCase").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 1
		def receivedErrorDetails = receivedData.get(0)
		//As per new modification if for FATAL block we removed- So, as discussed commenting below 2 lines Jira OPTIMUS-1563
		//			receivedErrorDetails.getCaseId() != null
		//			receivedErrorDetails.getCaseId() == caseId
		caseDesciption != ""
		caseDesciption.startsWith("A FATAL error occurred in  " + activityName)
		cleanup:
		mongo.close();
	}

	def "Sales force case creation Step Execution - ETL - FATAL"() {
		setup:
		//set up embedded mongo
		def dbHostIP = mongoHost
		def dbPort = mongoPort
		def databaseName = "local";
		def collectionName = "JobErrorDetails";
		def jobResultCollectionName = "JobResult"
		def jobInfoCollectionName = "JobInfo"
		def jobId = "errorJob3"
		def caseDesciption = ""
		def workflowName = "TestEtlError"
		def caseTemplateCollection = "ReconCaseTemplate"

		def mongo = new MongoClient(dbHostIP, dbPort);
		def mongoDataBase = mongo.getDatabase(databaseName);

		//insert sample job info
		def jobInfoCollection = mongoDataBase.getCollection(jobInfoCollectionName)
		def sampleJobInfoJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfoEtl.txt")
		def sampleJobInfoBufferedReader = new BufferedReader(new InputStreamReader(sampleJobInfoJsonStream));
		def sampleRecordLine = sampleJobInfoBufferedReader.readLine();
		while (sampleRecordLine != null) {
			def dbObject = Document.parse(sampleRecordLine)
			println("db object" + dbObject)
			jobInfoCollection.insertOne(dbObject)
			jobId = dbObject.get("_id").toHexString()
			sampleRecordLine = sampleJobInfoBufferedReader.readLine();
		}
		
		// Insert MongoDB template
		def mongoTemplateCollection = mongoDataBase.getCollection(caseTemplateCollection)
		def sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleCaseTemplate.txt")
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			println("template sample to be inserted : " + sampleRecordLine)
			def dbObject = Document.parse(sampleRecordLine)
			println("template db object" + dbObject)
			mongoTemplateCollection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}

		//Build the SalesForceStepWorkflowConfig
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/SalesForceStepWorkflowConfig.json")
		println("Sales force step config Json Stream: " + jsonStream)
		def object = mapper.readValue(jsonStream, TestWorkflowConfig.class)
		def salesForceStepWorkflowrConfig = object.stepConfig;
		println("Sales force step config: " + salesForceStepWorkflowrConfig)

		def workflowConfig = new WorkflowConfig()
		workflowConfig.stepConfigs = [
			salesForceStepWorkflowrConfig
		]

		def userDetailsMessage = "Test error message raised for sales force step test."

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_3", workflowConfig, new WorkflowExecutionConfig())
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		//build the Error Details to be emitted
		def errorDetails = ErrorDetails.builder()
				.userDetails(userDetailsMessage)
				.severity(Severity.FATAL)
				.errorDetail(new TestException("Test error occured. Test sales force step."))
				.build();

		//mock the case response
		def caseId = "case1"
		def childCaseId = "case3"
		def accessToken = "abcd1234"

		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();

		salesforceCaseHelper.authenticate() >> {
			salesForceAuthResponse
		}
		
		def sourceReference = FileSourceReference.builder().fileName("test.txt").rowIndex(1).rawRecordData("test line for case").build();
		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue("salesForceCase").getEmitter()
		emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails, sourceReference))
		emitter.emit(messageFactory.createEndMessage())
		def jobResult = result.get()
		then:
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			def referenceId1 = arguments[0].records[0].referenceId
			def childCaseRefId = arguments[0].records[0].childcases[0].referenceId
			caseDesciption = arguments[0].records[0].childcases[0].description
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId(caseId).caseNumber("1").referenceId(referenceId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId(childCaseId).caseNumber("2").referenceId(childCaseRefId).caseDetailUrl("https://salesforce.com/test/Case/1/view").build()
			]

			def successList = new ArrayList(successListSalesforceCaseDetails)

			return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}
		noExceptionThrown()
		def receiver = localJobTaskExecutor.getOutBoundQueue("salesForceCase").get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 1
		def receivedErrorDetails = receivedData.get(0)
		//As per new modification if for FATAL block we removed- So, as discussed commenting below 2 lines Jira OPTIMUS-1563
		//		receivedErrorDetails.getCaseId() != null
		//		receivedErrorDetails.getCaseId() == caseId
		caseDesciption != ""
		caseDesciption.startsWith("A FATAL error occurred in  ")
		cleanup:
		mongo.close();
	}
}
