package com.opus.optimus.offline.runtime.exception.test

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

import org.bson.Document
import org.junit.Test
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.context.ContextConfiguration
import org.springframework.web.client.RestTemplate

import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.CaseCreation
import com.opus.optimus.offline.config.casemanagement.Priority
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceBulkCaseRequest
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails
import com.opus.optimus.offline.runtime.workflow.exception.Severity
import com.opus.optimus.offline.runtime.workflow.test.TestWorkflowConfig

import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import spock.lang.Ignore
import spock.lang.Specification

@Ignore
@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class CaseCreateTestSpecification extends Specification {

	@SpringBean(name = "restTemplate")
	RestTemplate restTemplate = Mock()
	
	@Autowired
	SalesforceCaseHelper salesForceCaseHelper
	
	@SpringBean
	JobErrorDetailsRepository jobErrorDetailsRepository = Mock()
	
	def "Single case create - One Master-MultiChild cases - Success"(){
		given:
			def referenceId1 = "ref1"
			def referenceId2 = "ref2"
			def token = "testtoken123"
			
			//requests
			def childCases = [
				SalesforceCaseRequest.builder().referenceId(referenceId1).status("New").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build(),
				SalesforceCaseRequest.builder().referenceId(referenceId2).status("New").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build()
			]
			
			def parentCaseRequest = SalesforceCaseRequest.builder().referenceId("parentRef").status("New").project("testProject")
				.systemErrorType(Severity.ERROR).origin("junit").activity("testActivity").subject("test")
				.childcases(new ArrayList(childCases)).build()
			//mock response
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").referenceId(referenceId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId("case2").caseNumber("2").referenceId(referenceId2).caseDetailUrl("https://salesforce.com/test/Case/2/view").build(),
			]
		
			def successList = new ArrayList(successListSalesforceCaseDetails)
			
			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		
			restTemplate.postForEntity(_, _, SalesforceCaseResponse.class) >> {
				new ResponseEntity(salesForceResponse, HttpStatus.OK);
			}
		when:
			def singleCaseCreateResponse = salesForceCaseHelper.createCase(parentCaseRequest, token)
		then:
			singleCaseCreateResponse.hasError == false
			singleCaseCreateResponse.getSuccessList() != null
			singleCaseCreateResponse.getSuccessList().each { casedetails ->
				assert casedetails.getCaseId() != null
				assert casedetails.getReferenceId() != null
			}
	}
	
	def "Bulk case create - One Master-MultiChild cases - Success"(){
		given:
			def referenceId1 = "ref1"
			def referenceId2 = "ref2"
			def token = "testtoken123"
			
			//requests
			def childCases = [
				SalesforceCaseRequest.builder().referenceId(referenceId1).status("New").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build(),
				SalesforceCaseRequest.builder().referenceId(referenceId2).status("New").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build()
			]
			
			def parentCase = SalesforceCaseRequest.builder().referenceId("parentRef").status("New").project("testProject")
				.systemErrorType(Severity.ERROR).origin("junit").activity("testActivity").subject("test")
				.childcases(new ArrayList(childCases)).build()
			
			def bulkCreateRequest = SalesforceBulkCaseRequest.builder().records(new ArrayList([parentCase])).build()
			
			//mock response
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").referenceId(referenceId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId("case2").caseNumber("2").referenceId(referenceId2).caseDetailUrl("https://salesforce.com/test/Case/2/view").build(),
			]
		
			def successList = new ArrayList(successListSalesforceCaseDetails)
			
			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		
			restTemplate.postForEntity(_, _, SalesforceCaseResponse.class) >> {
				new ResponseEntity(salesForceResponse, HttpStatus.OK);
			}
		when:
			def bulkCreateResponse = salesForceCaseHelper.bulkCreate(bulkCreateRequest, token)
		then:
			bulkCreateResponse.hasError == false
			bulkCreateResponse.getSuccessList() != null
			bulkCreateResponse.getSuccessList().each { casedetails ->
				assert casedetails.getCaseId() != null
				assert casedetails.getReferenceId() != null
			}
	}
	
	def "Single case update - One Master-MultiChild cases - Success"(){
		given:
			def caseId1 = "case1"
			def caseId2 = "case2"
			def token = "testtoken123"
			
			//requests
			def childCases = [
				SalesforceCaseRequest.builder().caseId(caseId1).status("Closed").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build(),
				SalesforceCaseRequest.builder().caseId(caseId2).status("Closed").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build()
			]
			
			def parentCaseRequest = SalesforceCaseRequest.builder().caseId("parentCase").status("Closed").project("testProject")
				.systemErrorType(Severity.ERROR).origin("junit").activity("testActivity").subject("test")
				.childcases(new ArrayList(childCases)).build()
			//mock response
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId("case2").caseNumber("2").caseDetailUrl("https://salesforce.com/test/Case/2/view").build(),
			]
		
			def successList = new ArrayList(successListSalesforceCaseDetails)
			
			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		
			restTemplate.patchForObject(_, _, SalesforceCaseResponse.class) >> {
				return salesForceResponse;
			}
		when:
			def singleUpdateResponse = salesForceCaseHelper.updateCase(parentCaseRequest, token)
		then:
			singleUpdateResponse.hasError == false
			singleUpdateResponse.getSuccessList() != null
			singleUpdateResponse.getSuccessList().each { casedetails ->
				assert casedetails.getCaseId() != null
			}
	}
	
	def "Bulk case update - One Master-MultiChild cases - Success"(){
		given:
			def caseId1 = "case1"
			def caseId2 = "case2"
			def token = "testtoken123"
			
			//requests
			def childCases = [
				SalesforceCaseRequest.builder().caseId(caseId1).status("Closed").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build(),
				SalesforceCaseRequest.builder().caseId(caseId2).status("Closed").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build()
			]
			
			def parentCaseRequest = SalesforceCaseRequest.builder().caseId("parentCase").status("Closed").project("testProject")
				.systemErrorType(Severity.ERROR).origin("junit").activity("testActivity").subject("test")
				.childcases(new ArrayList(childCases)).build()
				
			def bulkUpdateRequest = SalesforceBulkCaseRequest.builder().records(new ArrayList([parentCaseRequest])).build()
			//mock response
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId("case2").caseNumber("2").caseDetailUrl("https://salesforce.com/test/Case/2/view").build(),
			]
		
			def successList = new ArrayList(successListSalesforceCaseDetails)
			
			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		
			restTemplate.patchForObject(_, _, SalesforceCaseResponse.class) >> {
				return salesForceResponse;
			}
		when:
			def bulkUpdateResponse = salesForceCaseHelper.bulkUpdate(bulkUpdateRequest, token)
		then:
			bulkUpdateResponse.hasError == false
			bulkUpdateResponse.getSuccessList() != null
			bulkUpdateResponse.getSuccessList().each { casedetails ->
				assert casedetails.getCaseId() != null
			}
	}
	
	def "Bulk case create - No auth token - Fail"(){
		given:
			def referenceId1 = "ref1"
			def referenceId2 = "ref2"
			def token = ""
			
			//requests
			def childCases = [
				SalesforceCaseRequest.builder().referenceId(referenceId1).status("New").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build(),
				SalesforceCaseRequest.builder().referenceId(referenceId2).status("New").systemErrorType(Severity.ERROR)
					.origin("junit").activity("testActivity").subject("test").build()
			]
			
			def parentCase = SalesforceCaseRequest.builder().referenceId("parentRef").status("New").project("testProject")
				.systemErrorType(Severity.ERROR).origin("junit").activity("testActivity").subject("test")
				.childcases(new ArrayList(childCases)).build()
			
			def bulkCreateRequest = SalesforceBulkCaseRequest.builder().records(new ArrayList([parentCase])).build()
			
			//mock response
			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").referenceId(referenceId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId("case2").caseNumber("2").referenceId(referenceId2).caseDetailUrl("https://salesforce.com/test/Case/2/view").build(),
			]
		
			def successList = new ArrayList(successListSalesforceCaseDetails)
			
			def salesForceResponse = SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		
			restTemplate.postForEntity(_, _, SalesforceCaseResponse.class) >> {
				new ResponseEntity(salesForceResponse, HttpStatus.OK);
			}
		when:
			def bulkCreateResponse = salesForceCaseHelper.bulkCreate(bulkCreateRequest, token)
		then:
			bulkCreateResponse.hasError == true
	}
	
	def "Bulk case create - Authenticate - Success"(){
		given:
			def authId = "auth1"
			def accessToken = "testtoken123"
			
			//requests
			
			//mock response
			def salesForceResponse = SalesforceAuthenticateResponse.builder().id(authId).tokenType("Bearer")
					.instanceUrl("https://salesforce.com/test/").accessToken(accessToken).build()
		
			restTemplate.postForEntity(_, _, SalesforceAuthenticateResponse.class) >> {
				new ResponseEntity(salesForceResponse, HttpStatus.OK);
			}
		when:
			def authResponse = salesForceCaseHelper.authenticate()
		then:
			authResponse.getTokenType() == "Bearer"
			authResponse.getAccessToken() != null
			authResponse.getAccessToken() == accessToken
	}
}
