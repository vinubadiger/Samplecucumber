package com.opus.optimus.offline.runtime.exception.test;

public class TestException extends Exception {
	public TestException(String message) {
		super(message);
	}
}
