package com.opus.optimus.offline.runtime.exception.test

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

import org.bson.Document
import org.junit.Test
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.MongoCollection
import com.opus.optimus.offline.config.casemanagement.CaseCreation
import com.opus.optimus.offline.config.casemanagement.Priority
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceBulkCaseRequest
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.OperationStatus
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutor
import com.opus.optimus.offline.runtime.workflow.api.impl.StepInstanceExecutorCreatorFactory
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails
import com.opus.optimus.offline.runtime.workflow.exception.Severity
import com.opus.optimus.offline.runtime.workflow.test.TestWorkflowConfig

import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.IMongodConfig
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import spock.lang.Ignore
import spock.lang.Specification

@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class SalesForceIntegrationTestSpecification extends Specification {

	@Autowired
	SalesforceCaseHelper salesForceCaseHelper
	
	@SpringBean
	JobErrorDetailsRepository jobErrorDetailsRepository = Mock()
	
	def "Single case CREATE and CLOSE - One Master-MultiChild cases - Success"(){
		given:
			def referenceId = UUID.randomUUID().toString()
			def token = ""
			def caseId = ""
			def parentCaseRequest = SalesforceCaseRequest.builder().referenceId(referenceId).status(CaseStatus.OPEN.name()).project("testProject")
				.systemErrorType(Severity.ERROR).origin("Recon").activity("testActivity").subject("test")
				.priority(Priority.MEDIUM).contactName("").contactSkypeName("").description("Running the Junit test case.")
				.childcases(Collections.EMPTY_LIST).caseId("").reasonCode("").comment("").build()
		when:
			def authResponse = salesForceCaseHelper.authenticate()
		then:
			authResponse != null
			authResponse.getAccessToken() != null
		when:
			token = authResponse.getAccessToken()
			def singleCaseCreateResponse = salesForceCaseHelper.createCase(parentCaseRequest, token)
		then:
			singleCaseCreateResponse != null
			singleCaseCreateResponse.isHasError() == false
			singleCaseCreateResponse.getErrorList().isEmpty() == true
			singleCaseCreateResponse.getSuccessList().size() != 0
			singleCaseCreateResponse.getSuccessList().each { caseDetails ->
				assert caseDetails.getCaseId() != null
			}
		when:
			caseId = singleCaseCreateResponse.getSuccessList().get(0).getCaseId()
			referenceId = UUID.randomUUID().toString()
			def parentCaseUpdateRequest = SalesforceCaseRequest.builder().referenceId(referenceId).status(CaseStatus.CLOSED.name()).caseId(caseId).build()
			def singleCaseUpdateResponse = salesForceCaseHelper.updateCase(parentCaseUpdateRequest, token)
		then:
			singleCaseUpdateResponse != null
			singleCaseUpdateResponse.isHasError() == false
			singleCaseUpdateResponse.getErrorList().isEmpty() == true
			singleCaseUpdateResponse.getSuccessList().size() != 0
			singleCaseUpdateResponse.getSuccessList().each { caseDetails ->
				assert caseDetails.getCaseId() != null
			}
	}
}
