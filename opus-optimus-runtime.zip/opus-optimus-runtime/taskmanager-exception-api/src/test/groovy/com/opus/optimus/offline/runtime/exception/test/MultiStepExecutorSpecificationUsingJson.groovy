package com.opus.optimus.offline.runtime.exception.test

import java.util.concurrent.TimeoutException

import org.bson.Document
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.context.ContextConfiguration

import com.mongodb.MongoClient
import com.mongodb.client.FindIterable
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse
import com.opus.optimus.offline.config.datasource.MongoDataSource
import com.opus.optimus.offline.config.datasource.MongoDataSourceMeta
import com.opus.optimus.offline.exception.configuration.TestGlobalExceptionHandlingConfiguration
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper
import com.opus.optimus.offline.runtime.taskmanager.mongo.impl.PublishedWorkflowConfigService
import com.opus.optimus.offline.runtime.taskmanager.mongo.repository.WorkflowConfigRepository
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil

import spock.lang.Specification
/**
 * Test case for case creation related to ETL jobs , Error Type 
 * 
 * @author Yashkumar.Thakur
 *
 */
@ContextConfiguration(classes = TestGlobalExceptionHandlingConfiguration.class)
class MultiStepExecutorSpecificationUsingJson extends Specification {

	@Autowired
	LocalJobTaskExecutorBuilder executorBuilder

	@Autowired
	IMessageFactory messageFactory

	@Autowired
	DataSourceFactory dataSourceFactory;

	@Autowired
	MapperFactory mapperFactory

	@Autowired
	String mongoHost;

	@Autowired
	Integer mongoPort;

	@Autowired
	PublishedWorkflowConfigService publishedWorkflowConfigService;

	@SpringBean
	SalesforceCaseHelper salesforceCaseHelper = Mock()


	def "Reader Exception With Record processing exception - Writter multistep execution using JSON"() {
		setup:
		def databaseName = "local";
		def collectionName = "samson";
		def jobId="RDWRJSON_JOB"
		def templateCollection = "PublishedService"
		def templateCollection_Institution = "Institution"
		def referenceId1 = "ref1"
		def referenceId2 = "ref2"
		def childCaseRefId1 = ""
		def childCaseReasonCode1 = ""
		def childCaseRefId2 = ""
		def childCaseReasonCode2 = ""
		def NoOfErrorCont= ""
		def DelimitedReader = "DelimitedReader"
		def MongoDBWriter = "MongoDBWriter"
		def caseTemplateCollection = "ReconCaseTemplate"

		MongoClient mongo = new MongoClient(mongoHost, mongoPort);
		MongoDatabase mongoDataBase = mongo.getDatabase(databaseName);
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		mongoDataSource.init();
		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

		//insert the templates
		def mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		def sampleDataJsonStream = getClass().getResourceAsStream("/defaultWorkflowConf.json") //global handler
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		println("template sample to be inserted : " + sampleRecordLine)
		def dbObject = Document.parse(sampleRecordLine)
		println("template db object" + dbObject)
		mongoTemplateCollection.insertOne(dbObject)

		//insert sample Institution
		def InstitutionCollection = mongoDataBase.getCollection(templateCollection_Institution)
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/Institution.json")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		dbObject = Document.parse(sampleRecordLine)
		println("db object" + dbObject)
		InstitutionCollection.insertOne(dbObject)
		sampleRecordLine = sampleRecordBufferedReader.readLine();

		//insert the templates
		mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		sampleDataJsonStream = getClass().getResourceAsStream("/MultiStepJson.json") //workflow handler
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		println("template sample to be inserted : " + sampleRecordLine)
		dbObject = Document.parse(sampleRecordLine)
		println("template db object" + dbObject)
		mongoTemplateCollection.insertOne(dbObject)
		def groupId =dbObject.get("_id").toHexString();
		println("Id of workflow : "+groupId);

		//insert sample job info
		def jobInfoCollection = mongoDataBase.getCollection("JobInfo")
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfoEtlCaseCreation.json")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		dbObject = Document.parse(sampleRecordLine)
		println("db object" + dbObject)
		jobInfoCollection.insertOne(dbObject)
		jobId = dbObject.get("_id").toHexString();
		sampleRecordLine = sampleRecordBufferedReader.readLine();

		// Insert MongoDB template
		mongoTemplateCollection = mongoDataBase.getCollection(caseTemplateCollection)
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleCaseTemplate.txt")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			println("template sample to be inserted : " + sampleRecordLine)
			dbObject = Document.parse(sampleRecordLine)
			println("template db object" + dbObject)
			mongoTemplateCollection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1",new JobConfig("default","defaultInMemoryGlobalErrorWorkflow"), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		println(getClass().getResource("/testFile.csv").getFile())
		String inputFileLocation = "./src/test/resources/testFile.csv";


		// Mocking response object
		def accessToken = "Ykcd1234"
		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();
		salesforceCaseHelper.authenticate() >> {
			return salesForceAuthResponse;
		}

		def childCaseDesciption = ""
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			NoOfErrorCont = arguments[0].records[0].errorCounts
			// For 1st child
			childCaseRefId1 = arguments[0].records[0].childcases[0].referenceId
			childCaseReasonCode1 = arguments[0].records[0].childcases[0].reasonCode
			println("Child case refid :"+childCaseRefId1+" Reson Code : "+childCaseReasonCode1)
			// For second Child
			childCaseRefId2 = arguments[0].records[0].childcases[1].referenceId
			childCaseReasonCode2 = arguments[0].records[0].childcases[1].reasonCode
			println("Child case refid :"+childCaseRefId2+" Reson Code : "+childCaseReasonCode2)

			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").referenceId(childCaseRefId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
				SalesforceCaseDetails.builder().caseId("case2").caseNumber("2").referenceId(childCaseRefId2).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
			]
			def successList = new ArrayList(successListSalesforceCaseDetails);
			return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(DelimitedReader).getEmitter()
		emitter.emit(messageFactory.createMessage(inputFileLocation))
		emitter.end(messageFactory.createEndMessage()) // Need to remove
		def jobTaskExecutorResult = result.get()

		then:
		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriter).get(1).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 8

		//Check dumped data in mongoDB
		MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
		Document searchDocument = new Document();
		searchDocument.append("second", 4l);
		println("Document Filter: " + searchDocument);
		Document searchResult = resultCollection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		searchResult != null
		// Get total count of records
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()

		// Assertion for case creation request
		childCaseRefId1 != null;
		childCaseRefId1 != null;
		childCaseReasonCode2 != null
		childCaseReasonCode2 != null
		NoOfErrorCont == 2

		println jobTaskExecutorResult

		cleanup:
		if (mongo != null)
			mongoDataBase.drop()
		mongo.close()
	}


	def "Reader Exception - Writter multistep execution using JSON"() {
		setup:
		def databaseName = "local";
		def collectionName = "samson";
		def jobId="RDWRJSON_JOB"
		def templateCollection = "PublishedService"
		def templateCollection_Institution = "Institution"
		def referenceId1 = "ref1"
		def childCaseRefId1 = ""
		def childCaseReasonCode1 = ""
		def NoOfErrorCont= ""
		def DelimitedReader = "DelimitedReader"
		def MongoDBWriter = "MongoDBWriter"
		def caseTemplateCollection = "ReconCaseTemplate"

		MongoClient mongo = new MongoClient(mongoHost, mongoPort);
		MongoDatabase mongoDataBase = mongo.getDatabase(databaseName);
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		mongoDataSource.init();
		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

		//insert the templates
		def mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		def sampleDataJsonStream = getClass().getResourceAsStream("/defaultWorkflowConf.json") //global handler
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		println("template sample to be inserted : " + sampleRecordLine)
		def dbObject = Document.parse(sampleRecordLine)
		println("template db object" + dbObject)
		mongoTemplateCollection.insertOne(dbObject)

		//insert sample Institution
		def InstitutionCollection = mongoDataBase.getCollection(templateCollection_Institution)
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/Institution.json")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		dbObject = Document.parse(sampleRecordLine)
		println("db object" + dbObject)
		InstitutionCollection.insertOne(dbObject)
		sampleRecordLine = sampleRecordBufferedReader.readLine();

		//insert the templates
		mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		sampleDataJsonStream = getClass().getResourceAsStream("/MultiStepJson.json") //workflow handler
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		println("template sample to be inserted : " + sampleRecordLine)
		dbObject = Document.parse(sampleRecordLine)
		println("template db object" + dbObject)
		mongoTemplateCollection.insertOne(dbObject)
		def groupId =dbObject.get("_id").toHexString();
		println("Id of workflow : "+groupId);

		//insert sample job info
		def jobInfoCollection = mongoDataBase.getCollection("JobInfo")
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfoEtlCaseCreation.json")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		dbObject = Document.parse(sampleRecordLine)
		println("db object" + dbObject)
		jobInfoCollection.insertOne(dbObject)
		jobId = dbObject.get("_id").toHexString();
		sampleRecordLine = sampleRecordBufferedReader.readLine();

		// Insert MongoDB template
		mongoTemplateCollection = mongoDataBase.getCollection(caseTemplateCollection)
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleCaseTemplate.txt")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			println("template sample to be inserted : " + sampleRecordLine)
			dbObject = Document.parse(sampleRecordLine)
			println("template db object" + dbObject)
			mongoTemplateCollection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1",new JobConfig("default","defaultInMemoryGlobalErrorWorkflow"), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		println(getClass().getResource("/testFileRE.csv").getFile())
		String inputFileLocation = "./src/test/resources/testFileRE.csv";


		// Mocking response object
		def accessToken = "Ykcd1234"
		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();
		salesforceCaseHelper.authenticate() >> {
			return salesForceAuthResponse
		}

		def childCaseDesciption = ""
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			NoOfErrorCont = arguments[0].records[0].errorCounts
			// For 1st child
			childCaseRefId1 = arguments[0].records[0].childcases[0].referenceId
			childCaseReasonCode1 = arguments[0].records[0].childcases[0].reasonCode
			println("Child case refid :"+childCaseRefId1+" Reson Code : "+childCaseReasonCode1)

			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").referenceId(childCaseRefId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
			]
			def successList = new ArrayList(successListSalesforceCaseDetails);
			return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(DelimitedReader).getEmitter()
		emitter.emit(messageFactory.createMessage(inputFileLocation))
		emitter.end(messageFactory.createEndMessage()) // Need to remove
		def jobTaskExecutorResult = result.get()

		then:
		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriter).get(1).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 8

		//Check dumped data in mongoDB
		MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
		Document searchDocument = new Document();
		searchDocument.append("second", 4l);
		println("Document Filter: " + searchDocument);
		Document searchResult = resultCollection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		searchResult != null
		// Get total count of records
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()

		// Assertion for case creation request
		childCaseRefId1 != null;
		childCaseReasonCode1 != null;
		childCaseReasonCode1.startsWith(ExceptionCodes.CASE_REASON_CODE.get("RDR-DAT-002"))
		NoOfErrorCont == 1

		println jobTaskExecutorResult

		cleanup:
		if (mongo != null)
			mongoDataBase.drop()
		mongo.close()
	}


	def "Record processing exception - Writter multistep execution using JSON"() {
		setup:
		def databaseName = "local";
		def collectionName = "samson";
		def jobId="RDWRJSON_JOB"
		def templateCollection = "PublishedService"
		def templateCollection_Institution = "Institution"
		def referenceId1 = "ref1"
		def childCaseRefId1 = ""
		def childCaseReasonCode1 = ""
		def NoOfErrorCont= ""
		def DelimitedReader = "DelimitedReader"
		def MongoDBWriter = "MongoDBWriter"
		def caseTemplateCollection = "ReconCaseTemplate"

		MongoClient mongo = new MongoClient(mongoHost, mongoPort);
		MongoDatabase mongoDataBase = mongo.getDatabase(databaseName);
		def mapper = mapperFactory.getMapper()
		def jsonStream = getClass().getResourceAsStream("/MongoDBDataSourceMetaData.json")
		def mongoDbDataSourceMetaData = mapper.readValue(jsonStream, MongoDataSourceMeta.class)

		//change the dynamic port with meta data.
		mongoDbDataSourceMetaData.addressMetadatas.stream().each { addressMeta ->
			addressMeta.setPort(mongoPort)
		}

		def mongoDataSource = new MongoDataSource(mongoDbDataSourceMetaData);
		mongoDataSource.init();
		dataSourceFactory.register("samsonMongoDataSource", mongoDataSource);

		//insert the templates
		def mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		def sampleDataJsonStream = getClass().getResourceAsStream("/defaultWorkflowConf.json") //global handler
		def sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		def sampleRecordLine = sampleRecordBufferedReader.readLine();
		println("template sample to be inserted : " + sampleRecordLine)
		def dbObject = Document.parse(sampleRecordLine)
		println("template db object" + dbObject)
		mongoTemplateCollection.insertOne(dbObject)

		//insert sample Institution
		def InstitutionCollection = mongoDataBase.getCollection(templateCollection_Institution)
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/Institution.json")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		dbObject = Document.parse(sampleRecordLine)
		println("db object" + dbObject)
		InstitutionCollection.insertOne(dbObject)
		sampleRecordLine = sampleRecordBufferedReader.readLine();

		//insert the templates
		mongoTemplateCollection = mongoDataBase.getCollection(templateCollection)
		sampleDataJsonStream = getClass().getResourceAsStream("/MultiStepJson.json") //workflow handler
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		println("template sample to be inserted : " + sampleRecordLine)
		dbObject = Document.parse(sampleRecordLine)
		println("template db object" + dbObject)
		mongoTemplateCollection.insertOne(dbObject)
		def groupId =dbObject.get("_id").toHexString();
		println("Id of workflow : "+groupId);

		//insert sample job info
		def jobInfoCollection = mongoDataBase.getCollection("JobInfo")
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleJobInfoEtlCaseCreation.json")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		dbObject = Document.parse(sampleRecordLine)
		println("db object" + dbObject)
		jobInfoCollection.insertOne(dbObject)
		jobId = dbObject.get("_id").toHexString();
		sampleRecordLine = sampleRecordBufferedReader.readLine();

		// Insert MongoDB template
		mongoTemplateCollection = mongoDataBase.getCollection(caseTemplateCollection)
		sampleDataJsonStream = getClass().getResourceAsStream("/testdata/sampleCaseTemplate.txt")
		sampleRecordBufferedReader = new BufferedReader(new InputStreamReader(sampleDataJsonStream));
		sampleRecordLine = sampleRecordBufferedReader.readLine();
		while (sampleRecordLine != null) {
			println("template sample to be inserted : " + sampleRecordLine)
			dbObject = Document.parse(sampleRecordLine)
			println("template db object" + dbObject)
			mongoTemplateCollection.insertOne(dbObject)
			sampleRecordLine = sampleRecordBufferedReader.readLine();
		}

		def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_1",new JobConfig("default","defaultInMemoryGlobalErrorWorkflow"), new WorkflowConfigRepository(groupId, publishedWorkflowConfigService))
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		println(getClass().getResource("/testFileRPE.csv").getFile())
		String inputFileLocation = "./src/test/resources/testFileRPE.csv";


		// Mocking response object
		def accessToken = "Ykcd1234"
		def salesForceAuthResponse = SalesforceAuthenticateResponse.builder().accessToken(accessToken).build();
		salesforceCaseHelper.authenticate() >> {
			salesForceAuthResponse;
		}

		def childCaseDesciption = ""
		_ * salesforceCaseHelper.bulkCreate(_, _) >> {arguments ->
			NoOfErrorCont = arguments[0].records[0].errorCounts
			// For 1st child
			childCaseRefId1 = arguments[0].records[0].childcases[0].referenceId
			childCaseReasonCode1 = arguments[0].records[0].childcases[0].reasonCode
			println("Child case refid :"+childCaseRefId1+" Reson Code : "+childCaseReasonCode1)

			def successListSalesforceCaseDetails = [
				SalesforceCaseDetails.builder().caseId("case1").caseNumber("1").referenceId(childCaseRefId1).caseDetailUrl("https://salesforce.com/test/Case/1/view").build(),
			]
			def successList = new ArrayList(successListSalesforceCaseDetails);
			return SalesforceCaseResponse.builder().hasError(false).successList(successList).build();
		}

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(DelimitedReader).getEmitter()
		emitter.emit(messageFactory.createMessage(inputFileLocation))
		emitter.end(messageFactory.createEndMessage()) // Need to remove
		def jobTaskExecutorResult = result.get()

		then:
		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue(MongoDBWriter).get(1).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 8

		//Check dumped data in mongoDB
		MongoCollection<Document> resultCollection = mongoDataBase.getCollection(collectionName);
		Document searchDocument = new Document();
		searchDocument.append("second", 4l);
		println("Document Filter: " + searchDocument);
		Document searchResult = resultCollection.find(searchDocument).first();
		println("Document Found: " + searchResult);
		searchResult != null
		// Get total count of records
		Document searchCurrJobDocument = new Document();
		searchCurrJobDocument.append("_jobId", jobId);
		FindIterable<Document> currJobDocuments = resultCollection.find(searchCurrJobDocument)
		receivedData.size() == currJobDocuments.size()

		// Assertion for case creation request
		childCaseRefId1 != null;
		childCaseReasonCode1 != null;
		childCaseReasonCode1.startsWith("General Exception occured during Validator Execution !")
		NoOfErrorCont == 1

		println jobTaskExecutorResult

		cleanup:
		if (mongo != null)
			mongoDataBase.drop()
		mongo.close()
	}

}