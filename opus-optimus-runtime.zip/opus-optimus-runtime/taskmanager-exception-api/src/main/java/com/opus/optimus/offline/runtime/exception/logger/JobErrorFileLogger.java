package com.opus.optimus.offline.runtime.exception.logger;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;

/**
 * This is file logger for the exceptions occurred while processing the job. In case of Data ingestion, this logger will log the error records to the
 * file.
 */
/**
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
@Component
public class JobErrorFileLogger {

	@Value ("${errorlogfile.location}")
	public String errorLogFileLocation;

	private static final Logger logger = LoggerFactory.getLogger(JobErrorFileLogger.class);
	private static final String ERROR_FILENAME_TRAILER_TIME_FORMAT = "MM.dd.YYYY.hh.mm.ss";
	private static final String ERROR_FILE_NAME_TRAILER = "_Errored_Records_";
	private static final String ERROR_FILE_EXTENSION = ".txt";
	private static final int FILE_WRITE_BATCH_SIZE = 1024;
	private Map<String, ErrorFileWriter> jobWriters = Collections.synchronizedMap(new HashMap<>());

	/**
	 * Inner class to handle file writing scenario
	 */
	private class ErrorFileWriter {
		private Path filePath;
		private String fileLoaction;
		private List<ErrorRecord> records = new ArrayList<>();
		private int count = 0;

		public ErrorFileWriter(String errorFileLocation) {
			super();
			this.fileLoaction = errorFileLocation;
			this.filePath = Paths.get(errorFileLocation);
		}

		/**
		 * Method to increase count of error row record and check for file write batch size
		 * 
		 * @param record : Error record
		 * @throws IOException
		 */
		public synchronized void write(final ErrorRecord record) throws IOException {
			count++;
			this.records.add(record);
			// check if batch threshold reaches and if yes, flush the records.
			if (records.size() >= FILE_WRITE_BATCH_SIZE){
				flushRecords();
				this.records.clear();
			}
		}

		/**
		 * Flush the record bucket and write the errors in file.
		 * 
		 * @throws IOException
		 */
		public void flushRecords() throws IOException {
			final List<String> lines = records.stream().map(ErrorRecord::getErrorRecordLine).collect(Collectors.toList());
			Files.write(this.filePath, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
		}

		/**
		 * Gives file location path
		 * 
		 * @return : File Location path
		 */
		public String getFileLocation() {
			return this.fileLoaction;
		}

		public int getCount() {
			return count;
		}
	}

	/**
	 * Method to build the file location for logging errors. In case of File type - <Original_File_Name>_Errored_Records_DateTimeStamp and in case of
	 * DB type - <Database_name>_Errored_Records_DataTimeStamp
	 * 
	 * @param sourceReference
	 * @return - The file location as per the source reference provided
	 */
	public String getAbsoluteFilePath(ISourceReference sourceReference) {
		final StringBuilder fileName = new StringBuilder();
		if (sourceReference == null){
			logger.error("No file location can be build. Invalid source reference. Expected: {} or {}, Actual: Null", FileSourceReference.class.getName(), DBSourceReference.class.getName());
			return null;
		} else if (FileSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			return fileName.append(errorLogFileLocation).append(getFileName(sourceReference)).append(ERROR_FILE_NAME_TRAILER).append(buildCurrentTimestamp()).append(ERROR_FILE_EXTENSION).toString();
		} else if (DBSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			return fileName.append(errorLogFileLocation).append(((DBSourceReference) sourceReference).getDataSourceName()).append(ERROR_FILE_NAME_TRAILER).append(buildCurrentTimestamp()).append(ERROR_FILE_EXTENSION).toString();
		} else{
			logger.error("No file location can be build. Invalid source reference. Expected: {} or {}, Actual: {}", FileSourceReference.class.getName(), DBSourceReference.class.getName(), sourceReference.getClass().getName());
			return null;
		}
	}

	/**
	 * To extract file name from path
	 * 
	 * @param sourceReference
	 * @return : File name with extension if present
	 */
	private String getFileName(ISourceReference sourceReference) {
		String tempFilePath = ((FileSourceReference) sourceReference).getFileName();
		try{
			File f = new File(tempFilePath);
			return f.getName();
		} catch (Exception e){
			logger.error("Error while creating error file, for : {} , exception :{}", tempFilePath, e);
			return "TempFile";
		}
	}

	/**
	 * Gives current time stamp with "MM.dd.YYYY.hh.mm.ss" format
	 * 
	 * @return : Current time stamp
	 */
	private String buildCurrentTimestamp() {
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern(ERROR_FILENAME_TRAILER_TIME_FORMAT));
	}

	/**
	 * Method to log error records to file
	 * 
	 * @param errorDetails
	 * @param sourceReference
	 * @param jobId
	 * @return - File name where the record logged
	 */
	public String logErrorRecord(final ErrorDetails errorDetails, ISourceReference sourceReference, String jobId) {
		// build the ErrorRecord
		final ErrorRecord errorRecord = buildErrorRecord(errorDetails, sourceReference);
		// get the writer
		ErrorFileWriter fileWriter = getWriterForJobId(jobId, sourceReference);
		if (fileWriter == null){
			logger.error("Can not instantiate file writer due to previoud error. Please check logs for more details.");
			return null;
		}
		// put it in the batch
		try{
			fileWriter.write(errorRecord);
			return fileWriter.getFileLocation();
		} catch (IOException exception){
			logger.error("Failed to write the error file at {} for the failed records. Please check the logs for more details.", fileWriter.getFileLocation(), exception);
			return fileWriter.getFileLocation();
		}
	}

	/**
	 * Synchronized method for create error writer
	 * 
	 * @param jobId : running job ID
	 * @param sourceReference : source reference object
	 * @return : Writer object
	 */
	private synchronized ErrorFileWriter getWriterForJobId(String jobId, ISourceReference sourceReference) {
		ErrorFileWriter fileWriter = jobWriters.get(jobId);
		if (fileWriter == null){
			fileWriter = initWriter(sourceReference, jobId);
		}
		return fileWriter;
	}

	/**
	 * Final call to write remaining record into file
	 * 
	 * @param jobId : Current running job id.
	 */
	public void onJobEnd(String jobId) {
		ErrorFileWriter fileWriter = jobWriters.get(jobId);
		if (fileWriter != null){
			try{
				fileWriter.flushRecords();
				jobWriters.remove(jobId);
			} catch (IOException exp){
				logger.error("Error while flusing records", exp);
			}
		}
	}

	/**
	 * Initialized file writer for write the error records.
	 * 
	 * @param sourceReference : Input file information
	 * @param jobId : Current running job id
	 * @return : Object of FIle writer.
	 */
	private synchronized ErrorFileWriter initWriter(ISourceReference sourceReference, String jobId) {
		ErrorFileWriter fileWriter = jobWriters.get(jobId);
		if (fileWriter != null){
			return fileWriter;
		}
		String errorFileLocation = getAbsoluteFilePath(sourceReference);
		if (errorFileLocation == null){
			return null;
		}
		fileWriter = new ErrorFileWriter(errorFileLocation);
		jobWriters.put(jobId, fileWriter);
		return fileWriter;
	}

	/**
	 * Build the error records
	 * 
	 * @param errorDetails : Actual error information, about encountered error.
	 * @param sourceReference : File information.
	 * @return : build error record
	 */
	private ErrorRecord buildErrorRecord(ErrorDetails errorDetails, ISourceReference sourceReference) {
		if (sourceReference == null){
			return ErrorRecord.builder().errorMessage(errorDetails.getUserDetails()).rawRecordData("Raw record details not available.").build();
		} else if (FileSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			return ErrorRecord.builder().errorMessage(errorDetails.getUserDetails()).rawRecordData(((FileSourceReference) sourceReference).getRawRecordData()).build();
		} else if (DBSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			return ErrorRecord.builder().errorMessage(errorDetails.getUserDetails()).rawRecordData((String) ((DBSourceReference) sourceReference).getRawRecordData()).build();
		} else{
			return ErrorRecord.builder().errorMessage(errorDetails.getUserDetails()).rawRecordData("Invalid source reference...").build();
		}
	}

	/**
	 * For getting Number of error counts
	 * 
	 * @param jobId : Running job id
	 * @return : Count of error row
	 */
	public int getErrorCount(String jobId) {
		ErrorFileWriter fileWriter = jobWriters.get(jobId);
		return (fileWriter != null) ? fileWriter.getCount() : 0;
	}
}
