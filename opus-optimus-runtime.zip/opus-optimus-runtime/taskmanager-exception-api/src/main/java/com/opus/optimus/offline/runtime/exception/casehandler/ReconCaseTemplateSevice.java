package com.opus.optimus.offline.runtime.exception.casehandler;

import java.util.List;
import java.util.Map;

public interface ReconCaseTemplateSevice {
	ReconCaseTemplate save(ReconCaseTemplate reconCaseTemplates);

	Map<String, String> findByProjectNameandActivityName(String projectName, String activityName);

	List<ReconCaseTemplate> find(String workflowType);

}
