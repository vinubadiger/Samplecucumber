package com.opus.optimus.offline.runtime.exception.utility;

import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * This is case template resolver utility. The utility resolves the template configured in velocity grammar to the human readable string.
 *
 */
@Component
public class CaseTemplateResolverUtil {
    private static final Logger logger = LoggerFactory.getLogger(CaseTemplateResolverUtil.class);
	VelocityEngine ve;

    @Lazy
    @PostConstruct
    public void init() {
        ve = new VelocityEngine();
        Properties prop = new Properties();

        prop.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        prop.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        ve.setProperty("directive.set.null.allowed", true);
        ve.init(prop);
    }

    public String resolve(String template, Map<String, Object> variables) {
    	logger.debug("Template received to resolve: {}", template);
        VelocityContext context = new VelocityContext();

        for (Map.Entry<String, Object> variableEntry : variables.entrySet()) {
            context.put(variableEntry.getKey(), variableEntry.getValue());
        }

        context.put("NEWLINE", "\n");
        StringWriter writer = new StringWriter();
        try {
        	ve.evaluate(context, writer, "CaseTemplateResolver", template);
        	return writer.toString();
        } catch(ParseErrorException | MethodInvocationException | ResourceNotFoundException exception) {
        	logger.error("Failed to resolve template.", exception);
        	return StringUtils.EMPTY;
        }
    }

}
