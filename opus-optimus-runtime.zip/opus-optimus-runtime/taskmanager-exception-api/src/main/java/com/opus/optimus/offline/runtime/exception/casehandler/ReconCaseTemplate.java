package com.opus.optimus.offline.runtime.exception.casehandler;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document (collection = "ReconCaseTemplate")
public class ReconCaseTemplate {
	String activityName; //TODO need to remove this once OPTIMUS-1347 & OPTIMUS-1354 completed
	String projectName;
	String templates;
	String recon_status; //TODO need to remove this once OPTIMUS-1347 & OPTIMUS-1354 completed
	boolean masterCase;
	String workflowType;
	
}
