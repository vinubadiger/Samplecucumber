package com.opus.optimus.offline.runtime.exception.repository;

import java.util.List;

import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;

public interface IJobErrorDetailsService {
	JobErrorDetails logErrorDetails(ErrorDetails errorDetails, ISourceReference sourceReference, IJobTaskInfo jobTaskInfo);
	
	List<JobErrorDetails> getjobErrorDetails(String jobId);
}
