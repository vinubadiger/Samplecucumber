package com.opus.optimus.offline.runtime.exception.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.opus.optimus.offline.runtime.exception.casehandler.ReconCaseTemplate;

@Repository
public interface ReconCaseTemplatesRepository extends MongoRepository<ReconCaseTemplate, String> {
	@Query (value = "{ $and : [ { 'projectName' : ?0 }, { 'activityName' : ?1 }] }")
	List<ReconCaseTemplate> findByProjectNameandActivityName(String projectName ,String activityName);
	
	List<ReconCaseTemplate> findByWorkflowType(String workflowType);
}
