package com.opus.optimus.offline.runtime.exception.logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.icu.text.SimpleDateFormat;
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse;
import com.opus.optimus.offline.config.casemanagement.SalesforceBulkCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.ErrorHandlerConstants;
import com.opus.optimus.offline.runtime.exception.casehandler.JobErrorCaseRequestFactory;
import com.opus.optimus.offline.runtime.exception.casehandler.MongoRecordUpdaterProcecss;
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;

/**
 * @author Ram
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 *
 */
//NOTE: bean scope should not be prototype. Else it will missfunction
@Component
public class JobErrorSalesforceCaseLogger {
	private static final Logger logger = LoggerFactory.getLogger(JobErrorSalesforceCaseLogger.class);
	private static final int CASE_FLUSH_BATCH_SIZE = 1024;

	/*
	 * bucket to store the sub case records. Key= Job Id, Value=Error records to be written in file
	 */
	private Map<String, SalesforceCaseRequest> reconJobCases = new HashMap<>();

	/*
	 * bucket for record ids to be updated for generated cases. Key=Sub Case unique reference id, Value=Map(key of unique record ids
	 */
	private Map<String, List<UnReconcileRecords>> recordIds = new HashMap<>();

	/*
	 * bucket for errorType in case of ETL. required so that we create only one case per errorType
	 */
	private Map<String, Map<String, String>> etlErrorTypes = new HashMap<>();
	
	//bucket to store the No Match records for count purpose. count for each source per processing date in yyyy-MM-dd format
	private Map<String, Map<String,UnReconcileRecords>> noMatchCount = Collections.synchronizedMap(new HashMap<>());
	private SimpleDateFormat noMatchBucketKeyFormatter = new SimpleDateFormat("yyyy-MM-dd");

	@Autowired
	private JobErrorCaseRequestFactory caseRequestFactory;

	@Autowired
	private SalesforceCaseHelper salesforceCaseHelper;

	@Autowired
	private MongoRecordUpdaterProcecss mongoRecordUpdaterProcecss;
	
	@SuppressWarnings ("unchecked")
	public void logCase(final ErrorDetails errorDetails, ISourceReference sourceReference, JobInfo jobInfo, String errorFileLocation) {
		// get a parent case
		SalesforceCaseRequest parentCaseRequest = getJobParentCase(jobInfo, errorDetails, errorFileLocation);
		if (parentCaseRequest == null){
			logger.error("Could not create the parent case request for workflow {}. Please check the logs for more details.", jobInfo.getWorkflowType());
			return;
		}

		// For checking only for error type with job id
		if (StepTypeConstants.ETL_WORKFLOW_TYPE.equals(jobInfo.getWorkflowType())){
			String errorType = ((Throwable) errorDetails.getErrorDetail()).getClass().getSimpleName();
			Map<String, String> jobErrorTypes = etlErrorTypes.get(jobInfo.getId());
			if (jobErrorTypes == null){
				jobErrorTypes = new HashMap<>();
				etlErrorTypes.put(jobInfo.getId(), jobErrorTypes);
			}
			if (jobErrorTypes.containsKey(errorType)){
				logger.debug("Already sub case object created for :{}", errorType);
				return;
			}
			jobErrorTypes.put(errorType, errorType);
		}

		// create the sub case
		final SalesforceCaseRequest subCaseRequest = caseRequestFactory.createSubCaseRequest(jobInfo.getWorkflowType(), errorDetails, jobInfo, sourceReference);
		if (subCaseRequest == null){
			logger.error("Could not create the sub case request for workflow {}. Please check the logs for more details.", jobInfo.getWorkflowType());
			return;
		}
		// link subcase to parent
		addToParentCase(parentCaseRequest, subCaseRequest);
		// if job category is RECON
		String activityName = null;
		if (StepTypeConstants.RECON_WORKFLOW_TYPE.equals(jobInfo.getWorkflowType())){
			if (errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_UNIQUE_REC_IDS_KEY) == null || errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY) == null || errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_STATUS_KEY) == null){
				logger.error("No required information available to update records post the case created. Records will not be updated for the case created with reference id: {}", subCaseRequest.getReferenceId());
				return;
			}
			recordIds.put(subCaseRequest.getReferenceId(), (List<UnReconcileRecords>) errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_UNIQUE_REC_IDS_KEY));
			activityName = (String) errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY);
			/*
			 * this line is removed and kept for reference reconStatus = (ReconSubStatus)
			 * errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_STATUS_KEY)
			 */
		}

		/**
		 * Forcefully create case if child cases are out of threshold value.
		 */
		if (parentCaseRequest.getChildcases().size() == CASE_FLUSH_BATCH_SIZE){
			postCasesToSalesforce(parentCaseRequest, jobInfo.getWorkflowType(), activityName);
		}
	}

	/**
	 * This method gets the parent case request from the bucket. If its not there in the bucket it create one and update the bucket with job id
	 * 
	 * @param jobInfo : Job related information object.
	 * @param errorDetails : Error related information object.
	 * @param errorFileLocation : Path of error file.
	 * @return : Parent case object.
	 */
	private synchronized SalesforceCaseRequest getJobParentCase(final JobInfo jobInfo, final ErrorDetails errorDetails, String errorFileLocation) {
		SalesforceCaseRequest parentCaseRequest = reconJobCases.get(jobInfo.getId());
		if (parentCaseRequest == null){
			parentCaseRequest = caseRequestFactory.createParentCaseRequest(jobInfo.getWorkflowType(), errorDetails, jobInfo, errorFileLocation);
			if (parentCaseRequest == null){
				logger.error("Parent case not created");
				return null;
			} else{
				reconJobCases.put(jobInfo.getId(), parentCaseRequest);
				return parentCaseRequest;
			}
		} else{
			return parentCaseRequest;
		}
	}

	/**
	 * For on job end case creation call with valid object
	 * 
	 * @param jobInfo : Job information object
	 */
	public void flushCases(final JobInfo jobInfo) {
		// get a parent case
		final SalesforceCaseRequest parentCaseRequest = reconJobCases.get(jobInfo.getId());
		if (parentCaseRequest == null){
			logger.info("No parent case available to flush at the end of the step instance. Job Id: {}", jobInfo.getId());
			return;
		}
		postCasesToSalesforce(parentCaseRequest, jobInfo.getWorkflowName(), jobInfo.getWorkflowType());
	}

	/**
	 * Posting case creation request for ETL & Recon both.
	 * 
	 * @param parentCaseRequest : Parent case request object.
	 * @param activityName : Activity Name.
	 * @param jobCategory : Work flow type.
	 */
	private void postCasesToSalesforce(SalesforceCaseRequest parentCaseRequest, String activityName, String jobCategory) {
		// authenticate with salesforce
		final SalesforceAuthenticateResponse response = salesforceCaseHelper.authenticate();
		if (StringUtils.isEmpty(response.getAccessToken())){
			logger.error("Can not post the cases to the sales force application due to authentication failure.");
			return;
		}
		final String accessToken = response.getAccessToken();
		// create a bulk request
		final SalesforceBulkCaseRequest bulkCreateRequest = SalesforceBulkCaseRequest.builder().records(Arrays.asList(parentCaseRequest)).build();
		final SalesforceCaseResponse caseResponse = salesforceCaseHelper.bulkCreate(bulkCreateRequest, accessToken);
		if (caseResponse.isHasError()){
			logger.error("Error while posting the cases to sales force. Error message are listed as below:");
			caseResponse.getErrorList().stream().forEach(saleForceErrorDetails -> logger.error("\t\t {}", saleForceErrorDetails.getMessage()));
			return;
		}
		/*
		 * update the parent request with generated parent case id. This is for the first time when no parent case create.
		 */
		updateParentCase(parentCaseRequest, caseResponse);
		// if job type is RECON then update all the recon records for the case generated.
		if (StepTypeConstants.RECON_WORKFLOW_TYPE.equals(jobCategory)){
			processRecordUpdatesForCaseId(caseResponse, activityName);
		}
	}

	/**
	 * Adding child request object to relevant parent request object
	 * 
	 * @param parentCaseRequest : Parent case request object.
	 * @param subCaseRequest : Sub case request object.
	 */
	private void addToParentCase(SalesforceCaseRequest parentCaseRequest, SalesforceCaseRequest subCaseRequest) {
		if (parentCaseRequest.getChildcases() == null){
			parentCaseRequest.setChildcases(new ArrayList<>());
		}
		parentCaseRequest.getChildcases().add(subCaseRequest);
	}

	/**
	 * Updating Parent case request object.
	 * 
	 * @param parentCaseRequest : Parent case request object.
	 * @param caseResponse : Case response form Sales force.
	 */
	private void updateParentCase(SalesforceCaseRequest parentCaseRequest, SalesforceCaseResponse caseResponse) {
		if (StringUtils.isEmpty(parentCaseRequest.getCaseId())){
			caseResponse.getSuccessList().stream().filter(caseDetails -> parentCaseRequest.getReferenceId().equalsIgnoreCase(caseDetails.getReferenceId())).forEach(caseDetails -> parentCaseRequest.setCaseId(caseDetails.getCaseId()));
		}
		// clear the sub case list
		parentCaseRequest.getChildcases().clear();
	}

	/**
	 * Process record update of child case id from DB.
	 * 
	 * @param caseResponse : Sales force response object.
	 * @param activityName : Activity name.
	 */
	private void processRecordUpdatesForCaseId(SalesforceCaseResponse caseResponse, String activityName) {
		// this process is asynchronous activity for effective performance.
		mongoRecordUpdaterProcecss.init(recordIds);
		mongoRecordUpdaterProcecss.process(recordIds, caseResponse.getSuccessList(), activityName, CaseStatus.OPEN);
	}

	/**
	 * Updating number of error row count
	 * 
	 * @param errorRowCount : Actual error row count
	 * @param jobId : Running job's id
	 */
	public void updateParentCaseForErrorCount(int errorRowCount, String jobId) {
		SalesforceCaseRequest parentCaseRequest = reconJobCases.get(jobId);
		if (parentCaseRequest != null) {
			parentCaseRequest.setErrorCounts(errorRowCount == 0 ? 0 : errorRowCount);
		}
	}

	/**
	 * For on job end call deleting the entry for job id
	 * 
	 * @param jobInfo : Job information object
	 */
	public void onJobEnd(JobInfo jobInfo) {
		logger.debug("Removing entry for : {}", jobInfo.getId());
		etlErrorTypes.remove(jobInfo.getId());
		//remove the parent case from the bucket for a particular job id
		reconJobCases.remove(jobInfo.getId());
		//clear record ids
		recordIds.clear();
	}
	
	public UnReconcileRecords getNoMatchSourceRecord(Date processingDate, String sourceName) {
		final String processingDateKey = buildProcDateKey(processingDate);
		noMatchCount.computeIfAbsent(processingDateKey, k -> new HashMap<>());
		return noMatchCount.get(processingDateKey).get(sourceName);
	}

	public void pushToNoMatchCountBucket(Date processingDate, String sourceName, UnReconcileRecords unReconcileRecords) {
		final String processingDateKey = buildProcDateKey(processingDate);
		noMatchCount.get(processingDateKey).put(sourceName, unReconcileRecords);
	}

	private synchronized String buildProcDateKey(Date processingDate) {
		return noMatchBucketKeyFormatter.format(processingDate);
	}
	
	/**
	 * Create a case for No Match scenario with total no match count from source A and Source B
	 */
	public void postCaseForAllNoMatch(final JobInfo jobInfo, final String sourceAName, final String sourceBName,
			final ErrorDetails errorDetails) {
		if(errorDetails == null) {
			logger.error("No ErrorDetails provided for posting All No Match case. Please check the logs for more details.");
			return;
		}
		noMatchCount.entrySet().forEach(entry -> {
			logger.debug("Posting cases for Processing Date: {}", entry.getKey());
			final UnReconcileRecords sourceANoMatchRecords = entry.getValue().get(sourceAName);
			final UnReconcileRecords sourceBNoMatchRecords = entry.getValue().get(sourceBName);
			int sourceANoMatchCount = (sourceANoMatchRecords != null && sourceANoMatchRecords.getOIDs() != null
					? sourceANoMatchRecords.getOIDs().size()
					: 0);
			int sourceBNoMatchCount = (sourceBNoMatchRecords != null && sourceBNoMatchRecords.getOIDs() != null
					? sourceBNoMatchRecords.getOIDs().size()
					: 0);

			logger.debug("All No Match Count for Source=A : {}, Source-B: {}", sourceANoMatchCount,
					sourceBNoMatchCount);
			final List<UnReconcileRecords> errorRecordInfoList = Arrays.asList(sourceANoMatchRecords, sourceBNoMatchRecords);			
			errorDetails.getAdditionalData().put(ErrorHandlerConstants.ERR_RECON_PROC_DATE_KEY, entry.getKey());
			errorDetails.getAdditionalData().put(ErrorHandlerConstants.ERR_UNIQUE_REC_IDS_KEY, errorRecordInfoList);
			errorDetails.getAdditionalData().put(ErrorHandlerConstants.ERR_RECON_SOURCE_A_ALL_NOMATCH_CNT_KEY,
					sourceANoMatchCount);
			errorDetails.getAdditionalData().put(ErrorHandlerConstants.ERR_RECON_SOURCE_B_ALL_NOMATCH_CNT_KEY,
					sourceBNoMatchCount);
			errorDetails.getAdditionalData().put(ErrorHandlerConstants.ERR_RECON_IS_ALL_NOMATCH_CASE_KEY, true);
			logCase(errorDetails, null, jobInfo, null);
		});
		noMatchCount.clear();
	}
}
