package com.opus.optimus.offline.runtime.exception.handler;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.exception.casehandler.JobErrorCaseRequestFactory;
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper;
import com.opus.optimus.offline.runtime.exception.config.SalesForceCaseCreatorStepConfig;
import com.opus.optimus.offline.runtime.exception.logger.JobErrorFileLogger;
import com.opus.optimus.offline.runtime.exception.logger.JobErrorSalesforceCaseClosure;
import com.opus.optimus.offline.runtime.exception.logger.JobErrorSalesforceCaseLogger;
import com.opus.optimus.offline.runtime.exception.repository.IJobErrorDetailsService;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * This class is used for creating the case on sales force platform in case if the severity is FATAL or work flow type is RECON.
 */
/**
 * @author Ram
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
@Component ("SalesForceCase")
@Scope (value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SalesForceCaseCreatorStep extends AbstractStep<SalesForceCaseCreatorStepConfig> implements IJobTaskInfoAware {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(SalesForceCaseCreatorStep.class);

	/** The job info service. */
	@Autowired
	IJobInfoService jobInfoService;

	/** The error details log repository. */
	@Autowired
	JobErrorDetailsRepository errorDetailsLogRepository;

	/** The error details service. */
	@Autowired
	IJobErrorDetailsService errorDetailsService;

	/** The case creation authentication implementation */
	@Autowired
	private SalesforceCaseHelper salesforceCaseHelper;
	

	/** The message factory. */
	@Autowired
	IMessageFactory messageFactory;

	/** The job task info. */
	IJobTaskInfo jobTaskInfo;

	/** The job info. */
	JobInfo jobInfo = null;

	/** The error file logger. */
	// Changes for OPTIMUS-1347, OPTIMUS-1354, OPTIMUS-1356
	@Autowired
	JobErrorFileLogger errorFileLogger;

	/** The error salesforce case logger. */
	@Autowired
	JobErrorSalesforceCaseLogger errorSalesforceCaseLogger;
	
	@Autowired
	JobErrorSalesforceCaseClosure errorSalesforceCaseClosure;
	
	@Autowired
	JobErrorCaseRequestFactory caseRequestFactory;

	/**
	 * Instantiates a new sales force case creator step.
	 *
	 * @param config the configuration
	 */
	public SalesForceCaseCreatorStep(SalesForceCaseCreatorStepConfig config) {
		super(config);
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		try{
			String jobId = jobTaskInfo.getJobId();
			logger.debug("Recevied doProcess command for SalesForceCaseCreatorStep for job id : {}", jobId);
			if (jobInfo == null){
				jobInfo = jobInfoService.findById(jobId);
			}
			ErrorDetails errorDetails = (ErrorDetails) data.getData();
			// get the source reference from the message
			final ISourceReference sourceReference = IMessage.class.isAssignableFrom(data.getClass()) ? data.getSourceReference() : null;
			StringBuilder filedirectory = new StringBuilder();
			if (sourceReference != null){
				filedirectory.append(FileSourceReference.class.isAssignableFrom(sourceReference.getClass()) ? ((FileSourceReference) sourceReference).getFileName() : StringUtils.EMPTY);
			}
			// send error record to file and create a case for validation/transformation processing exception
			handleRecordProcessingException(errorDetails, jobInfo, sourceReference);
			emitter.emit(messageFactory.createMessage(MessageType.DATA, data.getData(), data.getSourceReference()));
		} catch (Exception e){
			logger.error("Error While case creation step : {}", e);
			emitter.emit(messageFactory.createMessage(MessageType.DATA, data.getData(), data.getSourceReference()));
			ErrorDetails errorDetails = ErrorDetails.builder().userDetails(e.getMessage()).errorDetail(e).severity(Severity.ERROR).build();
			emitter.emit(messageFactory.createMessage(MessageType.DATA, errorDetails, data.getSourceReference()));
		}
	}
	
	/**
	 * Create error details for both ETL and Recon.
	 * 
	 * @param errorDetails : Error information object.
	 * @param workflowType : workflowType name as a String.
	 * @param jobId : jobId as a String.
	 */
	public SalesforceCaseDetails createCase(final SalesforceCaseRequest caseRequest) {
		final SalesforceAuthenticateResponse response = salesforceCaseHelper.authenticate();
		final String accessToken = response.getAccessToken();

		// Create single case
		final SalesforceCaseResponse singleCaseCreateResponse = salesforceCaseHelper.createCase(caseRequest,
				accessToken);
		List<SalesforceCaseDetails> salesforce = singleCaseCreateResponse.getSuccessList();

		Optional<SalesforceCaseDetails> salesforceCaseDetail = salesforce.stream()
				.filter(salesForceResp -> salesForceResp.getReferenceId().equals(caseRequest.getReferenceId()))
				.findAny();

		if (salesforceCaseDetail.isPresent()) {
			return salesforceCaseDetail.get();
		} else {
			logger.error(
					"No case details available in the response received from Sales force for the request reference Id: {}. Error details will not have case associated.",
					caseRequest.getReferenceId());
			return null;
		}
	}

	/**
	 * Create file for ETL and case for both ETL and Recon.
	 * 
	 * @param errorDetails : Error information object.
	 * @param jobInfo : Job information object.
	 * @param sourceReference : Input file information Object.
	 */
	private void handleRecordProcessingException(ErrorDetails errorDetails, JobInfo jobInfo, ISourceReference sourceReference) {
		String errorFileLocation = null;
		if (StepTypeConstants.ETL_WORKFLOW_TYPE.equals(jobInfo.getWorkflowType())){
			/* log the errors record in the file , for ETL */
			errorFileLocation = errorFileLogger.logErrorRecord(errorDetails, sourceReference, jobInfo.getId());
			if (StringUtils.isEmpty(errorFileLocation)){
				logger.error("Error in preparing the errored record file for the occured exception. Please check the logs for more details.");
				return;
			}
		}
		/* Create case for error scenarios */
		errorSalesforceCaseLogger.logCase(errorDetails, sourceReference, jobInfo, errorFileLocation);
	}

	@Override
	public void onStepEnd(boolean forceEnd, IEmitter emitter) {
		logger.info("{} Step end.", this.getClass().getSimpleName());
		try {
			if (jobInfo == null){
	 			jobInfo = jobInfoService.findById(jobTaskInfo.getJobId());
	 		}
			updateCaseForErrorCount(jobInfo);
			errorSalesforceCaseLogger.flushCases(jobInfo);
			errorSalesforceCaseLogger.onJobEnd(jobInfo);
			errorSalesforceCaseClosure.jobEnd(); 
		} catch (Exception e){
			logger.error("Error While processing onStepEnd of salesForceStep", e);
		}
		super.onStepEnd(forceEnd, emitter);
	}

	private void updateCaseForErrorCount(JobInfo jobInfo) {
		if (StepTypeConstants.ETL_WORKFLOW_TYPE.equals(jobInfo.getWorkflowType())){
			/* Getting no of error row count of current job */
			int noOfErrors = errorFileLogger.getErrorCount(jobTaskInfo.getJobId());
			/* Forcefully flush and write remaining error rows */
			errorFileLogger.onJobEnd(jobTaskInfo.getJobId());
			/* Update number of error row count of running job */
			errorSalesforceCaseLogger.updateParentCaseForErrorCount(noOfErrors, jobTaskInfo.getJobId());
		}
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
	}
}
