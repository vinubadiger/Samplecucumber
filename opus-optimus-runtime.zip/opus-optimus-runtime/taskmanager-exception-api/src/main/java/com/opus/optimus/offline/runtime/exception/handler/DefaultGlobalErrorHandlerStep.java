package com.opus.optimus.offline.runtime.exception.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.exception.config.DefaultErrorHandlerStepConfig;
import com.opus.optimus.offline.runtime.exception.repository.IJobErrorDetailsService;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetailsRepository;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.taskmanager.api.IJobInfoService;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfoAware;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceSummary;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import com.opus.optimus.offline.runtime.workflow.api.impl.StopJobException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * This class is used to as default global handler step Which is responsible for generating job error details at the same time it check the severity
 * of job and if it is FATAL it stop the job.
 */
@Component ("DefaultGlobalErrorHandler")
@Scope (value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class DefaultGlobalErrorHandlerStep extends AbstractStep<DefaultErrorHandlerStepConfig> implements IJobTaskInfoAware {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(DefaultGlobalErrorHandlerStep.class);

	/** The error details service. */
	@Autowired
	IJobErrorDetailsService errorDetailsService;

	/** The job task info. */
	IJobTaskInfo jobTaskInfo;

	@Autowired
	IJobInfoService jobInfoService;

	JobInfo jobInfo = null;

	/** The log error details bag. */
	List<JobErrorDetails> logErrorDetailsBag;

	/** The error details log repository. */
	@Autowired
	JobErrorDetailsRepository errorDetailsLogRepository;

	/** The executor service. */
	@Autowired
	ExecutorService executorService;

	@Value ("${stop.job.on.error.threshold.count:0}")
	public long stopJobOnErrorThresholdCount;

	long localErrorRecordCount = 0;

	/** The Constant BAG_SIZE. */
	private static final int BAG_SIZE = 1024;

	/**
	 * Instantiates a new default global error handler step.
	 *
	 * @param config the config
	 */
	public DefaultGlobalErrorHandlerStep(DefaultErrorHandlerStepConfig config) {
		super(config);
		logErrorDetailsBag = new ArrayList<>();
	}

	@Override
	public void process(IMessage data, IEmitter emitter) {
		ErrorDetails errorDetails = null;
		try{
			if (stopJobOnErrorThresholdCount > 0 && jobInfo.getWorkflowType().equals(StepTypeConstants.ETL_WORKFLOW_TYPE)){
				localErrorRecordCount++;
				if (localErrorRecordCount >= stopJobOnErrorThresholdCount){
					logger.error(
							"Error count for current job has exceeded threshold count. Configured Threshold: {} Error Count: {}, Aborting Job !",
							stopJobOnErrorThresholdCount, localErrorRecordCount);
					throw new StopJobException("Error count is beyond threshold. Error Count: " + localErrorRecordCount, null, null);
				}
			}

			IMessage errorStepMessage = data;
			if (!ErrorDetails.class.isAssignableFrom(errorStepMessage.getData().getClass())){
				logger.error("Unknown details provided for the Global Error Handler. Expected: com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails & Actual: {}", data.getClass());
				return;
			}
			errorDetails = (ErrorDetails) errorStepMessage.getData();
			if (null != errorDetails.getErrorDetail()){
				logger.error("Logging error from DefaultGlobalErrorHandlerStep: {} -- {}", ((Throwable) errorDetails.getErrorDetail()).getMessage(), errorDetails.getErrorDetail().toString());
			} else{
				logger.error("No log mesage found in DefaultGlobalErrorHandlerStep");
			}
			final ISourceReference sourceReference = errorStepMessage.getSourceReference();

			// log the details to repository
			logErrorDetailsBag.add(errorDetailsService.logErrorDetails(errorDetails, sourceReference, jobTaskInfo));

			if (logErrorDetailsBag.size() >= BAG_SIZE){
				executorService.submit(batchCommit(logErrorDetailsBag));
				logErrorDetailsBag = new ArrayList<>();
			}
		} catch (StopJobException e){
			throw e;
		} catch (Exception exception){
			logger.error("Error while globally handling the errror. Please check the logs", exception);
		}
		// handle FATAL severity
		handleSeverity(errorDetails, data.getSourceReference());
	}

	/**
	 * Method to clear error record and save it to MongoDB.
	 *
	 * @return the runnable
	 */
	private Runnable batchCommit(final List<JobErrorDetails> errorDetailsBag) {
		return () -> { 
			errorDetailsLogRepository.saveAll(errorDetailsBag);
			errorDetailsBag.clear();
		};
	}

	/**
	 * This method is used to check the severity of job and if it is FATAL then STOP the job.
	 *
	 * @param errorDetails - The name which holds error details information
	 * @param sourceReference - The field which holds the source reference type
	 */
	private void handleSeverity(ErrorDetails errorDetails, ISourceReference sourceReference) {
		if (errorDetails != null){
			if (Severity.FATAL.equals(errorDetails.getSeverity())){
				logger.error("Error severity is FATAL, Job will be aborted.");
				throw new StopJobException(errorDetails.getUserDetails(), new Exception(errorDetails.getUserDetails()), sourceReference);
			}
		} else{
			logger.info("Error Details is null. Can not handle severity. Please check the logs for more details.");
		}
	}

	@Override
	public void setJobTaskInfo(IJobTaskInfo jobTaskInfo) {
		this.jobTaskInfo = jobTaskInfo;
		if (jobInfo == null){
			jobInfo = jobInfoService.findById(jobTaskInfo.getJobId());
		}
	}

	@Override
	public IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter) {
		if (!logErrorDetailsBag.isEmpty()){
			executorService.submit(batchCommit(logErrorDetailsBag));
		}
		return null;
	}
}
