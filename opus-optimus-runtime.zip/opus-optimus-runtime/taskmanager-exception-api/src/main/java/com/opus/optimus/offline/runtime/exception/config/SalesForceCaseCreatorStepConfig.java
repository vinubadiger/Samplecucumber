package com.opus.optimus.offline.runtime.exception.config;

import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.Data;

@Data
public class SalesForceCaseCreatorStepConfig implements IStepConfig {
	private static final long serialVersionUID = 1L;
	String stepName;
	String stepType;
	
	@Override
	public String getStepType() {
		return StepTypeConstants.SALESFORCE_CASE_CREATOR;
	}

	@Override
	public boolean validate() {
		if (this.stepName == null || this.stepName.isEmpty()){
			throw new ValidationException("Caught inside SalesForceCaseCreatorStepConfig ,stepName field is required");
		}
		return true;
	}

}
