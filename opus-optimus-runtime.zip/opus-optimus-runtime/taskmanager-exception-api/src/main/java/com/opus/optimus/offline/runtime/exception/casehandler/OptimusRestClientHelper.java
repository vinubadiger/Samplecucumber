/**
 * 
 */
package com.opus.optimus.offline.runtime.exception.casehandler;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class OptimusRestClientHelper.
 */
@Configuration
public class OptimusRestClientHelper {

	/**
	 * Rest template.
	 *
	 * @return the rest template
	 */
	@Bean
	public RestTemplate restTemplate() {
		HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		httpRequestFactory.setConnectionRequestTimeout(0);
		httpRequestFactory.setConnectTimeout(0);
		httpRequestFactory.setReadTimeout(0);
		RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
		registerMessageConverter(restTemplate);
		return restTemplate;
	}

	/**
	 * This is very specific to Sales force integration API calls. The APIs are using rest template which should have a message converter register to
	 * convert the POJO to JSON for successful communication
	 *
	 * @param restTemplate the rest template
	 */
	private void registerMessageConverter(RestTemplate restTemplate) {
		final List<HttpMessageConverter<?>> messageConverters = restTemplate.getMessageConverters();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		final MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(mapper);
		/**
		 * Note: here we are making this converter to process any kind of response, not only application/*json, which is the default behavior
		 */
		converter.setSupportedMediaTypes(Arrays.asList(MediaType.ALL));
		messageConverters.add(converter);
		restTemplate.setMessageConverters(messageConverters);
	}
}
