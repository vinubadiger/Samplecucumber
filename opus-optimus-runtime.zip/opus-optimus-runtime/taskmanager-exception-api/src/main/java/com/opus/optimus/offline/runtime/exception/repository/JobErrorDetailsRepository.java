package com.opus.optimus.offline.runtime.exception.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface JobErrorDetailsRepository extends MongoRepository<JobErrorDetails, String> {
	@Query("{ 'jobId' : ?0 }")
	List<JobErrorDetails> findByjobId(String jobId);
	
	@Query (value = "{ $and : [ { 'jobId' : ?0 }, { 'errorType' : ?1 }] }")
	List<JobErrorDetails> findByjobIdAnderrorType(String jobId, String errorType);
	
}
