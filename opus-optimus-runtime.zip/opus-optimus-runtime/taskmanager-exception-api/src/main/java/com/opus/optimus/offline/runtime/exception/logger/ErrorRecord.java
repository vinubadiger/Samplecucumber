package com.opus.optimus.offline.runtime.exception.logger;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * POJO to create the error record json for file logger
 *
 * @param <T>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ErrorRecord {
	private static final String ERROR_DETAILS_SEPARATOR = "|";
	private String rawRecordData;
	private String errorMessage;
	
	public String getErrorRecordLine() {
		return this.rawRecordData + ERROR_DETAILS_SEPARATOR + errorMessage;
	}
}
