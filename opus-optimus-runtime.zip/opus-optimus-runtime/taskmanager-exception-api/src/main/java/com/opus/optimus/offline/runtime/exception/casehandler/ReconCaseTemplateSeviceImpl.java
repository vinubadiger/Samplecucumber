package com.opus.optimus.offline.runtime.exception.casehandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opus.optimus.offline.runtime.exception.repository.ReconCaseTemplatesRepository;

@Service
public class ReconCaseTemplateSeviceImpl implements ReconCaseTemplateSevice {

	@Autowired
	ReconCaseTemplatesRepository reconcaseTemplatesRepo;

	/**
	 * Save ReconCaseTemplates instance.
	 *
	 * @param reconCaseTemplates the recon case templates
	 * @return the recon case templates
	 */
	@Override
	public ReconCaseTemplate save(ReconCaseTemplate reconCaseTemplates) {

		return reconcaseTemplatesRepo.save(reconCaseTemplates);
	}

	/**
	 * Find by project projectName and activity name.
	 *
	 * @param projectName the project name
	 * @param activityName the activity name
	 * @return the list
	 */
	@Override
	public Map<String,String> findByProjectNameandActivityName(String projectName, String activityName) {
		List<ReconCaseTemplate> reconTempList = reconcaseTemplatesRepo.findByProjectNameandActivityName(projectName, activityName);
		Map<String, String> templatemap = new HashMap<>();
		if(reconTempList == null || reconTempList.isEmpty()) return templatemap;
		reconTempList.forEach(map -> {
			templatemap.put(map.getRecon_status(), map.getTemplates());
		});
		return templatemap;
	}

	@Override
	public List<ReconCaseTemplate> find(String workflowType) {
		return reconcaseTemplatesRepo.findByWorkflowType(workflowType);
	}

	
}
