package com.opus.optimus.offline.runtime.exception.logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse;
import com.opus.optimus.offline.config.casemanagement.SalesforceBulkCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus;
import com.opus.optimus.offline.runtime.exception.casehandler.JobErrorCaseRequestFactory;
import com.opus.optimus.offline.runtime.exception.casehandler.MongoRecordUpdaterProcecss;
import com.opus.optimus.offline.runtime.exception.casehandler.SalesforceCaseHelper;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;

/**
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 *
 */
//NOTE: bean scope should not be prototype. Else it will missfunction
@Component
public class JobErrorSalesforceCaseClosure {
	private static final Logger logger = LoggerFactory.getLogger(JobErrorSalesforceCaseClosure.class);
	private static final int CASE_FLUSH_BATCH_SIZE = 1024;
	private static final String CLOSE_CASE_COMMENT = "";

	/*
	 * bucket to store the sub case records. Key= Job Id, Value=Error records to be written in file
	 */
	Map<String, List<SalesforceCaseRequest>> jobCloseCases = Collections.synchronizedMap(new HashMap<>());
	/*
	 * bucket for record ids to be updated for generated cases. Key=Sub Case unique reference id, Value=Map(key of unique record ids
	 */
	private Map<String, List<UnReconcileRecords>> recordIds = Collections.synchronizedMap(new HashMap<>());


	@Autowired
	private JobErrorCaseRequestFactory caseRequestFactory;

	@Autowired
	private SalesforceCaseHelper salesforceCaseHelper;
	
	@Autowired
	private MongoRecordUpdaterProcecss mongoRecordUpdaterProcecss;

	public synchronized void closeCase(final Set<String> closeCaseIds, JobInfo jobInfo, List<UnReconcileRecords> reconciledRecordInfoList) {
		if(closeCaseIds == null || closeCaseIds.isEmpty()) {
			logger.info("No Case ids available for closure");
		} else if (jobInfo == null){ 
			logger.error("No JobInfo available for closing the cases. Cannot be closed the cases. Cases are {}", closeCaseIds);
		}else {
			if(jobCloseCases.get(jobInfo.getId()) == null) {
				jobCloseCases.put(jobInfo.getId(), new ArrayList<>());
			}
			final List<SalesforceCaseRequest> caseRequests = jobCloseCases.get(jobInfo.getId());
			
			//check if already a case request available
			final List<SalesforceCaseRequest> newCloseCaseRequests = closeCaseIds.stream().filter(caseId -> !isCaseRequestAvailable(caseId, caseRequests))
					.map(caseId -> caseRequestFactory.createCloseCaseRequest(caseId, CLOSE_CASE_COMMENT)).collect(Collectors.toList());
			caseRequests.addAll(newCloseCaseRequests);
			
			//group the unreconciled records per case id
			Map<String, List<UnReconcileRecords>> groupedUnReconciledRecords = reconciledRecordInfoList.stream()
					.collect(Collectors.groupingBy(UnReconcileRecords::getCaseId, Collectors.toList()));
			
			caseRequests.stream()
					.filter(closeCaseReq -> groupedUnReconciledRecords.get(closeCaseReq.getCaseId()) != null)
					.sequential().forEach(closeCaseReq -> {
						final List<UnReconcileRecords> value = groupedUnReconciledRecords.get(closeCaseReq.getCaseId());
						if (recordIds.get(closeCaseReq.getReferenceId()) != null) {
							recordIds.get(closeCaseReq.getReferenceId()).addAll(value);// put the OIDs in the same map
																						// value with reference id of
																						// the identified case request
						} else {
							recordIds.put(closeCaseReq.getReferenceId(), value);// put the OIDs in the map with
																				// reference id of the identified case
																				// request
						}
					});
			
			/**
			 * send cases to salesforce as batch is full.
			 */
			if (jobCloseCases.get(jobInfo.getId()).size() >= CASE_FLUSH_BATCH_SIZE){
				sendCloseCaseRequestToSalesforce(jobInfo);
			}
		}
	}
	
	private boolean isCaseRequestAvailable(String caseId, List<SalesforceCaseRequest> caseRequests) {
		Optional<SalesforceCaseRequest> existingCaseReq = caseRequests.stream()
				.filter(caseRequest -> caseRequest.getCaseId().equalsIgnoreCase(caseId)).findFirst();
		return existingCaseReq.isPresent();
	}
	
	/**
	 * For on job end case creation call with valid object
	 * 
	 * @param jobInfo : Job information object
	 */
	public void flushCases(final JobInfo jobInfo) {
		if (jobInfo == null){ 
			logger.error("No JobInfo available for closing the cases. Cannot be closed the cases.");
			return;
		}
		sendCloseCaseRequestToSalesforce(jobInfo);
	}

	/**
	 * Posting case creation request for ETL & Recon both.
	 * 
	 * @param parentCaseRequest : Parent case request object.
	 * @param activityName : Activity Name.
	 * @param jobCategory : Work flow type.
	 */
	private void sendCloseCaseRequestToSalesforce(final JobInfo jobInfo) {
		final List<SalesforceCaseRequest> closeCaseRequests = jobCloseCases.get(jobInfo.getId());
		if(closeCaseRequests == null || closeCaseRequests.isEmpty()) return;
		// authenticate with salesforce
		final SalesforceAuthenticateResponse response = salesforceCaseHelper.authenticate();
		if (StringUtils.isEmpty(response.getAccessToken())){
			logger.error("Can not post the cases to the sales force application due to authentication failure.");
			return;
		}
		final String accessToken = response.getAccessToken();
		// create a bulk request
		final SalesforceBulkCaseRequest bulkCreateRequest = SalesforceBulkCaseRequest.builder().records(closeCaseRequests).build();
		final SalesforceCaseResponse caseResponse = salesforceCaseHelper.bulkUpdate(bulkCreateRequest, accessToken);
		if (caseResponse.isHasError()){
			logger.error("Error while posting the cases to sales force for update. Error message are listed as below:");
			caseResponse.getErrorList().stream().forEach(saleForceErrorDetails -> logger.error("\t\t {}", saleForceErrorDetails.getMessage()));
			return;
		}
		//update the records for case info status to CLOSED
		processRecordUpdatesForCaseId(caseResponse, jobInfo.getWorkflowName());
		//clear the cases for a job id
		jobCloseCases.remove(jobInfo.getId());
	}
	
	/**
	 * Process record update of child case id from DB.
	 * 
	 * @param caseResponse : Sales force response object.
	 * @param activityName : Activity name.
	 */
	private void processRecordUpdatesForCaseId(SalesforceCaseResponse caseResponse, String activityName) {
		// this process is asynchronous activity for effective performance.
		mongoRecordUpdaterProcecss.init(recordIds);
		mongoRecordUpdaterProcecss.process(recordIds, caseResponse.getSuccessList(), activityName, CaseStatus.CLOSED);
	}
	
	public void jobEnd() {
		recordIds.clear();
	}
}
