package com.opus.optimus.offline.runtime.exception.casehandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.SalesforceCaseDetails;
import com.opus.optimus.offline.config.casemanagement.UnReconcileRecords;
import com.opus.optimus.offline.config.datasource.MongoDataSource;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.NoSuchDataSourceAvailableException;
import com.opus.optimus.offline.runtime.common.api.datasource.impl.DataSourceFactory;

import lombok.NoArgsConstructor;

@NoArgsConstructor
@Component
@Scope("prototype")
public class MongoRecordUpdaterProcecss {
	private static final Logger logger = LoggerFactory.getLogger(MongoRecordUpdaterProcecss.class);
	private static final String RECONCTRLFIELDNAME = "reconControlFields";
	private static final String CASEINFOFIELDNAME = "caseInfo";
	private static final String FIELD_NAME_SEPRATOR = ".";
	
	private Map<String, MongoTemplate> tempMongoTemplateCache = new HashMap<>(); 
	
	@Autowired
	private DataSourceFactory dataSourceFactory;

	public void init(Map<String, List<UnReconcileRecords>> recordIds) {
		recordIds.keySet().stream().forEach(subCaseId -> 
			recordIds.get(subCaseId).stream().forEach(unReconciledRecord -> {
				if (unReconciledRecord != null && unReconciledRecord.getDataSourceName() != null 
						&& tempMongoTemplateCache.get(unReconciledRecord.getDataSourceName()) == null) {
					try {
						IDataSource dataSource = dataSourceFactory
								.getDataSource(unReconciledRecord.getDataSourceName());
						final MongoTemplate mongoTemplate = new MongoTemplate(
								((MongoDataSource) dataSource).getMongoClient(),
								((MongoDataSource) dataSource).getDatabase().getName());
						tempMongoTemplateCache.put(unReconciledRecord.getDataSourceName(), mongoTemplate);
					} catch (NoSuchDataSourceAvailableException | DataSourceInitializationException e) {
						logger.error(
								"Failed to instantiate the Mongo record update process. the case information will not be updated with the records.",
								e);
					}
				}
			})
		);
	}

	/**
	 * Process the records to update all with the provided case ids
	 * @param recordPrimaryIds
	 * @param generatedCases
	 * @param activityName
	 * @param reconStatus
	 */
	public void process(final Map<String, List<UnReconcileRecords>> recordPrimaryIds,
			final List<SalesforceCaseDetails> generatedCases, final String activityName, final CaseStatus caseStatus) {
//		new Thread(() -> {
			if (generatedCases == null || generatedCases.isEmpty()) {
				logger.error("Generated case details is empty or null. Cannot update the records with generate case ids.");
				return;
			}
			if (recordPrimaryIds == null || recordPrimaryIds.isEmpty()) {
				logger.error(
						"record primary key details is empty or null. Cannot update the records for generate case ids.");
				return;
			}
			
			//generated case loop
			for (int caseIndex = 0; caseIndex < generatedCases.size(); caseIndex++) {
				final SalesforceCaseDetails caseDetails = generatedCases.get(caseIndex);
				//reference to records ids from all sources to be updated for this case
				final List<UnReconcileRecords> primaryIds = recordPrimaryIds.get(caseDetails.getReferenceId());
				if(primaryIds == null || primaryIds.isEmpty()) {
					logger.info("No Primary record ids are available to be updated for this case. this might be the parent case.");
					continue;
				}
				//records loop by source.
				updateRecordsForCaseId(activityName, caseDetails, primaryIds, caseStatus);
			}
//		}).start()
	}

	private void updateRecordsForCaseId(String activityName, final SalesforceCaseDetails caseDetails,
			final List<UnReconcileRecords> primaryIds, CaseStatus caseStatus) {
		for (int recordInfoIndex = 0; recordInfoIndex < primaryIds.size(); recordInfoIndex++) {
			final UnReconcileRecords unReconciledRecords = primaryIds.get(recordInfoIndex);
			if (unReconciledRecords == null) {
				logger.error(
						"Either One of the collection from recon activity is Empty or missing to update Case details. Case Id: {}, URL: {}",
						caseDetails.getCaseId(), caseDetails.getCaseDetailUrl());
			} else if (unReconciledRecords.getDataSourceName() == null) {
				logger.error(
						" No Data Source Name available for the record which has to be updated for case info. Collection Name: {},  OIDs: {}, Case Id: {}",
						unReconciledRecords.getCollectionName(), unReconciledRecords.getOIDs(),
						caseDetails.getCaseId());
			} else {
				final MongoTemplate mongoTemplate = tempMongoTemplateCache.get(unReconciledRecords.getDataSourceName());
				if (mongoTemplate == null) {
					logger.error("Due to missing database information, records can not be updated for case id.");
					continue;
				}
				final BulkOperations bulkOps = mongoTemplate.bulkOps(BulkMode.UNORDERED, HashMap.class,
						unReconciledRecords.getCollectionName());
				final Update update = Update.update(buildReconControlFiledName(activityName),
						buildCaseInfo(caseDetails, caseStatus));
				unReconciledRecords.getOIDs().stream().map(oID -> Query.query(new Criteria("_id").is(oID)))
						.forEach(query -> bulkOps.updateOne(query, update));
				bulkOps.execute();
			}
		}
	}

	private Object buildCaseInfo(SalesforceCaseDetails caseDetails, CaseStatus caseStatus) {
		return CaseInfo.builder().caseID(caseDetails.getCaseId())
				.status(caseStatus).build();  
	}

	private String buildReconControlFiledName(String activityName) {
		return RECONCTRLFIELDNAME + FIELD_NAME_SEPRATOR + activityName + FIELD_NAME_SEPRATOR + CASEINFOFIELDNAME;
	}
}
