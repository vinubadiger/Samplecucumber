package com.opus.optimus.offline.runtime.exception.casehandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opus.optimus.offline.config.casemanagement.CaseGetResponse;
import com.opus.optimus.offline.config.casemanagement.CasePriorityCountResponse;
import com.opus.optimus.offline.config.casemanagement.SalesforceAuthenticateResponse;
import com.opus.optimus.offline.config.casemanagement.SalesforceBulkCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseResponse;

/**
 * This class is the helper class to create/update/close the sales force case.
 */
@Component
public class SalesforceCaseHelper {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory.getLogger(SalesforceCaseHelper.class);

	/** The sales force authentication URL. */
	@Value ("${saleforce.authurl}")
	String salesForceAuthUlr;

	/** The sales force token. */
	@Value ("${saleforce.token}")
	String salesForceToken;

	/** The bulk create url. */
	@Value ("${salesforce.bulk.createcaseurl}")
	String bulkCreateUrl;

	/** The close case url. */
	@Value ("${saleforce.casecloseurl}")
	String closeCaseUrl;

	/** The get case url. */
	@Value ("${saleforce.getcaseurl}")
	String getCaseUrl;

	/** The get count url. */
	@Value ("${saleforce.getcasecount}")
	String getCountUrl;

	/** The Constant AUTHORIZATION. */
	private static final String AUTHORIZATION = "Authorization";

	/**
	 * Authenticate.
	 *
	 * @return the salesforce authenticate response
	 */
	public SalesforceAuthenticateResponse authenticate() {
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		final HttpEntity<String> request = new HttpEntity<>(salesForceToken, headers);
		final ResponseEntity<SalesforceAuthenticateResponse> response = buildRestTemplate().postForEntity(salesForceAuthUlr, request, SalesforceAuthenticateResponse.class);
		logger.info("Http Status Code for Sales force authentication: {} ", response.getStatusCodeValue());
		return response.getBody();
	}

	/**
	 * Method to create the bulk cases with or without child cases. results in multiple parent cases created in one go.
	 *
	 * @param bulkCreateRequest the bulk create request
	 * @param token the token
	 * @return Response - which will have details for each case including parent and child in the success list and error details if fails
	 */
	public SalesforceCaseResponse bulkCreate(final SalesforceBulkCaseRequest bulkCreateRequest, final String token) {
		if (StringUtils.isEmpty(token)){
			logger.error("Auth token can not be empty/null if you want create a case.");
			return SalesforceCaseResponse.builder().hasError(true).errorMessage("Auth token can not be empty/null").build();
		}
		// build headers
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTHORIZATION, buildAuthorizatioHeaderValue(token));
		return callSalesForceBulkPostAPI(bulkCreateRequest, bulkCreateUrl, headers);
	}

	/**
	 * Call sales force bulk post API.
	 *
	 * @param bulkCreateRequest the bulk create request
	 * @param bulkOperationUrl the bulk operation url
	 * @param headers the headers
	 * @return the salesforce case response
	 */
	private SalesforceCaseResponse callSalesForceBulkPostAPI(final SalesforceBulkCaseRequest bulkCreateRequest, final String bulkOperationUrl, final HttpHeaders headers) {
		// build the request
		HttpEntity<SalesforceBulkCaseRequest> request = new HttpEntity<>(bulkCreateRequest, headers);
		ResponseEntity<SalesforceCaseResponse> response = buildRestTemplate().postForEntity(bulkOperationUrl, request, SalesforceCaseResponse.class);
		logger.info("Http Status Code for Sales force bulk request: {} ", response.getStatusCodeValue());
		return response.getBody();
	}

	/**
	 * Call sales force bulk patch API.
	 *
	 * @param bulkCreateRequest the bulk create request
	 * @param bulkOperationUrl the bulk operation url
	 * @param headers the headers
	 * @return the salesforce case response
	 */
	private SalesforceCaseResponse callSalesForceBulkPatchAPI(final SalesforceBulkCaseRequest bulkCreateRequest, final String bulkOperationUrl, final HttpHeaders headers) {
		// build the request
		HttpEntity<SalesforceBulkCaseRequest> request = new HttpEntity<>(bulkCreateRequest, headers);
		return buildRestTemplateWithClientFactory().patchForObject(bulkOperationUrl, request, SalesforceCaseResponse.class);
	}

	/**
	 * Method to create a single case with or without child cases. Results in only one parent case created with this request.
	 *
	 * @param caseCreateRequest the case create request
	 * @param token the token
	 * @return Response - which will have one details for a case in the success list/ one error details if fails
	 */
	public SalesforceCaseResponse createCase(final SalesforceCaseRequest caseCreateRequest, final String token) {
		final List<SalesforceCaseRequest> records = new ArrayList<>(1);
		records.add(caseCreateRequest);
		final SalesforceBulkCaseRequest bulkCreateRequest = SalesforceBulkCaseRequest.builder().records(records).build();
		return bulkCreate(bulkCreateRequest, token);
	}

	/**
	 * Method to update the bulk cases with or without child cases. results in multiple cases updated in one go.
	 *
	 * @param bulkUpdateRequest the bulk update request
	 * @param token the token
	 * @return Response - which will have details for each case including parent and child in the success list and error details if fails
	 */
	public SalesforceCaseResponse bulkUpdate(final SalesforceBulkCaseRequest bulkUpdateRequest, final String token) {
		if (StringUtils.isEmpty(token)){
			logger.error("Auth token can not be empty/null if you want create a case.");
			return SalesforceCaseResponse.builder().hasError(true).errorMessage("Auth token can not be empty/null").build();
		}
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTHORIZATION, buildAuthorizatioHeaderValue(token));
		return callSalesForceBulkPatchAPI(bulkUpdateRequest, closeCaseUrl, headers);
	}

	/**
	 * Method to update a single case with or without child cases. Results in only one parent case updated with this request.
	 *
	 * @param caseUpdateRequest the case update request
	 * @param token the token
	 * @return Response - which will have one details for a case in the success list/ one error details if fails
	 */
	public SalesforceCaseResponse updateCase(final SalesforceCaseRequest caseUpdateRequest, final String token) {
		final List<SalesforceCaseRequest> records = new ArrayList<>(1);
		records.add(caseUpdateRequest);
		final SalesforceBulkCaseRequest bulkCreateRequest = SalesforceBulkCaseRequest.builder().records(records).build();
		return bulkUpdate(bulkCreateRequest, token);
	}

	/**
	 * Check if any of the case is send for update without case id.
	 *
	 * @param bulkUpdateRequest the bulk update request
	 * @return true, if successful
	 */
	boolean validateUpdateRequest(SalesforceBulkCaseRequest bulkUpdateRequest) {
		return bulkUpdateRequest.getRecords().stream().allMatch(caseRequest -> {
			boolean hasCaseId = StringUtils.isEmpty(caseRequest.getCaseId());
			if (caseRequest.getChildcases() == null || caseRequest.getChildcases().isEmpty()){
				return hasCaseId;
			} else{
				hasCaseId = hasCaseId && caseRequest.getChildcases().stream().anyMatch(childCase -> StringUtils.isEmpty(caseRequest.getCaseId()));
			}
			return hasCaseId;
		});
	}

	/**
	 * Builds the authorizatio header value.
	 *
	 * @param token the token
	 * @return the string
	 */
	private String buildAuthorizatioHeaderValue(String token) {
		return "OAuth " + token;
	}

	/**
	 * Get all the cases associated for a single recon activity on a particular date.
	 *
	 * @param token the token
	 * @param activity the activity
	 * @param transDate the trans date
	 * @param projectName the project name
	 * @param urlRecordsFrom the url records from
	 * @param urlRecordsTo the url records to
	 * @return the case list
	 */
	public CaseGetResponse getCaseList(String token, String activity, String transDate, String projectName, String urlRecordsFrom, String urlRecordsTo) {
		HttpEntity<CaseGetResponse> response = null;
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		headers.add(AUTHORIZATION, buildAuthorizatioHeaderValue(token));
		HttpEntity<?> entity = new HttpEntity<>(headers);
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(getCaseUrl).queryParam("urlProject", projectName).queryParam("urlActivity", activity).queryParam("urlDateOfTransaction", transDate).queryParam("urlRecordsFrom", urlRecordsFrom).queryParam("urlRecordsTo", urlRecordsTo);
		logger.debug("response from {}", builder.build(false).toUri());
		response = buildRestTemplate().exchange(builder.build(false).toUri(), HttpMethod.GET, entity, CaseGetResponse.class);
		return response.getBody();

	}

	/**
	 * Get open cases count by priority associated with every recon activity in a project.
	 *
	 * @param token the token
	 * @param activity the activity
	 * @param projectName the project name
	 * @param user the user
	 * @return the count
	 */
	public CasePriorityCountResponse getCount(String token, String activity, String projectName, String user) {
		HttpEntity<CasePriorityCountResponse> response = null;
		final HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.add(AUTHORIZATION, buildAuthorizatioHeaderValue(token));
		HttpEntity<?> entity = new HttpEntity<>(headers);
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(getCountUrl).queryParam("urlActivity", activity).queryParam("urlOwnerName", user).queryParam("urlProject", projectName);
		response = buildRestTemplate().exchange(builder.build(false).toUri(), HttpMethod.GET, entity, CasePriorityCountResponse.class);
		logger.debug("response from {}", response);
		return response.getBody();
	}

	
	private RestTemplate buildRestTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		registerMessageConverter(restTemplate);  
		return restTemplate;
	}
	
	private RestTemplate buildRestTemplateWithClientFactory() {
		HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		httpRequestFactory.setConnectionRequestTimeout(0);
		httpRequestFactory.setConnectTimeout(0);
		httpRequestFactory.setReadTimeout(0);
		RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
		registerMessageConverter(restTemplate);  
		return restTemplate;
	}

	/**
	 * This is very specific to Sales force integration API calls. The APIs are using rest template which should
	 * have a message converter register to convert the POJO to JSON for successful communication
	 * @param restTemplate
	 */
	private void registerMessageConverter(RestTemplate restTemplate) {
		final List<HttpMessageConverter<?>> messageConverters = restTemplate.getMessageConverters();
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		final MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(mapper);
		// Note: here we are making this converter to process any kind of response,
		// not only application/*json, which is the default behavior
		converter.setSupportedMediaTypes(Arrays.asList(MediaType.ALL));
		messageConverters.add(converter);
		restTemplate.setMessageConverters(messageConverters);
	}
}
