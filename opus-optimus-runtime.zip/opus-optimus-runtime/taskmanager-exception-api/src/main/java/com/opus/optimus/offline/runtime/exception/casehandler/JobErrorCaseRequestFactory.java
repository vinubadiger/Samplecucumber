package com.opus.optimus.offline.runtime.exception.casehandler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.eclipse.collections.api.multimap.list.MutableListMultimap;
import org.eclipse.collections.impl.factory.Multimaps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.config.casemanagement.Priority;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest;
import com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequestForSchedular;
import com.opus.optimus.offline.config.constants.Constants;
import com.opus.optimus.offline.config.recon.subtypes.CaseInfo.CaseStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.ErrorHandlerConstants;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.api.record.impl.RecordFactory;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.exception.utility.CaseTemplateResolverUtil;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;

/**
 * This is factory class to build the sales force API request as per the workflow type.(ETL, RECON)
 */
/**
 * @author Ram
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
@Component
public class JobErrorCaseRequestFactory {
	private static final Logger logger = LoggerFactory.getLogger(JobErrorCaseRequestFactory.class);

	public static final String DATA_INGESTION_ORIGIN = "Data Ingestion";
	public static final String DATA_INGESTION_ACTIVITY = "Data Ingestion - Operation";
	public static final String RECON_ORIGIN = "RECON";
	public static final String DEFAULT_KEY_FOR_SALESFORCE = "DEFAULT";
	public static final String DATE_FORMATE = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String CLOSE_CASE_STATUS = "Closed";

	@Autowired
	ReconCaseTemplateSevice reconCaseTemplateService;

	@Autowired
	CaseTemplateResolverUtil templateResolverUtil;

	RecordFactory recordFactory;

	private MutableListMultimap<String, ReconCaseTemplate> caseDescriptionTemplates = Multimaps.mutable.list.empty();

	/**
	 * Parent case creation for both ETL & Recon.
	 * 
	 * @param workflowType : Type of work flow .
	 * @param errorDetails : Error information object.
	 * @param jobInfo : Job information onject.
	 * @param errorFileLocation : Path of error file.
	 * @return : Parent case object.
	 */
	public SalesforceCaseRequest createParentCaseRequest(String workflowType, ErrorDetails errorDetails, JobInfo jobInfo, String errorFileLocation) {
		// create parent case request
		if (StepTypeConstants.RECON_WORKFLOW_TYPE.equalsIgnoreCase(workflowType)){
			final String reconStatus = getReconStatus(errorDetails);
			// get case description template
			final ReconCaseTemplate parentCaseDescriptionTemplate = getCaseDescriptionTemplate(workflowType, reconStatus, true);
			return reconParentCaseRequest(errorDetails, parentCaseDescriptionTemplate, jobInfo, errorFileLocation);
		} else if (StepTypeConstants.ETL_WORKFLOW_TYPE.equalsIgnoreCase(workflowType)){
			// get case description template
			final ReconCaseTemplate parentCaseDescriptionTemplate = getCaseDescriptionTemplate(workflowType, (errorDetails.getSeverity() == null ? Severity.ERROR.toString() : errorDetails.getSeverity().toString()), true);
			return etlParentCaseRequest(errorDetails, parentCaseDescriptionTemplate, jobInfo, errorFileLocation);
		} else{
			logger.error("Not supported workflow type for parent case creation : {}", workflowType);
			return null;
		}
	}

	private String getReconStatus(ErrorDetails errorDetails) {
		if (errorDetails.getAdditionalData() == null){
			return "Default";
		} else{
			return (errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_STATUS_KEY) == null ? "Default" : ((ReconSubStatus) errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_STATUS_KEY)).toString());
		}
	}

	/**
	 * Sub case creation for both ETL & Recon.
	 * 
	 * @param workflowType : Type of work flow .
	 * @param errorDetails : Error information object.
	 * @param jobInfo : Job information onject.
	 * @param sourceReference
	 * @return : Sub case object.
	 */
	public SalesforceCaseRequest createSubCaseRequest(String workflowType, ErrorDetails errorDetails, JobInfo jobInfo, ISourceReference sourceReference) {
		// create sub case request
		if (StepTypeConstants.RECON_WORKFLOW_TYPE.equalsIgnoreCase(workflowType)){
			final String reconStatus = (errorDetails.getSeverity() == null || Severity.ERROR.equals(errorDetails.getSeverity())) ? getReconStatus(errorDetails) : errorDetails.getSeverity().toString();
			// get case description template
			final ReconCaseTemplate subCaseDescriptionTemplate = getCaseDescriptionTemplate(workflowType, reconStatus, false);
			return reconSubCaseRequest(errorDetails, subCaseDescriptionTemplate, jobInfo);
		} else if (StepTypeConstants.ETL_WORKFLOW_TYPE.equalsIgnoreCase(workflowType)){
			// get case description template
			final ReconCaseTemplate subCaseDescriptionTemplate = getCaseDescriptionTemplate(workflowType, (errorDetails.getSeverity() == null ? Severity.ERROR.toString() : errorDetails.getSeverity().toString()), false);
			return etlSubCaseRequest(errorDetails, subCaseDescriptionTemplate, jobInfo, sourceReference);
		} else{
			logger.error("Not supported workflow type for sub case creation : {}", workflowType);
			return null;
		}
	}

	/**
	 * Request object of Recon parent case creation
	 * 
	 * @param errorDetails : Error information object.
	 * @param caseDescriptionTemplate : Case creation velocity template.
	 * @param jobInfo : Job related information object.
	 * @param errorFileLocation : Complete path of error file.
	 * @return : Request object.
	 */
	private SalesforceCaseRequest reconParentCaseRequest(ErrorDetails errorDetails, ReconCaseTemplate caseDescriptionTemplate, JobInfo jobInfo, String errorFileLocation) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		final Object activityName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY);
		final Object sourceAName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY);
		final Object sourceBName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY);
		final Object sourceANoMatchCnt = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_SOURCE_A_ALL_NOMATCH_CNT_KEY);
		final Object sourceBNoMatchCnt = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_SOURCE_B_ALL_NOMATCH_CNT_KEY);
		final Object isAllNoMatchCase = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_IS_ALL_NOMATCH_CASE_KEY);

		caseRequestBuilder.activity(activityName == null ? StringUtils.EMPTY : (String) activityName);
		caseRequestBuilder.caseId(StringUtils.EMPTY);
		caseRequestBuilder.comment(StringUtils.EMPTY);
		caseRequestBuilder.contactName(StringUtils.EMPTY);
		caseRequestBuilder.contactSkypeName(StringUtils.EMPTY);
		caseRequestBuilder.systemErrorType(Severity.ERROR);
		caseRequestBuilder.origin(RECON_ORIGIN);
		caseRequestBuilder.priority(Priority.MEDIUM);
		caseRequestBuilder.project(jobInfo.getProjectName());
		caseRequestBuilder.reasonCode(StringUtils.EMPTY);
		caseRequestBuilder.referenceId(generateCaseRefId());
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject("Unreconciled result identified in " + activityName);

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTIVITY_NAME, activityName == null ? StringUtils.EMPTY : (String) activityName);
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_A, sourceAName == null ? StringUtils.EMPTY : (String) sourceAName);
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_B, sourceBName == null ? StringUtils.EMPTY : (String) sourceBName);
		variables.put(ErrorHandlerConstants.ERROR_FILE_PATH, errorFileLocation);
		if (caseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(caseDescriptionTemplate, variables));
		}
		// For All No Match scenario to raise the CMS alert
		if (isAllNoMatchCase != null && (Boolean) isAllNoMatchCase){
			int srcANoMatchCnt = sourceANoMatchCnt == null ? 0 : (Integer) sourceANoMatchCnt;
			int srcBNoMatchCnt = sourceBNoMatchCnt == null ? 0 : (Integer) sourceBNoMatchCnt;
			caseRequestBuilder.errorCounts(srcANoMatchCnt > srcBNoMatchCnt ? srcANoMatchCnt : srcBNoMatchCnt);
		}
		return caseRequestBuilder.build();
	}

	/**
	 * Request object of ETL parent case creation
	 * 
	 * @param errorDetails : Error information object.
	 * @param caseDescriptionTemplate : Case creation velocity template.
	 * @param jobInfo : Job related information object.
	 * @param errorFileLocation : Complete path of error file.
	 * @return : Request object.
	 */
	private SalesforceCaseRequest etlParentCaseRequest(ErrorDetails errorDetails, ReconCaseTemplate caseDescriptionTemplate, JobInfo jobInfo, String errorFileLocation) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		final Object activityName = jobInfo.getWorkflowName();

		caseRequestBuilder.job_ID(jobInfo.getId());
		caseRequestBuilder.activity(activityName == null ? StringUtils.EMPTY : (String) activityName);
		caseRequestBuilder.caseId(StringUtils.EMPTY);
		caseRequestBuilder.comment(StringUtils.EMPTY);
		caseRequestBuilder.contactName(StringUtils.EMPTY);
		caseRequestBuilder.contactSkypeName(StringUtils.EMPTY);
		caseRequestBuilder.systemErrorType(errorDetails.getSeverity());
		caseRequestBuilder.origin(DATA_INGESTION_ORIGIN);
		caseRequestBuilder.priority(Priority.MEDIUM);
		caseRequestBuilder.project(jobInfo.getProjectName());
		caseRequestBuilder.reasonCode(StringUtils.EMPTY);
		caseRequestBuilder.referenceId(generateCaseRefId());
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject("DI - " + jobInfo.getProjectName() + " - " + jobInfo.getWorkflowName() + " At: " + jobInfo.getStartedTime());
		caseRequestBuilder.machineServerDetails(StringUtils.EMPTY);

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTIVITY_NAME, activityName == null ? StringUtils.EMPTY : (String) activityName);
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.ERROR_FILE_PATH, errorFileLocation);
		if (caseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(caseDescriptionTemplate, variables));
		}
		return caseRequestBuilder.build();

	}

	/**
	 * Request object of Recon sub case creation
	 * 
	 * @param errorDetails : Error information object.
	 * @param caseDescriptionTemplate : Case creation velocity template.
	 * @param jobInfo : Job related information object.
	 * @return : Request object.
	 */
	private SalesforceCaseRequest reconSubCaseRequest(ErrorDetails errorDetails, ReconCaseTemplate caseDescriptionTemplate, JobInfo jobInfo) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		final Object activityName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY);
		final Object isAllNoMatchCase = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_IS_ALL_NOMATCH_CASE_KEY);
		final Object reconStatus = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_STATUS_KEY);
		final Object reconProcDateString = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_PROC_DATE_KEY);

		caseRequestBuilder.activity(activityName == null ? StringUtils.EMPTY : (String) activityName);
		caseRequestBuilder.caseId(StringUtils.EMPTY);
		caseRequestBuilder.comment(StringUtils.EMPTY);
		caseRequestBuilder.contactName(StringUtils.EMPTY);
		caseRequestBuilder.contactSkypeName(StringUtils.EMPTY);
		caseRequestBuilder.systemErrorType(Severity.ERROR);
		caseRequestBuilder.origin(RECON_ORIGIN);
		caseRequestBuilder.priority(Priority.MEDIUM);
		caseRequestBuilder.project(jobInfo.getProjectName());
		if (isAllNoMatchCase != null && (Boolean) isAllNoMatchCase){
			caseRequestBuilder.reasonCode("All No Match Exceptions");
			final StringBuilder allNoMatchCaseSubject = new StringBuilder();
			allNoMatchCaseSubject.append("All No-Match exceptions identified in ");
			allNoMatchCaseSubject.append(activityName);
			allNoMatchCaseSubject.append(" for ");
			allNoMatchCaseSubject.append((reconProcDateString == null ? StringUtils.EMPTY : reconProcDateString));
			caseRequestBuilder.subject(allNoMatchCaseSubject.toString());
		} else{
			caseRequestBuilder.reasonCode(reconStatus == null ? StringUtils.EMPTY : ((ReconSubStatus) reconStatus).name());
			caseRequestBuilder.subject((reconStatus == null ? "Unreconciled" : ((ReconSubStatus) reconStatus).name()) + " result identified in " + activityName);
		}
		caseRequestBuilder.referenceId(generateCaseRefId());
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.systemErrorMessage((errorDetails.getErrorDetail() == null ? StringUtils.EMPTY : errorDetails.getErrorDetail().toString()));
		caseRequestBuilder.machineServerDetails(StringUtils.EMPTY);
		caseRequestBuilder.exceptionDateTime(getDateTime());

		final Map<String, Object> variables = loadDataForDescriptionTemplate(jobInfo, errorDetails, activityName, reconStatus, isAllNoMatchCase);
		if (caseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(caseDescriptionTemplate, variables));
		}
		caseRequestBuilder.job_ID(jobInfo.getId());
		caseRequestBuilder.project(jobInfo.getProjectName());
		return caseRequestBuilder.build();
	}

	private Map<String, Object> loadDataForDescriptionTemplate(JobInfo jobInfo, ErrorDetails errorDetails, final Object activityName, final Object reconStatus, final Object isAllNoMatchCase) {
		final Object sourceAName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY);
		final Object sourceBName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY);
		final Object actualTolerance = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_TOLERANCE_KEY);
		final Object sourceANoMatchCnt = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_SOURCE_A_ALL_NOMATCH_CNT_KEY);
		final Object sourceBNoMatchCnt = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_SOURCE_B_ALL_NOMATCH_CNT_KEY);
		final Object configuredTolerance = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_CONF_TOLERANCE_KEY);
		final Object uniqueReconRefId = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_RECON_UUID_KEY);

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTIVITY_NAME, activityName == null ? StringUtils.EMPTY : (String) activityName);
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.TEMPLATE_RECON_STATUS, reconStatus == null ? StringUtils.EMPTY : ((ReconSubStatus) reconStatus).name());
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_A, sourceAName == null ? StringUtils.EMPTY : (String) sourceAName);
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_A_NOMATCH_CNT, sourceANoMatchCnt == null ? 0 : (Integer) sourceANoMatchCnt);
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_B_NOMATCH_CNT, sourceBNoMatchCnt == null ? 0 : (Integer) sourceBNoMatchCnt);
		/*
		 * variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_A_TRANS,buildTransactionDetails(sourceAName, recordIds)) Discussed with Ram sir, not
		 * required for now
		 */
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_B, sourceBName == null ? StringUtils.EMPTY : (String) sourceBName);
		/*
		 * variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_B_TRANS,buildTransactionDetails(sourceBName, recordIds)) Discussed with Ram sir, not
		 * required for now
		 */
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTUAL_VARIANCE, actualTolerance == null ? null : (Double) actualTolerance);
		if (isAllNoMatchCase != null && (Boolean) isAllNoMatchCase){
			variables.put(ErrorHandlerConstants.TEMPLATE_ALL_NOMATCH_CASE, true);
		}
		variables.put(ErrorHandlerConstants.TEMPLATE_CONFIGURED_VARIANCE, configuredTolerance);
		variables.put(ErrorHandlerConstants.TEMPLATE_RECON_REC_UUID, uniqueReconRefId);
		return variables;
	}

	/**
	 * Request object of ETL sub case creation
	 * 
	 * @param errorDetails : Error information object.
	 * @param caseDescriptionTemplate : Case creation velocity template.
	 * @param jobInfo : Job related information object.
	 * @param sourceReference
	 * @return : Request object.
	 */
	private SalesforceCaseRequest etlSubCaseRequest(ErrorDetails errorDetails, ReconCaseTemplate caseDescriptionTemplate, JobInfo jobInfo, ISourceReference sourceReference) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		final Object userdetails = errorDetails.getUserDetails();
		final Object source = jobInfo.getWorkflowName();
		String reasonCode = getReasonCodes(getErrorCode(errorDetails));

		caseRequestBuilder.job_ID(jobInfo.getId());
		caseRequestBuilder.typeOfSource(StringUtils.EMPTY);
		caseRequestBuilder.activity(source == null ? StringUtils.EMPTY : (String) source);
		caseRequestBuilder.caseId(StringUtils.EMPTY);
		caseRequestBuilder.comment(StringUtils.EMPTY);
		caseRequestBuilder.contactName(StringUtils.EMPTY);
		caseRequestBuilder.contactSkypeName(StringUtils.EMPTY);
		caseRequestBuilder.systemErrorType(errorDetails.getSeverity());
		caseRequestBuilder.origin(DATA_INGESTION_ORIGIN);
		caseRequestBuilder.priority(Priority.MEDIUM);
		caseRequestBuilder.project(jobInfo.getProjectName());
		caseRequestBuilder.reasonCode(reasonCode == null ? StringUtils.EMPTY : reasonCode);
		caseRequestBuilder.referenceId(generateCaseRefId());
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject("DI - " + reasonCode + " - In :" + jobInfo.getProjectName() + " Under workflow :" + jobInfo.getWorkflowName());
		caseRequestBuilder.fileDBDetails(getFileOrDbName(sourceReference).toString());
		caseRequestBuilder.systemErrorMessage((errorDetails.getErrorDetail() == null ? StringUtils.EMPTY : errorDetails.getErrorDetail().toString()));
		caseRequestBuilder.machineServerDetails(StringUtils.EMPTY);
		caseRequestBuilder.exceptionDateTime(getDateTime());

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTIVITY_NAME, userdetails == null ? StringUtils.EMPTY : (String) userdetails);
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.ERROR_EXCEPTION_TYPE, ((Throwable) errorDetails.getErrorDetail()).getClass().getSimpleName());
		if (caseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(caseDescriptionTemplate, variables));
		}
		return caseRequestBuilder.build();
	}

	/**
	 * For getting valid reason code from step
	 * 
	 * @param reasonCode : Error code
	 * @return : reason for given code
	 */
	private String getReasonCodes(String reasonCode) {
		if (ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		} else if (com.opus.optimus.offline.runtime.common.validator.exception.ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return com.opus.optimus.offline.runtime.common.validator.exception.ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		} else if (com.opus.optimus.offline.runtime.common.transformer.util.ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return com.opus.optimus.offline.runtime.common.transformer.util.ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		} else if (com.opus.optimus.offline.runtime.common.writer.exception.ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return com.opus.optimus.offline.runtime.common.writer.exception.ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		}

		return "";
	}

	/**
	 * Return DateTime with format
	 * 
	 * @return
	 */
	private String getDateTime() {
		SimpleDateFormat ft = new SimpleDateFormat(DATE_FORMATE);
		return ft.format(new Date());
	}

	/**
	 * Return the reason code
	 * 
	 * @param errorDetails : error related information
	 * @return : Reason code
	 */
	private String getErrorCode(ErrorDetails errorDetails) {
		if (errorDetails.getErrorDetail() != null && ReaderException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())){
			return ((ReaderException) errorDetails.getErrorDetail()).getErrorCode();
		} else if (errorDetails.getErrorDetail() != null && RecordProcessingException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())){
			return ((RecordProcessingException) errorDetails.getErrorDetail()).getErrorCode();
		}
		return DEFAULT_KEY_FOR_SALESFORCE;
	}

	/**
	 * Function to gave file name or used DB name.
	 * 
	 * @param sourceReference : Source related information.
	 * @return For file, file name will be return. For DB, DB Collection will return.
	 */
	private Object getFileOrDbName(ISourceReference sourceReference) {
		if (sourceReference == null){
			logger.error("sourceReference if null");
			return "sourceReference if null";
		} else if (FileSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			return ((FileSourceReference) sourceReference).getFileName();
		} else if (DBSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			return ((DBSourceReference) sourceReference).getCollectionName();
		} else{
			logger.error("Not supported source referance");
			return "Not supported source referance";
		}
	}

	/**
	 * Generates random id.
	 * 
	 * @return : Random id
	 */
	private String generateCaseRefId() {
		return UUID.randomUUID().toString();
	}

	/**
	 * For creating body template for case creation
	 * 
	 * @param caseDescriptionTemplate : velocity syntax template
	 * @param variables : required parameters for velocity template
	 * @return : Complete string body of case creation.
	 */
	private String resolveDescTemplate(ReconCaseTemplate caseDescriptionTemplate, Map<String, Object> variables) {
		return templateResolverUtil.resolve(caseDescriptionTemplate.getTemplates(), variables);
	}

	@SuppressWarnings ("unused")
	private String buildTransactionDetails(Object sourceName, IRecord record) {
		if (sourceName == null || record == null){
			return StringUtils.EMPTY;
		}
		final StringBuilder sourceTransaction = new StringBuilder();
		recordFactory.getSchema((String) sourceName).getFields().stream().forEach(fieldSchema -> {
			sourceTransaction.append(fieldSchema.getName());
			sourceTransaction.append(":");
			sourceTransaction.append((Object) record.getValue(record.getFieldId(fieldSchema.getName())));
		});
		return sourceTransaction.toString();
	}

	/**
	 * Create the fatal case request populated with required fields
	 * 
	 * @param workflowType
	 * @param errorDetails
	 * @param jobInfo
	 * @param errorFileLocation
	 * @return
	 */
	public SalesforceCaseRequest createFatalCaseRequest(String workflowType, ErrorDetails errorDetails, JobInfo jobInfo, String errorFileLocation) {
		// get case description template
		final ReconCaseTemplate fatalCaseDescriptionTemplate = getCaseDescriptionTemplate(workflowType, errorDetails.getSeverity().toString(), false);
		// create parent case request
		if (StepTypeConstants.RECON_WORKFLOW_TYPE.equalsIgnoreCase(workflowType)){
			return reconFatalCaseRequest(errorDetails, fatalCaseDescriptionTemplate, jobInfo, errorFileLocation);
		} else if (StepTypeConstants.ETL_WORKFLOW_TYPE.equalsIgnoreCase(workflowType)){
			return etlFatalCaseRequest(errorDetails, fatalCaseDescriptionTemplate, jobInfo);
		} else{
			logger.error("Not supported workflow type for parent case creation : {}", workflowType);
			return null;
		}
	}

	/**
	 * For getting case creation velocity template from DB by workflow type and provided recon status.
	 * 
	 * @param workflowType : Current Work flow type.
	 * @param reconStatus : the recon status. In case of FATAL error, case template will be searched for recon_status=FATAL In case of error code wise
	 *            template, recon_status value would be referred as error code from ErrorDetails if any
	 * @param parent : Boolean value true -> parent case OR false -> sub case.
	 * @return : velocity template.
	 */
	private ReconCaseTemplate getCaseDescriptionTemplate(String workflowType, String reconStatus, boolean parent) {
		List<ReconCaseTemplate> caseTemplates = caseDescriptionTemplates.get(workflowType);
		if (caseTemplates == null || caseTemplates.isEmpty()){
			/* Need to implement for find by workflow type and recon sub status for Recon */
			final List<ReconCaseTemplate> workflowTypeCaseTemplates = reconCaseTemplateService.find(workflowType);
			caseDescriptionTemplates.putAll(workflowType, workflowTypeCaseTemplates);
			caseTemplates = caseDescriptionTemplates.get(workflowType);
		}
		final Optional<
						ReconCaseTemplate> parentCaseTemplateOptional = caseTemplates.stream().filter(caseTemplate -> parent ? caseTemplate.isMasterCase() : (!caseTemplate.isMasterCase() && caseTemplate.getRecon_status() != null && caseTemplate.getRecon_status().equalsIgnoreCase(reconStatus))).findFirst();

		if (parentCaseTemplateOptional.isPresent()){
			return parentCaseTemplateOptional.get();
		} else{
			logger.error("No case template available in DB for Workflow type: {}, Recon Status: {}", workflowType, reconStatus);
			return null;
		}
	}

	private SalesforceCaseRequest etlFatalCaseRequest(ErrorDetails errorDetails, ReconCaseTemplate fatalCaseDescriptionTemplate, JobInfo jobInfo) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = buildCaseRequestBuilderWithBlankValues();
		final String reasonCode = "Etl Job Failed";

		caseRequestBuilder.activity(jobInfo.getWorkflowName());
		caseRequestBuilder.systemErrorType(errorDetails.getSeverity());
		caseRequestBuilder.origin(DATA_INGESTION_ORIGIN);
		caseRequestBuilder.priority(Priority.MEDIUM);
		caseRequestBuilder.project(jobInfo.getProjectName());
		caseRequestBuilder.reasonCode(reasonCode);
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject("FATAL error occured in " + jobInfo.getProjectName() + "-" + jobInfo.getWorkflowName());
		caseRequestBuilder.job_ID(jobInfo.getId());

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTIVITY_NAME, jobInfo.getWorkflowName());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.TEMPLATE_MESSAGE, errorDetails.getUserDetails());
		if (fatalCaseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(fatalCaseDescriptionTemplate, variables));
		}
		return caseRequestBuilder.build();
	}

	private SalesforceCaseRequest reconFatalCaseRequest(ErrorDetails errorDetails, ReconCaseTemplate fatalCaseDescriptionTemplate, JobInfo jobInfo, String errorFileLocation) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = buildCaseRequestBuilderWithBlankValues();
		final Object activityName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_ACTIVITY_NAME_KEY);
		final Object sourceAName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_SOURCE_A_NAME_KEY);
		final Object sourceBName = errorDetails.getAdditionalData().get(ErrorHandlerConstants.ERR_SOURCE_B_NAME_KEY);
		final String reasonCode = "Recon Job Failed";

		caseRequestBuilder.activity(activityName == null ? StringUtils.EMPTY : (String) activityName);
		caseRequestBuilder.systemErrorType(errorDetails.getSeverity());
		caseRequestBuilder.origin(RECON_ORIGIN);
		caseRequestBuilder.priority(Priority.HIGH);
		caseRequestBuilder.project(jobInfo.getProjectName());
		caseRequestBuilder.reasonCode(reasonCode);
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject("FATAL error occured in " + activityName);

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_ACTIVITY_NAME, activityName == null ? StringUtils.EMPTY : (String) activityName);
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_A, sourceAName == null ? StringUtils.EMPTY : (String) sourceAName);
		variables.put(ErrorHandlerConstants.TEMPLATE_SOURCE_B, sourceBName == null ? StringUtils.EMPTY : (String) sourceBName);
		variables.put(ErrorHandlerConstants.TEMPLATE_MESSAGE, errorDetails.getUserDetails());
		variables.put(ErrorHandlerConstants.ERROR_FILE_PATH, errorFileLocation);
		if (fatalCaseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(fatalCaseDescriptionTemplate, variables));
		}
		return caseRequestBuilder.build();
	}

	/**
	 * Create the builder with possible blank values and unique reference id assigned
	 * 
	 * @return
	 */
	private com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder buildCaseRequestBuilderWithBlankValues() {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		caseRequestBuilder.activity(StringUtils.EMPTY);
		caseRequestBuilder.caseId(StringUtils.EMPTY);
		caseRequestBuilder.comment(StringUtils.EMPTY);
		caseRequestBuilder.contactName(StringUtils.EMPTY);
		caseRequestBuilder.contactSkypeName(StringUtils.EMPTY);
		caseRequestBuilder.origin(StringUtils.EMPTY);
		caseRequestBuilder.project(StringUtils.EMPTY);
		caseRequestBuilder.reasonCode(StringUtils.EMPTY);
		caseRequestBuilder.referenceId(generateCaseRefId());
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject(StringUtils.EMPTY);
		return caseRequestBuilder;
	}

	/**
	 * @param workflowType
	 * @param errorDetails
	 * @param jobInfo
	 * @return
	 */
	public SalesforceCaseRequest createErrorCodeWiseCaseRequest(String workflowType, ErrorDetails errorDetails, JobInfo jobInfo) {
		// get the error code from the error details
		String errorCode = (String) errorDetails.getAdditionalData().get(Constants.ERROR_CODE);
		// get case description template
		final ReconCaseTemplate fatalCaseDescriptionTemplate = getCaseDescriptionTemplate(workflowType, errorCode, false);
		// create parent case request
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = buildCaseRequestBuilderWithBlankValues();

		caseRequestBuilder.systemErrorType(errorDetails.getSeverity());
		caseRequestBuilder.origin(workflowType);
		caseRequestBuilder.priority(Priority.MEDIUM);
		caseRequestBuilder.project(jobInfo.getProjectName());
		caseRequestBuilder.reasonCode(errorCode);
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.subject("Error occured in " + jobInfo.getProjectName() + "-" + jobInfo.getWorkflowName());

		final Map<String, Object> variables = new HashMap<>();
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_ID, jobInfo.getId());
		variables.put(ErrorHandlerConstants.TEMPLATE_JOB_DATE, jobInfo.getStartedTime());
		variables.put(ErrorHandlerConstants.TEMPLATE_MESSAGE, errorDetails.getUserDetails());
		if (fatalCaseDescriptionTemplate != null){
			caseRequestBuilder.description(resolveDescTemplate(fatalCaseDescriptionTemplate, variables));
		}
		return caseRequestBuilder.build();
	}

	public SalesforceCaseRequest createCloseCaseRequest(String caseId, String comment) {
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		caseRequestBuilder.caseId(caseId);
		caseRequestBuilder.referenceId(generateCaseRefId());
		caseRequestBuilder.status(CLOSE_CASE_STATUS);
		caseRequestBuilder.comment(comment);
		return caseRequestBuilder.build();
	}

	/**
	 * Method which return SalesforceCaseRequest Object, used by scheduler module.
	 * 
	 * @param reasonCode
	 * @param projectName
	 * @param workflowName
	 * @param priority
	 * @param uuid
	 * @return
	 */
	public SalesforceCaseRequest createPlainSalesForceReqObjForSchedular(SalesforceCaseRequestForSchedular salesforceCaseRequestForSchedular) {
		// created plain Obj with all require fields
		List<SalesforceCaseRequest> childcases = new ArrayList<>();
		UUID uuid = UUID.randomUUID();
		final com.opus.optimus.offline.config.casemanagement.SalesforceCaseRequest.SalesforceCaseRequestBuilder caseRequestBuilder = SalesforceCaseRequest.builder();
		caseRequestBuilder.referenceId(uuid.toString());
		caseRequestBuilder.origin(DATA_INGESTION_ORIGIN);
		caseRequestBuilder.status(CaseStatus.OPEN.name());
		caseRequestBuilder.systemErrorType(Severity.ERROR);
		caseRequestBuilder.activity(DATA_INGESTION_ACTIVITY);
		caseRequestBuilder.childcases(childcases);
		caseRequestBuilder.exceptionDateTime(getDateTime());

		// Added From scheduler object
		caseRequestBuilder.reasonCode(salesforceCaseRequestForSchedular.getReasonCode());
		caseRequestBuilder.description(salesforceCaseRequestForSchedular.getDescription());
		caseRequestBuilder.subject(salesforceCaseRequestForSchedular.getSubject());
		caseRequestBuilder.project(salesforceCaseRequestForSchedular.getProject());
		caseRequestBuilder.priority(salesforceCaseRequestForSchedular.getPriority());
		caseRequestBuilder.fileDBDetails(salesforceCaseRequestForSchedular.getFileDBDetails());

		return caseRequestBuilder.build();
	}

}
