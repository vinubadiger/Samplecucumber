package com.opus.optimus.offline.runtime.exception.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.common.reader.config.FileSourceReference;
import com.opus.optimus.offline.runtime.common.reader.exception.DbReaderException;
import com.opus.optimus.offline.runtime.common.reader.exception.ExceptionCodes;
import com.opus.optimus.offline.runtime.common.reader.exception.ReaderException;
import com.opus.optimus.offline.runtime.common.writer.exception.WriterException;
import com.opus.optimus.offline.runtime.exception.repository.JobErrorDetails.JobErrorDetailsBuilder;
import com.opus.optimus.offline.runtime.workflow.api.IJobTaskInfo;
import com.opus.optimus.offline.runtime.workflow.api.ISourceReference;
import com.opus.optimus.offline.runtime.workflow.api.impl.RecordProcessingException;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;

/**
 * This class is used for building the error details and job error details. Also for fetching the job error details from DB based on jobId
 * 
 * @author Anup.Warke
 * @author Yashkumar.Thakur
 */
@Component
public class JobErrorDetailsServiceImpl implements IJobErrorDetailsService {
	@Autowired
	JobErrorDetailsRepository errorDetailsLogRepository;

	public static final String DEFAULT_CONSTANT = "DEFAULT";
	public static final String DEFAULT_ERROR = "Unhandled reason message, Please contact to Developer!";
	public static final String DEFAULT_RECORD_NOT_FOUND = "Record Not available !";

	@Override
	public JobErrorDetails logErrorDetails(ErrorDetails errorDetails, ISourceReference sourceReference, IJobTaskInfo jobTaskInfo) {
		return buildJobErrorDetailsToLog(errorDetails, sourceReference, jobTaskInfo);
	}

	/**
	 * This method is used build the job error details.
	 * 
	 * @param errorDetails - The name which holds information of Error Details
	 * @param sourceReference - The name which holds information of Source reference
	 * @param jobTaskInfo - The name which holds information of job task
	 * @return JobErrorDetails - The name which holds information of job error details
	 */
	private JobErrorDetails buildJobErrorDetailsToLog(ErrorDetails errorDetails, ISourceReference sourceReference, IJobTaskInfo jobTaskInfo) {
		// JobErrorDetailsBuilder builder
		JobErrorDetailsBuilder errorDetailsBuilder = JobErrorDetails.builder().jobId(jobTaskInfo == null ? null : jobTaskInfo.getJobId()).errorType(errorDetails.getSeverity().name()).caseId(errorDetails.getCaseId());

		// Get Row Index, Raw Record from file & DB
		if (sourceReference != null && FileSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			final FileSourceReference fileSourceReference = (FileSourceReference) sourceReference;
			errorDetailsBuilder.additionalDetails("File Name :" + fileSourceReference.getFileName());
			errorDetailsBuilder.rowIndex(fileSourceReference.getRowIndex()).rawRecordData(fileSourceReference.getRawRecordData() != null ? fileSourceReference.getRawRecordData() : DEFAULT_RECORD_NOT_FOUND);
		} else if (sourceReference != null && DBSourceReference.class.isAssignableFrom(sourceReference.getClass())){
			final DBSourceReference dBSourceReference = (DBSourceReference) sourceReference;
			errorDetailsBuilder.additionalDetails("Collection Name :" + dBSourceReference.getCollectionName() + "DataSource Name :" + dBSourceReference.getDataSourceName());
			errorDetailsBuilder.rowIndex(dBSourceReference.getRowIndex()).rawRecordData(dBSourceReference.getRawRecordData() != null ? dBSourceReference.getRawRecordData().toString() : DEFAULT_RECORD_NOT_FOUND);
		} else{
			errorDetailsBuilder.additionalDetails("Additinal details are not available !");
			errorDetailsBuilder.rowIndex(0).rawRecordData("Raw record information not available");
		}

		// To Get Reason Code and Reason
		if (errorDetails.getErrorDetail() != null && ReaderException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())){
			String reasonCode = ((ReaderException) errorDetails.getErrorDetail()).getErrorCode();
			buildErrorDetailsBuilder(errorDetailsBuilder, errorDetails, reasonCode);
		} else if (errorDetails.getErrorDetail() != null && RecordProcessingException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())){
			String reasonCode = ((RecordProcessingException) errorDetails.getErrorDetail()).getErrorCode();
			buildErrorDetailsBuilder(errorDetailsBuilder, errorDetails, reasonCode);
		} else if (errorDetails.getErrorDetail() != null && DbReaderException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())){
			String reasonCode = ((DbReaderException) errorDetails.getErrorDetail()).getErrorCode();
			buildErrorDetailsBuilder(errorDetailsBuilder, errorDetails, reasonCode);
		} else if (errorDetails.getErrorDetail() != null && WriterException.class.isAssignableFrom(errorDetails.getErrorDetail().getClass())){
			String reasonCode = ((WriterException) errorDetails.getErrorDetail()).getErrorCode();
			buildErrorDetailsBuilder(errorDetailsBuilder, errorDetails, reasonCode);
		} else{
			errorDetailsBuilder.errorMessage(getErrorMessage(errorDetails));
			errorDetailsBuilder.reasonCode(DEFAULT_CONSTANT + "Error Details Of type : " + errorDetails.getClass());
			errorDetailsBuilder.reason(getReason(DEFAULT_CONSTANT));
		}
		return errorDetailsBuilder.build();
	}

	/**
	 * For building error message
	 * 
	 * @param errorDetailsBuilder : response object.
	 * @param errorDetails : Error object
	 * @param reasonCode : reason code of specific error
	 */
	private void buildErrorDetailsBuilder(JobErrorDetailsBuilder errorDetailsBuilder, ErrorDetails errorDetails, String reasonCode) {
		errorDetailsBuilder.errorMessage(getErrorMessage(errorDetails));
		errorDetailsBuilder.reasonCode(reasonCode);
		errorDetailsBuilder.reason(getReason(reasonCode));
	}

	/**
	 * For build error message
	 * 
	 * @param errorDetails
	 * @return
	 */
	private String getErrorMessage(ErrorDetails errorDetails) {
		StringBuilder errorMessage = new StringBuilder();
		errorMessage.append("Exception while running job, ");
		errorMessage.append("Exception Message: " + errorDetails.getUserDetails() + " ");
		errorMessage.append("Exception Details: " + errorDetails.getErrorDetail());
		return errorMessage.toString();
	}

	/**
	 * For getting valid reason code from step
	 * 
	 * @param reasonCode : Error code
	 * @return : reason for given code
	 */
	private String getReason(String reasonCode) {
		if (ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		} else if (com.opus.optimus.offline.runtime.common.validator.exception.ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return com.opus.optimus.offline.runtime.common.validator.exception.ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		} else if (com.opus.optimus.offline.runtime.common.transformer.util.ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return com.opus.optimus.offline.runtime.common.transformer.util.ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		} else if (com.opus.optimus.offline.runtime.common.writer.exception.ExceptionCodes.CASE_REASON_CODE.containsKey(reasonCode)){
			return com.opus.optimus.offline.runtime.common.writer.exception.ExceptionCodes.CASE_REASON_CODE.get(reasonCode);
		}
		return reasonCode.equalsIgnoreCase(DEFAULT_CONSTANT) ? DEFAULT_ERROR : reasonCode;
	}

	@Override
	public List<JobErrorDetails> getjobErrorDetails(String jobId) {
		return errorDetailsLogRepository.findByjobId(jobId);
	}
}
