package com.opus.optimus.offline.runtime.taskmanager.api;

import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;

public interface ITaskExecutorFactory {
    ITaskExecutor newTaskExecutor(String jobId, JobTask jobTask);
}
