package com.opus.optimus.offline.runtime.taskmanager.api;

import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobIdException;
import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobStatusException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobInfo;
import com.opus.optimus.offline.runtime.taskmanager.model.JobResult;
import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public interface ITaskManager {
    String createJob(String name, List<JobTask> jobTask);

    CompletableFuture<JobResult> runJob(String jobId) throws InvalidJobIdException, InvalidJobStatusException;

    void cancelJob(String jobId) throws InvalidJobIdException, InvalidJobStatusException;

    JobInfo getJobInfo(String jobId) throws InvalidJobIdException;

    List<JobInfo> getJobInfos(JobStatus jobStatus);

    JobResult getJobResult(String jobId) throws InvalidJobIdException;

    //JobResult saveJobTaskResult(String jobId, String jobTaskId, JobTaskExecutorResult jobTaskExecutorResult);

    //void deleteById(String jobId);

}
