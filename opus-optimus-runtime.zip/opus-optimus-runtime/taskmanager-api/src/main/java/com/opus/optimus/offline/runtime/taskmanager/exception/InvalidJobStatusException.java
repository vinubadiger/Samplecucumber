package com.opus.optimus.offline.runtime.taskmanager.exception;

import com.opus.optimus.offline.runtime.taskmanager.model.JobStatus;

public class InvalidJobStatusException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JobStatus status;

    public InvalidJobStatusException(JobStatus status) {
        this.status = status;
    }

    public JobStatus getStatus() {
        return status;
    }
}
