package com.opus.optimus.offline.runtime.taskmanager.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SourceInfo {
	String source;
	String fileChecksum;
}
