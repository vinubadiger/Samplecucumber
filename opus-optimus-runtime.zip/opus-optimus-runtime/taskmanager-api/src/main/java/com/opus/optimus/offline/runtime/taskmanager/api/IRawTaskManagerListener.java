package com.opus.optimus.offline.runtime.taskmanager.api;

public interface IRawTaskManagerListener {
    void onTaskStart(String jobId, String taskId);

    void onTaskComplete(String jobId, String taskId);

    void onJobStart(String jobId);

    void onJobComplete(String jobId);
}
