package com.opus.optimus.offline.runtime.taskmanager.api;

import java.util.concurrent.CompletableFuture;

import com.opus.optimus.offline.runtime.workflow.api.JobTaskExecutorResult;

public interface ITaskExecutor {
	CompletableFuture<JobTaskExecutorResult> execute();

	void abort();
}
