package com.opus.optimus.offline.runtime.taskmanager.model;

public enum JobTaskType {
    CONTAINER, TASK, END
}
