package com.opus.optimus.offline.runtime.taskmanager.api;

import com.opus.optimus.offline.runtime.taskmanager.exception.InvalidJobIdException;
import com.opus.optimus.offline.runtime.taskmanager.model.JobTask;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public interface IRawTaskManager {
    void start();

    void stop();

    String generateJobId();

    CompletableFuture<Void> submitJob(String jobId, List<JobTask> jobTask);

    void cancelJob(String jobId) throws InvalidJobIdException;

    void addListener(IRawTaskManagerListener listener);

    void removeListener(IRawTaskManagerListener listener);
    
    void cleanZookeeperId(String jobId);
}
