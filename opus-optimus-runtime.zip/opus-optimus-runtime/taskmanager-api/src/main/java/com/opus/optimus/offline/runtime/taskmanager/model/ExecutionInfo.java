package com.opus.optimus.offline.runtime.taskmanager.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExecutionInfo {
    String groupId;
    String id;
    String type;
    String errorHandlingId;
    String errorHandlingType;
    Map<String, List<String>> stepInputs;
}
