package com.opus.optimus.offline.runtime.taskmanager.api;

public interface ITaskReceiver {
    void start();

    void stop();
}
