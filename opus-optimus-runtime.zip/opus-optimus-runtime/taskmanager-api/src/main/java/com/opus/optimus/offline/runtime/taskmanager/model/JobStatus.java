package com.opus.optimus.offline.runtime.taskmanager.model;

public enum JobStatus {
	CREATED, WAITING_TO_START, STARTED, CANCEL_IN_PROGRESS, CANCELLED, COMPLETED_SUCCESS, COMPLETED_FAILED, ABORTED
}