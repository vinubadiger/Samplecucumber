package com.opus.optimus.offline.config.user;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class CutoverDetail {
	
	/** The cut over time in hour. */
	private int hour;
	
	/** The cut over time in minute. */
	private int minute;
	
	/** The cut over time in calculate start time. */
	private Date cutOverTime;
}