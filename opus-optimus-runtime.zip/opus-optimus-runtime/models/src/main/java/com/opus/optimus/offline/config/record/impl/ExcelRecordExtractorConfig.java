package com.opus.optimus.offline.config.record.impl;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.field.impl.ExcelFieldConfig;
import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class ExcelRecordExtractorConfig implements ITextRecordExtractorConfig {
	public static final String RECORDTYPE = "ExcelRecordExtractorConfig";

	private String sectionName;
	private List<ExcelFieldConfig> fieldConfigs;
	private String type;
	
	
	@Override
	@JsonGetter ("type")
	public String getType() {
		return RECORDTYPE;
	}


	@Override
	public boolean validate() {
		if (this.sectionName == null || this.sectionName.isEmpty()){
			throw new ValidationException("Caught inside ExcelRecordExtractorConfig ,sectionName field is required");
		}
		if (this.fieldConfigs == null){
			throw new ValidationException("Caught inside ExcelRecordExtractorConfig ,fieldConfigs[] field is required");
		}
		fieldConfigs.parallelStream().forEach(ExcelFieldConfig::validate);
		return true;
	}
}
