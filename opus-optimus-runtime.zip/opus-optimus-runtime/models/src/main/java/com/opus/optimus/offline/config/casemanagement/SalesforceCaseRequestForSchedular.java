package com.opus.optimus.offline.config.casemanagement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
/**
 * POJO for salesforce care request only used by Scheduler module
 * 
 * @author Yashkumar.Thakur
 *
 */
public class SalesforceCaseRequestForSchedular {

	Priority priority;

	String subject;

	String project;

	String description;

	String reasonCode;

	String fileDBDetails;
}
