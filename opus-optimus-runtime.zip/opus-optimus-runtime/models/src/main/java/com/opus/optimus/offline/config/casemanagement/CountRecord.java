package com.opus.optimus.offline.config.casemanagement;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@Document
@NoArgsConstructor
public class CountRecord {
	public String priority;
	public int count;
}
