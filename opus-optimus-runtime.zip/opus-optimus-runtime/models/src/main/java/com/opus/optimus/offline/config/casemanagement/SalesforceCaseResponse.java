package com.opus.optimus.offline.config.casemanagement;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesforceCaseResponse {
	private List<SalesforceCaseDetails> successList;
	private boolean hasError;
	private List<SalesforceErrorDetails> errorList;
	private String errorMessage;
}
