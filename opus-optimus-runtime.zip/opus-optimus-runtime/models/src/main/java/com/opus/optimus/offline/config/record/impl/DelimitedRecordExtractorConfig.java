package com.opus.optimus.offline.config.record.impl;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class DelimitedRecordExtractorConfig implements ITextRecordExtractorConfig {
	
	public static final String RECORDTYPE = "DelimitedRecordExtractorConfig";

	private String recordSeperator;

	private int rowsToSkip;

	private String type;

	@Override
	@JsonGetter ("type")
	public String getType() {
		return RECORDTYPE;
	}

	@Override
	public boolean validate() {
		if (this.recordSeperator == null || this.recordSeperator.isEmpty()){
			throw new ValidationException("Caught inside DelimitedFieldExtractorConfig ,sectionName field is required");
		}
		return true;
	}
}
