package com.opus.optimus.offline.constants;

public class ReaderConstants {

    public static final String IN_CLAUSE_VALUE_SEPARATOR = ",";
    public static final String SCRIPT_MAP_RSH_FIELD_KEY = "RHS";
    public static final String SCRIPT_MAP_LSH_FIELD_KEY = "LHS";
    public static final String DOUBLE_QUOTES = "\"";
    public static final String SELECT = "SELECT";
    public static final String FROM = "FROM";
    public static final String WHERE = "WHERE";
    public static final String AND = "AND";
    public static final String OR = "OR";
    public static final String DATA = "DATA";
    public static final String SPACE = " ";
}
