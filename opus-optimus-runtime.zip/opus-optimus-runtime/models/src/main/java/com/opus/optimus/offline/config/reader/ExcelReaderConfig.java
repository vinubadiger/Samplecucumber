package com.opus.optimus.offline.config.reader;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.record.impl.ExcelRecordExtractorConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class ExcelReaderConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;

	public static final String EXCEL_READER_STEPTYPE = StepTypeConstants.EXCEL_READER_STEPTYPE;

	@NonNull
	private String name;

	private String label;

	private String charEncoding;

	private String layoutDefinition;

	private int topRowsToSkip;

	private int noOfHeaderRecs;

	private boolean processAllSheets;

	private String sheetsToProcess[];

	private String stepType;

	private Map<String, String> sectionDetails;

	private Map<String, ExcelRecordExtractorConfig> recordExtractorConfig;

	private boolean multipleSection;

	private boolean columnHeader;
	
	private boolean isFileChecksumRequired;

	@Override
	@JsonSetter("stepName")
	public String getStepName() {
		return name;
	}

	@Override
	@JsonGetter("stepType")
	public String getStepType() {
		return EXCEL_READER_STEPTYPE;
	}

	@Override
	public boolean validate() {
		if (this.name == null || this.name.isEmpty()){
			throw new ValidationException("Caught inside ExcelReaderConfig ,name field is required");
		}
		if (this.charEncoding == null || this.charEncoding.isEmpty()){
			throw new ValidationException("Caught inside ExcelReaderConfig ,charEncoding field is required");
		}
		if (this.layoutDefinition == null || this.layoutDefinition.isEmpty()){
			throw new ValidationException("Caught inside ExcelReaderConfig ,layoutDefinition field is required");
		}
		if (this.sectionDetails == null || this.sectionDetails.isEmpty()){
			throw new ValidationException("Caught inside ExcelReaderConfig ,sectionDetails field is required");
		}
		if (this.recordExtractorConfig == null || this.recordExtractorConfig.isEmpty()){
			throw new ValidationException("Caught inside ExcelReaderConfig ,recordExtractorConfig field is required");
		}
		recordExtractorConfig.forEach((k,v)->v.validate());
		return true;
	}
}
