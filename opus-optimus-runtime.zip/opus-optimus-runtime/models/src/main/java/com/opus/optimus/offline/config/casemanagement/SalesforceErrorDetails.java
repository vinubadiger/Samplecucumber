package com.opus.optimus.offline.config.casemanagement;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesforceErrorDetails {
	private String message;
	private String caseId;
	private List<String> fields;
}
