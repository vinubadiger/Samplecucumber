package com.opus.optimus.offline.config.casemanagement;

import java.util.List;

import lombok.Builder;
import lombok.Data;

/**
 * The POJO class to determine the list of primary ids and the data base reference in order to
 * update the record for the reconciliation exception case.
 *
 */
@Data
@Builder
public class UnReconcileRecords {
	private List<String> oIDs;
	private String dataSourceName;
	private String collectionName;
	private String sourceName;
	private String caseId;//This is in case when we need to mark case as closed against the records
}
