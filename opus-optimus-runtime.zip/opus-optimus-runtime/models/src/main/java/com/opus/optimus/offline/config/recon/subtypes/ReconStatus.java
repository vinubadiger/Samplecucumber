package com.opus.optimus.offline.config.recon.subtypes;

public enum ReconStatus {
    RECONCILED,
    UNRECONCILED
}
