package com.opus.optimus.offline.config.transformer;

import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class AdditionalTransformerConfig {
	private String fieldName;
	private FieldType fieldType;
	private IScriptConfig scriptConfig; 
	
	public boolean validate() {
		if (this.fieldName == null || this.fieldName.isEmpty()){
			throw new ValidationException("Caught inside AdditionalTransformerConfig ,fieldName field is required");
		}
		if (this.fieldType == null){
			throw new ValidationException("Caught inside AdditionalTransformerConfig ,fieldType field is required");
		}
		if (this.scriptConfig == null){
			throw new ValidationException("Caught inside AdditionalTransformerConfig ,fieldType field is required");
		}
		return true;
	}
}
