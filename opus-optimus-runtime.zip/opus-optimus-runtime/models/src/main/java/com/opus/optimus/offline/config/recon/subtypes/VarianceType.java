package com.opus.optimus.offline.config.recon.subtypes;

public enum VarianceType {
	ABSOLUTE, PERCENTAGE;
}
