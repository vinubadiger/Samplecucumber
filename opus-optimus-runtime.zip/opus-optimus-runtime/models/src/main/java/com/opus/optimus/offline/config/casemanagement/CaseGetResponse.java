package com.opus.optimus.offline.config.casemanagement;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@Document
@NoArgsConstructor
public class CaseGetResponse {
	public String message;
	public String hasError;
	public String totalRecords;
	public List<Record> result;
}
