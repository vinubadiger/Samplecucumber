package com.opus.optimus.offline.config.recon.subtypes;

import java.util.List;

import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;

import lombok.Data;

@Data
public class EtlSource {
	String sourceName; // Actual Workflow Name ex: Amex, VISA
	String dataSourceName;
	String collectionName;
	String activityName;
	List<MongoDBFieldConfig> fieldConfigs;

	public boolean validate() {
		if (this.sourceName == null || this.sourceName.isEmpty()){
			throw new ValidationException("Caught inside EtlSource ,sourceName field is required");
		}
		if (this.dataSourceName == null || this.dataSourceName.isEmpty()){
			throw new ValidationException("Caught inside EtlSource ,dataSourceName field is required");
		}
		if (this.collectionName == null || this.collectionName.isEmpty()){
			throw new ValidationException("Caught inside EtlSource ,collectionName field is required");
		}
		if (this.fieldConfigs == null){
			throw new ValidationException("Caught inside EtlSource ,fieldConfigs{} field is null");
		}
		fieldConfigs.parallelStream().forEach(MongoDBFieldConfig::validate);
		return true;
	}
}
