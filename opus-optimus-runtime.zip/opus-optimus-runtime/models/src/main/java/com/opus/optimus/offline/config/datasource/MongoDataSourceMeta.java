package com.opus.optimus.offline.config.datasource;

import com.opus.optimus.offline.constants.AnnotationConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@Document(collection = "MongoDataSourceMeta") 
//ToDO : have to change collection Name ::  DataSourceMeta
public class MongoDataSourceMeta { 
	// ToDO:  split this class based on Database type
	@Id
	private String id;

    @Field(AnnotationConstants.DATASOURCE_NAME)
    private String dataSourceName;

    /**
     * Possible supported Values as of now -
     * Mongo_DB, Oracle_DB
     */
    @Field(AnnotationConstants.DATABASE_TYPE)
    private String databaseType;

    @Field (AnnotationConstants.DATABASE_NAME)
    private String databaseName;

    @Field (AnnotationConstants.AUTHENTICATION_REQUIRED)
    private boolean authenticationRequired;

    @Field (AnnotationConstants.AUTH_METADATA)
    private DataSourceAuthMetaData authMetaData;

    @Field (AnnotationConstants.ADDRESS_METADATA)
    private List<ServerAddressMetadata> addressMetadatas;

    @Field (AnnotationConstants.COLLECTIONS)
	private List<String> collections;

    @Field(AnnotationConstants.SERVICE_NAME)
    private String serviceName;
    
	@CreatedBy
	private String createdBy;
	@LastModifiedBy
	private String lastModifiedBy;
	@CreatedDate
	private Date createdDate;
	@LastModifiedDate
	private Date lastModifiedDate;
}
