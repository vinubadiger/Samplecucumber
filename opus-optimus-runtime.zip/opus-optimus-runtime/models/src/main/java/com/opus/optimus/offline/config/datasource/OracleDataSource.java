package com.opus.optimus.offline.config.datasource;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

/**
 * Instantiates a new oracle data source.
 */
@RequiredArgsConstructor
public class OracleDataSource implements IDataSource {

	private static final Logger logger = LoggerFactory.getLogger(OracleDataSource.class);

	public static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String JDBC_URL = "jdbc:oracle:thin:@//"; // TODO Need to be changed String interpolation

	private DriverManagerDataSource dataSource;

	@NonNull
	private MongoDataSourceMeta dataSourceMetaMongoMongoData; // Todo - Datasource name need to be changed

	public boolean init() {
		try{
			dataSource = (DriverManagerDataSource) buildDataSource();
		} catch (Exception e){
			logger.error("Error while initialize datasource", e);
			return false;
		}
		return true;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	/**
	 * Returns a DataSource object for connection to the database.
	 *
	 * @return a DataSource.
	 */
	private DataSource buildDataSource() {
		// Creates a new instance of DriverManagerDataSource and sets
		// the required parameters such as the Jdbc Driver class,
		// Jdbc URL, database user name and password.
		try{
			// TODO Need to be created Oracle pool DS
			DriverManagerDataSource dataSource = new DriverManagerDataSource();
			dataSource.setDriverClassName(ORACLE_DRIVER);
			dataSource.setUrl(getJdbcURL());
			dataSource.setUsername(dataSourceMetaMongoMongoData.getAuthMetaData().getUserName());
			dataSource.setPassword(dataSourceMetaMongoMongoData.getAuthMetaData().getPassword());

			return dataSource;
		} catch (Exception e){
			throw new EngineException(e);
		}

	}

	private String getJdbcURL() {
		try{
			String host = dataSourceMetaMongoMongoData.getAddressMetadatas().get(0).getIpAddress();
			int port = dataSourceMetaMongoMongoData.getAddressMetadatas().get(0).getPort();
			String serviceName = dataSourceMetaMongoMongoData.getServiceName();
			return JDBC_URL + host + ":" + port + "/" + serviceName;
		} catch (Exception e){
			throw new EngineException(e);
		}
	}
}
