package com.opus.optimus.offline.config.user;

import java.util.Date;
import java.util.TimeZone;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opus.optimus.offline.config.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new institution.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Document (collection = "Institution")
public class Institution {

	/** The id. */
	@Id
	private String id;

	/** The institution name. */
	@Field (Constants.INSTITUTION_NAME)
	private String institutionName;

	/** The display name. */
	@Field (Constants.DISPLAY_NAME)
	private String displayName;

	/** The admin email. */
	@Field (Constants.ADMIN_EMAIL)
	private String adminEmail;

	/** The mobile no. */
	@Field (Constants.MOBILE_NO)
	private String mobileNo;

	/** The address. */
	private String address;

	/** The cutoverDetail time. */
	private CutoverDetail cutoverDetail;

	/** The bussiness date. */
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = Constants.TIMEZONE)
	@Field (Constants.BUSSINESS_PROCESSING_DATE)
	private Date businessProcessingDate;
	
	private TimeZone timeZone;

}