package com.opus.optimus.offline.config.validator;

import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
public class ValidatorConfig {
	private String name;
	private IScriptConfig scriptConfig;
	private String errorDesc;
	
	public boolean validate() {
		if (null == name || name.isEmpty()){
			throw new ValidationException("Caught inside ValidatorConfig ,name no Links defined between the Steps");
		}
		if (null == scriptConfig){
			throw new ValidationException("Caught inside ValidatorConfig,scriptConfig no Links defined between the Steps");
		}
		
		return true;
	}

}
