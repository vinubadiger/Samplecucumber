package com.opus.optimus.offline.config;

public interface IBaseConfig {

}
