package com.opus.optimus.offline.config.recon;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.opus.optimus.offline.config.recon.subtypes.ReconStatus;
import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document (collection = "ReconAcitivitySummary")
public class ReconAcitivitySummary {
	@Id
	private String id;
	private String activityName;
	private String projectName;
	private String description;
	private SourceMappingType activityType;// Has to be fetched from Activity - OneToOne, OneToMany
	private ReconStatus status;
	private ReconSubStatus subStatus;
	private ReconSourceSummary sourceASummary;
	private ReconSourceSummary sourceBSummary;

	// this will be always saved in yyyy-MM-dd format without
	// Hours/minutes/seconds
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date processingDate;

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		ReconAcitivitySummary other = (ReconAcitivitySummary) obj;
		if (activityName == null){
			if (other.activityName != null) return false;
		} else if (!activityName.equals(other.activityName)) return false;
		if (processingDate == null){
			if (other.processingDate != null) return false;
		} else if (!processingDate.equals(other.processingDate)) return false;
		if (status != other.status) return false;
		if (subStatus != other.subStatus) return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((activityName == null) ? 0 : activityName.hashCode());
		result = prime * result + ((processingDate == null) ? 0 : processingDate.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((subStatus == null) ? 0 : subStatus.hashCode());
		return result;
	}
}