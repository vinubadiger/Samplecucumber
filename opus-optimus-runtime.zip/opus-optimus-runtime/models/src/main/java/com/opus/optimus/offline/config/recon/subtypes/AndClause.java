package com.opus.optimus.offline.config.recon.subtypes;

import com.opus.optimus.offline.config.exception.ValidationException;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor 
@AllArgsConstructor
public class AndClause {
	SourceField lhsField;
	Operator operator;
	SourceField rhsField;
	String notes;
	public boolean validate()
	{
		if (null == lhsField){
			throw new ValidationException("Caught inside AndClause ,lhsField{} is required");
		}
		if (null == operator){
			throw new ValidationException("Caught inside AndClause ,operator{} is required");
		}
		if (null == rhsField){
			throw new ValidationException("Caught inside AndClause ,rhsField{} is required");
		}
		return true;
	}
}
