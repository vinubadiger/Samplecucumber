package com.opus.optimus.offline.config.field.impl;

import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class DelimitedFieldConfig implements IFieldConfig {

	private short fieldIndex;
	private String name;
	private FieldType type;

	// for date, datetime
	private String format;

	private int maxSize;

	// isImpliedDecimal
	private boolean implicitDecimal;
	private short noOfDecimals; // 1, 2, 3, 4; default is 2

	@Override
	public boolean validate() {
		if (this.name == null || this.name.isEmpty()){
			throw new ValidationException("Caught inside DelimitedFieldConfig ,name field is required");
		}
		if (this.type == null){
			throw new ValidationException("Caught inside DelimitedFieldConfig ,type field is required");
		}
		return true;
	}

}
