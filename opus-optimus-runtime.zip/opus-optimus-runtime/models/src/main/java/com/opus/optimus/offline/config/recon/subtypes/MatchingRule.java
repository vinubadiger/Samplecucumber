package com.opus.optimus.offline.config.recon.subtypes;

import lombok.Data;

@Data
public class MatchingRule {
	int priority;
	String ruleId;
	private OrClause matchingClause;
	private OrClause toleranceClause;

	public boolean validate() {
		matchingClause.validate();
		toleranceClause.validate();
		return true;
	}
}
