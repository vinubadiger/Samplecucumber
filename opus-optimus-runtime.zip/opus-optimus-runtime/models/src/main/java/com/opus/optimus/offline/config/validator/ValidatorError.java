package com.opus.optimus.offline.config.validator;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Builder
@Data
public class ValidatorError implements Serializable {
	private List<String> validatorErrorMessageList;

}
