package com.opus.optimus.offline.config.recon;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.recon.subtypes.SummaryField;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ReconStatusUpdateConfig implements IStepConfig {
	private static final long serialVersionUID = 1L;

	public enum UnitType {
		DAY, WEEK
	}

	@NonNull
	private String stepName;
	private String stepType;
	private String activityName;
	private String label;
	private String notes;
	/** For UI */
	/** The unreconciled backlog. */
	private boolean unreconciledBacklog;

	/** The time leg interval. */
	private int timeLegInterval;

	/** The unit. */
	private UnitType unit; // day/week
	
	/** The case creation threshold */
	private int caseCreationThreshold;

	// Summary Fields
	@NonNull
	private SummaryField sourceA;
	@NonNull
	private SummaryField sourceB;

	@Override
	@JsonGetter ("stepType")
	public String getStepType() {
		return StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE;
	}

	@Override
	public boolean validate() {
		if (this.stepName == null || this.stepName.isEmpty()){
			throw new ValidationException("Caught inside ReconStatusUpdateConfig, stepName field is required");
		}
		if (this.sourceA == null){
			throw new ValidationException("Caught inside ReconStatusUpdateConfig, sourceA field is required");
		}
		if (this.sourceB == null){
			throw new ValidationException("Caught inside ReconStatusUpdateConfig, sourceB field is required");
		}
		return true;
	}
}
