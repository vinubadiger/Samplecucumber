package com.opus.optimus.offline.config.recon.subtypes;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor 
@AllArgsConstructor
public class OrClause {
	private List<AndClause> andClauses;
	
	public boolean validate() {
		andClauses.parallelStream().forEach(AndClause::validate);
		return true;
	}
}
