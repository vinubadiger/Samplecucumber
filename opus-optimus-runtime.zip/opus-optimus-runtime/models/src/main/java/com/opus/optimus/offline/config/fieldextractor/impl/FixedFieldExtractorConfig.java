package com.opus.optimus.offline.config.fieldextractor.impl;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.field.impl.FixedFieldConfig;
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
public class FixedFieldExtractorConfig implements ITextFieldExtractorConfig {

	public static final String TYPE_CONFIG = "FixedFieldExtractorConfig";

	private String sectionName;
	private List<FixedFieldConfig> fieldConfigs;
	private String type;

	@Override
	@JsonGetter ("type")
	public String getType() {
		return TYPE_CONFIG;
	}

	@Override
	public boolean validate() {
		if (this.sectionName == null || this.sectionName.isEmpty()){
			throw new ValidationException("Caught inside FixedFieldExtractorConfig ,sectionName field is required");
		}
		if (this.type == null|| this.type.isEmpty()){
			throw new ValidationException("Caught inside FixedFieldExtractorConfig ,type field is required");
		}
		if (this.fieldConfigs == null){
			throw new ValidationException("Caught inside FixedFieldExtractorConfig ,fieldConfigs[] field is required");
		}
		return true;
	}
}
