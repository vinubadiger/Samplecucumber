package com.opus.optimus.offline.config.recon.subtypes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SummaryField {
	@NonNull
	private String sourceName;
	@NonNull
	private String fieldName;
	@NonNull
	private String txnDateFieldName;
}
