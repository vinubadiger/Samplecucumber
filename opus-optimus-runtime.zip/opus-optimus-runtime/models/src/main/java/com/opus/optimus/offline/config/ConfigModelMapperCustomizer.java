package com.opus.optimus.offline.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.opus.optimus.offline.config.fieldextractor.impl.DelimitedFieldExtractorConfig;
import com.opus.optimus.offline.config.fieldextractor.impl.FixedFieldExtractorConfig;
import com.opus.optimus.offline.config.reader.DBReaderConfig;
import com.opus.optimus.offline.config.reader.ExcelReaderConfig;
import com.opus.optimus.offline.config.reader.MongoDBReaderConfig;
import com.opus.optimus.offline.config.reader.TextFileReaderConfig;
import com.opus.optimus.offline.config.recon.ReconStatusUpdateConfig;
import com.opus.optimus.offline.config.record.impl.DelimitedRecordExtractorConfig;
import com.opus.optimus.offline.config.record.impl.ExcelRecordExtractorConfig;
import com.opus.optimus.offline.config.record.impl.FixedRecordExtractorConfig;
import com.opus.optimus.offline.config.transformer.TransformerConfig;
import com.opus.optimus.offline.config.validator.ValidatorStepConfig;
import com.opus.optimus.offline.config.writer.MongoDBWriterConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;
import com.opus.optimus.offline.runtime.script.config.ExcelImessageScriptConfig;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.config.RawTextExcelScriptConfig;
import org.springframework.stereotype.Component;

@Component
public class ConfigModelMapperCustomizer implements IMapperCustomizer<ObjectMapper> {

	@Override
	public void customize(ObjectMapper mapper) {
		// for stepType
		mapper.registerSubtypes(new NamedType(TextFileReaderConfig.class, StepTypeConstants.FILE_READER_STEPTYPE));
		mapper.registerSubtypes(new NamedType(ExcelReaderConfig.class, StepTypeConstants.EXCEL_READER_STEPTYPE));
		mapper.registerSubtypes(new NamedType(MongoDBWriterConfig.class, StepTypeConstants.MONGODB_WRITER_STEPTYPE));
		mapper.registerSubtypes(new NamedType(ValidatorStepConfig.class, StepTypeConstants.VALIDATOR_STEPTYPE));
		mapper.registerSubtypes(new NamedType(MongoDBReaderConfig.class, StepTypeConstants.MONGO_DBREADER_STEP_TYPE));
		mapper.registerSubtypes (new NamedType (DBReaderConfig.class, StepTypeConstants.DBREADER_STEP_TYPE));

		// for 'type' in field extractor
		mapper.registerSubtypes(new NamedType(DelimitedFieldExtractorConfig.class, DelimitedFieldExtractorConfig.TYPE_CONFIG));
		mapper.registerSubtypes(new NamedType(FixedFieldExtractorConfig.class, FixedFieldExtractorConfig.TYPE_CONFIG));

		// for 'type' in Record Extractor
		mapper.registerSubtypes(
				new NamedType(DelimitedRecordExtractorConfig.class, DelimitedRecordExtractorConfig.RECORDTYPE));
		mapper.registerSubtypes(new NamedType(FixedRecordExtractorConfig.class, FixedRecordExtractorConfig.RECORDTYPE));
		mapper.registerSubtypes(new NamedType(ExcelRecordExtractorConfig.class, ExcelRecordExtractorConfig.RECORDTYPE));

		// for script config
		mapper.registerSubtypes(new NamedType(ExcelScriptConfig.class, "excel.IRecord-script"));
		mapper.registerSubtypes(new NamedType(RawTextExcelScriptConfig.class, "excel.rawtext-script"));
		mapper.registerSubtypes(new NamedType(ExcelImessageScriptConfig.class, "excel.imessage-script"));
		
		// For Transformer
		mapper.registerSubtypes(new NamedType(TransformerConfig.class, StepTypeConstants.TRANSFORMER_STEPTYPE));
		
		//For Recon Steps
		mapper.registerSubtypes(new NamedType(MongoDBReaderConfig.class, StepTypeConstants.MONGO_DBREADER_STEP_TYPE));
		mapper.registerSubtypes(new NamedType(ReconStatusUpdateConfig.class, StepTypeConstants.RECONSTATUSUPDATE_STEPTYPE));
	}
}
