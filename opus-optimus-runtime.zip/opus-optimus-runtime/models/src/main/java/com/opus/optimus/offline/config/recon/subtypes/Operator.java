package com.opus.optimus.offline.config.recon.subtypes;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor 
@AllArgsConstructor
public class Operator {
	OperatorLiteral operatorLiteral; // If OperatorLiteral present, variance will not present
	Variance variance; // In case of Variance, OperatorLiteral will not present
}