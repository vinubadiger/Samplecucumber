package com.opus.optimus.offline.config.datasource;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoDatabase;
import com.opus.optimus.offline.runtime.common.api.datasource.IDataSource;
import com.opus.optimus.offline.runtime.common.api.datasource.exception.DataSourceInitializationException;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class MongoDataSource implements IDataSource {

	private static final Logger logger = LoggerFactory.getLogger(MongoDataSource.class);

	private MongoClient mongoClient;

	@NonNull
	private MongoDataSourceMeta dataSourceMetaMongoMongoData;

	public boolean init() {
		try{
			final List<ServerAddress> serverAddresses = dataSourceMetaMongoMongoData.getAddressMetadatas().stream().map(addressMetaData -> {
				return new ServerAddress(addressMetaData.getIpAddress(), addressMetaData.getPort());
			}).collect(Collectors.toList());

			final MongoClientOptions mongoClientOptions = MongoClientOptions.builder().applicationName("MongoDBWriter").build();

			if (!dataSourceMetaMongoMongoData.isAuthenticationRequired()){
				mongoClient = new MongoClient(serverAddresses, mongoClientOptions);
			} else{
				MongoCredential credential = MongoCredential.createCredential(dataSourceMetaMongoMongoData.getAuthMetaData().getUserName(), dataSourceMetaMongoMongoData.getDatabaseName(), dataSourceMetaMongoMongoData.getAuthMetaData().getPassword().toCharArray());
				mongoClient = new MongoClient(serverAddresses, credential, mongoClientOptions);
			}
			return true;
		} catch (Exception e){
			logger.error("Error while initilze datasource ", e);
			return false;
		}
	}

	public MongoDatabase getDatabase() throws DataSourceInitializationException {
		if (this.mongoClient == null) throw new DataSourceInitializationException("Failed to initialize the datasource. Please check the configuration/logs.");
		return this.mongoClient.getDatabase(dataSourceMetaMongoMongoData.getDatabaseName());
	}

	public MongoClient getMongoClient() {
		return mongoClient;
	}

}
