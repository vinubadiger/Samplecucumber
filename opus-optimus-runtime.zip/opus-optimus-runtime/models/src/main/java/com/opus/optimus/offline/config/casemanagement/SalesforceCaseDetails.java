package com.opus.optimus.offline.config.casemanagement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesforceCaseDetails {
	private String referenceId;
	private String caseNumber;
	private String caseId;
	private String caseDetailUrl;
}
