package com.opus.optimus.offline.config.recon.subtypes;

public enum CaseStatus {
	NEW, OPEN, CLOSE
}
