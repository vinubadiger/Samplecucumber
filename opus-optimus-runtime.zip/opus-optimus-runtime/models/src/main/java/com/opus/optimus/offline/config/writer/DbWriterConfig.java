package com.opus.optimus.offline.config.writer;

import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

/**
 * @author Anup.Warke
 */
public abstract class DbWriterConfig implements IStepConfig {
	private static final long serialVersionUID = 1L;
	protected abstract String getDataBaseType();

	protected abstract String getDataSourceName();

}
