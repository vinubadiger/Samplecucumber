package com.opus.optimus.offline.config.recon.subtypes;

import java.util.List;

import com.opus.optimus.offline.config.recon.subtypes.OrClause;

import lombok.Data;

@Data
public class SelectionCriteria {
	List<OrClause> orClauseSections;

	public boolean validate() {
		orClauseSections.parallelStream().forEach(OrClause::validate);
		return true;
	}
}
