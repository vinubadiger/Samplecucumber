package com.opus.optimus.offline.config.casemanagement;

import java.util.List;

import com.opus.optimus.offline.runtime.workflow.exception.Severity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesforceCaseRequest {
	String referenceId;

	String status;

	String origin;

	Priority priority; // enum

	Severity systemErrorType; // enum

	String subject;

	String contactName;

	String contactSkypeName;

	String activity;

	String project;

	String description; // Case body

	List<SalesforceCaseRequest> childcases;

	// update operation specific field
	String caseId;

	String reasonCode;

	String comment;

	int errorCounts;

	String job_ID;

	String typeOfSource;

	String fileDBDetails;

	String systemErrorMessage;

	String machineServerDetails;

	String exceptionDateTime;
}
