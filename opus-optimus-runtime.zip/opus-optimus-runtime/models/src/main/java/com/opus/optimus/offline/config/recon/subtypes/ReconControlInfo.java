package com.opus.optimus.offline.config.recon.subtypes;

import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReconControlInfo {
	private String activityName;
	private String jobId;
	private ReconStatus status;
	private ReconSubStatus subStatus;
	private String ruleId;
	private double amount;
	private double tolerance;
	private double absoluteTolerance;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date processingDate;
	private CaseInfo caseInfo;
	private Map<String, String> supportingData;
	private String relatedRecordsRefId;
	private String updatedBy;
	private String updatedRemark;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updatedDate;
	private String manReasonComments;
	private String manReasonId;
	@JsonFormat (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date transactionDate;
}
