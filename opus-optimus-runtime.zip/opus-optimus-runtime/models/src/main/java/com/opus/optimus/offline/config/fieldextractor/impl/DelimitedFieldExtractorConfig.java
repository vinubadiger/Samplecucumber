package com.opus.optimus.offline.config.fieldextractor.impl;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.field.impl.DelimitedFieldConfig;
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class DelimitedFieldExtractorConfig implements ITextFieldExtractorConfig {

	public static final String TYPE_CONFIG = "DelimitedFieldExtractorConfig";

	private String sectionName;
	private String delimiter;
	
	private String type;
	
	private List<DelimitedFieldConfig> fieldConfigs;

	@Override
	@JsonGetter ("type")
	public String getType() {
		return TYPE_CONFIG;
	}

	@Override
	public boolean validate() {
		if (this.sectionName == null || this.sectionName.isEmpty()){
			throw new ValidationException("Caught inside DelimitedFieldExtractorConfig ,sectionName field is required");
		}
		if (this.type == null){
			throw new ValidationException("Caught inside DelimitedFieldExtractorConfig ,type field is required");
		}
		if (this.fieldConfigs == null){
			throw new ValidationException("Caught inside FixedFieldExtractorConfig ,fieldConfigs[] field is required");
		}
		fieldConfigs.parallelStream().forEach(DelimitedFieldConfig::validate);
		return true;
	}
}
