package com.opus.optimus.offline.config.casemanagement;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalesforceAuthenticateResponse {
	private String id;
	
	@JsonProperty("issued_at")
	private long issuedAt;
	
	@JsonProperty("instance_url")
	private String instanceUrl;
	private String signature;
	
	@JsonProperty("access_token")
	private String accessToken;
	
	@JsonProperty("token_type")
	private String tokenType;
}
