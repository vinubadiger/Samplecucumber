package com.opus.optimus.offline.config.casemanagement;

import com.opus.optimus.offline.config.recon.subtypes.ReconSubStatus;

import lombok.Builder;
import lombok.Data;

/**
 * This is POJO class to determine the details for the reconciliation exception
 *
 */
@Data
@Builder
public class UnReconciliedSourceInfo {
	private UnReconcileRecords unReconcileRecords;
	private String activityName;
	private ReconSubStatus reconStatus; 
}
