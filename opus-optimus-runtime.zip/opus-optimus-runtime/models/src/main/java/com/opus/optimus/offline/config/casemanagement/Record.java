package com.opus.optimus.offline.config.casemanagement;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@Document
@NoArgsConstructor
public class Record {
	public String caseId;
	public String caseNumber;
	public String status;
	public String priority;
	public int age;
}
