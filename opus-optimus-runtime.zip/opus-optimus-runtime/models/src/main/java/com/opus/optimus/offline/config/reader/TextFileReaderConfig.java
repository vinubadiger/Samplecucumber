package com.opus.optimus.offline.config.reader;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.fieldextractor.ITextFieldExtractorConfig;
import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
@Builder
@Data
public class TextFileReaderConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;

	public static final String FILE_READER_STEPTYPE = StepTypeConstants.FILE_READER_STEPTYPE;

	@NonNull
	private String name;

	private String charEncoding;

	private String label;

	private String layoutDefinition;

	private String stepType;
	
	private boolean duplicateFileValidationCheckRequired;

	@JsonProperty ("recordExtractorConfig")
	private ITextRecordExtractorConfig recordExtractorConfig;

	private Map<String, IScriptConfig> sectionDetails;

	private Map<String, ITextFieldExtractorConfig> fieldExtractorConfig;

	@Override
	@JsonSetter ("stepName")
	public String getStepName() {
		return name;
	}

	@Override
	@JsonGetter ("stepType")
	public String getStepType() {
		return FILE_READER_STEPTYPE;
	}

	@Override
	public boolean validate() {
		if (this.name == null || this.name.isEmpty()){
			throw new ValidationException("Caught inside TextFileReaderConfig ,name field is required");
		}
		if (this.charEncoding == null || this.charEncoding.isEmpty()){
			throw new ValidationException("Caught inside TextFileReaderConfig ,charEncoding field is required");
		}
		if (this.layoutDefinition == null || this.layoutDefinition.isEmpty()){
			throw new ValidationException("Caught inside TextFileReaderConfig ,layoutDefinition field is required");
		}
		if (this.stepType == null || this.stepType.isEmpty()){
			throw new ValidationException("Caught inside TextFileReaderConfig ,stepType field is required");
		}
		if(recordExtractorConfig==null) {
			throw new ValidationException("Caught inside TextFileReaderConfig ,recordExtractorConfig field is required");
		}
		if(fieldExtractorConfig!=null && !fieldExtractorConfig.isEmpty()) {
			fieldExtractorConfig.values().parallelStream().forEach(ITextFieldExtractorConfig::validate);
		}
		if(sectionDetails==null) {
			throw new ValidationException("Caught inside TextFileReaderConfig ,sectionDetails{} field is required");
		}
		recordExtractorConfig.validate();
		fieldExtractorConfig.forEach((k,v)->v.validate());
		return true;
	}
}
