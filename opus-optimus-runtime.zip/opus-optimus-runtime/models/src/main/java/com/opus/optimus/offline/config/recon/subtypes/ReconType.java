package com.opus.optimus.offline.config.recon.subtypes;

public enum ReconType {
	POSTING, SETTLEMENT, FUNDING, OTHER

}
