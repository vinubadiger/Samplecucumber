package com.opus.optimus.offline.config.reader;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.opus.optimus.offline.config.field.impl.DBFieldConfig;
import com.opus.optimus.offline.config.recon.subtypes.SelectionCriteria;
import com.opus.optimus.offline.constants.StepTypeConstants;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DBReaderConfig implements IStepConfig {
    private static final long serialVersionUID = 1L;
    String dataSourceName; // dataSource to read from
    String collectionName; // tableName
    List<DBFieldConfig> fieldConfigs;
    List<DBFieldConfig> fieldSelected;
    SelectionCriteria selectionCriteria;
    private String stepName;
    private String stepType;
    private String notes;
    private String section;
	@NonNull
	private String name;
	private String dataBaseType;

    @Override
    public String getStepType() {
        return StepTypeConstants.DBREADER_STEP_TYPE;
    }
	
	@Override
	@JsonSetter("stepName")
	public String getStepName() {
		return name;
	}

	@Override
	public boolean validate() {
		return true;
	}

}
