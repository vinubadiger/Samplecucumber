package com.opus.optimus.offline.config.recon.subtypes;

public enum OperatorLiteral {
	EQUAL, NOTEQUAL, LTE, GTE, LT, GT, IN, NOTIN, LIKE;
}
