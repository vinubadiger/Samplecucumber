package com.opus.optimus.offline.config.recon;

import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;

import lombok.Builder;
import lombok.Data;

/**
 * The Class ReconCaseCreationStepConfig.
 *
 * @author Yashkumar.Thakur
 */

@Builder
@Data
public class ReconCaseCreationStepConfig implements IStepConfig {

	private static final long serialVersionUID = 1L;

	/** The template type. */
	private String template;

	/** The Constant RECONCASECREATION_STEPTYPE. */
	public static final String RECONCASECREATION_STEPTYPE = "ReconCaseCreation";

	/** The name. */
	private String name;

	@Override
	public String getStepName() {
		return name;
	}

	@Override
	public String getStepType() {
		return RECONCASECREATION_STEPTYPE;
	}

	@Override
	public boolean validate() {
		if (this.template == null || this.template.isEmpty()){
			throw new ValidationException("Caught inside ReconCaseCreationStepConfig ,template field is required");
		}
		if (this.name == null || this.name.isEmpty()){
			throw new ValidationException("Caught inside ReconCaseCreationStepConfig ,name field is required");
		}
		return true;
	}
}
