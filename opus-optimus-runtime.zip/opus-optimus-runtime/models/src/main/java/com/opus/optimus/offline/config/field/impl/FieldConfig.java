package com.opus.optimus.offline.config.field.impl;

import com.opus.optimus.offline.config.field.IFieldConfig;
import com.opus.optimus.offline.runtime.common.api.record.FieldType;
import lombok.Data;

@Data
public abstract class FieldConfig implements IFieldConfig {

    private short fieldIndex;
    private String name;
    private FieldType type;

    // for date, datetime
    private String format;
}
