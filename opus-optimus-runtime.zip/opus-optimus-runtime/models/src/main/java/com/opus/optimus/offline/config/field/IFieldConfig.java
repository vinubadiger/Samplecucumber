package com.opus.optimus.offline.config.field;

import com.opus.optimus.offline.runtime.common.api.record.FieldType;

public interface IFieldConfig {
    String getName();

    FieldType getType();

    short getFieldIndex();

    // for date, datetime
    String getFormat();
    
    boolean validate();
}
