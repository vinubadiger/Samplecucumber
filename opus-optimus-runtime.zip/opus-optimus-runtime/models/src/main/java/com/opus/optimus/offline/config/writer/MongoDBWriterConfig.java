// package com.opus.optimus.offline.runtime.common.writer.config;

package com.opus.optimus.offline.config.writer;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.field.impl.MongoDBFieldConfig;
import com.opus.optimus.offline.constants.StepTypeConstants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;

/**
 * @author Anup.Warke
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@EqualsAndHashCode(callSuper=true)
@ToString(callSuper=true)
public class MongoDBWriterConfig extends DbWriterConfig {

	private static final long serialVersionUID = 1L;

	private static final String MONGODB_WRITER_STEPTYPE = StepTypeConstants.MONGODB_WRITER_STEPTYPE;

	@NonNull
	private String name;

	private String lable;
	private String sectionName;
	private String dataBaseType;
	private String dataSourceName;
	// Mongo DB specific configuration
	private String collectionName;
	private boolean createCollection; // flag to decide whether to create the collection if not exist
	private boolean update;
	private List<MongoDBFieldConfig> fieldConfigs;
	private String stepType;

	@Override
	public String getStepName() {
		return this.name;
	}

	@Override
	public String getDataBaseType() {
		return this.dataBaseType;
	}

	@Override
	public String getDataSourceName() {
		return this.dataSourceName;
	}

	@Override
	@JsonGetter("stepType")
	public String getStepType() {
		return MONGODB_WRITER_STEPTYPE;
	}

	@Override
	public boolean validate() {
		if (this.name == null || this.name.isEmpty()){
			throw new ValidationException("Caught inside MongoDBWriterConfig ,name field is required");
		}
		if (this.sectionName == null || this.sectionName.isEmpty()){
			throw new ValidationException("Caught inside MongoDBWriterConfig ,sectionName field is required");
		}
		if (this.dataBaseType == null || this.dataBaseType.isEmpty()){
			throw new ValidationException("Caught inside MongoDBWriterConfig ,dataBaseType field is required");
		}
		if (this.dataSourceName == null || this.dataSourceName.isEmpty()){
			throw new ValidationException("Caught inside MongoDBWriterConfig ,dataSourceName field is required");
		}
		if (this.collectionName == null || this.collectionName.isEmpty()){
			throw new ValidationException("Caught inside MongoDBWriterConfig ,collectionName field is required");
		}
		if (this.fieldConfigs == null || this.fieldConfigs.isEmpty()){
			throw new ValidationException("Caught inside MongoDBWriterConfig ,fieldConfigs[]  is required");
		}
		fieldConfigs.parallelStream().forEach(MongoDBFieldConfig::validate);
		return true;
	}
}