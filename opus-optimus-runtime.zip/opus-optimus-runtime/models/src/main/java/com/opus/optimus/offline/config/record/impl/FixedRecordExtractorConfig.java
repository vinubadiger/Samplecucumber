package com.opus.optimus.offline.config.record.impl;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.opus.optimus.offline.config.exception.ValidationException;
import com.opus.optimus.offline.config.record.ITextRecordExtractorConfig;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class FixedRecordExtractorConfig implements ITextRecordExtractorConfig {

	public static final String RECORDTYPE = "FixedRecordExtractorConfig";

	private short recordLength;
	private int rowsToSkip;
	
	private String type;

	@Override
	@JsonGetter ("type")
	public String getType() {
		return RECORDTYPE;
	}

	@Override
	public boolean validate() {
		if (this.recordLength <=0){
			throw new ValidationException("Caught inside FixedRecordExtractorConfig ,recordLength field is required");
		}
		return true;
	}
	
}
