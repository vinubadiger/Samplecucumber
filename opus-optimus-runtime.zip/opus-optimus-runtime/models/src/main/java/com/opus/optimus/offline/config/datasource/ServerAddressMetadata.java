package com.opus.optimus.offline.config.datasource;

import org.springframework.data.mongodb.core.mapping.Field;

import com.opus.optimus.offline.constants.AnnotationConstants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class ServerAddressMetadata {
	
	@Field (AnnotationConstants.SERVER_IP_ADDRESS)
	private String ipAddress;
	
	@Field (AnnotationConstants.SERVER_PORT)
	private int port;
}