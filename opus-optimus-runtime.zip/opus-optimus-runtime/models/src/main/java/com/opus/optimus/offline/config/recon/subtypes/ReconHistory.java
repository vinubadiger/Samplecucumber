package com.opus.optimus.offline.config.recon.subtypes;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReconHistory {
	private String activityName;
	private String jobId;
	private ReconStatus status;
	private ReconSubStatus subStatus;
	private String ruleId;
	private double amount;
	private double tolerance;	
	private Date processingDate;
	private CaseInfo caseInfo;
	private Date createdAt;
}
