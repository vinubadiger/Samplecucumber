package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.config.recon.SourceMappingType
import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory
import com.opus.optimus.offline.runtime.step.reconciliation.match.IToleranceValue
import com.opus.optimus.offline.runtime.step.reconciliation.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.step.reconciliation.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.*
import com.opus.optimus.offline.runtime.workflow.test.DelegatorConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@ContextConfiguration(classes = TestReconciliationConfiguration.class)
class ReconciliationStepSpecification extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    Utility utility;

    @Autowired
    ScriptCreatorFactory scriptCreatorFactory;

    @Autowired
    Map<String, IToleranceValue> toleranceValueCalculator;

    def "Reconciliation single rule test"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def builder = ReconciliationRuleConfig.builder()
        def Rule1 = "Rule1"
        def reconciliationRuleStepConfig = builder
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key'], 'source2': ['key']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
                .build()
        workflowConfig.stepConfigs = [source1Config, reconciliationRuleStepConfig]
        workflowConfig.stepLinks = [
                new StepLink(Source1, Rule1)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()

        emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
        emitter.emit(messageFactory.createEndMessage())
        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(Rule1).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        def reconciliationResult = receivedData.get(0)

        reconciliationResult.getType() == MatchedResultType.PERFECT
        reconciliationResult.getRuleId() == 'Rule1'
        reconciliationResult.getRuleType() == RuleType.PERFECT

        def selectedRecords = reconciliationResult.getSelectedRecords()
        selectedRecords.get('source1').size() == 1
        selectedRecords.get('source2').size() == 1

        jobTaskExecutorResult != null
        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null
        stepExecutionResults.size() == 2

        def rule1Result = stepExecutionResults.grep { it -> it.stepName == Rule1 }
        rule1Result != null
        rule1Result.size() == 1
        2 == rule1Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.inbound.dataCount }
        receivedData.size() == rule1Result.get(0).instanceStats.asList().inject(0) { sum, val -> sum + val.outbound.dataCount }
        println jobTaskExecutorResult
    }

    def "Reconciliation multiple rule test"() {
        setup:
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def Source2 = "Source2"
        def source2Config = new CsvBasedMapRecordStepConfig(Source2)

        def Rule1 = "Rule1"
        def reconciliationRule1StepConfig = ReconciliationRuleConfig.builder()
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key1'], 'source2': ['key1']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
                .build()

        def Rule2 = "Rule2"
        def reconciliationRule2StepConfig = ReconciliationRuleConfig.builder()
                .stepName(Rule2)
                .ruleGroupName(Rule2)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key2'], 'source2': ['key2']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule2', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField2', 'matchField3']))])
                .build()

        def Reconciliation = 'Reconciliation'
        def reconciliationStepConfig = new TestReconciliationStepConfig(Reconciliation,
                [reconciliationRule1StepConfig, reconciliationRule2StepConfig])

        def Collector = 'Collector'
        def collectorStep = new DelegatorConfig(Collector)

        def input1 = '/reconciliation_input1.csv'
        def input2 = '/reconciliation_input2.csv'

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [source1Config, source2Config, reconciliationStepConfig, collectorStep]
        workflowConfig.stepLinks = [
                new StepLink(Source1, Reconciliation),
                new StepLink(Source2, Reconciliation),
                new StepLink(Reconciliation, Collector)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
/*
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule2, new LocalStepExecutorConfig(1, 1, null))

        def repository = new InMemoryWorkflowConfigRepository()
                .addWorkflowConfig(workflowConfig)
                .addWorkflowExecutionConfig("JOB_TASK_1", Reconciliation + '.subworkflow', workflowExecutionConfig);
*/

        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def source1Emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()
        def source2Emitter = localJobTaskExecutor.getInBoundQueue(Source2).getEmitter()

        source1Emitter.emit(messageFactory.createMessage(input1))
        source2Emitter.emit(messageFactory.createMessage(input2))

        source1Emitter.emit(messageFactory.createEndMessage())
        source2Emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        def receiver = localJobTaskExecutor.getOutBoundQueue(Collector).get(0).getReceiver()
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 5

        println jobTaskExecutorResult
    }

    def "Reconciliation single rule test and abort before receiving all records"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def DelegatorWithDelay = "DelegatorWithDelay"
        def delegatorWithDelayConfig = new DelegatorWithDelayConfig(DelegatorWithDelay, 4_000)

        def builder = ReconciliationRuleConfig.builder()
        def Rule1 = "Rule1"
        def reconciliationRuleStepConfig = builder
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key'], 'source2': ['key']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
                .build()
        workflowConfig.stepConfigs = [source1Config, delegatorWithDelayConfig, reconciliationRuleStepConfig]
        workflowConfig.stepLinks = [
                new StepLink(Source1, DelegatorWithDelay),
                new StepLink(DelegatorWithDelay, Rule1)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", DelegatorWithDelay, new LocalStepExecutorConfig(1, 1, null))
        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()

        emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
        emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
        emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
        emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(5, TimeUnit.SECONDS)

        then:
        thrown(TimeoutException)

        when:
        localJobTaskExecutor.abort()
        jobTaskExecutorResult = result.get(5, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        jobTaskExecutorResult != null

        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null

        println jobTaskExecutorResult
    }

    def "Reconciliation single rule test and abort after receiving all records"() {
        setup:
        def workflowConfig = new WorkflowConfig()
        def Source1 = "Source1"
        def source1Config = new CsvBasedMapRecordStepConfig(Source1)

        def builder = ReconciliationRuleConfig.builder()
        def Rule1 = "Rule1"
        def reconciliationRuleStepConfig = builder
                .stepName(Rule1)
                .ruleGroupName(Rule1)
                .sourceNames(['source1', 'source2'])
                .keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key'], 'source2': ['key']]))
                .ruleMatchType(RuleMatchType.ONE_TO_ONE)
                .rules([new ReconciliationRule('Rule1',
                        new SlowRecordMatcher(new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']), 2_000))])
                .build()
        workflowConfig.stepConfigs = [source1Config, reconciliationRuleStepConfig]
        workflowConfig.stepLinks = [
                new StepLink(Source1, Rule1)
        ]

        def workflowExecutionConfig = new WorkflowExecutionConfig()
        def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()

        emitter.emit(messageFactory.createMessage('/reconciliation_abort_test_data.csv'))
        emitter.emit(messageFactory.createEndMessage())

        def jobTaskExecutorResult = result.get(5, TimeUnit.SECONDS)

        then:
        thrown(TimeoutException)

        when:
        localJobTaskExecutor.abort()
        jobTaskExecutorResult = result.get(5, TimeUnit.SECONDS)

        then:
        notThrown(TimeoutException)
        jobTaskExecutorResult != null

        def stepExecutionResults = jobTaskExecutorResult.stepExecutorResults
        stepExecutionResults != null

        println jobTaskExecutorResult
    }

    def "Reconciliation multiple rule test - DPS-PTech"() {
        setup:
        def vistaPaymentIdField = "VESTA_PAYMENTID"
        def paymentIdField = "PAYMENTID"
        def merchantOrderNo = "MERCHANT_ORDER_No"
        def dpsSource = "DPS"
        def pTechSource = "Ptech"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/reconMultipleMatchingRuleConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconMultiRuleJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for DPS
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(vistaPaymentIdField)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(paymentIdField)
                .type(FieldType.STRING)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, dpsSource);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(merchantOrderNo)
                .type(FieldType.STRING)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, pTechSource);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()

        //build the DPS record
        Map<String, Object> testDPSRecordFieldValues = new HashMap<>();
        testDPSRecordFieldValues.put(vistaPaymentIdField, "000000002");
        testDPSRecordFieldValues.put(paymentIdField, null);
        IRecord dpsRecord1 = utility.buildRecord(recordFieldConfigs1, testDPSRecordFieldValues, dpsSource);
        emitter.emit(messageFactory.createMessage(dpsRecord1))

        testDPSRecordFieldValues.put(vistaPaymentIdField, null);
        testDPSRecordFieldValues.put(paymentIdField, "000000003");
        IRecord dpsRecord2 = utility.buildRecord(recordFieldConfigs1, testDPSRecordFieldValues, dpsSource);
        emitter.emit(messageFactory.createMessage(dpsRecord2))

        //build the PaymentTech record
        Map<String, Object> testPTechRecordFieldValues = new HashMap<>();
        testPTechRecordFieldValues.put(merchantOrderNo, "000000002");
        IRecord pTechRecord1 = utility.buildRecord(recordFieldConfigs2, testPTechRecordFieldValues, pTechSource);
        emitter.emit(messageFactory.createMessage(pTechRecord1))

        testPTechRecordFieldValues.put(merchantOrderNo, "000000003");
        IRecord pTechRecord2 = utility.buildRecord(recordFieldConfigs2, testPTechRecordFieldValues, pTechSource);
        emitter.emit(messageFactory.createMessage(pTechRecord2))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() != 0
        receivedData.forEach { reconResult ->
            assert reconResult.type == MatchedResultType.PERFECT
            assert reconResult.ruleType == RuleType.PERFECT
            assert reconResult.selectedRecords.size() != 0
            if (reconResult.ruleId == 0) {
                for (selectedRecord in reconResult.selectedRecords) {
                    if (selectedRecord.key == dpsSource) {
                        selectedRecord.value.each { message ->
                            def iRecord = (IRecord) message.getData()
                            assert iRecord.getValue(iRecord.getFieldId(vistaPaymentIdField)) != null
                            assert iRecord.getValue(iRecord.getFieldId(paymentIdField)) == null
                            return
                        }
                    } else {
                        selectedRecord.value.each { message ->
                            def iRecord = (IRecord) message.getData()
                            assert iRecord.getValue(iRecord.getFieldId(merchantOrderNo)) != null
                            return
                        }
                    }
                }
            } else if (reconResult.ruleId == 1) {
                for (selectedRecord in reconResult.selectedRecords) {
                    if (selectedRecord.key == dpsSource) {
                        selectedRecord.value.each { message ->
                            def iRecord = (IRecord) message.getData()
                            assert iRecord.getValue(iRecord.getFieldId(vistaPaymentIdField)) == null
                            assert iRecord.getValue(iRecord.getFieldId(paymentIdField)) != null
                            return
                        }
                    } else {
                        selectedRecord.value.each { message ->
                            def iRecord = (IRecord) message.getData()
                            assert iRecord.getValue(iRecord.getFieldId(merchantOrderNo)) != null
                            return
                        }
                    }
                }
            }
        }
    }

    def "Reconciliation multiple rule test - With Tolerance"() {
        setup:
        BeanHelper.setScriptCreatorFactory(scriptCreatorFactory);
        BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);

        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/reconMatchingWithToleranceConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()

        //build the Source-A record
        Map<String, Object> testSourceARecordFieldValues = new HashMap<>();
        testSourceARecordFieldValues.put(souceAField1, "000000002");
        testSourceARecordFieldValues.put(souceAField2, new Double(100.00));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues = new HashMap<>();
        testSourceBRecordFieldValues.put(souceBField1, "000000002");
        testSourceBRecordFieldValues.put(souceBField2, new Double(101.15));
        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.MATCHED
            assert reconResult.ruleType == RuleType.TOLERANCE
            assert reconResult.selectedRecords.size() != 0
            for (selectedRecord in reconResult.selectedRecords) {
                if (selectedRecord.key == sourceA) {
                    selectedRecord.value.each { message ->
                        def iRecord = (IRecord) message.getData()
                        assert iRecord.getValue(iRecord.getFieldId(souceAField1)) == "000000002"
                        assert iRecord.getValue(iRecord.getFieldId(souceAField2)) == 100.00
                        return
                    }
                } else {
                    selectedRecord.value.each { message ->
                        def iRecord = (IRecord) message.getData()
                        assert iRecord.getValue(iRecord.getFieldId(souceBField1)) == "000000002"
                        assert iRecord.getValue(iRecord.getFieldId(souceBField2)) == 101.15
                        return
                    }
                }
            }
        }
    }


    def "Reconciliation multiple rule test - With Tolerance - Negative Same Amount"() {
        setup:
        BeanHelper.setScriptCreatorFactory(scriptCreatorFactory);
        BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);

        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/reconMatchingWithToleranceConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()

        //build the Source-A record
        Map<String, Object> testSourceARecordFieldValues = new HashMap<>();
        testSourceARecordFieldValues.put(souceAField1, "000000002");
        testSourceARecordFieldValues.put(souceAField2, new Double(-100.00));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues = new HashMap<>();
        testSourceBRecordFieldValues.put(souceBField1, "000000002");
        testSourceBRecordFieldValues.put(souceBField2, new Double(-100.00));
        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.PERFECT
            assert reconResult.ruleType == RuleType.PERFECT
            assert reconResult.selectedRecords.size() != 0
            for (selectedRecord in reconResult.selectedRecords) {
                if (selectedRecord.key == sourceA) {
                    selectedRecord.value.each { message ->
                        def iRecord = (IRecord) message.getData()
                        assert iRecord.getValue(iRecord.getFieldId(souceAField1)) == "000000002"
                        assert iRecord.getValue(iRecord.getFieldId(souceAField2)) == -100.00
                        return
                    }
                } else {
                    selectedRecord.value.each { message ->
                        def iRecord = (IRecord) message.getData()
                        assert iRecord.getValue(iRecord.getFieldId(souceBField1)) == "000000002"
                        assert iRecord.getValue(iRecord.getFieldId(souceBField2)) == -100.00
                        return
                    }
                }
            }
        }
    }
	
	def "Reconciliation Step - No Key-Identifier - Test"() {
		setup:
		def workflowConfig = new WorkflowConfig()
		def Source1 = "Source1"
		def source1Config = new CsvBasedMapRecordStepConfig(Source1)

		def builder = ReconciliationRuleConfig.builder()
		def Rule1 = "Rule1"
		def reconciliationRuleStepConfig = builder
				.stepName(Rule1)
				.ruleGroupName(Rule1)
				.sourceNames(['source1', 'source2'])
				.keyIdentifier(null)
				.ruleMatchType(RuleMatchType.ONE_TO_ONE)
				.rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
				.build()
		workflowConfig.stepConfigs = [source1Config, reconciliationRuleStepConfig]
		workflowConfig.stepLinks = [
				new StepLink(Source1, Rule1)
		]
		workflowConfig.validate()
		def workflowExecutionConfig = new WorkflowExecutionConfig()
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()

		emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
		emitter.emit(messageFactory.createEndMessage())
		def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

		then:
		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue(Rule1).get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 0
	}
	
	def "Reconciliation Step - No Rule Match Type - Test"() {
		setup:
		def workflowConfig = new WorkflowConfig()
		def Source1 = "Source1"
		def source1Config = new CsvBasedMapRecordStepConfig(Source1)

		def builder = ReconciliationRuleConfig.builder()
		def Rule1 = "Rule1"
		def reconciliationRuleStepConfig = builder
				.stepName(Rule1)
				.ruleGroupName(Rule1)
				.sourceNames(['source1', 'source2'])
				.keyIdentifier(new MapBasedKeyIdentifier(['source1': ['key'], 'source2': ['key']]))
				.ruleMatchType(null)
				.rules([new ReconciliationRule('Rule1', new MapBasedRecordMatcher(RuleType.PERFECT, ['matchField1', 'matchField2']))])
				.build()
		workflowConfig.stepConfigs = [source1Config, reconciliationRuleStepConfig]
		workflowConfig.stepLinks = [
				new StepLink(Source1, Rule1)
		]
		workflowConfig.validate()
		def workflowExecutionConfig = new WorkflowExecutionConfig()
//        workflowExecutionConfig.addStepExecutionConfig("JOB_TASK_1", Rule1, new LocalStepExecutorConfig(1, 1, null))
		def localJobTaskExecutor = executorBuilder.buildWith("JOB1", "JOB_TASK_1", workflowConfig, workflowExecutionConfig)
		localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
		localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))

		when:
		def result = localJobTaskExecutor.execute()
		def emitter = localJobTaskExecutor.getInBoundQueue(Source1).getEmitter()

		emitter.emit(messageFactory.createMessage('/reconciliation_match_rule_test_data.csv'))
		emitter.emit(messageFactory.createEndMessage())
		def jobTaskExecutorResult = result.get(2000, TimeUnit.SECONDS)

		then:
		notThrown(TimeoutException)
		def receiver = localJobTaskExecutor.getOutBoundQueue(Rule1).get(0).getReceiver()
		def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
		receivedData.size() == 0
	}
}
