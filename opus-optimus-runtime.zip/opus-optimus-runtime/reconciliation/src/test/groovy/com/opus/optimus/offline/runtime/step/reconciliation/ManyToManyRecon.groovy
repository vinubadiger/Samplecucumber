package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.step.reconciliation.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.step.reconciliation.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import com.opus.optimus.offline.runtime.workflow.api.event.impl.ConsoleJobEventEmitter
import com.opus.optimus.offline.runtime.workflow.api.impl.JobEventEmitterHelper
import com.opus.optimus.offline.runtime.workflow.api.impl.LocalJobTaskExecutorBuilder
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowExecutionConfig
import com.opus.optimus.offline.runtime.workflow.test.ReceiverUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

import java.text.SimpleDateFormat

@ContextConfiguration(classes = TestReconciliationConfiguration.class)
class ManyToManyRecon extends Specification {
    @Autowired
    LocalJobTaskExecutorBuilder executorBuilder

    @Autowired
    IMessageFactory messageFactory

    @Autowired
    MapperFactory mapperFactory

    @Autowired
    Utility utility;

    def "Many to Many Reconciliation - RECONCILED - TOLERANCE "() {
        setup:
        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def souceAField3 = "FieldA3"
        def souceBField3 = "FieldB3"

        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/ManyToManyReconConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceAField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceBField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        //build the Source-A record
        Map<String, Object> testSourceARecordFieldValues = new HashMap<>();
        testSourceARecordFieldValues.put(souceAField1, "1234");
        testSourceARecordFieldValues.put(souceAField2, new Double(50.00));
        testSourceARecordFieldValues.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-A2 record
        Map<String, Object> testSourceARecordFieldValues2 = new HashMap<>();
        testSourceARecordFieldValues2.put(souceAField1, "1234");
        testSourceARecordFieldValues2.put(souceAField2, new Double(1.00));
        testSourceARecordFieldValues2.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord2 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues2, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord2))

        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues1 = new HashMap<>();
        testSourceBRecordFieldValues1.put(souceBField1, "1234");
        testSourceBRecordFieldValues1.put(souceBField2, new Double(50.00));
        testSourceBRecordFieldValues1.put(souceBField3, dateFormat.parse("20-03-2019"));
        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues2 = new HashMap<>();
        testSourceBRecordFieldValues2.put(souceBField1, "1234");
        testSourceBRecordFieldValues2.put(souceBField2, new Double(1.00));
        testSourceBRecordFieldValues2.put(souceBField3, dateFormat.parse("20-03-2019"));

        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues1, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.MATCHED
            assert reconResult.ruleType == RuleType.TOLERANCE
        }
    }

    def "Many to Many Reconciliation - RECONCILED - PERFECT "() {
        setup:
        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def souceAField3 = "FieldA3"
        def souceBField3 = "FieldB3"

        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/ManyToManyReconConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceAField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceBField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        //build the Source-A record
        Map<String, Object> testSourceARecordFieldValues = new HashMap<>();
        testSourceARecordFieldValues.put(souceAField1, "1234");
        testSourceARecordFieldValues.put(souceAField2, new Double(50.00));
        testSourceARecordFieldValues.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-A2 record
        Map<String, Object> testSourceARecordFieldValues2 = new HashMap<>();
        testSourceARecordFieldValues2.put(souceAField1, "1234");
        testSourceARecordFieldValues2.put(souceAField2, new Double(1.00));
        testSourceARecordFieldValues2.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord2 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues2, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord2))

        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues1 = new HashMap<>();
        testSourceBRecordFieldValues1.put(souceBField1, "1234");
        testSourceBRecordFieldValues1.put(souceBField2, new Double(50.00));
        testSourceBRecordFieldValues1.put(souceBField3, dateFormat.parse("21-03-2019"));
        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues2 = new HashMap<>();
        testSourceBRecordFieldValues2.put(souceBField1, "1234");
        testSourceBRecordFieldValues2.put(souceBField2, new Double(1.00));
        testSourceBRecordFieldValues2.put(souceBField3, dateFormat.parse("21-03-2019"));

        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues1, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.PERFECT
            assert reconResult.ruleType == RuleType.PERFECT

        }
    }

    def "Many to Many Reconciliation - UNRECONCILED - Matched beyond tolerance"() {
        setup:
        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def souceAField3 = "FieldA3"
        def souceBField3 = "FieldB3"

        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/ManyToManyReconConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceAField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceBField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        //build the Source-A record
        Map<String, Object> testSourceARecordFieldValues = new HashMap<>();
        testSourceARecordFieldValues.put(souceAField1, "1234");
        testSourceARecordFieldValues.put(souceAField2, new Double(50.00));
        testSourceARecordFieldValues.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-A2 record
        Map<String, Object> testSourceARecordFieldValues2 = new HashMap<>();
        testSourceARecordFieldValues2.put(souceAField1, "1234");
        testSourceARecordFieldValues2.put(souceAField2, new Double(1.00));
        testSourceARecordFieldValues2.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord2 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues2, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord2))

        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues1 = new HashMap<>();
        testSourceBRecordFieldValues1.put(souceBField1, "1234");
        testSourceBRecordFieldValues1.put(souceBField2, new Double(50.00));
        testSourceBRecordFieldValues1.put(souceBField3, dateFormat.parse("21-04-2019"));
        //build the Source-B record
        Map<String, Object> testSourceBRecordFieldValues2 = new HashMap<>();
        testSourceBRecordFieldValues2.put(souceBField1, "1234");
        testSourceBRecordFieldValues2.put(souceBField2, new Double(100.00));
        testSourceBRecordFieldValues2.put(souceBField3, dateFormat.parse("21-04-2019"));

        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues1, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.UNMATCHED


        }
    }
    def "Many to Many  Reconciliation test ::  one to Many scenarios  multiple records in source B "() {
        setup:
        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def souceAField3 = "FieldA3"
        def souceBField3 = "FieldB3"

        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/ManyToManyReconConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceAField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceBField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")

        //build the Source-A1 record
        Map<String, Object> testSourceARecordFieldValues1 = new HashMap<>();
        testSourceARecordFieldValues1.put(souceAField1, "1234");
        testSourceARecordFieldValues1.put(souceAField2, new Double(100.00));
        testSourceARecordFieldValues1.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues1, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-A2 record
        Map<String, Object> testSourceARecordFieldValues2 = new HashMap<>();
        testSourceARecordFieldValues2.put(souceAField1, "1234");
        testSourceARecordFieldValues2.put(souceAField2, new Double(100.00));
        testSourceARecordFieldValues2.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord2 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues2, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord2))

        //build the Source-B1 record
        Map<String, Object> testSourceBRecordFieldValues1 = new HashMap<>();
        testSourceBRecordFieldValues1.put(souceBField1, "1234");
        testSourceBRecordFieldValues1.put(souceBField2, new Double(51.15));
        testSourceBRecordFieldValues1.put(souceBField3, dateFormat.parse("20-03-2019"));
        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues1, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))

        //build the Source-B2 record
        Map<String, Object> testSourceBRecordFieldValues2 = new HashMap<>();
        testSourceBRecordFieldValues2.put(souceBField1, "1234");
        testSourceBRecordFieldValues2.put(souceBField2, new Double(50.15));
        testSourceBRecordFieldValues2.put(souceBField3, dateFormat.parse("22-03-2019"));
        IRecord sourceBRecord2 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues2, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord2))

        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.UNMATCHED
        }

    }

    def "Many to Many  Reconciliation test ::  Many to One scenarios  multiple records in source A/B "() {
        setup:
        def souceAField1 = "FieldA1"
        def souceBField1 = "FieldB1"
        def souceAField2 = "FieldA2"
        def souceBField2 = "FieldB2"
        def souceAField3 = "FieldA3"
        def souceBField3 = "FieldB3"

        def sourceA = "Source-A"
        def sourceB = "Source-B"

        def mapper = mapperFactory.getMapper()
        //set up step config
        def stepConfigJsonStream = getClass().getResourceAsStream("/jsonData/ManyToManyReconConfig.json")
        def testWorkflowConfig = mapper.readValue(stepConfigJsonStream, TestReconWorkflowConfig.class)

        def workflowConfig = new WorkflowConfig()
        workflowConfig.stepConfigs = [testWorkflowConfig.getReconConfig()]

        //prepare the Local Job Task Executor
        def jobId = "reconWithToleranceJob"

        def localJobTaskExecutor = executorBuilder.buildWith(jobId, "JOB_TASK_2", workflowConfig, new WorkflowExecutionConfig())
        localJobTaskExecutor.setTestEnabled(true)   // Set only for test case
        localJobTaskExecutor.setJobEventEmitterHelper(new JobEventEmitterHelper(new ConsoleJobEventEmitter()))
        //Record schema for Source-A
        List<RecordFieldConfig> recordFieldConfigs1 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceAField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceAField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs1.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceAField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs1, sourceA);
        //Record schema for PaymentTech
        List<RecordFieldConfig> recordFieldConfigs2 = new ArrayList<RecordFieldConfig>();
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name(souceBField1)
                .type(FieldType.STRING)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name(souceBField2)
                .type(FieldType.DOUBLE)
                .build());
        recordFieldConfigs2.add(RecordFieldConfig.builder()
                .fieldIndex((short) 3)
                .name(souceBField3)
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(recordFieldConfigs2, sourceB);

        when:
        def result = localJobTaskExecutor.execute()
        def emitter = localJobTaskExecutor.getInBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).getEmitter()
        def receiver = localJobTaskExecutor.getOutBoundQueue(testWorkflowConfig.getReconConfig().getStepName()).get(0).getReceiver()
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")

        //build the Source-A1 record
        Map<String, Object> testSourceARecordFieldValues1 = new HashMap<>();
        testSourceARecordFieldValues1.put(souceAField1, "1234");
        testSourceARecordFieldValues1.put(souceAField2, new Double(25.00));
        testSourceARecordFieldValues1.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord1 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues1, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord1))

        //build the Source-A2 record
        Map<String, Object> testSourceARecordFieldValues2 = new HashMap<>();
        testSourceARecordFieldValues2.put(souceAField1, "1234");
        testSourceARecordFieldValues2.put(souceAField2, new Double(26.00));
        testSourceARecordFieldValues2.put(souceAField3, dateFormat.parse("21-03-2019"));
        IRecord sourceARecord2 = utility.buildRecord(recordFieldConfigs1, testSourceARecordFieldValues2, sourceA);
        emitter.emit(messageFactory.createMessage(sourceARecord2))

        //build the Source-B1 record
        Map<String, Object> testSourceBRecordFieldValues1 = new HashMap<>();
        testSourceBRecordFieldValues1.put(souceBField1, "1234");
        testSourceBRecordFieldValues1.put(souceBField2, new Double(51.15));
        testSourceBRecordFieldValues1.put(souceBField3, dateFormat.parse("20-03-2019"));
        IRecord sourceBRecord1 = utility.buildRecord(recordFieldConfigs2, testSourceBRecordFieldValues1, sourceB);
        emitter.emit(messageFactory.createMessage(sourceBRecord1))


        emitter.emit(messageFactory.createEndMessage())
        result.get()
        then:
        def receivedData = ReceiverUtil.collectDataFromReceiver(receiver)
        receivedData.size() == 1
        for (def i = 0; i < receivedData.size(); i++) {
            def reconResult = receivedData.get(i)
            assert reconResult.type == MatchedResultType.MATCHED
        }

    }

}
