package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.config.recon.subtypes.OrClause

class ReconOrCluaseConfig {
	OrClause orClause;

	protected OrClause getOrClause() {
		return orClause;
	}

	protected void setOrClause(OrClause orClause) {
		this.orClause = orClause;
	}
}
