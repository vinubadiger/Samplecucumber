package com.opus.optimus.offline.runtime.step.reconciliation.match

import com.opus.optimus.offline.runtime.common.api.record.FieldType
import com.opus.optimus.offline.runtime.common.api.record.IRecord
import com.opus.optimus.offline.runtime.common.api.serializer.impl.MapperFactory
import com.opus.optimus.offline.runtime.step.reconciliation.*
import com.opus.optimus.offline.runtime.step.reconciliation.util.RecordFieldConfig
import com.opus.optimus.offline.runtime.step.reconciliation.util.Utility
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ContextConfiguration

import spock.lang.Ignore
import spock.lang.Specification

import java.text.SimpleDateFormat

@ContextConfiguration(classes = TestReconciliationConfiguration.class)
class RecordMatcherSpecification extends Specification {
    @Autowired
    MapperFactory mapperFactory

    @Autowired
    Utility utility;

    @Autowired
    IMessageFactory messageFactory
	
	@Autowired
	Map<String, IToleranceValue> toleranceValueCalculator;

    def "Check Amount Variance - Absolute - Successful"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.14d);
        sourceARecordFieldValues.put("TRANSACTION_DATE", new Date());
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.00d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == true
        matchResult.getType() == RuleType.TOLERANCE
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) != null
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) == 0.14
    }

    def "Check Amount Variance - Perfect Match - Successful"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.00d);
        sourceARecordFieldValues.put("TRANSACTION_DATE", new Date());
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.00d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        IRecordMatcher recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == true
        matchResult.getType() != RuleType.TOLERANCE
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) != null
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) == 0.0
        matchResult.getType() == RuleType.PERFECT
    }

    def "Check Date Variance - Perfect Match - Successful"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.70d);
        //build Source A date
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        sourceARecordFieldValues.put("TRANSACTION_DATE", dateFormat.parse("19-03-2019"));
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.70d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", dateFormat.parse("19-03-2019"));
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchDateAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == true
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_DATE_VALUE) != null
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_DATE_VALUE) == 0
        matchResult.getType() != RuleType.TOLERANCE
        matchResult.getType() == RuleType.PERFECT
    }

    def "Check Date Variance - Absolute - Successful"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.00d);
        //build Source A date
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        sourceARecordFieldValues.put("TRANSACTION_DATE", dateFormat.parse("19-03-2019"));
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.70d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", dateFormat.parse("21-03-2019"));
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchDateAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == true
        matchResult.getType() == RuleType.TOLERANCE
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_DATE_VALUE) != null
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_DATE_VALUE) == 2
    }

    def "Check Date Variance - Percentage - Not supported"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.00d);
        //build Source A date
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        sourceARecordFieldValues.put("TRANSACTION_DATE", dateFormat.parse("19-03-2019"));
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.70d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", dateFormat.parse("21-03-2019"));
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchDatePercentageConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == false
        matchResult.getType() == RuleType.TOLERANCE
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_DATE_VALUE) != null
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_DATE_VALUE) == 2
    }

    def "Check Amount Variance - Percentage - Successful"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.00d);
        sourceARecordFieldValues.put("TRANSACTION_DATE", new Date());
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.70d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountPercentageConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == true
        matchResult.getType() == RuleType.TOLERANCE
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) != null
        matchResult.getSupportingData().get(IRecordMatcher.TOLERANCE_AMOUNT_VALUE) == -0.70
    }

    def "Check Amount Variance - Absolute - Failed"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.14d);
        sourceARecordFieldValues.put("TRANSACTION_DATE", new Date());
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 150.00d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == false
        matchResult.getType() == RuleType.TOLERANCE
    }

    def "Check Date Variance - Absolute - Failed"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.00d);
        //build Source A date
        def dateFormat = new SimpleDateFormat("dd-MM-yyyy")
        sourceARecordFieldValues.put("TRANSACTION_DATE", dateFormat.parse("19-03-2019"));
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.70d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", dateFormat.parse("23-03-2019"));
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchDateAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == false
        matchResult.getType() == RuleType.TOLERANCE
    }

    def "Check Amount Variance - Percentage - Failed"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.00d);
        sourceARecordFieldValues.put("TRANSACTION_DATE", new Date());
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 135.70d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountPercentageConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == false
        matchResult.getType() == RuleType.TOLERANCE
    }

    def "Check Variance - Without toleranceValueProviders"() {
        given:
        //build the record for Source-A
        List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("TRANSACTION_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("TRANSACTION_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
        Map<String, Object> sourceARecordFieldValues = new HashMap<>();
        sourceARecordFieldValues.put("TRANSACTION_AMOUNT", 145.14d);
        sourceARecordFieldValues.put("TRANSACTION_DATE", new Date());
        IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

        //build the record for Source-B
        List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 1)
                .name("PAYMENT_AMOUNT")
                .type(FieldType.DOUBLE)
                .build());
        sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
                .fieldIndex((short) 2)
                .name("PAYMENT_DATE")
                .type(FieldType.DATETIME)
                .build());
        utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
        Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
        sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.00d);
        sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
        IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

        //set not variance value identifier
        BeanHelper.setToleranceValueCalculator(null);

        //build the matching clause
        def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
        def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
        def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
        when:
        def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
        then:
        matchResult.isMatches() == false
        matchResult.getType() == RuleType.TOLERANCE
    }
	
	def "Check Variance - LHS Other than IRecord"() {
		given:
		//build the record for Source-B
		List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("PAYMENT_AMOUNT")
				.type(FieldType.DOUBLE)
				.build());
		sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 2)
				.name("PAYMENT_DATE")
				.type(FieldType.DATETIME)
				.build());
		utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
		Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
		sourceBRecordFieldValues.put("PAYMENT_AMOUNT", 145.00d);
		sourceBRecordFieldValues.put("PAYMENT_DATE", new Date());
		IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

		//set not variance value identifier
		BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);

		//build the matching clause
		def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
		def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
		def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
		when:
		def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage("record1")), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
		then:
		matchResult.isMatches() == false
		matchResult.getType() == RuleType.TOLERANCE
	}
	
	def "Check Variance - LHS-RHS Other than IRecord"() {
		given:
		//set not variance value identifier
		BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);

		//build the matching clause
		def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
		def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
		def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
		when:
		def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage("record1")), Arrays.asList(messageFactory.createMessage("record2")));
		then:
		matchResult.isMatches() == false
		matchResult.getType() == RuleType.TOLERANCE
	}
	
	def "Check Variance - No LHS - RHS Records available"() {
		given:
		//set not variance value identifier
		BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);

		//build the matching clause
		def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountAbsoluteConfig.json")
		def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
		def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
		when:
		def matchResult = recordMatcher.check(Arrays.asList(), Arrays.asList());
		then:
		matchResult.isMatches() == false
		matchResult.getType() == RuleType.TOLERANCE
	}
	
	def "Check Variance - Other than DOUBLE and DATE"() {
		given:
		//build the record for Source-A
		List<RecordFieldConfig> sourceARecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceARecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("TRANSACTION_AMOUNT")
				.type(FieldType.STRING)
				.build());
		
		utility.buildRecordMetaData(sourceARecordFieldConfigs, "sourceAData");
		Map<String, Object> sourceARecordFieldValues = new HashMap<>();
		sourceARecordFieldValues.put("TRANSACTION_AMOUNT", "145.14");
		IRecord sourceA_Record = utility.buildRecord(sourceARecordFieldConfigs, sourceARecordFieldValues, "sourceAData");

		//build the record for Source-B
		List<RecordFieldConfig> sourceBRecordFieldConfigs = new ArrayList<RecordFieldConfig>();
		sourceBRecordFieldConfigs.add(RecordFieldConfig.builder()
				.fieldIndex((short) 1)
				.name("PAYMENT_AMOUNT")
				.type(FieldType.STRING)
				.build());
		utility.buildRecordMetaData(sourceBRecordFieldConfigs, "sourceBData");
		Map<String, Object> sourceBRecordFieldValues = new HashMap<>();
		sourceBRecordFieldValues.put("PAYMENT_AMOUNT", "145.00");
		IRecord sourceB_Record = utility.buildRecord(sourceBRecordFieldConfigs, sourceBRecordFieldValues, "sourceBData");

		//set not variance value identifier
		BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);

		//build the matching clause
		def orClauseConfigJsonStream = getClass().getResourceAsStream("/variance/recordMatchAmountPercentageConfig.json")
		def orClauseConfig = mapperFactory.getMapper().readValue(orClauseConfigJsonStream, ReconOrCluaseConfig.class)
		def recordMatcher = new RecordMatcher(orClauseConfig.getOrClause());
		when:
		def matchResult = recordMatcher.check(Arrays.asList(messageFactory.createMessage(sourceA_Record)), Arrays.asList(messageFactory.createMessage(sourceB_Record)));
		then:
		matchResult.isMatches() == false
		matchResult.getType() == RuleType.TOLERANCE
	}
}
