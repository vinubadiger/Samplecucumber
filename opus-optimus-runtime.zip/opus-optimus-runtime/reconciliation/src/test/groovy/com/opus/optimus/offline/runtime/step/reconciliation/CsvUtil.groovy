package com.opus.optimus.offline.runtime.step.reconciliation

@Singleton
class CsvUtil {
    List<Map<String, Object>> getAllRecords(def fileName) {
        def jsonStream = getClass().getResourceAsStream(fileName)
        def lines = jsonStream.readLines()
        def headers = lines.get(0).split(',').collect { it.trim() }
        return lines.drop(1).collect {
            it.split(',').collect { it.trim() }.withIndex().collectEntries { value ->
                [(headers.get(value.second)): value.first]
            }
        }
    }


    List<Map<String, Object>> getAllResults(def fileName) {
        def jsonStream = getClass().getResourceAsStream(fileName)
        def lines = jsonStream.readLines()
        def headers = lines.get(0).split(',').collect { it.trim() }
        return lines.drop(1).collect {
            it.split(',').collect { it.trim() }.withIndex().collectEntries { value ->
                def actualValue = value.first
                def fieldName = headers.get(value.second)
                if (fieldName == 'source1Records' || fieldName == 'source2Records') {
                    actualValue = value.first.split('#').collect { it.trim() }
                }
                [(fileName): actualValue]
            }
        }
    }

}
