package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class DelegatorWithDelayConfig extends SimpleStepConfig {
    def static STEP_TYPE = "DelegatorWithDelay"

    int delayInMs = 0;

    DelegatorWithDelayConfig() {
        this("", STEP_TYPE, 0)
    }

    DelegatorWithDelayConfig(String stepName) {
        this(stepName, STEP_TYPE, 0)
    }

    DelegatorWithDelayConfig(String stepName, int delayInMs) {
        super(stepName, STEP_TYPE)
        this.delayInMs = delayInMs
    }
}
