package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.impl.MapStep
import org.springframework.beans.factory.config.ConfigurableBeanFactory
import org.springframework.context.annotation.Scope
import org.springframework.stereotype.Component

@Component("DelegatorWithDelay")
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
class DelegatorWithDelayStep extends MapStep<DelegatorWithDelayConfig> {
    DelegatorWithDelayStep(DelegatorWithDelayConfig config) {
        super(config)
    }

    @Override
    protected <I extends Serializable, R extends Serializable> R doProcess(I data) {
        if (config.delayInMs != 0) {
            println "Delay starts"
            Thread.sleep(config.delayInMs)
            println "Delay ends"
            println data
        }

        return data
    }
}
