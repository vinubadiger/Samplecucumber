package com.opus.optimus.offline.runtime.step.reconciliation;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.opus.optimus.offline.config.exception.EngineException;

@Configuration
@ComponentScan({"com.opus.optimus.offline", "com.opusconsulting.pegasus"})
@EnableMongoRepositories ({"com.opus.optimus.offline.runtime.common.reader.repository" ,"com.opus.optimus.offline.runtime.common.writer.repository"})
public class TestReconciliationConfiguration {
    @Bean
    public ExecutorService createExecutorService() {
        return Executors.newCachedThreadPool();
    }
    
    @Bean
    public MongoClient mongo() {
        return new MongoClient("localhost");
    }
 
    @Bean
    public MongoTemplate mongoTemplate() throws EngineException {
        return new MongoTemplate(mongo(), "test");
    }
}
