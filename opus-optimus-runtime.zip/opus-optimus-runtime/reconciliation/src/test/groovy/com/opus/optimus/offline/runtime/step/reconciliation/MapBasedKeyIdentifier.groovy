package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.IMessage

public class MapBasedKeyIdentifier implements IKeyIdentifier<IMessage> {
    Map<String, List<String>> sourceBasedKeyFields

    public MapBasedKeyIdentifier(Map<String, List<String>> sourceBasedKeyFields) {
        this.sourceBasedKeyFields = sourceBasedKeyFields;
    }

    @Override
    public String getKey(IMessage message) {
        Map<String, Object> data = message.getData()
        def source = data.get('_source')
        return sourceBasedKeyFields.get(source).collect {
            data.get(it)
        }.join('_');
    }
}
