package com.opus.optimus.offline.runtime.step.reconciliation


import com.opus.optimus.offline.runtime.workflow.api.IEmbeddedSubWorkflowConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.EndStepConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.StartStepConfig
import com.opus.optimus.offline.runtime.workflow.api.impl.StepLink
import com.opus.optimus.offline.runtime.workflow.api.impl.WorkflowConfig

class TestReconciliationStepConfig extends SimpleStepConfig implements IEmbeddedSubWorkflowConfig {
    def static STEP_TYPE = "TestReconciliationStep"
    List<ReconciliationRuleConfig> ruleConfigs

    TestReconciliationStepConfig() {
        super('', STEP_TYPE)
    }

    TestReconciliationStepConfig(String stepName, List<ReconciliationRuleConfig> ruleConfigs) {
        super(stepName, STEP_TYPE)

        this.ruleConfigs = ruleConfigs;
    }

    @Override
    WorkflowConfig getWorkflowConfig() {
        def ruleStepConfigs = getRuleStepConfigs()
        def startStepConfig = new StartStepConfig();
        def endStepConfig = new EndStepConfig();

        def unwrapMatchedResultStepConfigs = []
        def stepLinks = ruleStepConfigs.dropRight(1).withIndex().collect {
            def from = it.first.getStepName()
            def to = ruleStepConfigs.get(it.second + 1).getStepName()
            def unwrapName = from + '.unWrap'
            unwrapMatchedResultStepConfigs.add(new UnWrapReconciliationMatchedResultConfig(unwrapName))

            return [
                    new StepLink(from, unwrapName, new MatchedResultTypeScriptConfig([MatchedResultType.NO_DATA_IN_SOURCE])),
                    new StepLink(unwrapName, to),
                    new StepLink(from, endStepConfig.getStepName())
            ]
        }.flatten()

        def startToFirstRuleLink = new StepLink(startStepConfig.getStepName(), ruleStepConfigs.get(0).getStepName())
        def lastRuleToEndStepLink = new StepLink(ruleStepConfigs.get(ruleStepConfigs.size() - 1).getStepName(), endStepConfig.getStepName())
        stepLinks = stepLinks + startToFirstRuleLink + lastRuleToEndStepLink

        return WorkflowConfig.builder()
                .name(stepName + '.subworkflow')
                .stepConfigs(ruleStepConfigs + startStepConfig + endStepConfig + unwrapMatchedResultStepConfigs)
                .stepLinks(stepLinks)
                .startStepName(startStepConfig.getStepName())
                .endStepName(endStepConfig.getStepName())
                .build();
    }

    List<ReconciliationRuleConfig> getRuleStepConfigs() {
        return ruleConfigs
    }
}
