package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.impl.SimpleStepConfig

class CsvBasedMapRecordStepConfig extends SimpleStepConfig {
    def static STEP_TYPE = "CsvBaseMapRecordStep"

    CsvBasedMapRecordStepConfig(String stepName) {
        super(stepName, STEP_TYPE)
    }

}
