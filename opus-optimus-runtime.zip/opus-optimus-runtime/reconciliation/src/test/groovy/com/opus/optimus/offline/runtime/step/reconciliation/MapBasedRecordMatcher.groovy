package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.IMessage

class MapBasedRecordMatcher implements IRecordMatcher<IMessage> {
    RuleType ruleType
    List<String> matchFields

    MapBasedRecordMatcher(RuleType ruleType, List<String> matchFields) {
        this.ruleType = ruleType
        this.matchFields = matchFields
    }

    @Override
    RecordMatcherResult check(List<IMessage> lhsMessages, List<IMessage> rhsMessages) {
        IMessage lhs = lhsMessages.get(0);
        IMessage rhs = rhsMessages.get(0);
        def matchedList = matchFields.grep {
            lhs.getData().get(it) != rhs.getData().get(it)
        }

        return new RecordMatcherResult(matchedList.size() == 0, ruleType, new HashMap<String, Object>())
    }
}
