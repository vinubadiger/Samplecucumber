package com.opus.optimus.offline.runtime.step.reconciliation

class TestReconWorkflowConfig {
	ReconciliationConfig reconConfig;

	protected ReconciliationConfig getReconConfig() {
		return reconConfig;
	}

	protected void setReconConfig(ReconciliationConfig reconConfig) {
		this.reconConfig = reconConfig;
	}
	
	
}
