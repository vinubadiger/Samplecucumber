package com.opus.optimus.offline.runtime.step.reconciliation

import com.opus.optimus.offline.runtime.workflow.api.IMessage

class SlowRecordMatcher implements IRecordMatcher<IMessage> {
    IRecordMatcher<IMessage> delegate;
    int delayInMs = 0;

    SlowRecordMatcher(IRecordMatcher<IMessage> delegate, int delayInMs) {
        this.delegate = delegate
        this.delayInMs = delayInMs
    }

    @Override
    RecordMatcherResult check(List<IMessage> lhsMessages, List<IMessage> rhsMessages) {
        if (delayInMs != 0) {
            println "Match delay starts"
            Thread.sleep(delayInMs)
            println "Match delay ends"
        }

        return delegate.check(lhsMessages, rhsMessages);
    }
}
