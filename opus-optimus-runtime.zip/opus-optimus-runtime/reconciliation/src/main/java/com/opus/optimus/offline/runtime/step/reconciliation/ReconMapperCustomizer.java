package com.opus.optimus.offline.runtime.step.reconciliation;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsontype.NamedType;
import com.opus.optimus.offline.runtime.common.api.serializer.IMapperCustomizer;
import org.springframework.stereotype.Component;

@Component
public class ReconMapperCustomizer implements IMapperCustomizer<ObjectMapper> {

    @Override
    public void customize(ObjectMapper mapper) {
        mapper.registerSubtypes(new NamedType(ReconciliationConfig.class, ReconciliationConfig.STEP_TYPE));
    }
}
