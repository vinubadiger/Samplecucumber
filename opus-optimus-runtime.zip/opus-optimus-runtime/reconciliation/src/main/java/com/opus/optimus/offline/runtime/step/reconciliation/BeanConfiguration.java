package com.opus.optimus.offline.runtime.step.reconciliation;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.step.reconciliation.match.IToleranceValue;

@Configuration
@ComponentScan("com.opus.optimus")
public class BeanConfiguration {

	@Bean
	boolean setRequiredBeansForConfig(@Autowired ScriptCreatorFactory scriptCreatorFactory,
			@Autowired Map<String, IToleranceValue> toleranceValueCalculator) {
		BeanHelper.setScriptCreatorFactory(scriptCreatorFactory);
		BeanHelper.setToleranceValueCalculator(toleranceValueCalculator);
		return true;
	}

}
