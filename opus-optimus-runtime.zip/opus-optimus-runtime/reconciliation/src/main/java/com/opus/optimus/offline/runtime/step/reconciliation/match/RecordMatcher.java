package com.opus.optimus.offline.runtime.step.reconciliation.match;

import com.opus.optimus.offline.config.recon.subtypes.AndClause;
import com.opus.optimus.offline.config.recon.subtypes.OrClause;
import com.opus.optimus.offline.config.recon.subtypes.Variance;
import com.opus.optimus.offline.config.recon.subtypes.VarianceType;
import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.config.ExcelScriptConfig;
import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.step.reconciliation.BeanHelper;
import com.opus.optimus.offline.runtime.step.reconciliation.IRecordMatcher;
import com.opus.optimus.offline.runtime.step.reconciliation.RecordMatcherResult;
import com.opus.optimus.offline.runtime.step.reconciliation.RuleType;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

/**
 * A Class to match the records from the message data as per the tolerance rule configured for the
 * Reconciliation job.
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class RecordMatcher implements IRecordMatcher<IMessage> {
    static final Logger logger = LoggerFactory.getLogger (RecordMatcher.class);
    private static final String SOURCE_FIELD_LHS_FILED_IND = "LHS";
    private static final String SOURCE_FIELD_RHS_FILED_IND = "RHS";
    private static final String AMOUNT = "AMOUNT";
    private static final String DATE = "DATE";


    final Map<String, IScript<IRecord, ?>> andClauseFieldScripts = new HashMap<> ();
    OrClause toleranceClause;
    ScriptCreatorFactory scriptCreatorFactory;
    private Map<String, IToleranceValue> toleranceValueCalculator;

    public RecordMatcher(OrClause toleranceClause) {
        this.toleranceClause = toleranceClause;
        this.scriptCreatorFactory = BeanHelper.getScriptCreatorFactory ();
        toleranceValueCalculator = BeanHelper.getToleranceValueCalculator ();
        init ();
    }

    private void init() {
        IntStream.range (0, this.toleranceClause.getAndClauses ().size ()).forEach (andClauseIndex -> {
            createAndLoadFieldScript (andClauseIndex, SOURCE_FIELD_LHS_FILED_IND,
                    this.toleranceClause.getAndClauses ().get (andClauseIndex).getLhsField ().getFormulaConfig ());
            createAndLoadFieldScript (andClauseIndex, SOURCE_FIELD_RHS_FILED_IND,
                    this.toleranceClause.getAndClauses ().get (andClauseIndex).getRhsField ().getFormulaConfig ());
        });
    }

    private void createAndLoadFieldScript(int andClauseIndex, String fieldIndicatorKey, IScriptConfig scriptConfig) {
        IScript<IRecord, ?> lhsScript = scriptCreatorFactory.createScript (scriptConfig);
        andClauseFieldScripts.put (buildFieldScriptMapKey (fieldIndicatorKey, andClauseIndex), lhsScript);
    }

    private String buildFieldScriptMapKey(String fieldIndicatorKey, int andClauseIndex) {
        final StringBuilder mapKeyBuilder = new StringBuilder ();
        mapKeyBuilder.append (andClauseIndex);
        mapKeyBuilder.append ("_");
        mapKeyBuilder.append (fieldIndicatorKey);
        return mapKeyBuilder.toString ();
    }

    /**
     * Method which checks the configured reconciliation variance match rules
     * against the provided records. The current reconciliation rule support the
     * Amount and date variances check. For other types, method will return failure
     * result
     */
    @Override
    public RecordMatcherResult check(List<IMessage> lhs, List<IMessage> rhs) {

        if (toleranceValueCalculator == null) {
            logger.error (
                    "No value calculator available with this version for variance match. Application will not able to verify the records. Please check with implementation team.");
            return RecordMatcherResult.builder ().matches (false).supportingData (null).type (RuleType.TOLERANCE).build ();
        }

        final Map<String, Serializable> supportingData = new HashMap<> ();
        if (!isValidMessageData (lhs, rhs, supportingData)) {
            return RecordMatcherResult.builder ().matches (false).supportingData (supportingData).type (RuleType.TOLERANCE)
                    .build ();
        }

        boolean matches = isMatches (lhs, rhs, supportingData);


        RuleType ruleType = getRuleType (supportingData, matches);
        return RecordMatcherResult.builder ().matches (matches).supportingData (supportingData).type (ruleType)
                .build ();
    }

    /**
     * This method return Rule Type details based on supporting data
     * if TOLERANCE_*_VALUE is zero, then RuleType will be Perfect match
     *
     * @param supportingData
     * @param matches
     * @return
     */
    private RuleType getRuleType(Map<String, Serializable> supportingData, boolean matches) {
        if (matches) {
            boolean isExactMatch = false;
            if (supportingData.get (TOLERANCE_AMOUNT_VALUE) != null) {
                isExactMatch = Double.compare ((Double) supportingData.get (TOLERANCE_AMOUNT_VALUE), 0.0) == 0;
            }
            if (supportingData.get (TOLERANCE_DATE_VALUE) != null) {
                isExactMatch = supportingData.get (TOLERANCE_DATE_VALUE) == (Integer) 0;
            }
            return isExactMatch ? RuleType.PERFECT : RuleType.TOLERANCE;
        }
        return RuleType.TOLERANCE;

    }

    private boolean isValidMessageData(List<IMessage> lhs, List<IMessage> rhs, Map<String, Serializable> supportingData) {

        boolean isValidLhsMessageData = lhs.stream ().anyMatch (lhs_Record -> {
            Serializable lhsRecord = lhs_Record.getData ();
            if (!validMessageData (lhsRecord)) {
                logger.error (
                        "Source A - The received message's data are not as expected. Expected data Type: com.opus.optimus.offline.runtime.common.api.record.IRecord, Actual Message type: {}",
                        lhsRecord.getClass ().getName ());
                supportingData.put (ToleranceConstants.TOLERANCE_MATCH_ERR,
                        "Source A - The received message's data is not as expected. Please check the logs for more details");
                return false;
            } else {
                return true;
            }
        });

        boolean isValidRhsMessageData = rhs.stream ().anyMatch (rhs_Record -> {
            Serializable rhsRecord = rhs_Record.getData ();
            if (!validMessageData (rhsRecord)) {
                logger.error (
                        "Source B - The received message's data are not as expected. Expected data Type: com.opus.optimus.offline.runtime.common.api.record.IRecord, Actual Message type: {}",
                        rhsRecord.getClass ().getName ());
                supportingData.put (ToleranceConstants.TOLERANCE_MATCH_ERR,
                        "Source AB - The received message's data is not as expected. Please check the logs for more details");
                return false;
            } else {
                return true;
            }
        });
        return isValidLhsMessageData && isValidRhsMessageData;

    }


    private boolean isMatches(List<IMessage> lhsRecords, List<IMessage> rhsRecords, Map<String, Serializable> supportingData) {

        return IntStream.range (0, this.toleranceClause.getAndClauses ().size ()).allMatch (andClauseIndex -> {

            final AndClause andClause = this.toleranceClause.getAndClauses ().get (andClauseIndex);

            Map<String, List<?>> lhsMatchRecordMap = new HashMap<> ();
            lhsRecords.stream ().forEach (lhsRecord -> {
                Object lhsEvalValue = andClauseFieldScripts
                        .get (buildFieldScriptMapKey (SOURCE_FIELD_LHS_FILED_IND, andClauseIndex)).execute ((IRecord) lhsRecord.getData ());
                aggreateEvalValues (lhsMatchRecordMap, lhsEvalValue);
            });

            Map<String, List<?>> rhsMatchRecordMap = new HashMap<> ();
            rhsRecords.stream ().forEach (rhsRecord -> {
                Object rhsEvalValue = andClauseFieldScripts
                        .get (buildFieldScriptMapKey (SOURCE_FIELD_RHS_FILED_IND, andClauseIndex)).execute ((IRecord) rhsRecord.getData ());
                aggreateEvalValues (rhsMatchRecordMap, rhsEvalValue);
            });

            // get the variance
            Variance allowedVariance = andClause.getOperator ().getVariance ();
            //set the configured tolerance value
            supportingData.put (CONFIGURED_TOLERANCE_VALUE, buildConfiguredToleranceDisplayValue (allowedVariance));
            boolean match = false;


            List<Double> lhsAmounts = (List<Double>) lhsMatchRecordMap.get (AMOUNT);
            List<Double> rhsAmounts = (List<Double>) rhsMatchRecordMap.get (AMOUNT);

            List<Date> lshDates = (List<Date>) lhsMatchRecordMap.get (DATE);
            List<Date> rhsDates = (List<Date>) rhsMatchRecordMap.get (DATE);

            if (lhsAmounts != null && rhsAmounts != null) {
                Double lAmt = lhsAmounts.stream ().reduce (0.0, Double::sum);
                Double rAmt = rhsAmounts.stream ().reduce (0.0, Double::sum);
                match = matchAmounts (lAmt, rAmt, allowedVariance);
                supportingData.put (TOLERANCE_AMOUNT_VALUE, calculateAmountVariance (lAmt, rAmt));

            } else if (lshDates != null && rhsDates != null) {
                List<Boolean> dateMatchResult = new ArrayList<> ();
                List<Integer> ltVariances = new ArrayList<> ();

                lshDates.stream ().forEach (lDate -> {
                    rhsDates.stream ().forEach (rDate -> {
                        dateMatchResult.add (matchDates (lDate, rDate, allowedVariance));
                        ltVariances.add (calculateDateVariance (lDate, rDate));
                    });
                });
                supportingData.put (TOLERANCE_DATE_VALUE, Collections.max (ltVariances));
                match = !dateMatchResult.contains (Boolean.FALSE);

            } else {
                logger.error ("Record does not match with provided tolerance criteria. Tolerance Criteria : LHS Field - "
                        + ((ExcelScriptConfig) andClause.getLhsField ().getFormulaConfig ()).getFormulaText ()
                        + ", RHS Field - "
                        + ((ExcelScriptConfig) andClause.getRhsField ().getFormulaConfig ()).getFormulaText ());
                logger.info ("Engine will skip the followed tolerance clause.");
            }
            return match;
        });

    }


    private void aggreateEvalValues(Map<String, List<?>> lhsMatchRecords, Object evalValue) {
        if (isDoubleObject (evalValue)) {
            List<Double> amountList = (List<Double>) lhsMatchRecords.get (AMOUNT);
            if (amountList == null) {
                amountList = new ArrayList<> ();
            }
            amountList.add ((Double) evalValue);
            lhsMatchRecords.put (AMOUNT, amountList);
        }
        if (isDateObject (evalValue)) {
            List<Date> dateList = (List<Date>) lhsMatchRecords.get (DATE);
            if (dateList == null) {
                dateList = new ArrayList<> ();
            }
            dateList.add ((Date) evalValue);
            lhsMatchRecords.put (DATE, dateList);
        }
    }


    boolean isDoubleObject(Object evalValue) {
        return Double.class.isAssignableFrom (evalValue.getClass ());
    }

    boolean isDateObject(Object evalValue) {
        return Date.class.isAssignableFrom (evalValue.getClass ());
    }


    private boolean matchAmounts(Object lhsEvalValue, Object rhsEvalValue, Variance variance) {
        // get the LHS floor value
        Double lhsFloorValue = calculateFloorValue (lhsEvalValue, variance.getType (), variance.getFloor ());
        // get the LHS ceiling value
        Double lhsCeilingValue = calculateCeilingValue (lhsEvalValue, variance.getType (), variance.getCeiling ());
        if (lhsFloorValue == null || lhsCeilingValue == null) {
            logger.info (
                    "Invalid floor and ceiling value calculated. Floor Value Calculated: {}, Ceiling value calculated: {}",
                    lhsFloorValue, lhsCeilingValue);
            return false;
        }
        // compare the amounts
		if (isNegative(lhsFloorValue) && isNegative(lhsCeilingValue) && isNegative((Double) rhsEvalValue)) {
			int floorCompare = lhsCeilingValue.compareTo((Double) rhsEvalValue);
			int ceilingCompare = lhsFloorValue.compareTo((Double) rhsEvalValue);
			return floorCompare <= 0 && ceilingCompare >= 0;
		} else {
			int floorCompare = lhsFloorValue.compareTo((Double) rhsEvalValue);
			int ceilingCompare = lhsCeilingValue.compareTo((Double) rhsEvalValue);
			return floorCompare <= 0 && ceilingCompare >= 0;
		}
    }

    private boolean matchDates(Object lhsEvalValue, Object rhsEvalValue, Variance variance) {
        // get the LHS floor value
        Date lhsFloorValue = calculateFloorValue (lhsEvalValue, variance.getType (), variance.getFloor ());
        // get the LHS ceiling value
        Date lhsCeilingValue = calculateCeilingValue (lhsEvalValue, variance.getType (), variance.getCeiling ());
        if (lhsFloorValue == null || lhsCeilingValue == null) {
            logger.info (
                    "Matching rule failed due to invalid floor and ceiling value calculated. Floor Value Calculated: {}, Ceiling value calculated: {}",
                    lhsFloorValue, lhsCeilingValue);
            return false;
        }
        // compare the amounts
        int floorCompare = lhsFloorValue.compareTo ((Date) rhsEvalValue);
        int ceilingCompare = lhsCeilingValue.compareTo ((Date) rhsEvalValue);
        return floorCompare <= 0 && ceilingCompare >= 0;
    }

    private <T> T calculateFloorValue(Object fieldEvaluatedValue, VarianceType type, String floor) {
        if (Double.class.isAssignableFrom (fieldEvaluatedValue.getClass ())) {
            return (T) handleAmountFields (fieldEvaluatedValue, type, floor, ToleranceType.FLOOR);
        } else if (Date.class.isAssignableFrom (fieldEvaluatedValue.getClass ())) {
            return (T) handleDateFields (fieldEvaluatedValue, type, floor, ToleranceType.FLOOR);
        } else {
            logger.error (
                    "Can not calculate floor value. The field value should be either of type java.lang.Double or java.util.Date. Actual: {}",
                    fieldEvaluatedValue.getClass ().getName ());
            return null;
        }
    }

    private <T> T calculateCeilingValue(Object fieldEvaluatedValue, VarianceType type, String ceiling) {
        if (Double.class.isAssignableFrom (fieldEvaluatedValue.getClass ())) {
            return (T) handleAmountFields (fieldEvaluatedValue, type, ceiling, ToleranceType.CEILING);
        } else if (Date.class.isAssignableFrom (fieldEvaluatedValue.getClass ())) {
            return (T) handleDateFields (fieldEvaluatedValue, type, ceiling, ToleranceType.CEILING);
        } else {
            logger.error (
                    "Can not calculate ceiling value. The field value should be either of type java.lang.Double or java.util.Date. Actual: {}",
                    fieldEvaluatedValue.getClass ().getName ());
            return null;
        }
    }

    private Double handleAmountFields(Object fieldEvaluatedValue, VarianceType type, String tolerance,
                                      ToleranceType toleranceType) {
        final IToleranceValue<BigDecimal, BigDecimal> doubleValueCalculator = toleranceValueCalculator
                .get (Double.class.getName ());
        final BigDecimal fieldValue = BigDecimal.valueOf ((Double) fieldEvaluatedValue);
        switch (type) {
            case ABSOLUTE:
                return doubleValueCalculator.calculateAbsoluteValue (fieldValue, new BigDecimal (tolerance), toleranceType)
                        .doubleValue ();
            case PERCENTAGE:
                return doubleValueCalculator.calculatePercentageValue (fieldValue, new BigDecimal (tolerance), toleranceType)
                        .doubleValue ();
            default:
                logger.debug (
                        "Only ABSOLUTE or PERCENTAGE based variance can be calculated. Actual: {}, Original Field value will be considered for matching.",
                        type);
                return null;
        }
    }

    private Date handleDateFields(Object fieldEvaluatedValue, VarianceType type, String tolerance,
                                  ToleranceType toleranceType) {
        final IToleranceValue<Date, Integer> dateValueCalculator = toleranceValueCalculator.get (Date.class.getName ());
        switch (type) {
            case ABSOLUTE:
                return dateValueCalculator.calculateAbsoluteValue ((Date) fieldEvaluatedValue, Integer.parseInt (tolerance),
                        toleranceType);
            case PERCENTAGE:
                logger.error (
                        "Only ABSOLUTE based variance can be calculated for date type of fields. Actual: {}, Original Field value will be considered for matching.",
                        type);
                return dateValueCalculator.calculatePercentageValue((Date) fieldEvaluatedValue, Integer.parseInt (tolerance),
                        toleranceType);
            default:
                return null;
        }
    }

    private Double calculateAmountVariance(Double primaryValue, Double secondaryValue) {
        return BigDecimal.valueOf (primaryValue).subtract (BigDecimal.valueOf (secondaryValue))
                .setScale (2, RoundingMode.HALF_UP).doubleValue ();
    }

    private int calculateDateVariance(Date primaryValue, Date secondaryValue) {
        //convert the java.util.Date to java.time.LocalDate
        final LocalDate localDate1 = primaryValue.toInstant ().atZone (ZoneId.of ("GMT")).toLocalDate ();
        final LocalDate localDate2 = secondaryValue.toInstant ().atZone (ZoneId.of ("GMT")).toLocalDate ();
        return Period.between (localDate1, localDate2).getDays ();
    }


    private boolean validMessageData(Serializable record) {
        if (!IRecord.class.isAssignableFrom (record.getClass ())) {
            return false;
        } else {
            return true;
        }
    }

    private boolean isNegative(Double value) {
    	return value < 0.0d;
    }
    
	private String buildConfiguredToleranceDisplayValue(Variance allowedVariance) {
		return allowedVariance.getCeiling()
				+ (VarianceType.PERCENTAGE.equals(allowedVariance.getType()) ? "%" : StringUtils.EMPTY);
	}
}
