package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.common.api.record.IRecord;
import com.opus.optimus.offline.runtime.common.reader.config.DBSourceReference;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.IMessageFactory;
import com.opus.optimus.offline.runtime.workflow.api.IStepInstanceSummary;
import com.opus.optimus.offline.runtime.workflow.api.MessageType;
import com.opus.optimus.offline.runtime.workflow.exception.ErrorDetails;
import com.opus.optimus.offline.runtime.workflow.exception.Severity;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(ReconciliationRuleConfig.STEP_TYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ReconciliationRuleStep extends AbstractReconciliationRuleStep<IMessage, ReconciliationRuleConfig<IMessage>> {
	private static final Logger logger = LoggerFactory.getLogger(ReconciliationRuleStep.class);
	@Autowired
	IMessageFactory messageFactory;
	
	IEmitter emitter;

	public ReconciliationRuleStep(ReconciliationRuleConfig config) {
		super(config);
	}

	@Override
	public IStepInstanceSummary onInstanceEnd(boolean forceEnd, IEmitter emitter) {
		this.emitter = emitter;
		try{
			processAllRecords();
			return super.onInstanceEnd(forceEnd, emitter);
		} catch (Exception exception){
			logger.error("Error while processing the matching of all collected records. Error: {}", exception.getMessage(), exception);
			emitErrorMessage(exception, "Error while processing the matching of all collected records. Error: " + exception.getMessage(), emitter);
			return super.onInstanceEnd(forceEnd, emitter);
		}
	}

	@Override
	protected void emitResult(ReconciliationMatchResult matchRecords) {
		emitter.emit(messageFactory.createMessage(matchRecords));
	}

	@Override
	protected RuleMatchType getRuleMatchType() {
		return config.getRuleMatchType();
	}

	@Override
	protected String getSource(IMessage message) {
		Serializable data = message.getData();
		if (data instanceof Map){
			return (String) ((Map) data).get("_source");
		}

		IRecord record = (IRecord) data;
		return record.getSchema().getName();
	}

	@Override
	public void process(IMessage message, IEmitter emitter) {
		try{
			this.emitter = emitter;
			collectRecords(message, emitter);
		} catch (Exception exception){
			logger.error("Error while collecting the record for the reconcillation. Failed Record Collection Name: {}", (message.getSourceReference() == null || !DBSourceReference.class.isAssignableFrom(message.getSourceReference().getClass()) ? "No Details available" : ((DBSourceReference) message.getSourceReference()).getCollectionName()));
			emitErrorMessage(exception, buildCollectionErrorMsg(message), emitter);
		}
	}

	/**
	 * This method is used to build collection of error messages.
	 * 
	 * @param message
	 * @return String
	 */
	private String buildCollectionErrorMsg(IMessage message) {
		return "Recond collection failed for record from collection : " + (message.getSourceReference() == null || !DBSourceReference.class.isAssignableFrom(message.getSourceReference().getClass()) ? "No collection details available. Please check configuration." : ((DBSourceReference) message.getSourceReference()).getCollectionName());
	}

	/**
	 * This method is used to emit the error massages.
	 * 
	 * @param exception
	 * @param message
	 * @param emitter
	 */
	private void emitErrorMessage(Exception exception, String message, IEmitter emitter) {
		// build the error details
		ErrorDetails errorDetails = ErrorDetails.builder().errorDetail(exception).severity(Severity.ERROR).userDetails(message).build();
		emitter.emit(messageFactory.createMessage(MessageType.ERROR, errorDetails));
	}

	@Override
	protected void processInvalidKeyRecord(String key, IMessage message, IEmitter emitter) {
		ReconciliationMatchResult<IMessage> matchResult = createReconciliationMatchResult(MatchedResultType.NO_DATA_IN_SOURCE, message);
		emitter.emit(messageFactory.createMessage(MessageType.DATA, matchResult));
	}

	/**
	 * 
	 * @param matchedResultType
	 * @param singleMessage
	 * @return
	 */
	protected ReconciliationMatchResult<IMessage> createReconciliationMatchResult(MatchedResultType matchedResultType, IMessage singleMessage) {
		Map<String, List<IMessage>> convertedResult = new HashMap<>();
		convertedResult.put(getSource(singleMessage), Arrays.asList(singleMessage));
		return new ReconciliationMatchResult<>(matchedResultType, convertedResult);
	}

	@Override
	protected boolean isValidKey(String key) {
		return !StringUtils.isEmpty(key);
	}
}
