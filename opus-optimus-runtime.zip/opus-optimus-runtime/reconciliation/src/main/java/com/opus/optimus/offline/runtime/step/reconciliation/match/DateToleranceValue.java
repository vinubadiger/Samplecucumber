package com.opus.optimus.offline.runtime.step.reconciliation.match;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component("java.util.Date")
public class DateToleranceValue implements IToleranceValue<Date, Integer> {
	
	@Override
	public Date calculateAbsoluteValue(Date fieldValue, Integer tolerance, ToleranceType toleranceType) {
		final Instant fieldInstanceValue = fieldValue.toInstant();
		switch (toleranceType) {
		case FLOOR:
			return Date.from(fieldInstanceValue.minus(tolerance, ChronoUnit.DAYS));
		case CEILING:
			return Date.from(fieldInstanceValue.plus(tolerance, ChronoUnit.DAYS));
		default:
			return fieldValue;
		}
	}

	@Override
	public Date calculatePercentageValue(Date fieldValue, Integer tolerance,
			ToleranceType toleranceType) {
		//TODO throw exception unsupported
		return null;
	}
}
