package com.opus.optimus.offline.runtime.step.reconciliation;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.collections.api.bag.Bag;
import org.eclipse.collections.api.list.MutableList;
import org.eclipse.collections.api.multimap.list.MutableListMultimap;
import org.eclipse.collections.impl.factory.Multimaps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opus.optimus.offline.config.exception.EngineException;
import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;

public abstract class AbstractReconciliationRuleStep<T, C extends ReconciliationRuleConfig<T>> extends AbstractStep<C> {
    private static final Logger logger = LoggerFactory.getLogger (AbstractReconciliationRuleStep.class);
    MutableListMultimap<String, T> keyBasedRecords = Multimaps.mutable.list.empty ();
    private static final int noOfSources = 2;

    public AbstractReconciliationRuleStep(C config) {
        super (config);
    }

    protected void collectRecords(T record, IEmitter emitter) {
        String key = getKey (record);
        if (isValidKey(key)) {
            keyBasedRecords.put(key, record);
        } else {
            processInvalidKeyRecord(key, record, emitter);
        }
    }
    
    protected abstract void processInvalidKeyRecord(String key, T record, IEmitter emitter);

    protected boolean isValidKey(String key) {
        return key != null;
    }

    protected void processAllRecords() {
        logger.info ("No of records received for processing: {}", keyBasedRecords.size ());

        for (String key : keyBasedRecords.keySet ()) {
            if (forceStop.get() == true) {
                return;
            }
            MutableList<T> singleKeyRecords = keyBasedRecords.get (key);
            emitResult (matchRecords (singleKeyRecords));
        }
    }

    protected ReconciliationMatchResult<T> matchRecords(MutableList<T> records) {
        MutableListMultimap<String, T> sourceBasedRecords = records.groupBy (this::getSource);
        RuleMatchType matchType = getRuleMatchType ();

        if (!validateReconSources (sourceBasedRecords)) {
            return new ReconciliationMatchResult<T> (MatchedResultType.NO_DATA_IN_SOURCE, convertToMapOfList (sourceBasedRecords));
        }

        switch (matchType) {
            case ONE_TO_ONE:
                return processOneToOneRule (sourceBasedRecords);
            case ONE_TO_N:
                return processOneToNRule (sourceBasedRecords);
            case N_TO_ONE:
                return processNToOneRule (sourceBasedRecords);
            case N_TO_N:
                return processNToNRule (sourceBasedRecords);
            default:
                throw new EngineException ("Invalid rule match type " + matchType);
        }
    }

    private boolean validateReconSources(MutableListMultimap<String, T> sourceBasedRecords) {
        Bag<String> sources = sourceBasedRecords.keyBag ();

        if (sources.size () < noOfSources) {
            return false;
        }
        return true;
    }

    private ReconciliationMatchResult<T> processOneToOneRule(MutableListMultimap<String, T> sourceBasedRecords) {
        Bag<String> moreThanOneRecords = sourceBasedRecords.keyBag ().selectByOccurrences ((occurrence) -> occurrence > 1);

        if (moreThanOneRecords.size () > 0) {
            return new ReconciliationMatchResult<> (MatchedResultType.UNEXPECTED_MULTIPLE_RECORDS, convertToMapOfList (sourceBasedRecords));
        }
        return buildReconMatchResult (sourceBasedRecords, config.getSourceNames ());
    }

    private ReconciliationMatchResult<T> processOneToNRule(MutableListMultimap<String, T> sourceBasedRecords) {
        List<String> sourceNames = config.getSourceNames ();

        if (sourceBasedRecords.get (sourceNames.get (0)).size () > 1) {
            return new ReconciliationMatchResult<> (MatchedResultType.UNEXPECTED_MULTIPLE_RECORDS, convertToMapOfList (sourceBasedRecords));
        }
        return buildReconMatchResult (sourceBasedRecords, sourceNames);
    }

    private ReconciliationMatchResult<T> processNToOneRule(MutableListMultimap<String, T> sourceBasedRecords) {
        List<String> sourceNames = config.getSourceNames ();

        if (sourceBasedRecords.get (sourceNames.get (1)).size () > 1) {  //Source B
            return new ReconciliationMatchResult<> (MatchedResultType.UNEXPECTED_MULTIPLE_RECORDS, convertToMapOfList (sourceBasedRecords));
        }
        return buildReconMatchResult (sourceBasedRecords, sourceNames);
    }

    private ReconciliationMatchResult<T> processNToNRule(MutableListMultimap<String, T> sourceBasedRecords) {
        List<String> sourceNames = config.getSourceNames ();
        return buildReconMatchResult (sourceBasedRecords, sourceNames);
    }

    private ReconciliationMatchResult<T> buildReconMatchResult(MutableListMultimap<String, T> sourceBasedRecords, List<String> sourceNames) {
        String source1 = sourceNames.get (0);
        String source2 = sourceNames.get (1);

        if (config.getRules () == null || config.getRules ().isEmpty ()) {
            return new ReconciliationMatchResult<> (MatchedResultType.PERFECT, config.getRuleGroupName (), RuleType.PERFECT,
                    convertToMapOfList (sourceBasedRecords), null);
        }

        Map<String, Serializable> toleranceVerificationSupportingData = null;
        for (ReconciliationRule<T> rule : config.getRules ()) {
            List<T> source1Data = sourceBasedRecords.get (source1);
            List<T> source2Data = sourceBasedRecords.get (source2);
            RecordMatcherResult matcherResult = rule.getRecordMatcher ().check (source1Data, source2Data);
            //substatus check
			final MatchedResultType matchResultType = isExactMatch(matcherResult) ? MatchedResultType.PERFECT
					: MatchedResultType.MATCHED;
            if (matcherResult.matches) {
                return new ReconciliationMatchResult<> (matchResultType,
                        rule.getId (), matcherResult.getType (),
                        convertToMapOfList (sourceBasedRecords),
                        matcherResult.getSupportingData ());
            } else {
            	//in case the records are match beyond tolerance, we need to update the tolerance
            	toleranceVerificationSupportingData = matcherResult.getSupportingData ();
            }
        }
        return new ReconciliationMatchResult<> (MatchedResultType.UNMATCHED,
                config.getRuleGroupName (), null,
                convertToMapOfList (sourceBasedRecords), toleranceVerificationSupportingData);
    }

    private Map<String, List<T>> convertToMapOfList(MutableListMultimap<String, T> sourceBasedRecords) {
        Map<String, List<T>> convertedResult = new HashMap<> ();

        for (String key : sourceBasedRecords.keySet ()) {
            convertedResult.put (key, sourceBasedRecords.get (key));
        }
        return convertedResult;
    }

    protected String getKey(T record) {
        return config.getKeyIdentifier ().getKey (record);
    }

    protected RuleMatchType getRuleMatchType() {
        return config.getRuleMatchType ();
    }
    
    private boolean isExactMatch(RecordMatcherResult matcherResult) {
		return matcherResult.matches && RuleType.PERFECT.equals(matcherResult.getType());
	}

    protected abstract void emitResult(ReconciliationMatchResult<T> matchRecords);

    protected abstract String getSource(T record);

}

