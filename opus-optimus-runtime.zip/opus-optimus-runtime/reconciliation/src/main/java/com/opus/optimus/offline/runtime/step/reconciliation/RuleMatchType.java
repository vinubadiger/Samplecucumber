package com.opus.optimus.offline.runtime.step.reconciliation;

public enum RuleMatchType {
    ONE_TO_ONE,
    ONE_TO_N,
    N_TO_ONE,
    N_TO_N
}
