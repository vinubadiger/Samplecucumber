package com.opus.optimus.offline.runtime.step.reconciliation.match;

public interface ToleranceConstants {
	String TOLERANCE_MATCH_ERR = "toleranceMatchingErrorKey";
}
