package com.opus.optimus.offline.runtime.step.reconciliation;

import java.util.Map;

import com.opus.optimus.offline.runtime.script.impl.ScriptCreatorFactory;
import com.opus.optimus.offline.runtime.step.reconciliation.match.IToleranceValue;

public class BeanHelper {
    static private ScriptCreatorFactory scriptCreatorFactory;
    private static Map<String, IToleranceValue> toleranceValueCalculator;

    public static ScriptCreatorFactory getScriptCreatorFactory() {
        return scriptCreatorFactory;
    }

    public static void setScriptCreatorFactory(ScriptCreatorFactory scriptCreatorFactory) {
        BeanHelper.scriptCreatorFactory = scriptCreatorFactory;
    }

	public static Map<String, IToleranceValue> getToleranceValueCalculator() {
		return toleranceValueCalculator;
	}

	public static void setToleranceValueCalculator(Map<String, IToleranceValue> toleranceValueCalculator) {
		BeanHelper.toleranceValueCalculator = toleranceValueCalculator;
	}
}
