package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.queue.api.IEmitter;
import com.opus.optimus.offline.runtime.workflow.api.IMessage;
import com.opus.optimus.offline.runtime.workflow.api.impl.AbstractStep;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

@Component(UnWrapReconciliationMatchedResultConfig.STEP_TYPE)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class UnWrapReconciliationMatchedResultStep extends AbstractStep<UnWrapReconciliationMatchedResultConfig> {
    public UnWrapReconciliationMatchedResultStep(UnWrapReconciliationMatchedResultConfig config) {
        super(config);
    }

    @Override
    public void process(IMessage message, IEmitter emitter) {
        ReconciliationMatchResult<IMessage> results = (ReconciliationMatchResult<IMessage>) message.getData();
        for (List<IMessage> sourceMessages : results.getSelectedRecords().values()) {
            for (IMessage sourceMessage : sourceMessages) {
                emitter.emit(sourceMessage);
            }
        }
    }
}
