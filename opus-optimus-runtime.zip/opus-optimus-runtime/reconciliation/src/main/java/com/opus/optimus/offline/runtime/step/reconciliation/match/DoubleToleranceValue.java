package com.opus.optimus.offline.runtime.step.reconciliation.match;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

@Component("java.lang.Double")
public class DoubleToleranceValue implements IToleranceValue<BigDecimal, BigDecimal> {
	private static final BigDecimal BIG_HUNDRED = new BigDecimal("100");
	
	@Override
	public BigDecimal calculateAbsoluteValue(BigDecimal fieldValue, BigDecimal tolerance, ToleranceType toleranceType) {
		switch (toleranceType) {
		case FLOOR:
			return fieldValue.subtract(tolerance);
		case CEILING:
			return fieldValue.add(tolerance);
		default:
			return fieldValue;
		}
	}

	@Override
	public BigDecimal calculatePercentageValue(BigDecimal fieldValue, BigDecimal tolerance,
			ToleranceType toleranceType) {
		final BigDecimal toleranceAbsoluteValue = fieldValue.multiply(tolerance).divide(BIG_HUNDRED);
		return calculateAbsoluteValue(fieldValue, toleranceAbsoluteValue, toleranceType);
	}
}
