package com.opus.optimus.offline.runtime.step.reconciliation.match;

public interface IToleranceValue<T,K> {
	T calculateAbsoluteValue(T fieldValue, K tolerance, ToleranceType toleranceType);
	T calculatePercentageValue(T fieldValue, K tolerance, ToleranceType toleranceType);
}
