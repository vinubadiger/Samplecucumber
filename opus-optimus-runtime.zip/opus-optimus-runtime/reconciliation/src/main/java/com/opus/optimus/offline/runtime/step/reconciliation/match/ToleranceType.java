package com.opus.optimus.offline.runtime.step.reconciliation.match;

public enum ToleranceType {
	FLOOR, CEILING;
}
