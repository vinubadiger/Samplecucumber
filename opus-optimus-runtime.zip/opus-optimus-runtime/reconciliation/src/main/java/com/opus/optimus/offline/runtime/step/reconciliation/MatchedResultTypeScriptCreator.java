package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.script.api.IScript;
import com.opus.optimus.offline.runtime.script.api.IScriptConfig;
import com.opus.optimus.offline.runtime.script.api.IScriptCreator;
import org.springframework.stereotype.Component;

@Component(MatchedResultTypeScriptConfig.TYPE)
public class MatchedResultTypeScriptCreator implements IScriptCreator {

    @Override
    public IScript create(IScriptConfig config) {
        return new MatchedResultTypeScript(((MatchedResultTypeScriptConfig) config).getMatchedResultTypes());
    }
}
