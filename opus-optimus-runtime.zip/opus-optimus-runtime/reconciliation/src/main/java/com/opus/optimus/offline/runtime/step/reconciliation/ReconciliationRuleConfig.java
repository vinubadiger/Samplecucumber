package com.opus.optimus.offline.runtime.step.reconciliation;

import com.opus.optimus.offline.runtime.workflow.api.ICustomizableInBoundQueueSupport;
import com.opus.optimus.offline.runtime.workflow.api.ICustomizableTaskCreatorSupport;
import com.opus.optimus.offline.runtime.workflow.api.IPartitionKeyProvider;
import com.opus.optimus.offline.runtime.workflow.api.IStepConfig;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Builder
@Data
public class ReconciliationRuleConfig<T> implements IStepConfig, ICustomizableInBoundQueueSupport,
        ICustomizableTaskCreatorSupport, IPartitionKeyProvider {
    public final static String STEP_TYPE = "ReconciliationRule";

    String stepName;

    @Builder.Default
    String stepType = STEP_TYPE;

    String ruleGroupName;
    List<String> sourceNames;
    IKeyIdentifier keyIdentifier;
    RuleMatchType ruleMatchType;
    List<ReconciliationRule<T>> rules;

    @Override
    public String getQueueCreatorName() {
        return "partitionBased";    // TODO avoid string usage directly
    }

    @Override
    public String getStepTaskCreatorName() {
        return "partition";         // TODO avoid string usage directly
    }

    @Override
    public <I extends Serializable, R extends Serializable> R getPartitionKey(I message) {
        return null;
    }

	@Override
	public boolean validate() {
		return true;
	}

}
