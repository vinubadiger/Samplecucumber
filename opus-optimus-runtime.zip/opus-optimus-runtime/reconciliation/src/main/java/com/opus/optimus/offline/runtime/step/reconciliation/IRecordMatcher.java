package com.opus.optimus.offline.runtime.step.reconciliation;

import java.util.List;

public interface IRecordMatcher<T> {
    String TOLERANCE_AMOUNT_VALUE = "toleranceAmt";
    String TOLERANCE_DATE_VALUE = "toleranceDays";
    String CONFIGURED_TOLERANCE_VALUE = "configuredTolerance";

    RecordMatcherResult check(List<T> lhs, List<T> rhs);
}
