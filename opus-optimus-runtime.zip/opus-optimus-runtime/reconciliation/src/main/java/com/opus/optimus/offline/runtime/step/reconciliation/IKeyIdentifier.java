package com.opus.optimus.offline.runtime.step.reconciliation;

@FunctionalInterface
public interface IKeyIdentifier<T> {
    String getKey(T data);
}
