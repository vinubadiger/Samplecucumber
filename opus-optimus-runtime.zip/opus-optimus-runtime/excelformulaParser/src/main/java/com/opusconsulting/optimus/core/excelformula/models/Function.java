package com.opusconsulting.optimus.core.excelformula.models;

import java.util.List;

public class Function extends Expression {
	private List<Expression> params;
	private String name;

	public Function() {
		super.setType(ExpressionType.Function);
	}
	
	public List<Expression> getParams() {
		return params;
	}
	public void setParams(List<Expression> params) {
		this.params = params;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
