package com.opusconsulting.optimus.core.excelgrammer.parser;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;

//import me.tomassetti.pythonast.parser.Python3Lexer;
//import me.tomassetti.pythonast.parser.Python3Parser;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;

import com.opusconsulting.optimus.core.excelformula.models.Model;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaLexer;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser;
import com.opusconsulting.optimus.core.excelgrammer.antlr4.parser.ExcelFormulaParser.ModelContext;
import com.opusconsulting.optimus.core.excelgrammer.visitor.VisitorImpl;

public class ParserFacade {

	private boolean hasSyntaxError = false;
	
	private void setSyntaxError() {
		hasSyntaxError = true;
	}
	private void reset() {
		hasSyntaxError = false;
	}
	
	public boolean hasSyntaxErrors() {
		return hasSyntaxError;
	}

	
    public Model parse(File file, Charset encoding) throws IOException {    	
        byte[] encoded = Files.readAllBytes(file.toPath());
        return parse(new String(encoded, encoding));    	
    }
    
    public Model parse(String testInput) throws IOException {
    	reset();
    	
        String code = testInput;
        ExcelFormulaLexer lexer = new ExcelFormulaLexer(new ANTLRInputStream(code));
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        
        ExcelFormulaParser parser = new ExcelFormulaParser(tokens);        
        ModelContext mdlCtx = parser.model();
        
        int noOfErrors = parser.getNumberOfSyntaxErrors();
        if (noOfErrors > 0) {
        	setSyntaxError();
        }
        System.out.println("Syntax errors - " + noOfErrors);
        
        VisitorImpl visitor = new VisitorImpl();
        Model mdl = visitor.visit(mdlCtx);

        return mdl;
    }    
}
