package com.opusconsulting.optimus.core.excelformula.models;

public class Variable extends Expression {
		private String name;

		public Variable() {
			super.setType(ExpressionType.Variable);
		}
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}				
}
