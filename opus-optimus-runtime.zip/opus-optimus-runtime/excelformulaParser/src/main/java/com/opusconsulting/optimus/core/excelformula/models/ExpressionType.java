package com.opusconsulting.optimus.core.excelformula.models;

public enum ExpressionType {
	Function, Constant, Variable;
}
