package com.opusconsulting.optimus.core.excelgrammer.parser

import spock.lang.Specification
import spock.lang.Unroll
import spock.lang.Shared

import com.opusconsulting.optimus.core.excelformula.models.ExpressionType
import com.opusconsulting.optimus.core.excelformula.models.NumberConstant
import com.opusconsulting.optimus.core.excelformula.models.StringConstant
import com.opusconsulting.optimus.core.excelformula.models.Function

/**
 * @author Ramkumar S
 */
class ParserFacadeSpec extends Specification {

    def parserFacade = new ParserFacade();
    
    @Shared
    def eVariable = ExpressionType.Variable;
    @Shared
    def eConstant = ExpressionType.Constant;
    @Shared
    def eFunction = ExpressionType.Function;

    def 'Variable Test'(String input) {
        given: "A variable string"
        	def variableEnum = ExpressionType.Variable

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be variable"
        	def expType = model.getExpression().getType()
        	def varName = model.getExpression().getName()
        	!parserFacade.hasSyntaxErrors() && varName == input && expType == variableEnum
        	
		where:
		     input     | _
		     "DE"      | _
		     "DE01"    | _
		     "_DE"     | _
		     "_DE12"   | _
		     "_12"     | _
		     "_1DE"    | _
    }

	@Unroll
    def 'Number Test for #input'(String input) {
        given: "A number constant"
        	def constantEnum = ExpressionType.Constant

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be number"
        	def exp = model.getExpression()
        	def expType = exp.getType()
        	def text = exp.getText()
        	
        	!parserFacade.hasSyntaxErrors() && 
        	text == input && expType == constantEnum && exp instanceof NumberConstant
        	
		where:
		     input     | _
		     "123"      | _
		     "1230"      | _
		     "00"    | _
		     "0"     | _
		     "0123"    | _
    }

	@Unroll
    def 'Number with fraction Test for #input'(String input) {
        given: "A number constant"
        	def constantEnum = ExpressionType.Constant

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be number"
        	def exp = model.getExpression()
        	def expType = exp.getType()
        	def text = exp.getInteger() + "." + exp.getFraction()
        	
        	!parserFacade.hasSyntaxErrors() && 
        	text == input && expType == constantEnum && exp instanceof NumberConstant
        	
		where:
		     input     | _
		     "0123.00"    | _
		     "0123.11"    | _
		     "0.012"     | _
		     "0.12"   | _
		     "0.120"     | _
    }

	@Unroll
    def 'Negative Number Test for #input'(String input) {
        given: "An invalid number constant"
        	def constantEnum = ExpressionType.Constant

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be number"
        	def exp = model.getExpression()
        	
        	parserFacade.hasSyntaxErrors() == true || !(exp instanceof NumberConstant) 
        	
		where:
		     input     | _
		     "123.."   | _
		     "..12"    | _
		     ".2.0"    | _
		     "0123A"   | _
		     "0123.A"  | _
		     "A123"    | _
    }
    
	@Unroll
    def 'String Test for #input'(String input) {
        given: "A String constant"
        	def constantEnum = ExpressionType.Constant

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be String"
        	def exp = model.getExpression()
        	def expType = exp.getType()
        	def text = exp.getValue()
        	
        	!parserFacade.hasSyntaxErrors() && 
        	text == input && expType == constantEnum && exp instanceof StringConstant
        	
		where:
		     input     | _
		     "\"123\""      | _
		     "\"00\""    | _
		     "\"0\""     | _
		     "\"0.12\""   | _
		     "\"0.120\""     | _
		     "\"AAA\""    | _
		     "\"DE01\""    | _
		     "\"IF\""    | _
		     "\"_A123\""    | _
		     "\"_1A123\""    | _
		     "\" Hello World\""    | _
		     "\"Hello World\""    | _
		     "\"Hello World \""    | _
		     "\"Test's\""    | _
    }

	@Unroll
    def 'NoArgs Function Test for #input'(String input, String name, int paramSize) {
        given: "A Function expression"
        	def functionEnum = ExpressionType.Function

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be function"
        	def exp = model.getExpression()
        	def expType = exp.getType()
        	def params = exp.getParams()
        	def funcName = exp.getName()
        	
        	!parserFacade.hasSyntaxErrors() && 
        	funcName == name && expType == functionEnum && exp instanceof Function && params.size() == paramSize
        	
		where:
		     input     		| name   | paramSize
		     "FUNC()"       | "FUNC" | 0
		     "_FUNC()"      | "_FUNC" | 0
		     "_FUNC1()"      | "_FUNC1" | 0
	}

	@Unroll
    def 'Simple Argument Function Test for #input'(String input, String name, int paramSize) {
        given: "A Function expression"
        	def functionEnum = ExpressionType.Function

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be function"
        	def exp = model.getExpression()
        	def expType = exp.getType()
        	def params = exp.getParams()
        	def funcName = exp.getName()
        	
        	!parserFacade.hasSyntaxErrors() && 
        	funcName == name && expType == functionEnum && exp instanceof Function && params.size() == paramSize
        	
		where:
		     input     					| name    | paramSize
		     "_FUNC(DE1)"      			| "_FUNC" | 1
		     "_FUNC(_1DE1)"      		| "_FUNC" | 1
		     "_FUNC(\"DE1\")"      		| "_FUNC" | 1
		     "_FUNC(\"DE 10\")"    		| "_FUNC" | 1
		     "_FUNC(\"02.50\")"      	| "_FUNC" | 1
		     "_FUNC(02.50)"      		| "_FUNC" | 1
		     "_FUNC(25)"      			| "_FUNC" | 1
		     "_FUNC(DE1, DE2)"      	| "_FUNC" | 2
		     "_FUNC(DE1, DE2, \"AA\")"  | "_FUNC" | 3
		     "_FUNC(DE1, \"123\", \"AA\")"  | "_FUNC" | 3
		     "_FUNC(12, \"123\", \"AA\")"   | "_FUNC" | 3
	}

	@Unroll
    def 'Simple ArgumentType Function Test for #input'(String input, String name, int paramSize, ExpressionType paramType1, ExpressionType paramType2, ExpressionType paramType3) {
        given: "A Function expression"
        	def functionEnum = ExpressionType.Function

		when:
			def model = parserFacade.parse(input);
		
        then: "Instance should be function"
        	def exp = model.getExpression()
        	def expType = exp.getType()
        	def params = exp.getParams()
        	def funcName = exp.getName()
        	
        	def retValue = false;
        	if(!parserFacade.hasSyntaxErrors()) {
        		if (paramSize == 1) {
        			def pType1 = params.get(0).getType();
        			
        			retValue = (funcName == name && expType == functionEnum && 
        			exp instanceof Function && params.size() == paramSize &&
        			pType1 == paramType1);			
        		} else if (paramSize == 2) {
        			def pType1 = params.get(0).getType();
        			def pType2 = params.get(1).getType();
        			
					retValue = (funcName == name && expType == functionEnum && 
        			exp instanceof Function && params.size() == paramSize &&
        			pType1 == paramType1 && pType2 == paramType2);			
        		} else {
        			def pType1 = params.get(0).getType();
        			def pType2 = params.get(1).getType();
        			def pType3 = params.get(2).getType();
        			
					retValue = (funcName == name && expType == functionEnum && 
        			exp instanceof Function && params.size() == paramSize &&
        			pType1 == paramType1 && pType2 == paramType2 && pType3 == paramType3);			
        		}
        	} else {
        		retValue = !parserFacade.hasSyntaxErrors();
        	}
        	
        	retValue == true;
		where:
		     input     					| name    | paramSize    | paramType1  | paramType2  | paramType3
		     "_FUNC(DE1)"      			| "_FUNC" | 1			 | eVariable   | eVariable   | eVariable 
		     "_FUNC(_1DE1)"      		| "_FUNC" | 1            | eVariable   | eVariable   | eVariable
		     "_FUNC(\"DE1\")"      		| "_FUNC" | 1			 | eConstant   | eVariable   | eVariable
		     "_FUNC(\"DE 10\")"    		| "_FUNC" | 1			 | eConstant   | eVariable   | eVariable
		     "_FUNC(\"02.50\")"      	| "_FUNC" | 1            | eConstant   | eVariable   | eVariable
		     "_FUNC(02.50)"      		| "_FUNC" | 1            | eConstant   | eVariable   | eVariable
		     "_FUNC(25)"      			| "_FUNC" | 1            | eConstant   | eVariable   | eVariable
		     "_FUNC(DE1, DE2)"      	| "_FUNC" | 2            | eVariable   | eVariable   | eVariable
		     "_FUNC(DE1, DE2, \"AA\")"  | "_FUNC" | 3            | eVariable   | eVariable   | eConstant
		     "_FUNC(DE1, \"123\", \"AA\")"  | "_FUNC" | 3        | eVariable   | eConstant   | eConstant
		     "_FUNC(12, \"123\", \"AA\")"   | "_FUNC" | 3        | eConstant   | eConstant   | eConstant
		     "_FUNC(12, \"123\", DE)"       | "_FUNC" | 3        | eConstant   | eConstant   | eVariable
	}
}